package monopoly;

import java.util.Scanner;
//implementacion normal da consola que usa system.out e scanner

public class ConsolaNormal implements Consola {

    // Usamos un só Scanner para todo o programa.
    private Scanner sc;

    // Inicializa o Scanner unha única vez.

    public ConsolaNormal() {
        this.sc = new Scanner(System.in);
    }

    //Implementación de imprimir usando System.out.println.

    @Override
    public void imprimir(String mensaxe) {
        System.out.println(mensaxe);
    }

    /**
     * Implementación de ler:
     * - imprime a descripción (sen salto de liña)
     * - le o que escriba o usuario ata pulsar Enter
     * - devolve esa cadea
     */
    @Override
    public String ler(String descripcion) {
        // Poñemos a descripción como "prompt"
        System.out.print(descripcion);
        // Devolvemos a liña que escriba o usuario
        return sc.nextLine();
    }
}
