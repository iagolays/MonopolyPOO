package monopoly;

import partida.*;   // Importamos Jugador, Avatar, Dado
import java.util.*; // Importamos ArrayList, HashMap, etc.
import java.io.*;   // Para ler ficheiros máis adiante
import monopoly.Exceptions.*; // Importamos as excepcións personalizadas

// A clase Juego é o corazón do Monopoly ETSE (Requisito 25).
// Implementa todo o que antes estaba en Menu e ademais implementa Comando.
public abstract class Juego implements Comando {

    // Usamos unha consola estática para poder imprimir/ler desde calquera clase (Requisito 31)
    public static final Consola consola = new ConsolaNormal();


    // ================================
    // ATRIBUTOS PRINCIPAIS DO XOGO
    // ================================

    // Lista de xogadores na partida
    private ArrayList<Jugador> jugadores;

    // Lista de avatares creados (para evitar repeticións)
    private ArrayList<Avatar> avatares;

    // O taboleiro do Monopoly
    private Tablero tablero;

    // O xogador especial "Banca"
    private Jugador banca;

    // Os dous dados do xogo
    private Dado dado1;
    private Dado dado2;

    // Control do turno: número do xogador actual
    private int turno;

    // Indica se o xogador xa tirou os dados neste turno
    private boolean tirado;

    // Indica se o xogador é solvente (pagou o que debe)
    private boolean solvente;

    // Xestor das cartas de Sorte e Comunidade
    private CartasSuerte cartasSuerte;

    // Mapa de tratos pendentes → (ID, Trato)
    private HashMap<Integer, Trato> tratosPendentes;

    // O seguinte ID que se asignará a un trato
    private int siguienteIdTrato;


    // =====================================
    // CONSTRUCTOR DO XOGO (Requisito 25)
    // =====================================
    public Juego() {

        // Creamos as listas baleiras de xogadores e avatares
        jugadores = new ArrayList<>();
        avatares = new ArrayList<>();

        // A banca é un xogador especial sen avatar
        banca = new Jugador();

        // Creamos o taboleiro asociado á banca
        tablero = new Tablero(banca);

        // Creamos os dous dados
        dado1 = new Dado();
        dado2 = new Dado();

        // Comeza no xogador 0 (aínda non hai xogadores creados)
        turno = 0;

        // Aínda non se tiraron os dados
        tirado = false;

        // Supoñemos que comeza solvente
        solvente = true;

        // Creamos o xestor de cartas
        cartasSuerte = new CartasSuerte();

        // Inicializamos o sistema de tratos
        tratosPendentes = new HashMap<>();
        siguienteIdTrato = 1;

        // Mensaxe de inicio usando ConsolaNormal (non System.out)
        consola.imprimir("Xogo inicializado correctamente.");
        consola.imprimir("Use 'crear jugador <nome> <avatar>' para iniciar.");
    }


    // ==============================================
    // DEVOLVE O XOGADOR QUE TEN O TURNO
    // ==============================================
    public Jugador getJugadorActual() {
        // Simplemente devolvemos o xogador na posición "turno"
        return jugadores.get(turno);
    }


    // ======================================================
    // DEVOLVE TRUE SE HAI POLO MENOS UN XOGADOR
    // ======================================================
    public boolean haiXogadores() {
        return !jugadores.isEmpty();
    }


    // ==============================================
    // CAMBIA O TURNO AO SEGUINTE XOGADOR
    // ==============================================
    private void avanzarTurno() {

        // Pasamos ao seguinte xogador → (turno + 1) modulo tamaño da lista
        turno = (turno + 1) % jugadores.size();

        // Reseteamos o estado do novo turno
        tirado = false;
        solvente = true;

        // Obtemos o xogador actual despois de avanzar o turno
        Jugador j = getJugadorActual();

        // Notificamos o cambio de turno
        consola.imprimir("É o turno de: " + j.getNombre());
        consola.imprimir("Estado actual: " + j);
    }


    // =====================================================================
    // VERIFICA QUE HAXA AO MENOS 2 XOGADORES PARA COMEZA-LA PARTIDA
    // =====================================================================
    private void verificarMinimoXogadores() throws ComandoInvalidoException {

        // Se hai menos de dous xogadores, non podemos lanzar os dados
        if (jugadores.size() < 2) {
            throw new ComandoInvalidoException(
                    "Precísanse polo menos 2 xogadores para comezar a partida.");
        }
    }

    // ==============================================================
    // MÉTODO PRINCIPAL QUE PROCESA UN COMANDO ESCRITO POLO USUARIO
    // Equivalente a analizarComando() que tiñas en Menu
    // ==============================================================
    @Override
    public void procesarComando(String linea) throws MonopolyException {

        // Eliminamos espazos ao principio e final
        linea = linea.trim();

        // Se a liña está baleira, non facemos nada
        if (linea.isEmpty()) {
            return;
        }

        // Separamos a liña en palabras usando espazos como separador
        // "\\s+" significa: un ou máis espazos en branco (espazo, tab, etc.)
        String[] partes = linea.split("\\s+");

        // A primeira palabra é o comando principal (crear, lanzar, listar, etc.)
        String comando = partes[0].toLowerCase();

        // Se xa hai xogadores, comprobamos se o xogador actual ten débedas
        if (!jugadores.isEmpty()) {
            Jugador actual = getJugadorActual();
            if (actual.getFortuna() < 0 && !actual.isEnBancarrota()) {
                consola.imprimir(actual.getNombre() +
                        " aínda ten débedas pendentes (" +
                        (int) Math.abs(actual.getFortuna()) + "€).");
                consola.imprimir("Use 'hipotecar <casilla>' ou 'acabar turno' para resolver.");
            }
        }

        // Usamos un switch co comando principal
        switch (comando) {

            case "crear":
                // Formato esperado: crear jugador <nome> <tipoAvatar>
                if (partes.length >= 4 && partes[1].equalsIgnoreCase("jugador")) {
                    // Chamamos ao método que crea o xogador
                    crearXogador(partes[2], partes[3]);
                } else {
                    // Se o formato é incorrecto, lanzamos unha excepción de comando inválido
                    throw new ComandoInvalidoException("Uso correcto: crear jugador <nome> <avatar>");
                }
                break;

            case "jugador":
                // Comando: jugador  → mostra info do xogador actual
                mostrarXogadorActual();
                break;

            case "listar":
                // Reenviamos o array de partes ao método que se encarga de listar
                comandoListar(partes);
                break;

            case "lanzar":
                // Formato: lanzar dados [2+3]
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("dados")) {
                    if (partes.length == 3) {
                        // Tirada forzada tipo "2+3"
                        lanzarDadosForzados(partes[2]);
                    } else {
                        // Tirada normal (aleatoria)
                        lanzarDados();
                    }
                } else {
                    throw new ComandoInvalidoException("Uso correcto: lanzar dados [a+b]");
                }
                break;

            case "describir":
                // Pode ser: describir jugador <nome> OU describir <casilla>
                if (partes.length >= 3 && partes[1].equalsIgnoreCase("jugador")) {
                    describirJugador(partes[2]);
                } else if (partes.length >= 2) {
                    describirCasilla(partes[1]);
                } else {
                    throw new ComandoInvalidoException(
                            "Uso correcto: describir jugador <nome> OU describir <casilla>");
                }
                break;

            case "comprar":
                // Formato: comprar <nomeCasilla>
                if (partes.length >= 2) {
                    comprarCasilla(partes[1]);
                } else {
                    throw new ComandoInvalidoException("Uso correcto: comprar <nomeCasilla>");
                }
                break;

            case "salir":
                // Formato: salir carcel
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("carcel")) {
                    salirCarcel();
                } else {
                    throw new ComandoInvalidoException("Uso correcto: salir carcel");
                }
                break;

            case "acabar":
                // Formato: acabar turno
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("turno")) {
                    acabarTurno();
                } else {
                    throw new ComandoInvalidoException("Uso correcto: acabar turno");
                }
                break;

            case "ver":
                // Formato: ver tablero
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("tablero")) {
                    // Mostramos o taboleiro completo
                    consola.imprimir(tablero.toString());
                } else {
                    throw new ComandoInvalidoException("Uso correcto: ver tablero");
                }
                break;

            case "edificar":
                // A lóxica completa faremos en Parte 4 (edificios)
                comandoEdificar(partes);
                break;

            case "hipotecar":
                // Parte 4 tamén, pero deixamos chamada
                hipotecar(partes);
                break;

            case "deshipotecar":
                deshipotecar(partes);
                break;

            case "vender":
                comandoVender(partes);
                break;

            case "estadisticas":
                // Pode ser: estadisticas OU estadisticas <xogador>
                if (partes.length == 1) {
                    mostrarEstadisticasXogo();
                } else {
                    mostrarEstadisticasJugador(partes[1]);
                }
                break;

            case "comandos":
                // Formato: comandos <ficheiro>
                if (partes.length >= 2) {
                    lerComandosFicheiro(partes[1]);
                } else {
                    throw new ComandoInvalidoException("Uso correcto: comandos <ficheiro>");
                }
                break;

            // Na clase Juego non tratamos "salir" xeral → iso farao o main
            default:
                // Se o comando non se recoñece, lanzamos ComandoInvalidoException
                throw new ComandoInvalidoException("Comando non recoñecido: " + linea);
        }
    }


    // ==============================================================
    // CREA UN NOVO XOGADOR CO SEU AVATAR (antes crearJugador en Menu)
    // ==============================================================
    @Override
    public void crearXogador(String nombre, String tipoAvatar) throws MonopolyException {

        // Comprobamos que non se superou o máximo de xogadores (4)
        if (jugadores.size() >= 4) {
            throw new ComandoInvalidoException("Xa hai 4 xogadores, non se poden engadir máis.");
        }

        // Comprobamos que o nome non estea xa en uso
        for (Jugador j : jugadores) {
            if (j.getNombre().equalsIgnoreCase(nombre)) {
                throw new ComandoInvalidoException("Xa existe un xogador con ese nome.");
            }
        }

        // Lista de tipos de avatar válidos
        String[] tiposValidos = {"Coche", "Esfinge", "Sombrero", "Pelota"};
        boolean tipoValido = false;

        // Comprobamos se o tipoAvatar está na lista de válidos
        for (String t : tiposValidos) {
            if (t.equalsIgnoreCase(tipoAvatar)) {
                tipoValido = true;
                break;
            }
        }

        // Se o tipo non é válido, lanzamos excepción
        if (!tipoValido) {
            throw new ComandoInvalidoException(
                    "Tipo de avatar non válido. Use: Coche, Esfinge, Sombrero ou Pelota.");
        }

        // Comprobamos que ese tipo de avatar non estea xa collido por outro xogador
        for (Avatar av : avatares) {
            if (av.getTipo().equalsIgnoreCase(tipoAvatar)) {
                throw new ComandoInvalidoException(
                        "O tipo de avatar '" + tipoAvatar + "' xa está en uso por outro xogador.");
            }
        }

        // Buscamos a casilla de "Salida" no taboleiro, onde comezan os xogadores
        Casilla salida = tablero.encontrar_casilla("Salida");
        if (salida == null) {
            throw new MonopolyException("Erro interno: non se atopou a casilla 'Salida'.");
        }

        // Creamos o novo xogador co nome, tipo de avatar, casilla de saída e lista de avatares
        Jugador novo = new Jugador(nombre, tipoAvatar, salida, avatares);

        // Engadimos o xogador á lista de xogadores
        jugadores.add(novo);

        // Engadimos o avatar á lista de avatares
        avatares.add(novo.getAvatar());

        // Mostramos a información do xogador creado, co formato que ti xa tiñas
        consola.imprimir("{");
        consola.imprimir("nome: " + novo.getNombre() + ",");
        consola.imprimir("avatar: " + novo.getAvatar().getId());
        consola.imprimir("}");

        // Mostramos o taboleiro para ver a súa posición inicial
        consola.imprimir(tablero.toString());
    }


    // ===============================================================
    // MOSTRA INFORMACIÓN DO XOGADOR QUE TEN O TURNO
    // ===============================================================
    @Override
    public void mostrarXogadorActual() throws MonopolyException {

        // Se non hai xogadores, non podemos mostrar nada
        if (jugadores.isEmpty()) {
            throw new ComandoInvalidoException("Non hai xogadores na partida.");
        }

        // Obtemos o xogador na posición "turno"
        Jugador actual = getJugadorActual();

        // Imprimimos quen ten o turno e o seu estado actual
        consola.imprimir("É o turno de: " + actual.getNombre() + ".");
        consola.imprimir("Estado actual: " + actual.toString());
    }


    // ===============================================================
    // DESCRIBE UN XOGADOR BUSCANDO POR NOME (antes descJugador)
    // ===============================================================
    @Override
    public void describirJugador(String nombreBuscar) throws MonopolyException {

        // Inicializamos unha referencia a null. Se atopamos o xogador, gardámolo aquí.
        Jugador encontrado = null;

        // Percorremos a lista de xogadores
        for (Jugador j : jugadores) {
            // Comparación sen distinguir maiúsculas/minúsculas
            if (j.getNombre().equalsIgnoreCase(nombreBuscar)) {
                encontrado = j;
                break;
            }
        }

        // Se non atopamos ningún, lanzamos unha excepción
        if (encontrado == null) {
            throw new ComandoInvalidoException("Non existe ningún xogador con ese nome.");
        }

        // Se o atopamos, mostramos a súa información detallada
        consola.imprimir(encontrado.infoJugador());
    }


    // ===============================================================
    // DESCRIBE UNHA CASILLA POR NOME (antes descCasilla)
    // ===============================================================
    @Override
    public void describirCasilla(String nombre) throws MonopolyException {

        // Buscamos a casilla no taboleiro polo seu nome
        Casilla c = tablero.encontrar_casilla(nombre);

        // Se non se atopa, lanzamos unha excepción
        if (c == null) {
            throw new ComandoInvalidoException("Non se atopou a casilla: " + nombre);
        }

        // Se a atopamos, chamamos ao método infoCasilla() que xa tiñas implementado
        consola.imprimir(c.infoCasilla());
    }


    // ===============================================================
    // PROCESA O COMANDO "listar ..." (antes comandoListar)
    // ===============================================================
    @Override
    public void comandoListar(String[] partes) throws MonopolyException {

        // Se só pon "listar" sen nada máis, o formato é incorrecto
        if (partes.length < 2) {
            throw new ComandoInvalidoException(
                    "Uso correcto: listar jugadores|edificios|enventa");
        }

        // Miramos que quere listar: jugadores, edificios ou enventa
        String subcomando = partes[1].toLowerCase();

        switch (subcomando) {

            case "jugadores":
                // Lógica para listar xogadores farémola nun método separado
                listarJugadores();
                break;

            case "edificios":
                // Se só poñen "listar edificios", listamos todos
                if (partes.length == 2) {
                    listarTodosEdificios();
                } else {
                    // Se poñen "listar edificios <colorGrupo>", reconstruímos o nome do grupo
                    StringBuilder colorGrupoBuilder = new StringBuilder();
                    for (int i = 2; i < partes.length; i++) {
                        if (i > 2) {
                            colorGrupoBuilder.append(" "); // engadimos espazo entre palabras
                        }
                        colorGrupoBuilder.append(partes[i]);
                    }
                    String colorGrupo = colorGrupoBuilder.toString();
                    listarEdificiosGrupo(colorGrupo);
                }
                break;

            case "enventa":
                // Listamos propiedades en venda
                listarVenta();
                break;

            default:
                // Se poñen algo que non recoñecemos, lanzamos excepción
                throw new ComandoInvalidoException(
                        "Subcomando listar non recoñecido: " + subcomando);
        }
    }


    // ===============================================================
    // LISTA TODOS OS XOGADORES DA PARTIDA
    // ===============================================================
    private void listarJugadores() throws MonopolyException {

        // Se non hai xogadores, lanzamos excepción
        if (jugadores.isEmpty()) {
            throw new ComandoInvalidoException("Non hai xogadores na partida.");
        }

        // Percorremos todos os xogadores e imprimimos a súa info
        for (Jugador j : jugadores) {
            consola.imprimir(j.infoJugador());
        }
    }


    // ===============================================================
    // LISTA TODAS AS PROPIEDADES EN VENDA (antes listarVenta)
    // ===============================================================
    private void listarVenta() {

        // Usamos unha bandeira para saber se atopamos algunha en venda
        boolean hayPropiedades = false;

        // O taboleiro ten 4 lados, iteramos por cada lado
        for (int lado = 0; lado < 4; lado++) {

            // Obtemos a lista de casillas dese lado
            ArrayList<Casilla> casillasLado = tablero.getLado(lado);

            // Recorremos cada casilla do lado
            for (Casilla casilla : casillasLado) {

                // casEnVenta() devolve unha cadea co info se está en venda, ou "" se non
                String infoVenta = casilla.casEnVenta();

                // Se non é unha cadea baleira, imprimimos a info
                if (!infoVenta.isEmpty()) {
                    consola.imprimir(infoVenta);
                    hayPropiedades = true;
                }
            }
        }

        // Se non atopamos ningunha, avisamos
        if (!hayPropiedades) {
            consola.imprimir("Non hai propiedades en venda.");
        }
    }


    // ===============================================================
    // LISTA TODOS OS EDIFICIOS DE TODOS OS XOGADORES
    // (versión baseada na que tiñas en Menu)
    // ===============================================================
    private void listarTodosEdificios() {

        // Bandeira para saber se atopamos algún edificio
        boolean hayEdificios = false;

        // Recorremos cada xogador
        for (Jugador j : jugadores) {

            // Os edificios están gardados como IDs únicos (ex: "casa-1")
            for (String idEdificio : j.getEdificios()) {

                // Separamos tipo e número (por exemplo "casa-3")
                String[] partes = idEdificio.split("-");

                if (partes.length >= 2) {

                    String tipo = partes[0]; // casa, hotel, piscina, pista

                    Casilla casillaEdificio = null;

                    // Buscamos a casilla á que pertence este edificio
                    for (Casilla propiedad : j.getPropiedades()) {

                        // Só ten sentido mirar en solares
                        if ("solar".equalsIgnoreCase(propiedad.getTipo())) {

                            // Obtemos os datos de edificios para esa casilla
                            Solares.DatosEdificios edificios = propiedad.getDatosedificios();
                            if (edificios != null) {
                                boolean tenEsteTipo = false;

                                switch (tipo.toLowerCase()) {
                                    case "casa":
                                        tenEsteTipo = edificios.getNumCasas() > 0;
                                        break;
                                    case "hotel":
                                        tenEsteTipo = edificios.getNumHoteles() > 0;
                                        break;
                                    case "piscina":
                                        tenEsteTipo = edificios.getNumPiscinas() > 0;
                                        break;
                                    case "pista":
                                        tenEsteTipo = edificios.getNumPistas() > 0;
                                        break;
                                }

                                if (tenEsteTipo) {
                                    casillaEdificio = propiedad;
                                    break;
                                }
                            }
                        }
                    }

                    // Se atopamos a casilla do edificio, calculamos o custo
                    if (casillaEdificio != null) {
                        float coste = 0;

                        switch (tipo.toLowerCase()) {
                            case "casa":
                                coste = Solares.obtenerPrecioCasa(casillaEdificio.getNombre());
                                break;
                            case "hotel":
                                coste = Solares.obtenerPrecioHotel(casillaEdificio.getNombre());
                                break;
                            case "piscina":
                                coste = Solares.obtenerPrecioPiscina(casillaEdificio.getNombre());
                                break;
                            case "pista":
                                coste = Solares.obtenerPrecioPista(casillaEdificio.getNombre());
                                break;
                        }

                        // Xeramos unha cadea de info do edificio
                        String info = Solares.generarInfoEdificio(
                                idEdificio, j, casillaEdificio, coste);

                        consola.imprimir(info);
                        hayEdificios = true;
                    }
                }
            }
        }

        if (!hayEdificios) {
            consola.imprimir("Non hai edificios construídos.");
        }
    }


    // ===============================================================
    // LISTA OS EDIFICIOS DUN GRUPO (COR DE GRUPO)
    // ===============================================================
    private void listarEdificiosGrupo(String colorGrupo) {

        // Eliminamos espazos extras e pasamos a minúsculas para comparar ben
        colorGrupo = colorGrupo.trim().toLowerCase();

        // Lista de grupos atopados (para non repetir)
        ArrayList<Grupo> gruposEncontrados = new ArrayList<>();

        // Recorremos xogadores e as súas propiedades
        for (Jugador jugador : jugadores) {
            for (Casilla propiedad : jugador.getPropiedades()) {

                Grupo grupo = propiedad.getGrupo();

                // Se hai grupo e a cor coincide, e aínda non o engadimos, engadímolo
                if (grupo != null &&
                        grupo.getColorGrupo().equalsIgnoreCase(colorGrupo) &&
                        !gruposEncontrados.contains(grupo)) {

                    gruposEncontrados.add(grupo);
                }
            }
        }

        // Se non atopamos ningún grupo, avisamos
        if (gruposEncontrados.isEmpty()) {
            consola.imprimir(
                    "Non se atopou ningún edificio no grupo de cor " + colorGrupo + ".");
            return;
        }

        boolean hayEdificios = false;

        // Para cada grupo atopado, pedimos ao grupo que devolva info dos edificios
        for (Grupo grupo : gruposEncontrados) {
            String info = grupo.obtenerInfoEdificios();
            consola.imprimir(info);

            // Comprobamos de forma sinxela se hai edificios mencionados
            if (info.contains("casa-") || info.contains("hotel-") ||
                    info.contains("piscina-") || info.contains("pista-")) {
                hayEdificios = true;
            }
        }

        if (!hayEdificios) {
            consola.imprimir(
                    "Non hai casillas con edificios construídos no grupo " + colorGrupo + ".");
        }
    }


    // ===============================================================
    // LEE COMANDOS DUN FICHEIRO E VAI EXECUTANDOOS UN A UN
    // (antes lerFicheiroComandos)
    // ===============================================================
    @Override
    public void lerComandosFicheiro(String nomeFicheiro) throws MonopolyException {

        // Creamos unha referencia a un obxecto File co nome indicado
        File ficheiro = new File(nomeFicheiro);

        // Comprobamos se o ficheiro existe
        if (!ficheiro.exists()) {
            throw new ComandoInvalidoException("O ficheiro non existe: " + nomeFicheiro);
        }

        Scanner scanner = null;

        try {
            // Abrimos o ficheiro para lectura
            scanner = new Scanner(ficheiro);

            // Lemos liña a liña
            while (scanner.hasNextLine()) {
                String liña = scanner.nextLine().trim();

                // Ignoramos liñas baleiras e comentarios que comezan por "#"
                if (liña.isEmpty() || liña.startsWith("#")) {
                    continue;
                }

                // Mostramos o comando que se vai executar
                consola.imprimir("$> " + liña);

                // Procesamos o comando igual que se o escribise o usuario
                procesarComando(liña);
            }

        } catch (FileNotFoundException e) {
            // Se non se pode abrir, lanzamos unha excepción de Monopoly xenérica
            throw new MonopolyException("Non se pode abrir o ficheiro: " + e.getMessage());
        } finally {
            // Pechamos o scanner se se chegou a crear
            if (scanner != null) {
                scanner.close();
            }
        }
    }

    // ===============================================================
    // LANZA OS DADOS EN MODO NORMAL (non forzado)
    // Este método chama ao Dado para obter valores aleatorios
    // e despois delega en gestionarTirada() toda a lóxica.
    // ===============================================================
    @Override
    public void lanzarDados() throws MonopolyException {

        // Se non hai xogadores, non se pode tirar
        if (jugadores.isEmpty()) {
            throw new ComandoInvalidoException("Non hai xogadores na partida.");
        }

        // Se hai menos de 2 xogadores non se permite tirar (igual que no teu Menu)
        if (jugadores.size() < 2) {
            throw new ComandoInvalidoException("Precísanse 2 xogadores para comenzar a partida.");
        }

        Jugador actual = getJugadorActual();

        // Se está no cárcere, este método NON o trata → sairCarcel/intentarSalirCarcel fará ese traballo
        if (actual.isEnCarcel()) {
            // Non tiramos dados aquí, delegamos no método especial
            lanzarDesdeCarcel(false, 0, 0);
            return;
        }

        // Se xa tirou neste turno, non pode repetir salvo dobres
        if (tirado) {
            throw new ComandoInvalidoException("Xa tiraches nesta quenda. Usa 'acabar turno'.");
        }

        // Facemos tirada normal dos dados
        int valor1 = dado1.hacerTirada();
        int valor2 = dado2.hacerTirada();

        // Xestionamos a tirada completa
        gestionarTirada(actual, valor1, valor2);
    }


    // ===============================================================
    // LANZA OS DADOS EN MODO FORZADO (2+3)
    // O formato recibido é algo coma "2+5" e pásase ao método Dado.procesarTiradaForzada
    // ===============================================================
    @Override
    public void lanzarDadosForzados(String expresion) throws MonopolyException {

        if (jugadores.isEmpty()) {
            throw new ComandoInvalidoException("Non hai xogadores na partida.");
        }

        if (jugadores.size() < 2) {
            throw new ComandoInvalidoException("Precísanse 2 xogadores para comezar a partida.");
        }

        Jugador actual = getJugadorActual();

        // Obtemos os dous valores da expresión
        int[] vals = Dado.procesarTiradaForzada(expresion);

        if (vals == null) {
            throw new ComandoInvalidoException("Formato inválido. Use algo como 2+5");
        }

        int v1 = vals[0];
        int v2 = vals[1];

        // Se o xogador está na cárcere, só é válido se é unha saída válida
        if (actual.isEnCarcel()) {
            lanzarDesdeCarcel(true, v1, v2);
            return;
        }

        if (tirado) {
            throw new ComandoInvalidoException("Xa tiraches nesta quenda.");
        }

        // Gardamos valores nos dados (compatibilidade co teu código de Dado)
        dado1.lanzarForzado(v1);
        dado2.lanzarForzado(v2);

        gestionarTirada(actual, v1, v2);
    }


    // ===============================================================
    // XESTIONA A SITUACIÓN ESPECIAL: o xogador está no cárcere
    // Este método centraliza todo o que antes tiñas repartido en Menu.
    // ===============================================================
    private void lanzarDesdeCarcel(boolean forzado, int v1, int v2) throws MonopolyException {

        Jugador actual = getJugadorActual();

        if (!actual.isEnCarcel()) {
            throw new MonopolyException("Erro interno: o xogador non está na cárcere.");
        }

        if (tirado) {
            throw new ComandoInvalidoException("Xa fixeches un intento de saída nesta quenda.");
        }

        int resultado;

        // Se a tirada é forzada, chamamos ao método de saída indicando valores fixos
        if (forzado) {
            resultado = actual.intentarSalirCarcel(
                    dado1, dado2, tablero, true, v1, v2);
        }
        else {
            // Tirada normal. A propia intentarSalirCarcel chama a dados aleatorios
            resultado = actual.intentarSalirCarcel(
                    dado1, dado2, tablero, false, 0, 0);
        }

        // -1 → non pode pagar → bancarrota
        if (resultado == -1) {
            consola.imprimir(actual.getNombre() + " está en bancarrota.");
            tirado = true;
            xestionarBancarrota(actual);
            return;
        }

        // 0 → segue no cárcere
        if (resultado == 0) {
            consola.imprimir(actual.getNombre() + " non conseguiu saír do cárcere.");
            tirado = true;
            return;
        }

        // 1 → sae do cárcere e debe moverse cos valores dos dados
        tirado = true;

        if (forzado) {
            gestionarTirada(actual, v1, v2);
        } else {
            int valor1 = dado1.getValor();
            int valor2 = dado2.getValor();
            gestionarTirada(actual, valor1, valor2);
        }
    }


    // ===============================================================
    // XESTIONA DOBRES, MOVEMENTO, AVALIACIÓN DA CASILLA E DÉBEDAS
    // Este é o núcleo de movemento, igual que no teu Menu.
    // ===============================================================
    private void gestionarTirada(Jugador actual, int v1, int v2) throws MonopolyException {

        int total = v1 + v2;

        // Comprobamos dobres
        if (v1 == v2) {

            // Aumentamos contador de dobres consecutivos
            actual.incrementarDobles();

            // Se fixo 3 dobres seguidos → cárcere
            if (actual.getDoblesConsecutivos() == 3) {
                consola.imprimir(actual.getNombre() +
                        " sacou dobres 3 veces seguidas. Vai ao cárcere.");
                actual.encarcelar(tablero.getPosiciones(), tablero);
                actual.resetearDobles();

                tirado = true;
                acabarTurno();
                return;
            }

            // Movemento normal
            moverEProcesar(actual, total);

            consola.imprimir("¡Dobres! " + actual.getNombre() + " tira outra vez.");

            // Permitimos volver tirar
            tirado = false;

            // Non deixar tirar se quedou insolvente
            if (actual.isEnBancarrota() || actual.getFortuna() < 0) {
                tirado = true;
            }

            return;
        }

        // Non son dobres
        actual.resetearDobles();
        moverEProcesar(actual, total);

        // Turno rematado
        tirado = true;

        // Avisamos de débedas se quedaron
        if (actual.getFortuna() < 0) {
            consola.imprimir(actual.getNombre() + " ten débedas pendentes.");
        }
    }


    // ===============================================================
    // MOVE O AVATAR, AVALÍA A CASILLA, MANEXA SUERTE/COMUNIDAD
    // ===============================================================
    private void moverEProcesar(Jugador actual, int total) throws MonopolyException {

        Avatar avatar = actual.getAvatar();

        // Xuntamos todas as casillas do taboleiro
        ArrayList<ArrayList<Casilla>> todas = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            todas.add(tablero.getLado(i));
        }

        // Movemos o avatar
        avatar.moverAvatar(todas, total, tablero, true);

        // Casilla onde cae
        Casilla c = avatar.getLugar();
        String tipo = c.getTipo().toLowerCase();

        // Suerte
        if (tipo.equals("suerte")) {
            cartasSuerte.sacarCartaSuerte(actual, tablero, jugadores);

            if (actual.getFortuna() < 0 && !actual.isEnBancarrota()) {
                consola.imprimir(actual.getNombre() +
                        " ten débedas tras a carta de Suerte.");
            }
        }
        // Comunidad
        else if (tipo.equals("comunidad")) {
            cartasSuerte.sacarCartaComunidad(actual, tablero);

            if (actual.getFortuna() < 0 && !actual.isEnBancarrota()) {
                consola.imprimir(actual.getNombre() +
                        " ten débedas tras a carta de Comunidad.");
            }
        }
        else {
            // Casilla normal
            boolean solvente = c.evaluarCasilla(
                    actual, banca, total, tablero, false);

            if (actual.getFortuna() < 0 && solvente) {
                consola.imprimir(actual.getNombre() + " ten débedas pendentes.");
            }
        }

        // Mostramos taboleiro actualizado
        consola.imprimir(tablero.toString());
    }



    // ===============================================================
    // COMPRA DE PROPIEDADE: comprobar se existe, se está nela, se é comprable, etc.
    // ===============================================================
    @Override
    public void comprarCasilla(String nome) throws MonopolyException {

        if (jugadores.isEmpty()) {
            throw new ComandoInvalidoException("Non hai xogadores na partida.");
        }

        Jugador actual = getJugadorActual();
        Casilla c = tablero.encontrar_casilla(nome);

        if (c == null) {
            throw new ComandoInvalidoException("Casilla non atopada: " + nome);
        }

        // Debe estar situado na casilla
        if (!actual.getAvatar().getLugar().equals(c)) {
            throw new ComandoInvalidoException(
                    "Só podes comprar a casilla na que estás: " +
                            actual.getAvatar().getLugar().getNombre());
        }

        // Debe ser comprable
        if (!c.getTipo().equalsIgnoreCase("solar") &&
                !c.getTipo().equalsIgnoreCase("transporte") &&
                !c.getTipo().equalsIgnoreCase("servicio")) {

            throw new ComandoInvalidoException("A casilla " + nome + " non é comprable.");
        }

        // Se xa ten dono
        if (c.getDuenho() != null &&
                !c.getDuenho().getNombre().equalsIgnoreCase("Banca")) {

            throw new ComandoInvalidoException("A casilla xa ten propietario.");
        }

        c.comprarCasilla(actual, banca);
    }



    // ===============================================================
    // SÁE DO CÁRCERE: método chamado dende "salir carcel"
    // ===============================================================
    @Override
    public void salirCarcel() throws MonopolyException {

        Jugador actual = getJugadorActual();

        if (!actual.isEnCarcel()) {
            throw new ComandoInvalidoException(actual.getNombre() + " non está no cárcere.");
        }

        actual.salirCarcel(tablero);
    }



    // ===============================================================
    // REMATA O TURNO E PASA AO SEGUINTE XOGADOR
    // ===============================================================
    @Override
    public void acabarTurno() throws MonopolyException {

        if (jugadores.isEmpty()) {
            throw new ComandoInvalidoException("Non hai xogadores.");
        }

        Jugador actual = getJugadorActual();

        if (!tirado) {
            throw new ComandoInvalidoException("Non podes acabar turno sen lanzar os dados.");
        }

        // Se ten débedas, hai que procesar bancarrota
        if (actual.getFortuna() < 0 && !actual.isEnBancarrota()) {

            Jugador pagarA = detectarAQuenDebe(actual);
            actual.declararBancarrota(tablero, pagarA);
            xestionarBancarrota(actual);
            return;
        }

        // Pasamos turno
        turno = (turno + 1) % jugadores.size();
        tirado = false;

        Jugador seguinte = getJugadorActual();
        consola.imprimir("É o turno de: " + seguinte.getNombre());
        consola.imprimir("Estado: " + seguinte.toString());
    }


    // ===============================================================
    // DETERMINA A QUEN LLE DEBE PAGAR O XOGADOR EN BANCARROTA
    // ===============================================================
    private Jugador detectarAQuenDebe(Jugador deudor) {

        if (deudor.getUltimoCobraAlquiler() != null) {
            return deudor.getUltimoCobraAlquiler();
        }
        return banca;
    }


    // ===============================================================
    // UN XOGADOR QUEBRA: elimínase, repártese, e compróbase final do xogo
    // ===============================================================
    private void xestionarBancarrota(Jugador x) throws MonopolyException {

        jugadores.remove(x);

        // Se non queda ninguén
        if (jugadores.isEmpty()) {
            consola.imprimir("Todos os xogadores en bancarrota. Xogo rematado.");
            throw new MonopolyException("Fin do xogo.");
        }

        // Axustamos turno
        if (turno >= jugadores.size()) {
            turno = 0;
        }

        // Se queda un → gañador
        if (jugadores.size() == 1) {
            Jugador g = jugadores.get(0);
            consola.imprimir("O xogo rematou!");
            consola.imprimir("Gañador: " + g.getNombre() + " (" + g.getFortuna() + "€)");
            consola.imprimir(g.mostrarEstadisticas());
            throw new MonopolyException("Fin do xogo.");
        }

        Jugador seguinte = getJugadorActual();
        consola.imprimir("Quedan " + jugadores.size() + " xogadores.");
        consola.imprimir("Segue " + seguinte.getNombre());
        consola.imprimir("Estado: " + seguinte.toString());
    }

    // ===============================================================
    // EDIFICAR nun solar (casa, hotel, piscina, pista)
    // Este comando require:
    //  - estar nun solar
    //  - ser o propietario
    //  - o tipo de edificio debe ser válido
    // O traballo pesado faino a clase Solares.
    // ===============================================================
    @Override
    public void edificar(String tipo) throws MonopolyException {

        Jugador actual = getJugadorActual();

        // Obtemos a casilla onde está o xogador
        Casilla c = actual.getAvatar().getLugar();

        // Comprobar que é un solar
        if (!c.getTipo().equalsIgnoreCase("solar")) {
            throw new ComandoInvalidoException("Só podes edificar nun solar.");
        }

        // Comprobar que o xogador é o propietario
        if (c.getDuenho() == null || !c.getDuenho().equals(actual)) {
            throw new ComandoInvalidoException("O solar non che pertence.");
        }

        // Validamos o tipo
        tipo = tipo.toLowerCase();
        if (!tipo.equals("casa") && !tipo.equals("hotel")
                && !tipo.equals("piscina") && !tipo.equals("pista")) {

            throw new ComandoInvalidoException(
                    "Tipo de edificio non válido. Use: casa, hotel, piscina ou pista.");
        }

        // Chamamos ao motor de edificación
        boolean exito = Solares.construirEdificio(c, actual, tipo);

        if (exito) {
            consola.imprimir("Edificación realizada correctamente.");
            consola.imprimir(tablero.toString());
        }
    }


    // ===============================================================
    // LISTAR EDIFICIOS dun xogador ou dun grupo de cor
    // Esta funcionalidade xa estaba en Menu, pero aquí intégrase
    // como método do interface Comando.
    // ===============================================================
    @Override
    public void listarEdificios() throws MonopolyException {

        boolean hai = false;

        // Percorremos todos os xogadores
        for (Jugador j : jugadores) {

            for (String id : j.getEdificios()) {

                // id é algo como "casa-3" → separámolo
                String[] partes = id.split("-");
                if (partes.length < 2) continue;

                String tipo = partes[0];

                // Buscamos a casilla propietaria dese edificio
                Casilla prop = buscarCasillaConEdificio(j, tipo);

                if (prop != null) {

                    float custo = obterCustoEdificio(prop, tipo);
                    consola.imprimir(
                            Solares.generarInfoEdificio(id, j, prop, custo)
                    );

                    hai = true;
                }
            }
        }

        if (!hai) {
            consola.imprimir("Non hai edificios construídos.");
        }
    }


    // ===============================================================
    // LISTAR EDIFICIOS FILTRANDO POR COR DE GRUPO
    // Igual que no teu Menu, usado para:
    //     listar edificios azul
    // ===============================================================
    @Override
    public void listarEdificiosGrupo(String colorGrupo) throws MonopolyException {

        colorGrupo = colorGrupo.toLowerCase().trim();
        boolean atopado = false;

        // Buscamos todos os grupos desa cor
        ArrayList<Grupo> grupos = new ArrayList<>();

        for (Jugador j : jugadores) {
            for (Casilla p : j.getPropiedades()) {

                Grupo g = p.getGrupo();

                if (g != null &&
                        g.getColorGrupo().equalsIgnoreCase(colorGrupo) &&
                        !grupos.contains(g)) {

                    grupos.add(g);
                }
            }
        }

        if (grupos.isEmpty()) {
            consola.imprimir("Non hai propiedades no grupo " + colorGrupo + ".");
            return;
        }

        // Cada grupo xerará a info das súas edificacións
        for (Grupo g : grupos) {
            String info = g.obtenerInfoEdificios();
            consola.imprimir(info);
            atopado = true;
        }

        if (!atopado) {
            consola.imprimir("Non hai edificios no grupo " + colorGrupo + ".");
        }
    }


    // ===============================================================
    // HIPOTECAR unha casilla
    // Delegamos en Casilla.hipotecar(Xogador)
    // ===============================================================
    @Override
    public void hipotecar(String nomeCasilla) throws MonopolyException {

        Casilla c = tablero.encontrar_casilla(nomeCasilla);
        if (c == null) {
            throw new ComandoInvalidoException("Casilla non atopada: " + nomeCasilla);
        }

        Jugador actual = getJugadorActual();
        c.hipotecar(actual);
        consola.imprimir("Hipoteca realizada correctamente.");
    }


    // ===============================================================
    // DESHIPOTECAR unha casilla
    // Delegamos en Casilla.deshipotecar(Xogador)
    // ===============================================================
    @Override
    public void deshipotecar(String nomeCasilla) throws MonopolyException {

        Casilla c = tablero.encontrar_casilla(nomeCasilla);
        if (c == null) {
            throw new ComandoInvalidoException("Casilla non atopada: " + nomeCasilla);
        }

        Jugador actual = getJugadorActual();
        c.deshipotecar(actual);
        consola.imprimir("Deshipoteca realizada correctamente.");
    }


    // ===============================================================
    // VENDER EDIFICIOS (casa/hotel/piscina/pista)
    // Exemplo:
    //       vender casa Solar5 2
    // ===============================================================
    @Override
    public void vender(String tipo, String nomeCasilla, int cant) throws MonopolyException {

        Casilla c = tablero.encontrar_casilla(nomeCasilla);
        if (c == null) {
            throw new ComandoInvalidoException("Casilla non atopada: " + nomeCasilla);
        }

        Jugador actual = getJugadorActual();

        boolean exito = Solares.venderEdificio(c, actual, tipo, cant);

        if (exito) {
            consola.imprimir("Venda realizada correctamente.");
            consola.imprimir(tablero.toString());
        }
    }


    // ===============================================================
    // LISTAR PROPIEDADES EN VENDA → equivalente ao teu listar enventa
    // ===============================================================
    @Override
    public void listarEnVenta() throws MonopolyException {

        boolean hai = false;

        for (int lado = 0; lado < 4; lado++) {

            ArrayList<Casilla> ladoCasillas = tablero.getLado(lado);

            for (Casilla c : ladoCasillas) {

                String info = c.casEnVenta();

                if (!info.isEmpty()) {
                    consola.imprimir(info);
                    hai = true;
                }
            }
        }

        if (!hai) {
            consola.imprimir("Non hai propiedades en venda.");
        }
    }


    // ===============================================================
    // MÉTODO AUXILIAR: atopar a casilla que contén un tipo concreto de edificio
    // ===============================================================
    private Casilla buscarCasillaConEdificio(Jugador j, String tipo) {

        for (Casilla c : j.getPropiedades()) {

            if (!c.getTipo().equalsIgnoreCase("solar")) continue;

            Solares.DatosEdificios datos = c.getDatosedificios();
            if (datos == null) continue;

            switch (tipo) {
                case "casa":    if (datos.getNumCasas() > 0) return c; break;
                case "hotel":   if (datos.getNumHoteles() > 0) return c; break;
                case "piscina": if (datos.getNumPiscinas() > 0) return c; break;
                case "pista":   if (datos.getNumPistas() > 0) return c; break;
            }
        }
        return null;
    }


    // ===============================================================
    // MÉTODO AUXILIAR: obter o custo dun edificio segundo o tipo
    // ===============================================================
    private float obterCustoEdificio(Casilla c, String tipo) {

        switch (tipo) {
            case "casa":    return Solares.obtenerPrecioCasa(c.getNombre());
            case "hotel":   return Solares.obtenerPrecioHotel(c.getNombre());
            case "piscina": return Solares.obtenerPrecioPiscina(c.getNombre());
            case "pista":   return Solares.obtenerPrecioPista(c.getNombre());
            default:        return 0;
        }
    }

    // ===============================================================
    // DESCRIBIR un xogador polo seu nome
    // Mostra todas as súas propiedades, fortuna, avatar, posición...
    // ===============================================================
    @Override
    public void describirJugador(String nome) throws MonopolyException {

        Jugador atopado = null;

        // Buscamos na lista de xogadores
        for (Jugador j : jugadores) {
            if (j.getNombre().equalsIgnoreCase(nome)) {
                atopado = j;
                break;
            }
        }

        if (atopado == null) {
            throw new ComandoInvalidoException("Xogador non atopado: " + nome);
        }

        // imprimimos a súa información
        consola.imprimir(atopado.infoJugador());
    }


    // ===============================================================
    // DESCRIBIR unha casilla polo seu nome
    // Mostra tipo, prezo, grupo, edificios, propietario...
    // ===============================================================
    @Override
    public void describirCasilla(String nome) throws MonopolyException {

        Casilla c = tablero.encontrar_casilla(nome);

        if (c == null) {
            throw new ComandoInvalidoException("Casilla non atopada: " + nome);
        }

        consola.imprimir(c.infoCasilla());
    }

    // ===============================================================
    // MOSTRA as estadísticas dun xogador en concreto
    // Chamamos a mostrarEstadisticas() xa existente en Jugador.
    // ===============================================================
    @Override
    public void estadisticasJugador(String nome) throws MonopolyException {

        Jugador x = null;

        for (Jugador j : jugadores) {
            if (j.getNombre().equalsIgnoreCase(nome)) {
                x = j;
                break;
            }
        }

        if (x == null) {
            throw new ComandoInvalidoException("Xogador non atopado: " + nome);
        }

        consola.imprimir(x.mostrarEstadisticas());
    }


    // ===============================================================
    // ESTADÍSTICAS XERAIS DO XOGO
    // Casilla máis rentable, máis visitada, xogador en cabeza, etc.
    // ===============================================================
    @Override
    public void estadisticasJuego() throws MonopolyException {

        consola.imprimir("{");
        consola.imprimir("casillaMasRentable: " + obterCasillaMasRentable() + ",");
        consola.imprimir("grupoMasRentable: " + obterGrupoMasRentable() + ",");
        consola.imprimir("casillaMasFrecuentada: " + obterCasillaMasFrecuentada() + ",");
        consola.imprimir("jugadorMasVueltas: " + obterXogadorMasVueltas() + ",");
        consola.imprimir("jugadorEnCabeza: " + obterXogadorEnCabeza());
        consola.imprimir("}");
    }


    // ===============================================================
    // MÉTODO PRIVADO: calcula casilla máis rentable
    // ===============================================================
    private String obterCasillaMasRentable() {

        float max = 0;
        String nome = "-";

        for (int lado = 0; lado < 4; lado++) {

            for (Casilla c : tablero.getLado(lado)) {

                if (c.getTotalAlquileresCobrados() > max) {
                    max = c.getTotalAlquileresCobrados();
                    nome = c.getNombre();
                }
            }
        }

        return nome;
    }


    // ===============================================================
    // MÉTODO PRIVADO: grupo con máis ingresos
    // ===============================================================
    private String obterGrupoMasRentable() {

        HashMap<String, Float> mapa = new HashMap<>();

        for (int lado = 0; lado < 4; lado++) {

            for (Casilla c : tablero.getLado(lado)) {

                if (c.getGrupo() == null) continue;

                String grupo = c.getGrupo().getColorGrupo();
                float ingresos = c.getTotalAlquileresCobrados();

                mapa.put(grupo, mapa.getOrDefault(grupo, 0f) + ingresos);
            }
        }

        float max = 0;
        String resultado = "-";

        for (String cor : mapa.keySet()) {
            if (mapa.get(cor) > max) {
                max = mapa.get(cor);
                resultado = cor;
            }
        }

        return resultado;
    }


    // ===============================================================
    // MÉTODO PRIVADO: casilla máis visitada
    // ===============================================================
    private String obterCasillaMasFrecuentada() {

        int max = 0;
        String nome = "-";

        for (int lado = 0; lado < 4; lado++) {

            for (Casilla c : tablero.getLado(lado)) {

                if (c.getVecesCaida() > max) {
                    max = c.getVecesCaida();
                    nome = c.getNombre();
                }
            }
        }

        return nome;
    }


    // ===============================================================
    // MÉTODO PRIVADO: xogador con máis voltas ao taboleiro
    // ===============================================================
    private String obterXogadorMasVueltas() {

        int max = 0;
        String nome = "-";

        for (Jugador j : jugadores) {
            if (j.getVueltas() > max) {
                max = j.getVueltas();
                nome = j.getNombre();
            }
        }

        return nome;
    }


    // ===============================================================
    // MÉTODO PRIVADO: xogador con maior fortuna total
    // Fortuna total = diñeiro + valor propiedades + valor edificios
    // ===============================================================
    private String obterXogadorEnCabeza() {

        float max = -1;
        String nome = "-";

        for (Jugador j : jugadores) {

            float total = j.getFortuna();

            for (Casilla p : j.getPropiedades()) {

                total += p.getValor();

                if (p.getDatosedificios() != null) {
                    Solares.DatosEdificios e = p.getDatosedificios();

                    total += e.getNumCasas() * Solares.obtenerPrecioCasa(p.getNombre());
                    total += e.getNumHoteles() * Solares.obtenerPrecioHotel(p.getNombre());
                    total += e.getNumPiscinas() * Solares.obtenerPrecioPiscina(p.getNombre());
                    total += e.getNumPistas() * Solares.obtenerPrecioPista(p.getNombre());
                }
            }

            if (total > max) {
                max = total;
                nome = j.getNombre();
            }
        }

        return nome;
    }



}

