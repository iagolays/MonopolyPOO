package monopoly.Exceptions;

//Excepcións para obxectos que non existen no xogo

public class NonExisteExcepcion extends MonopolyException{
    //costructor para obxectos que non existen sen tipo determinado
    public NonExisteExcepcion(String nomeObxecto) {
        super("Non existe o obxecto: " + nomeObxecto);
    }

    //costrutor para obxectos que non existen cun tipo determinado
    public NonExisteExcepcion(String tipoObxecto, String nomeObxecto) {
        super("Non existe o " + tipoObxecto + " co nome " + nomeObxecto);
    }
}
