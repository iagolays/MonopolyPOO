package monopoly.Exceptions;

public class ComandoInvalidoException extends MonopolyException{
    public ComandoInvalidoException(String mensaxe) {
        super(mensaxe);
    }
}
