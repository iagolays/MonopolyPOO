package monopoly;

import partida.Jugador;
import partida.*;
import monopoly.Exceptions.*; // Importamos as excepcións personalizadas


public class Trato {

    public int id;                  // ID único
    public Jugador propone;         // quen propón o trato
    public Jugador recibe;          // quen debe aceptalo

    public String descripcion;      // texto amable para mostrar
    public Runnable accion;         // acción que se executará ao aceptar

    public Trato(int id, Jugador p, Jugador r,
                 String desc, Runnable accion) {

        this.id = id;
        this.propone = p;
        this.recibe = r;
        this.descripcion = desc;
        this.accion = accion;
    }

    // ===============================================================
    // PROPOÑER UN TRATO (Requisito 32)
    // Tipos permitidos:
    //  - propiedade ↔ propiedade
    //  - propiedade ↔ diñeiro
    //  - diñeiro ↔ propiedade
    //  - propiedade ↔ propiedade + diñeiro
    //  - propiedade + diñeiro ↔ propiedade
    // Este método parsea a orde e crea un Trato.
    // ===============================================================
    @Override
    public void proponerTrato(String nomeReceptor, String expresion)
            throws MonopolyException {

        Jugador propone = getJugadorActual();
        Jugador recibe = buscarJugador(nomeReceptor);

        if (recibe == null) {
            throw new ComandoInvalidoException("Xogador non atopado: " + nomeReceptor);
        }

        if (recibe.equals(propone)) {
            throw new ComandoInvalidoException("Non podes propoñerte un trato a ti mesmo.");
        }

        // Aquí parseamos expresións tipo:
        //   (Solar3, Solar5)
        //   (Solar1, 200000)
        //   (Solar1, Solar5 y 300000)
        //
        // Para simplificar, chamamos a un método que devolve un Trato xa listo.
        Trato t = crearTratoDesdeExpresion(propone, recibe, expresion);

        tratosPendentes.put(t.id, t);

        consola.imprimir("Proposto trato" + t.id + ": " + t.descripcion);
    }

    // ===============================================================
    // ACEPTAR UN TRATO (Requisito 33)
    // O xogador receptor debe aceptar durante o seu propio turno.
    // ===============================================================
    @Override
    public void aceptarTrato(int id) throws MonopolyException {

        Trato t = tratosPendentes.get(id);

        if (t == null) {
            throw new ComandoInvalidoException("Non existe o trato" + id + ".");
        }

        // Só o xogador receptor pode aceptar
        if (!getJugadorActual().equals(t.recibe)) {
            throw new MonopolyException("Só o xogador destinatario pode aceptar o trato.");
        }

        // Intentamos executar o trato
        try {
            t.accion.run(); // acción validada ao crear o trato
        }
        catch (Exception e) {
            throw new MonopolyException("O trato non pode executarse: " + e.getMessage());
        }

        consola.imprimir("Trato aceptado: " + t.descripcion);

        // Eliminamos o trato aceptado
        tratosPendentes.remove(id);
    }

    // ===============================================================
    // LISTAR TRATOS propoñidos ao xogador actual
    // (Requisito 34)
    // ===============================================================
    @Override
    public void listarTratos() throws MonopolyException {

        Jugador actual = getJugadorActual();

        consola.imprimir("Tratos pendentes para " + actual.getNombre() + ":");

        boolean atopado = false;

        for (Trato t : tratosPendentes.values()) {

            if (t.recibe.equals(actual)) {

                consola.imprimir("{ id: trato" + t.id +
                        ", propone: " + t.propone.getNombre() +
                        ", trato: " + t.descripcion + " }");

                atopado = true;
            }
        }

        if (!atopado) {
            consola.imprimir("Non tes tratos pendentes.");
        }
    }

    // ===============================================================
    // ELIMINAR un trato que ti propuxeches (Requisito 35)
    // ===============================================================
    @Override
    public void eliminarTrato(int id) throws MonopolyException {

        Trato t = tratosPendentes.get(id);

        if (t == null) {
            throw new ComandoInvalidoException("O trato" + id + " non existe.");
        }

        // Só quen propuxo pode eliminalo
        if (!getJugadorActual().equals(t.propone)) {
            throw new MonopolyException("Só quen propuxo pode eliminar o trato.");
        }

        tratosPendentes.remove(id);

        consola.imprimir("Eliminado trato" + id + ".");
    }

    // ===============================================================
    // CREA un Trato a partir da expresión textual:
    // Ex:
    //   cambiar (Solar4, Solar2)
    //   cambiar (Solar3, 300000)
    //   cambiar (Solar1, Solar5 y 200000)
    //
    // O método devolve un Trato co Runnable listo para executar.
    // ===============================================================
    private Trato crearTratoDesdeExpresion(
            Jugador propone, Jugador recibe, String expr) throws MonopolyException {

        // Quitamos espazos e parénteses exteriores
        expr = expr.trim();
        if (expr.startsWith("(")) expr = expr.substring(1);
        if (expr.endsWith(")")) expr = expr.substring(0, expr.length() - 1);

        // Dividimos polo símbolo coma
        String[] partes = expr.split(",");

        if (partes.length < 2) {
            throw new ComandoInvalidoException("Expresión de trato inválida.");
        }

        String ofrece = partes[0].trim();
        String recibeCousa = partes[1].trim();

        // Detectar se hai "y" → formato combinado
        boolean combinado = recibeCousa.contains("y");

        // Preparar IDs novos
        int id = siguienteIdTrato++;

        // Agora analizamos cada caso
        // ---------------------------------------------------------
        // CASO 1: propiedade ↔ propiedade
        // ---------------------------------------------------------
        if (!combinado && isPropiedade(ofrece) && isPropiedade(recibeCousa)) {

            Casilla a = atoparPropiedadePropia(propone, ofrece);
            Casilla b = atoparPropiedadePropia(recibe, recibeCousa);

            if (a == null)
                throw new MonopolyException(ofrece + " non pertence a " + propone.getNombre());

            if (b == null)
                throw new MonopolyException(recibeCousa + " non pertence a " + recibe.getNombre());

            String desc = "Cambiar " + a.getNombre() + " por " + b.getNombre();

            Runnable accion = () -> {
                propone.transferirPropiedade(a, recibe);
                recibe.transferirPropiedade(b, propone);
            };

            return new Trato(id, propone, recibe, desc, accion);
        }

        // ---------------------------------------------------------
        // CASO 2: propiedade ↔ diñeiro
        // ---------------------------------------------------------
        if (!combinado && isPropiedade(ofrece) && isNumero(recibeCousa)) {

            Casilla a = atoparPropiedadePropia(propone, ofrece);
            int cant = Integer.parseInt(recibeCousa);

            if (a == null)
                throw new MonopolyException(ofrece + " non pertence ao propoñente.");

            if (recibe.getFortuna() < cant)
                throw new MonopolyException(recibe.getNombre() + " non ten " + cant + "€.");

            String desc = "te dou " + a.getNombre() + " e ti dásme " + cant + "€";

            Runnable accion = () -> {
                propone.transferirPropiedade(a, recibe);
                recibe.modificarFortuna(-cant);
                propone.modificarFortuna(cant);
            };

            return new Trato(id, propone, recibe, desc, accion);
        }

        // ---------------------------------------------------------
        // CASO 3: diñeiro ↔ propiedade
        // ---------------------------------------------------------
        if (!combinado && isNumero(ofrece) && isPropiedade(recibeCousa)) {

            int cant = Integer.parseInt(ofrece);
            Casilla b = atoparPropiedadePropia(recibe, recibeCousa);

            if (propone.getFortuna() < cant)
                throw new MonopolyException("Non tes " + cant + "€.");

            if (b == null)
                throw new MonopolyException(recibeCousa + " non pertence ao receptor.");

            String desc = "te dou " + cant + "€ e ti dásme " + b.getNombre();

            Runnable accion = () -> {
                propone.modificarFortuna(-cant);
                recibe.modificarFortuna(cant);
                recibe.transferirPropiedade(b, propone);
            };

            return new Trato(id, propone, recibe, desc, accion);
        }

        // ---------------------------------------------------------
        // CASO 4 e 5: propiedade + diñeiro ↔ propiedade (ou viceversa)
        // ---------------------------------------------------------
        if (combinado) {

            // Exemplo: "Solar1 y 300000"
            String[] sub = recibeCousa.split("y");

            String p2 = sub[0].trim();     // propiedade
            String q = sub[1].trim();     // cantidade

            Casilla a = atoparPropiedadePropia(propone, ofrece);
            Casilla b = atoparPropiedadePropia(recibe, p2);

            int cant = Integer.parseInt(q);

            if (a == null)
                throw new MonopolyException(ofrece + " non pertence ao propoñente.");

            if (b == null)
                throw new MonopolyException(p2 + " non pertence ao receptor.");

            if (propone.getFortuna() < cant)
                throw new MonopolyException("Non tes " + cant + "€.");

            String desc = "che dou " + a.getNombre() + " e " + cant +
                    "€ e ti dásme " + b.getNombre();

            Runnable accion = () -> {
                propone.transferirPropiedade(a, recibe);
                propone.modificarFortuna(-cant);
                recibe.modificarFortuna(cant);
                recibe.transferirPropiedade(b, propone);
            };

            return new Trato(id, propone, recibe, desc, accion);
        }

        throw new ComandoInvalidoException("Non se recoñece o formato do trato.");
    }

    // Comproba se a cadea representa unha propiedade existente
    private boolean isPropiedade(String s) {
        return tablero.encontrar_casilla(s) != null;
    }

    // Comproba se a cadea é un número enteiro
    private boolean isNumero(String s) {
        try { Integer.parseInt(s); return true; }
        catch (Exception e) { return false; }
    }

    // Atopa unha propiedade que realmente pertenza ao xogador
    private Casilla atoparPropiedadePropia(Jugador j, String nome) {

        Casilla c = tablero.encontrar_casilla(nome);
        if (c == null) return null;

        if (c.getDuenho() != null && c.getDuenho().equals(j))
            return c;

        return null;
    }

    // Busca un xogador polo seu nome
    private Jugador buscarJugador(String nome) {
        for (Jugador j : jugadores) {
            if (j.getNombre().equalsIgnoreCase(nome)) return j;
        }
        return null;
    }


}
