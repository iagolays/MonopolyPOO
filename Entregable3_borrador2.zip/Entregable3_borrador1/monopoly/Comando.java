package monopoly;

import monopoly.Exceptions.*;

public interface Comando {

    //empregase MonopolyException porque non se debe a un erro especifico se non a un erro qeu pode ser producido polo monopoly en xeral.
    // ----- Crear xogador -----
    void crearXogador(String nome, String tipoAvatar) throws MonopolyException;

    // ----- Información -----
    void mostrarXogadorActual() throws MonopolyException;
    void describirJugador(String nome) throws MonopolyException;
    void describirCasilla(String nome) throws MonopolyException;

    // ----- Listados -----
    void comandoListar(String[] partes) throws MonopolyException;

    // ----- Movemento e dados -----
    void lanzarDados() throws MonopolyException;
    void lanzarDadosForzados(String tirada) throws MonopolyException;

    // ----- Comprar / vender / edificar -----
    void comprarCasilla(String nome) throws MonopolyException;
    void comandoEdificar(String[] partes) throws MonopolyException;
    void comandoVender(String[] partes) throws MonopolyException;

    // ----- Hipotecas -----
    void hipotecar(String[] partes) throws MonopolyException;
    void deshipotecar(String[] partes) throws MonopolyException;

    // ----- Cárcere -----
    void salirCarcel() throws MonopolyException;

    // ----- Turnos -----
    void acabarTurno() throws MonopolyException;

    // ----- Estatísticas -----
    void mostrarEstadisticasXogo() throws MonopolyException;
    void mostrarEstadisticasJugador(String nome) throws MonopolyException;

    // ----- Lectura de ficheiro -----
    void lerComandosFicheiro(String nome) throws MonopolyException;

    // ----- Procesador xeral -----
    void procesarComando(String linea) throws MonopolyException;
}
