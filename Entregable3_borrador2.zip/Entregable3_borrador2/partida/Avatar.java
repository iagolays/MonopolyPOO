package partida;

import monopoly.*;
import monopoly.Casilla.Casilla;

import java.util.ArrayList;
import java.util.Random;

public class Avatar {
    private String id;
    private String tipo;
    private Jugador jugador;
    private Casilla lugar;

    public Avatar() {
    }

    public Avatar(String tipo, Jugador jugador, Casilla lugar, ArrayList<Avatar> avCreados) {
        this.tipo = tipo;
        this.jugador = jugador;
        this.lugar = lugar;
        this.generarId(avCreados);
        avCreados.add(this);

        if (this.lugar != null) {
            this.lugar.anhadirAvatar(this);
        }
        System.out.println("Avatar creado: " + this.id + " (Tipo: " + this.tipo + ") para " + jugador.getNombre());
    }

    // ✅ MÉTODO MOVER COMPLETAMENTE CORREGIDO
    private void mover(ArrayList<ArrayList<Casilla>> casillas, int valorTirada, Tablero tablero, boolean avanzar) {
        ArrayList<Casilla> todasCasillas = tablero.CasillasLineales();

        int posicionActual = -1;
        for (int i = 0; i < todasCasillas.size(); i++) {
            if (todasCasillas.get(i) == this.lugar) {
                posicionActual = i;
                break;
            }
        }
        if (posicionActual == -1) {
            System.out.println("Non se puido atopar a posición do avatar " + this.id);
            return;
        }

        // ✅ CORREGIDO: Cálculo correcto de la nueva posición
        int novaPos;
        if (avanzar) {
            novaPos = (posicionActual + valorTirada) % todasCasillas.size();

            // ✅ CORREGIDO: Verificar si pasa por Salida
            if (posicionActual + valorTirada >= todasCasillas.size()) {
                this.jugador.sumarFortuna(Valor.SUMA_VUELTA);
                this.jugador.registrarPasoSalida(Valor.SUMA_VUELTA);
                System.out.println(this.jugador.getNombre() + " recibe " + (int)Valor.SUMA_VUELTA + "€ por pasar por Salida.");
            }
        } else {
            // Para retroceder
            novaPos = (posicionActual - valorTirada + todasCasillas.size()) % todasCasillas.size();
        }

        Casilla casillaDestino = todasCasillas.get(novaPos);

        // ✅ CORREGIDO: Manejo de IrCarcel
        if ("IrCarcel".equalsIgnoreCase(casillaDestino.getNombre())) {
            Casilla carcel = tablero.encontrar_casilla("Carcel");
            if (carcel != null) {
                this.lugar.eliminarAvatar(this);
                this.lugar = carcel;
                carcel.anhadirAvatar(this);
                this.jugador.encarcelar(casillas, tablero);
                System.out.println(this.jugador.getNombre() + " vai directamente ao Cárcere!");
                return;
            }
        }

        // Movemento normal
        this.lugar.eliminarAvatar(this);
        this.lugar = casillaDestino;
        this.lugar.anhadirAvatar(this);
    }

    public void moverAvatar(ArrayList<ArrayList<Casilla>> casillas, int valorTirada, Tablero tablero, boolean avanzar) {
        String casillaAnteriorNombre = lugar.getNombre();
        mover(casillas, valorTirada, tablero, avanzar);

        String mensaje = "El avatar " + this.id + " avanza " + valorTirada +
                " posiciones, desde " + casillaAnteriorNombre +
                " hasta " + lugar.getNombre() + ".";
        System.out.println(mensaje);
    }

    public void moverAvatarHasta(String nombreCasilla, ArrayList<ArrayList<Casilla>> casillas, Tablero tablero, boolean pasarPorSalida) {
        ArrayList<Casilla> todasCasillas = tablero.CasillasLineales();

        int posActual = -1;
        int posDestino = -1;

        // Buscar posiciones actual y destino
        for (int i = 0; i < todasCasillas.size(); i++) {
            if (todasCasillas.get(i) == this.lugar) {
                posActual = i;
            }
            if (todasCasillas.get(i).getNombre().equalsIgnoreCase(nombreCasilla)) {
                posDestino = i;
            }
        }

        if (posActual == -1 || posDestino == -1) {
            System.out.println("Erro: non se puido atopar a casilla destino (" + nombreCasilla + ")");
            return;
        }

        // ✅ CORREGIDO: Cálculo correcto del movimiento
        int pasos;
        if (posDestino >= posActual) {
            pasos = posDestino - posActual;
        } else {
            pasos = (todasCasillas.size() - posActual) + posDestino;
        }

        // ✅ CORREGIDO: Verificar si pasa por Salida durante el movimiento
        if (pasarPorSalida && posDestino < posActual) {
            this.jugador.sumarFortuna(Valor.SUMA_VUELTA);
            this.jugador.registrarPasoSalida(Valor.SUMA_VUELTA);
            System.out.println(this.jugador.getNombre() + " recibe " + (int)Valor.SUMA_VUELTA + "€ por pasar por Salida.");
        }

        // Realizar el movimiento
        this.lugar.eliminarAvatar(this);
        this.lugar = todasCasillas.get(posDestino);
        this.lugar.anhadirAvatar(this);

        System.out.println(this.jugador.getNombre() + " móvese directamente a " + nombreCasilla + ".");

        // ✅ IMPORTANTE: Evaluar la casilla destino después del movimiento
        this.lugar.evaluarCasilla(this.jugador, tablero.getBanca(), 0, tablero, false);
    }

    private void generarId(ArrayList<Avatar> avCreados) {
        Random rand = new Random();
        String novoId;
        boolean idValido;

        do {
            int r = rand.nextInt(36);
            if (r < 26) {
                novoId = String.valueOf((char) ('A' + r));
            } else {
                novoId = String.valueOf((char) ('0' + (r - 26)));
            }

            idValido = true;
            for (Avatar av : avCreados) {
                if (av.getId().equalsIgnoreCase(novoId)) {
                    idValido = false;
                    break;
                }
            }
        } while (!idValido);

        this.id = novoId;
    }

    // ========== GETTERS ==========
    public String getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public Jugador getJugador() {
        return jugador;
    }

    public Casilla getLugar() {
        return lugar;
    }

    public void setLugar(Casilla lugar) {
        this.lugar = lugar;
    }

    @Override
    public String toString() {
        return "{avatar: " + this.id + ", tipo: " + this.tipo + "}";
    }
}