package partida;

import java.util.ArrayList;
import monopoly.*;
import monopoly.Casilla.Casilla;
import monopoly.Casilla.Edificio.*;

public class Jugador {
    // Atributos:
    private String nombre;
    private Avatar avatar;
    private float fortuna;
    private float gastos;
    private boolean enCarcel;
    private int tiradasCarcel;
    private int vueltas;
    private ArrayList<Casilla> propiedades;
    private ArrayList<Casilla> hipotecas;
    private ArrayList<Edificio> edificios;  // ✅ CAMBIADO: Ahora almacena objetos Edificio
    private boolean enBancarrota;
    private int doblesConsecutivos;
    private Jugador ultimoCobraAlquiler;

    // Para estadísticas
    private float dineroInvertido;
    private float pagoTasasEImpuestos;
    private float pagoDeAlquileres;
    private float cobroDeAlquileres;
    private float pasarPorCasillaSalida;
    private float premiosInversionesOBote;
    private int vecesEnCarcel;

    // Constructor vacío para la banca
    public Jugador() {
        this.nombre = "Banca";
        this.fortuna = 0f;
        this.gastos = 0f;
        this.enCarcel = false;
        this.tiradasCarcel = 0;
        this.vueltas = 0;
        this.propiedades = new ArrayList<>();
        this.hipotecas = new ArrayList<>();
        this.edificios = new ArrayList<>();  // ✅ Lista de objetos Edificio
        this.enBancarrota = false;
        inicializarEstadisticas();
    }

    // Constructor principal
    public Jugador(String nombre, String tipoAvatar, Casilla inicio, ArrayList<Avatar> avCreados) {
        this.nombre = nombre;
        this.fortuna = Valor.FORTUNA_INICIAL;
        this.gastos = 0f;
        this.enCarcel = false;
        this.tiradasCarcel = 0;
        this.vueltas = 0;
        this.propiedades = new ArrayList<>();
        this.hipotecas = new ArrayList<>();
        this.edificios = new ArrayList<>();  // ✅ Lista de objetos Edificio
        this.enBancarrota = false;
        this.avatar = new Avatar(tipoAvatar, this, inicio, avCreados);
        this.doblesConsecutivos = 0;
        this.ultimoCobraAlquiler = null;
        inicializarEstadisticas();
    }

    // ========== MÉTODOS PARA EDIFICIOS ==========

    public void anhadirEdificio(Edificio edificio) {
        if (edificio != null && !edificios.contains(edificio)) {
            edificios.add(edificio);
        }
    }

    public void eliminarEdificio(Edificio edificio) {
        edificios.remove(edificio);
    }

    public void eliminarEdificio(String idEdificio) {
        for (int i = 0; i < edificios.size(); i++) {
            if (edificios.get(i).getId().equals(idEdificio)) {
                edificios.remove(i);
                break;
            }
        }
    }

    public ArrayList<Edificio> getEdificiosObjetos() {
        return new ArrayList<>(edificios);
    }

    // Método para compatibilidad con código antiguo
    public ArrayList<String> getEdificios() {
        ArrayList<String> ids = new ArrayList<>();
        for (Edificio edificio : edificios) {
            ids.add(edificio.getId());
        }
        return ids;
    }

    // Buscar edificio por ID
    public Edificio buscarEdificio(String idEdificio) {
        for (Edificio edificio : edificios) {
            if (edificio.getId().equals(idEdificio)) {
                return edificio;
            }
        }
        return null;
    }

    // Contar edificios por tipo
    public int contarEdificiosPorTipo(String tipo) {
        int contador = 0;
        for (Edificio edificio : edificios) {
            if (edificio.getTipo().equalsIgnoreCase(tipo)) {
                contador++;
            }
        }
        return contador;
    }

    // ========== MÉTODOS ORIGINALES (modificados mínimamente) ==========

    private void inicializarEstadisticas() {
        this.dineroInvertido = 0f;
        this.pagoTasasEImpuestos = 0f;
        this.pagoDeAlquileres = 0f;
        this.cobroDeAlquileres = 0f;
        this.pasarPorCasillaSalida = 0f;
        this.premiosInversionesOBote = 0f;
        this.vecesEnCarcel = 0;
    }

    public void anhadirPropiedad(Casilla casilla) {
        if (casilla != null && !propiedades.contains(casilla)) {
            this.propiedades.add(casilla);
            casilla.setDuenho(this);
        }
    }

    public void eliminarPropiedad(Casilla casilla) {
        if (casilla != null) {
            this.propiedades.remove(casilla);
        }
    }

    public void sumarFortuna(float valor) {
        this.fortuna += valor;
        if (valor < 0) {
            this.sumarGastos(Math.abs(valor));
        }
        if (this.fortuna < 0 && !this.enBancarrota) {
            System.out.println(this.nombre + " entrou en números vermellos: " + (int) this.fortuna + "€");
        }
    }

    public void sumarGastos(float valor) {
        this.gastos += valor;
    }

    public void encarcelar(ArrayList<ArrayList<Casilla>> pos, Tablero tablero) {
        this.enCarcel = true;
        this.tiradasCarcel = 0;
        this.vecesEnCarcel++;

        Casilla carcel = tablero.encontrar_casilla("Carcel");
        if (carcel != null && this.avatar != null) {
            Casilla casillaActual = this.avatar.getLugar();
            if (casillaActual != null) {
                casillaActual.eliminarAvatar(this.avatar);
            }
            this.avatar.setLugar(carcel);
            carcel.anhadirAvatar(this.avatar);
        }
    }

    public boolean puedePagar(float valor) {
        return this.fortuna >= valor;
    }

    public boolean pagarJugador(Jugador receptor, float cantidad, Tablero tablero) {
        if (this.puedePagar(cantidad)) {
            this.sumarFortuna(-cantidad);
            receptor.sumarFortuna(cantidad);
            this.pagoDeAlquileres += cantidad;
            receptor.cobroDeAlquileres += cantidad;
            return true;
        } else {
            this.sumarFortuna(-cantidad);
            System.out.println(this.nombre + " non pode pagar ");
            System.out.println("Opcións dispoñibles:");
            System.out.println("   - 'hipotecar <casilla>' para obter diñeiro");
            System.out.println("   - 'acabar turno' para declararse en bancarrota");
            return false;
        }
    }

    public void salirCarcel(Tablero tablero) {
        if (this.enCarcel && this.puedePagar(Valor.CARCEL_SALIDA)) {
            this.sumarFortuna(-Valor.CARCEL_SALIDA);
            this.pagoTasasEImpuestos += Valor.CARCEL_SALIDA;
            this.enCarcel = false;
            this.tiradasCarcel = 0;
            System.out.println(this.nombre + " paga " + (int)Valor.CARCEL_SALIDA + "€ y sale de la cárcel.");
        } else if (this.enCarcel && !this.puedePagar(Valor.CARCEL_SALIDA)) {
            System.out.println(this.nombre + " no tiene dinero para salir de la cárcel.");
        } else {
            System.out.println(this.nombre + " no está en la cárcel.");
        }
    }

    public int intentarSalirCarcel(Dado dado1, Dado dado2, Tablero tablero, boolean forzarTirada, int valorForzado1, int valorForzado2) {
        if (!enCarcel){
            return 1;
        }

        tiradasCarcel++;
        int v1, v2;
        if (forzarTirada) {
            v1 = valorForzado1;
            v2 = valorForzado2;
            dado1.lanzarForzado(v1);
            dado2.lanzarForzado(v2);
        } else {
            v1 = dado1.hacerTirada();
            v2 = dado2.hacerTirada();
        }

        System.out.println(this.nombre + " saca " + v1 + " e " + v2 + " (turno " + this.tiradasCarcel + "/3)");

        if (v1 == v2) {
            System.out.println(this.nombre + " saca dobles y sale de la cárcel sin pagar.");
            this.enCarcel = false;
            this.tiradasCarcel = 0;
            return 1;

        } else if (tiradasCarcel >= 3) {
            if (puedePagar(Valor.CARCEL_SALIDA)) {
                salirCarcel(tablero);
                return 1;
            } else {
                System.out.println(nombre + " no puede pagar para salir de la cárcel.");
                this.declararBancarrota(tablero, null);
                return -1;
            }
        }
        return 0;
    }

    public void declararBancarrota(Tablero tablero, Jugador pagarA) {
        if (this.enBancarrota){
            return;
        }
        this.enBancarrota = true;
        this.fortuna = 0;

        Jugador receptor = pagarA != null ? pagarA : tablero.getBanca();

        // Transferir propiedades hipotecadas
        ArrayList<Casilla> propiedadesHipotecadas = new ArrayList<>(this.hipotecas);
        for (Casilla c : propiedadesHipotecadas) {
            c.setDuenho(receptor);
            if (receptor != tablero.getBanca()) {
                receptor.anhadirHipoteca(c);
            }
            this.eliminarHipoteca(c);
        }

        // Transferir propiedades no hipotecadas
        ArrayList<Casilla> propiedadesNoHipotecadas = new ArrayList<>(this.propiedades);
        for (Casilla c : propiedadesNoHipotecadas) {
            if (this.hipotecas.contains(c)) {
                continue;
            }
            c.setDuenho(receptor);
            if (receptor != tablero.getBanca()) {
                receptor.anhadirPropiedad(c);
            }
            this.eliminarPropiedad(c);
        }

        // Transferir edificios
        for (Edificio edificio : new ArrayList<>(edificios)) {
            edificio.setPropietario(receptor);
            if (receptor != tablero.getBanca()) {
                receptor.anhadirEdificio(edificio);
            }
        }

        this.propiedades.clear();
        this.hipotecas.clear();
        this.edificios.clear();

        if (this.avatar != null) {
            Casilla lugarActual = this.avatar.getLugar();
            if (lugarActual != null) {
                lugarActual.eliminarAvatar(this.avatar);
            }
            this.avatar = null;
        }

        if (pagarA != null) {
            System.out.println(this.nombre + " se declara en bancarrota y transfiere sus propiedades a " + pagarA.getNombre() + ".");
        } else {
            System.out.println(this.nombre + " se declara en bancarrota y transfiere sus propiedades al banco.");
        }
    }

    // ========== MÉTODOS DE ESTADÍSTICAS ==========

    public void sumarInversion(float valor) {
        this.dineroInvertido += valor;
    }

    public void registrarPasoSalida(float valor) {
        this.pasarPorCasillaSalida += valor;
        this.incrementarVueltas();
    }

    public void registrarPremio(float valor) {
        this.premiosInversionesOBote += valor;
    }

    public void registrarTasa(float valor) {
        this.pagoTasasEImpuestos += valor;
    }

    public void incrementarVueltas() {
        this.vueltas++;
    }

    public void registrarPagoAlquiler(float valor) {
        this.pagoDeAlquileres += valor;
    }

    public void registrarCobroAlquiler(float valor) {
        this.cobroDeAlquileres += valor;
    }

    public void registrarVecesEnCarcel() {
        this.vecesEnCarcel++;
    }

    // ========== MÉTODOS DE HIPOTECA ==========

    public void anhadirHipoteca(Casilla propiedad) {
        if (propiedad != null && !hipotecas.contains(propiedad)) {
            this.hipotecas.add(propiedad);
        }
    }

    public void eliminarHipoteca(Casilla propiedad) {
        this.hipotecas.remove(propiedad);
    }

    // ========== MÉTODOS DE INFORMACIÓN ==========

    public String infoJugador() {
        StringBuilder info = new StringBuilder();
        info.append("{\n");

        info.append("nombre: ").append(this.nombre).append(",\n");
        info.append("avatar: ").append(this.avatar != null ? this.avatar.getId() : "—").append(",\n");
        info.append("fortuna: ").append((int)this.fortuna).append(",\n");

        info.append("propiedades: [");
        int count = 0;
        for (Casilla p : this.propiedades) {
            if (count > 0) info.append(", ");
            info.append(p.getNombre());
            count++;
        }
        info.append("],\n");

        info.append("hipotecas: [");
        count = 0;
        for (Casilla h : this.hipotecas) {
            if (count > 0) info.append(", ");
            info.append(h.getNombre());
            count++;
        }
        info.append("],\n");

        info.append("edificios: [");
        count = 0;
        for (Edificio e : this.edificios) {
            if (count > 0) info.append(", ");
            info.append(e.getId());
            count++;
        }
        info.append("]\n");

        info.append("}");
        return info.toString();
    }

    public String mostrarEstadisticas() {
        StringBuilder info = new StringBuilder();
        info.append("{\n");
        info.append("dineroInvertido: ").append((int)this.dineroInvertido).append(",\n");
        info.append("pagoTasasEImpuestos: ").append((int)this.pagoTasasEImpuestos).append(",\n");
        info.append("pagoDeAlquileres: ").append((int)this.pagoDeAlquileres).append(",\n");
        info.append("cobroDeAlquileres: ").append((int)this.cobroDeAlquileres).append(",\n");
        info.append("pasarPorCasillaDeSalida: ").append((int)this.pasarPorCasillaSalida).append(",\n");
        info.append("premiosInversionesOBote: ").append((int)this.premiosInversionesOBote).append(",\n");
        info.append("vecesEnLaCarcel: ").append(this.vecesEnCarcel).append("\n");
        info.append("}");
        return info.toString();
    }

    // ========== GETTERS Y SETTERS ==========

    public void incrementarDobles() {
        this.doblesConsecutivos++;
    }

    public void resetearDobles() {
        this.doblesConsecutivos = 0;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public Avatar getAvatar() {
        return this.avatar;
    }

    public float getFortuna() {
        return fortuna;
    }

    public boolean isEnCarcel() {
        return enCarcel;
    }

    public int getDoblesConsecutivos() {
        return doblesConsecutivos;
    }

    public void setEnCarcel(boolean enCarcel) {
        this.enCarcel = enCarcel;
    }

    public boolean isEnBancarrota() {
        return enBancarrota;
    }

    public ArrayList<Casilla> getPropiedades() {
        return propiedades;
    }

    public int getVueltas() {
        return vueltas;
    }

    public Jugador getUltimoCobraAlquiler() {
        return ultimoCobraAlquiler;
    }

    public void setUltimoCobraAlquiler(Jugador ultimoCobraAlquiler) {
        this.ultimoCobraAlquiler = ultimoCobraAlquiler;
    }

    @Override
    public String toString() {
        return "{nombre: " + nombre + ", avatar: " + (avatar != null ? avatar.getId() : "—") +
                ", fortuna: " + (int)fortuna + ", propiedades: " + propiedades.size() +
                ", hipotecas: " + hipotecas.size() + ", edificios: " + edificios.size() + "}";
    }
}