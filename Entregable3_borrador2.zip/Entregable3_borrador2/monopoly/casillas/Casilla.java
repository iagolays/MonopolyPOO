package monopoly.casillas;
import partida.*;
import monopoly.*;
import java.util.ArrayList;

//Móvense os atributos e os métodos comúns da antigua clase Casilla a esta nova clase abstracta Casilla.
public abstract class Casilla {

    //Atributos comúns a todas as casillas
    protected String nombre; //Nombre de la casilla
    protected int posicion; //Posición que ocupa la casilla en el tablero (entero entre 1 y 40).
    protected ArrayList<Avatar> avatares; //Avatares que están situados en la casilla.
    protected int vecesCaida; //Contador de veces que un avatar cae na casilla
    protected float totalAlquileresCobrados; //Total de alquileres cobrados en esta Casilla

    //Constructor
    public Casilla(String nombre, int posicion) {
        this.nombre = nombre;
        this.posicion = posicion;
        this.avatares = new ArrayList<>();
        this.vecesCaida = 0;
        this.totalAlquileresCobrados = 0;
    }

    //Metodo que devolve se o avatar está na casilla ou non
    public boolean estaAvatar(Avatar avatar) {
        return avatar.getLugar().equals(this);
    }

    //Metodo para saber a frecuencia de caida na casilla
    public int frecuenciaVisita() {
        return vecesCaida;
    }

    @Override
    public  String toString(){
        //representacion xenerica, as subclases poden engadir mais informacion
        return  infoCasilla();
    }

    //Metodo utilizado para añadir un avatar ao array de avatares en casilla.
    public void anhadirAvatar(Avatar av) {
        if (av != null && !this.avatares.contains(av)) { //Comprobamos que o avatar a engadir ao array de avatares non está (no queremos duplicados)
            this.avatares.add(av); //Se non está, engádese
            this.vecesCaida++; //Incrementamos o contador de veces que se cae nesta casilla
        }
    }

    //Metodo utilizado para eliminar un avatar do array de avatares en casilla.
    public void eliminarAvatar(Avatar av) {
        if (av != null && this.avatares.contains(av)) { //Comprobamos que o avatar está no array
            this.avatares.remove(av);        //Se está en la lista de avatares, eliminámolo
        }
    }

    public String getAvataresString(){
        if (avatares == null || avatares.isEmpty()) {
            return ""; // Se non hai avatares, devolve unha cadea baleira
        }
        StringBuilder sb = new StringBuilder();
        for(Avatar av : avatares){
            sb.append(av.getId()); // Mostrar o ID do avatar
            if (av.getJugador().isEnCarcel()) {
                sb.append(" (c)"); // Indicar que o xogador está no cárcere
            }
            sb.append(" ");
        }
        return sb.toString().trim();
    }

    // Sumar valor á casilla (para Parking, etc.)
    public void sumarValor(float cantidad) {
        // Implementación por defecto, as subclases sobrescriben
    }

    // Sumar alquiler cobrado (estatísticas)
    public void sumarAlquilerCobrado(float cantidad) {
        if (cantidad > 0) {
            totalAlquileresCobrados += cantidad;
        }
    }

    public String getNombre() {
        return nombre;
    }

    public int getPosicion() {
        return posicion;
    }

    public ArrayList<Avatar> getAvatares() {
        return avatares;
    }

    public float getTotalAlquileresCobrados() {
        return totalAlquileresCobrados;
    }

    public int getVecesCaida() {
        return vecesCaida;
    }

    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("nome: ").append(nombre).append(",\n");
        sb.append("posicion: ").append(posicion).append(",\n");
        sb.append("vecesCaida: ").append(vecesCaida).append(",\n");
        sb.append("totalAlquileresCobrados: ").append((int) totalAlquileresCobrados).append("\n");
        sb.append("}");
        return sb.toString();
    }
}

