package monopoly.casillas;
import monopoly.*;
import partida.*;

public abstract class Accion extends Casilla {
    //Constructor
    public Accion(String nombre, int posicion) {
        super(nombre, posicion);
    }

    //Metodo abstracto que se implementará nas clases fillas
    public abstract boolean ejecutarAccion(Jugador jugador, Tablero tablero);

    //Metodo toString
    @Override
    public abstract String toString();
}
