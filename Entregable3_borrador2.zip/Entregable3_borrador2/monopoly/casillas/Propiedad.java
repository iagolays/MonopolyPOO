package monopoly.casillas;
import monopoly.*;
import partida.*;

//Clase abstracta porque implementa métodos abstractos
public abstract class Propiedad extends Casilla{

    //Atributos comúns a todas as propiedades
    private float valor; //Valor de esa casilla (en la mayoría será valor de compra, en la casilla parking se usará como el bote).
    private Jugador duenho; //Dueño de la casilla (por defecto sería la banca).
    private boolean hipotecada;  //false se no nestá hipotecada ou non se pode,true si está hipotecada
    private float alquiler; //Cantidad a pagar por caer en la Casilla: el alquiler en solares/servicios/transportes o impuestos.

    //Constructor
    public Propiedad(String nombre, int posicion, Jugador duenho) {
        super(nombre, posicion); //Chamada ao constructor da clase Casilla, con super para inicializar os atributos herdados
        this.valor = calcularValor();
        this.duenho = duenho;
        this.hipotecada = false; //por defecto non está hipotecada
        this.alquiler = calcularAlquiler();
    }


    //Metodo para saber se unha propiedade pertence a un xogador
    public boolean perteneceAJugador(Jugador jugador){
        return this.duenho!= null && this.duenho.equals(jugador);
    }

    //Metodo que devolve o aluguer dunha propiedade
    public abstract float calcularAlquiler();

    //Metodo que devolve o valor da propiedade
    public abstract float calcularValor();

    //Metodo abstracto para saber se unha propiedade está hipotecada
    public abstract boolean estaHipotecada();


    //Metodo para a compra dunha propiedade
    public void comprar(Jugador jugador){
        if (jugador == null){
            return;
        }
        if(this.duenho == null || "Banca".equals(this.duenho.getNombre())){ //Se a propiedade non ten dono ou o dono é a banca
            if (jugador.puedePagar(this.valor)){
                jugador.sumarFortuna(-this.valor); //O xogador paga o valor da propiedade
                jugador.sumarInversion(this.valor);
                this.duenho = jugador; //O xogador pasa a ser o dono da propiedade
                jugador.anhadirPropiedad(this);

                Juego.getConsola().imprimir(jugador.getNombre() + " compra " + this.getNombre() + " por " + this.valor + "€.");
            } else {
                Juego.getConsola().imprimir(jugador.getNombre() + " non ten diñeiro suficiente.");
            }
        } else {
            Juego.getConsola().imprimir("A propiedade xa ten dono.");
        }
    }

    //Metodo para hipotecar unha propiedade (por defecto non se pode hipotecar, so se é solar)
    public void hipotecar() {
        // Por defecto no se puede hipotecar
        Juego.getConsola().imprimir(this.getNombre() + " non se pode hipotecar.");
        return;
    }

    //Metodo para deshipotecar unha propiedade (por defecto non se pode deshipotecar, so se é solar)
    public void deshipotecar() {
        // Por defecto no se puede deshipotecar
        Juego.getConsola().imprimir(this.getNombre() + " non se pode deshipotecar.");
        return;
    }
    //Metodo abstracto para saber se unha propiedade cobra aluguer
    public abstract boolean alquiler();


    public Jugador getDuenho() {
        return duenho;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public void setDuenho(Jugador duenho) {
        this.duenho = duenho;
    }

    //Sobrescritura do metodo abstracto de Casilla
    @Override
    public boolean evaluarCasilla(Jugador jugador,
                                  Jugador banca,
                                  int tirada,
                                  Tablero tablero,
                                  boolean desdeCarta) {

        // Cada vez que se cae en la casilla, actualizamos la estadística
        this.vecesCaida++;

        // Si no puede cobrar alquiler, salimos
        if (!alquiler() || duenho == null || jugador == null || jugador.equals(duenho)) {
            return true;
        }

        // Calcular cuánto alquiler corresponde en este tipo de propiedad
        float cantidad = calcularAlquilerConcreto(tirada, tablero);
        if (cantidad <= 0) {
            return true;
        }

        // Cobrar alquiler al jugador que ha caído
        boolean resultado = jugador.pagarJugador(duenho, cantidad, tablero);

        if (resultado) {
            // Actualizar estadística de alquileres cobrados en la casilla
            sumarAlquilerCobrado(cantidad);
        }

        return resultado;
    }
    //Metodo abstracto para calcular o aluguer concreto dunha propiedade
    protected abstract float calcularAlquilerConcreto(int tirada, Tablero tablero);

    //Sobrescritura do metodo toString
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("nome: ").append(nombre).append(",\n");
        sb.append("posicion: ").append(posicion).append(",\n");
        sb.append("dono: ").append(duenho != null ? duenho.getNombre() : "Banca").append(",\n");
        sb.append("hipotecada: ").append(hipotecada).append(",\n");
        sb.append("valor: ").append((int) valor).append("\n");
        sb.append("}");
        return sb.toString();
    }
}
