package monopoly.casillas;
import monopoly.*;
import partida.*;

public class Parking extends Accion{

    private float bote; //bote de esa casilla (en la mayoría será bote de compra, en la casilla parking se usará como el bote).

    //Constructor
    public Parking(String nombre, int posicion) {
        super(nombre, posicion);
        this.bote = 0; //Inicialmente o bote do parking é 0
    }

    @Override
    public boolean ejecutarAccion(Jugador jugador, Tablero tablero) {
        //O xogados cae en parking e cobra o bote acumulado
        Juego.getConsola().imprimir(jugador.getNombre() + " cae en Parking.");
        if(this.bote > 0){
            Juego.getConsola().imprimir(" Cobra " + this.bote + "€ do Parking.");
            jugador.sumarFortuna(this.bote);
            jugador.registrarPremio(this.bote);
            this.bote = 0; //O bote do parking volve a 0
        } else {
            Juego.getConsola().imprimir(" O Parking está baleiro.");
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Parking {\n");
        sb.append("nome: '").append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append(",\n");
        sb.append("bote: ").append(bote).append("\n");
        sb.append("}");
        return sb.toString();
    }

    //Metodo para engadir bote ao parking
    public void anhadirAlBote(float cantidad) {
        this.bote += cantidad;
        Juego.getConsola().imprimir("Engádense " + (int)cantidad + "€ ao bote do Parking. Total: " + (int)bote + "€");
    }

    public float getBote() {
        return bote;
    }
}
