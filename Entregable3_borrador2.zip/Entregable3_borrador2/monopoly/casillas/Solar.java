package monopoly.casillas;

import partida.*;
import monopoly.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Solar extends Propiedad {

    //Atributos específicos de Solar
    private Grupo grupo; //Grupo al que pertenece la casilla (si es solar).
    private Solares.DatosEdificios datosEdificios; //Datos dos edificios construídos nesta casilla (se é solar)
    private ArrayList<String> idsEdificiosCasilla; //IDs dos edificios construídos nesta casilla (se é solar)
    private boolean hipotecada;  //false se no nestá hipotecada ou non se pode,true si está hipotecada
    private float valorHipoteca; //Valor otorgado por hipotecar una casilla

    //Constructor
    public Solar(String nombre, int posicion, float valor, Jugador duenho) {
        super(nombre, posicion, valor, duenho); //Chamada ao constructor da clase Propiedad
        this.datosEdificios = new Solares.DatosEdificios(); //Inicializamos os datos dos edificios
        this.idsEdificiosCasilla = new ArrayList<>(); //Inicializamos a lista de IDs dos edificios
        this.hipotecada = false; //Inicializamos a hipotecada a false
        this.valorHipoteca = valor / 2; //Valor da hipoteca é a metade do valor da propiedade
    }

    //Implementación do metodo abstracto alquiler(), true se se puido cobrar o aluguer, false se non
    @Override
    public boolean alquiler() {
        //////implementacion posteriormente

        Juego.getConsola().imprimir("Calcular aluguer para " + this.getNombre());
        return false;
    }

    //Implementación do metodo abstracto valor(), devolve o valor actual do solar
    @Override
    public float valor() {
        return getValor(); //Devolvemos o valor da propiedade (herdado de Propiedad)
    }

    //Metodo para edificar a casilla
    public void edificar(String tipoEdificio){
        Jugador jugador = getDuenho();
        
        if (!puedeConstruir(tipoEdificio)){ //verificamos que se pode construír
            return;
        }
        Solares.DatosSolar datos = Solares.obtenerDatos(getNombre());
        if (datos == null) {
            Juego.getConsola().imprimir("Non se puideron obter os datos do solar " + getNombre() + ".");
            return;
        }
        
        float costeTotal = 0; //coste total do edificio a construír

        switch (tipoEdificio.toLowerCase()){
            case "casa":
                costeTotal = datos.getValorCasa();
                if (!jugador.puedePagar(costeTotal)) {
                    Juego.getConsola().imprimir("A fortuna non é suficiente para construír unha casa en " + getNombre() + ".");
                    return;
                }
                construirCasa();
                break;
            case "hotel":
                costeTotal = datos.getValorHotel();
                if (!jugador.puedePagar(costeTotal)){
                    Juego.getConsola().imprimir("A fortuna non é suficiente para construír un hotel en " + getNombre() + ".");
                    return;
                }
                construirHotel();
                break;
            case "piscina":
                costeTotal = datos.getValorPiscina();
                if (!jugador.puedePagar(costeTotal)) {
                    Juego.getConsola().imprimir("A fortuna non é suficiente para construír unha piscina en " + getNombre() + ".");
                    return;
                }
                construirPiscina();
                break;
            case "pista":
                costeTotal = datos.getValorPista();
                if (!jugador.puedePagar(costeTotal)) {
                    Juego.getConsola().imprimir("A fortuna de non é suficiente para construír unha pista de deporte en " + getNombre() + ".");
                    return;
                }
                construirPista();
                break;
            default:
                Juego.getConsola().imprimir("Tipo de edificio descoñecido: " + tipoEdificio + ".");
                return;
        }
        jugador.sumarFortuna(-costeTotal); //restamos o custo de construir á fortuna do xogador
        jugador.sumarInversion(costeTotal); //o custo de construír é unha inversión

        Juego.getConsola().imprimir("Constrúese un " + tipoEdificio + " en " + getNombre() + ". A fortuna de " + jugador.getNombre() + " é " + (int) jugador.getFortuna() + "€.");
    }


    private boolean puedeConstruir(String tipo) {
        Jugador jugador = getDuenho();

        if (jugador == null || !perteneceAJugador(jugador)) {
            Juego.getConsola().imprimir("Non é o dono desta propiedade.");
            return false;
        }

        if (hipotecada) {
            Juego.getConsola().imprimir("Non se pode construír nun solar hipotecado.");
            return false;
        }

        if (grupo == null || !grupo.esDuenhoGrupo(jugador)) {
            Juego.getConsola().imprimir("Non posúe todo o grupo.");
            return false;
        }

        switch (tipo.toLowerCase()) {
            case "casa":
                if (datosEdificios.getNumCasas() >= 4) {
                    Juego.getConsola().imprimir("Xa hai 4 casas construídas.");
                    return false;
                }
                if (datosEdificios.getNumHoteles() > 0) {
                    Juego.getConsola().imprimir("Non se poden construír casas cando hai hotel.");
                    return false;
                }
                break;

            case "hotel":
                if (datosEdificios.getNumCasas() < 4) {
                    Juego.getConsola().imprimir("Necesitas 4 casas antes de construír un hotel.");
                    return false;
                }
                if (datosEdificios.getNumHoteles() >= 1) {
                    Juego.getConsola().imprimir("Xa hai un hotel construído.");
                    return false;
                }
                break;

            case "piscina":
                if (datosEdificios.getNumHoteles() < 1) {
                    Juego.getConsola().imprimir("Necesitas un hotel antes de construír unha piscina.");
                    return false;
                }
                if (datosEdificios.getNumPiscinas() >= 1) {
                    Juego.getConsola().imprimir("Xa hai unha piscina construída.");
                    return false;
                }
                break;

            case "pista":
                if (datosEdificios.getNumHoteles() < 1) {
                    Juego.getConsola().imprimir("Necesitas un hotel antes de construír unha pista.");
                    return false;
                }
                if (datosEdificios.getNumPiscinas() < 1) {
                    Juego.getConsola().imprimir("Necesitas unha piscina antes de construír unha pista.");
                    return false;
                }
                if (datosEdificios.getNumPistas() >= 1) {
                    Juego.getConsola().imprimir("Xa hai unha pista construída.");
                    return false;
                }
                break;
        }

        return true;
    }

    private void construirCasa() {
        datosEdificios.setNumCasas(datosEdificios.getNumCasas() + 1);
        String idCasa = "casa-" + (datosEdificios.getNumCasas());
        idsEdificiosCasilla.add(idCasa);
        getDuenho().anhadirEdificio(idCasa);
        datosEdificios.actualizarEstadoEdificios();
    }

    private void construirHotel() {
        // Eliminar las 4 casas
        Iterator<String> iterator = idsEdificiosCasilla.iterator();
        int casasEliminadas = 0;
        while (iterator.hasNext() && casasEliminadas < 4) {
            String id = iterator.next();
            if (id.startsWith("casa-")) {
                iterator.remove();
                getDuenho().eliminarEdificio(id);
                casasEliminadas++;
            }
        }

        datosEdificios.setNumCasas(0);
        datosEdificios.setNumHoteles(1);
        String idHotel = "hotel-1";
        idsEdificiosCasilla.add(idHotel);
        getDuenho().anhadirEdificio(idHotel);
        datosEdificios.actualizarEstadoEdificios();
    }

    private void construirPiscina() {
        datosEdificios.setNumPiscinas(1);
        String idPiscina = "piscina-1";
        idsEdificiosCasilla.add(idPiscina);
        getDuenho().anhadirEdificio(idPiscina);
        datosEdificios.actualizarEstadoEdificios();
    }

    private void construirPista() {
        datosEdificios.setNumPistas(1);
        String idPista = "pista-1";
        idsEdificiosCasilla.add(idPista);
        getDuenho().anhadirEdificio(idPista);
        datosEdificios.actualizarEstadoEdificios();
    }

    public static float calcularAlquiler(Casilla casilla) {
        Solares.DatosSolar datos = Solares.obtenerDatos(casilla.getNombre());
        if (datos == null){ //se non existen datos do solar, devolvemos 0
            return 0;
        }
        Solares.DatosEdificios edificios = casilla.getDatosedificios(); //obtemos os datos dos edificios da casilla
        float alquilerTotal = datos.getAlquiler(); //comezase cun aluguer base ao que se vai engadir o dos edificios

        if (edificios != null) {
            alquilerTotal += edificios.getNumCasas() * datos.getAlquilerCasa();
            alquilerTotal += edificios.getNumHoteles() * datos.getAlquilerHotel();
            alquilerTotal += edificios.getNumPiscinas() * datos.getAlquilerPiscina();
            alquilerTotal += edificios.getNumPistas() * datos.getAlquilerPista();
        }
        return alquilerTotal;
    }


    public void hipotecar () {

        Jugador duenho = getDuenho();

        //Verificar que o xogador é dono
        if (duenho == null || !perteneceAJugador(duenho)){
            String nombreMsg = (duenho != null) ? duenho.getNombre() : "Ningún"; //impedimos asi un posible NullPointerException
            Juego.getConsola().imprimir(nombreMsg + " non pode hipotecar " + getNombre() + " porque non é o seu dono.");
            return;
        }

        //Verificar que non está hipotecada
        if (estaHipotecada()){
            Juego.getConsola().imprimir(getNombre() + " xa está hipotecada.");
            return;
        }

        if (this.datosEdificios != null && this.datosEdificios.isTieneEdificios()) {
            Juego.getConsola().imprimir(duenho.getNombre() + " non pode hipotecar " + getNombre() + ". Ten edificios que deben venderse primeiro.");
            return;
        }

        //Hipotecar, dase o diñeiro ao xogador
        hipotecada = true;
        duenho.anhadirHipoteca(this);
        duenho.sumarFortuna(valorHipoteca); // Engadimos o diñeiro da hipoteca á fortuna do xogador
        duenho.sumarInversion(valorHipoteca); // Engadimos o diñeiro da hipoteca ás inversións do xogador

        Juego.getConsola().imprimir(duenho.getNombre() + " recibe " + (int)valorHipoteca + "€ pola hipoteca de " + getNombre() +
                ". Non pode recibir alugueres, nin edificar no grupo " + (this.grupo != null ? this.grupo.getColorGrupo() : "") + ".");
    }

    //Metodo para saber se a casilla está hipotecada
    public boolean estaHipotecada() {
        return hipotecada;
    }

    public Solares.DatosEdificios getDatosEdificios() {
        return datosEdificios;
    }

    public Grupo getGrupo() {
        return grupo;
    }

    public ArrayList<String> getIdsEdificiosCasilla() {
        return idsEdificiosCasilla;
    }

    public float getValorHipoteca() {
        return valorHipoteca;
    }

    //Metodo para anhadir ID de edificio á lista de IDs de edificios construídos nesta casilla
    public void anhadirIdEdificio(String idEdificio) {
        if (!this.idsEdificiosCasilla.contains(idEdificio)) {
            idsEdificiosCasilla.add(idEdificio);
        }
    }

    //Metodo para eliminar ID de edificio da lista de IDs de edificios construídos nesta casilla
    public void eliminarIdEdificio(String idEdificio) {
        idsEdificiosCasilla.remove(idEdificio);
    }

    // Implementación de evaluarCasilla sobreescrito de Casilla
    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero) {
        Jugador duenho = getDuenho();

        // Se non ten dono ou pertence á banca
        if (duenho == null || duenho == banca) {
            float precioCompra = Solares.obtenerPrecio(getNombre());
            Juego.getConsola().imprimir("O solar está dispoñible para comprar por " + (int)precioCompra + "€");
            return true;
        }

        //Si o dono é o propio xogador
        if (duenho.equals(actual)) {
            Juego.getConsola().imprimir("É o dono desta propiedade");
            return true;
        }

        //Se ten dono e non está hipotecado, págase alquiler
        if (!hipotecada) {
            float alquilerAPagar = Solares.calcularAlquiler(this);

            // Verificar se o dono ten o grupo enteiro para aplicar incremento
            if (this.grupo != null && this.grupo.esDuenhoGrupo(duenho) &&
                    this.datosEdificios != null && !this.datosEdificios.isTieneEdificios()) {
                alquilerAPagar *= 2;
                Juego.getConsola().imprimir("O dono ten todo o grupo " + this.grupo.getColorGrupo() + ", o aluguer dóbrase.");
            }

            Juego.getConsola().imprimir(actual.getNombre() + " debe pagar " + (int)alquilerAPagar + "€ de aluguer a " + duenho.getNombre());

            // Intentar pagar
            boolean pagoExitoso = actual.pagarJugador(duenho, alquilerAPagar, tablero);
            if (pagoExitoso) {
                // Rexistrar o cobro e o pago
                duenho.registrarCobroAlquiler(alquilerAPagar);
                actual.registrarPagoAlquiler(alquilerAPagar);
                return true;
            } else {
                actual.setUltimoCobraAlquiler(duenho); // Rexistramos o dono ao que non se puido pagar
                return false;
            }
        }

        //Se está hipotecado, non se paga alquiler
        Juego.getConsola().imprimir("O solar está hipotecado, non se paga aluguer.");
        return true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Solar {\n");
        sb.append("nome: '" ).append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append("',\n");
        sb.append("valor: '" ).append(getPrecioCompra()).append("',\n");
        sb.append("propietario: ").append(getDuenho() != null ? getDuenho().getNombre() : "Banca");
        sb.append("grupo: ").append(grupo != null ? grupo.getColorGrupo() : "null").append("',\n");
        sb.append("hipotecada: ").append(hipotecada).append("',\n");
        sb.append("\n}");
        return sb.toString();
    }
}
