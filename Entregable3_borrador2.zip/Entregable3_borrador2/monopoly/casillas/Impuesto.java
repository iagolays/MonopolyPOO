package monopoly.casillas;
import monopoly.*;
import partida.*;

public class Impuesto extends Casilla{

    private float cantidad; //Cantidad a pagar por caer en la casilla: el alquiler en solares/servicios/transportes o cantidads.
    
    //Constructor
    public Impuesto(String nombre, int posicion, float cantidad) {
        super(nombre, posicion);
        this.cantidad = cantidad;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("cantidad {\n");
        sb.append("nome: '").append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append(",\n");
        sb.append("cantidad: ").append(cantidad).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    //Metodo para pagar o imposto
    public boolean pagarcantidad(Jugador jugador, Tablero tablero) {

        Juego.getConsola().imprimir(jugador.getNombre() + " debe pagar un imposto de " + (int) cantidad + "€.");

        if (jugador.puedePagar(cantidad)) {
            jugador.sumarFortuna(-cantidad); // Restamos o imposto da fortuna do xogador
            jugador.registrarTasa(cantidad); // Rexistramos o gasto en impostos
            //Engádese ao parking
            Parking parking = encontrarParking(tablero);
            if (parking != null) {
                parking.anhadirAlBote(cantidad);
            }
            Juego.getConsola().imprimir("Imposto pagado. Jugador " + jugador.getNombre() + " agora ten " + (int) jugador.getFortuna() + "€.");
            return true;
        } else {
            //Non bancarrota automática
            jugador.sumarFortuna(-cantidad);
            Juego.getConsola().imprimir("\n" + jugador.getNombre() + " non pode pagar o imposto de " + (int) cantidad + "€.");
            Juego.getConsola().imprimir("Opcións dispoñibles:");
            Juego.getConsola().imprimir("   - 'hipotecar <casilla>' para obter diñeiro");
            Juego.getConsola().imprimir("   - 'acabar turno' para declararse en bancarrota");
            jugador.setUltimoCobraAlquiler(tablero.getBanca());
            return false;
        }
    }

    //Metodo para encontrar a casilla de parking no tablero
    private Parking encontrarParking(Tablero tablero){
        /// /Implementar a búsqueda da casilla de parking no tablero
        return null; // Non se atopou a casilla de parking
    }

    public float getCantidad() {
        return cantidad;
    }
}
