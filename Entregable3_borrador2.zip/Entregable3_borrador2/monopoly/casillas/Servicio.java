package monopoly.casillas;
import monopoly.*;
import partida.*;

public class Servicio extends Propiedad{
    //Constructor
    public Servicio(String nombre, int posicion, float precioCompra, Jugador duenho) {
        super(nombre, posicion, precioCompra, duenho);
    }

    @Override
    public boolean alquiler() {
        /// //Precísase a tirada dos dados para calcular o aluguer
        return false;
    }

    @Override
    public float valor() {
        return getPrecioCompra(); //O valor do servizo é o seu prezo de compra
    }

    @Override
    public boolean estaHipotecada() {
        // Os servizos non se poden hipotecar
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Servicio {\n");
        sb.append("nome: '" ).append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append("',\n");
        sb.append("precio: ").append(getPrecioCompra()).append("',\n");
        sb.append("propietario: ").append(getDuenho() != null ? getDuenho().getNombre() : "Banca");
        sb.append("\n}");
        return sb.toString();
    }

    //Metodo para calcular o aluguer en función do valor da tirada dos dados
    public float alquilerServicio(int valorTirada) {
        // En tu código original: tirada * Valor.FACTOR_SERVICIO * 4
        return valorTirada * Valor.FACTOR_SERVICIO * 4;
    }

    @Override
    public void hipotecar() {
        // Os servizos non se poden hipotecar
        Juego.getConsola().imprimir(this.getNombre() + " non se pode hipotecar.");
    }

    @Override
    public void deshipotecar() {
        // Os servizos non se poden deshipotecar
        Juego.getConsola().imprimir(this.getNombre() + " non se pode deshipotecar.");
    }
}
