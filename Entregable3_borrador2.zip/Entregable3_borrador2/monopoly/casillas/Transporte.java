package monopoly.casillas;
import monopoly.*;
import partida.*;

public class Transporte extends Propiedad{

    //Constructor
    public Transporte(String nombre, int posicion, float precioCompra, Jugador duenho) {
        super(nombre, posicion, precioCompra, duenho);
    }

    @Override
    public boolean alquiler() {
        /// //É o valor do imposto a menos que veña de cartas que se duplica
        return false;
    }

    @Override
    public float valor() {
        return getPrecioCompra(); //O valor do transporte é o seu prezo de compra
    }

    @Override
    public boolean estaHipotecada() {
        // Os transportes non se poden hipotecar
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Transporte {\n");
        sb.append("nome: '" ).append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append("',\n");
        sb.append("precio: ").append(getPrecioCompra()).append("',\n");
        sb.append("propietario: ").append(getDuenho() != null ? getDuenho().getNombre() : "Banca");
        sb.append("\n}");
        return sb.toString();
    }

    //Metodo para calcular o aluguer
    public float alquilerTransporte() {
        return Valor.TRANSPORTE_ALQUILER;
    }

    //Calculo do aluguer segundo se provén das cartas ou non
    public float calculoAlquilerTransporte(boolean desdeCarta) {
        float alquilerTransporte = this.alquilerTransporte();
        if (desdeCarta) {
            alquilerTransporte *= 2; //Dúas veces o aluguer se provén de cartas
        }
        return alquilerTransporte;
    }

    @Override
    public void hipotecar() {
        // Os transportes non se poden hipotecar
        Juego.getConsola().imprimir(this.getNombre() + " non se pode hipotecar.");
    }

    @Override
    public void deshipotecar() {
        // Os transportes non se poden deshipotecar
        Juego.getConsola().imprimir(this.getNombre() + " non se pode deshipotecar.");
    }
}
