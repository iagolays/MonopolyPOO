package monopoly.casillas;
import monopoly.*;
import partida.*;

public class CajaComunidad extends Accion{

    private CartasSuerte cartasSuerte; // Obxecto para xestionar as cartas

    //Constructor
    public CajaComunidad(String nombre, int posicion) {
        super(nombre, posicion);
        this.cartasSuerte = new CartasSuerte(); // Inicializar o obxecto de cartasSuerte
    }

    @Override
    public boolean ejecutarAccion(Jugador jugador, Tablero tablero) {
        //O xogador saca unha carta de caixa de comunidade e aplícase o efecto
        Juego.getConsola().imprimir(jugador.getNombre() + " cae en Caixa de Comunidade. Saca unha carta de Caixa de Comunidade:");

        //Executar a carta de caixa de comunidade
        cartasSuerte.sacarCartaComunidad(jugador, tablero);
        return !jugador.isEnBancarrota(); //devolve se o xogador queda en bancarrota ou non
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("CajaComunidad {\n");
        sb.append("nome: '").append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append("\n");
        sb.append("}");
        return sb.toString();
    }

    public CartasSuerte getCartasSuerte() {
        return cartasSuerte;
    }
}
