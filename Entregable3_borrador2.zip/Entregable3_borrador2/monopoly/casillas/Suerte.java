package monopoly.casillas;
import monopoly.*;
import partida.*;

import java.util.ArrayList;

public class Suerte extends Accion{

    private CartasSuerte cartasSuerte; // Obxecto para xestionar as cartas

    //Constructor
    public Suerte(String nombre, int posicion) {
        super(nombre, posicion);
        this.cartasSuerte = new CartasSuerte(); // Inicializar o obxecto de cartasSuerte
    }

    @Override
    public boolean ejecutarAccion(Jugador jugador, Tablero tablero) {
        //O xogador saca unha carta de sorte e aplícase o efecto
        Juego.getConsola().imprimir(jugador.getNombre() + " cae en Suerte. Saca unha carta de Suerte:");

        //Precisamos a lista de xogadores para algunhas cartas
        ArrayList<Jugador> jugadores = tablero.getJugadores();

        //Executar a carta de sorte
        cartasSuerte.sacarCartaSuerte(jugador, tablero, jugadores);
        return !jugador.isEnBancarrota(); //devolve se o xogador queda en bancarrota ou non
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Suerte {\n");
        sb.append("nome: '").append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append("\n");
        sb.append("}");
        return sb.toString();
    }

    public CartasSuerte getCartasSuerte() {
        return cartasSuerte;
    }
}
