package monopoly.Casilla;

import partida.Jugador;
import monopoly.Tablero;
import java.util.ArrayList;

public abstract class Accion extends Casilla {
    public Accion(String nombre, String tipo, int posicion) {
        super(nombre, tipo, posicion);
    }

    public Accion(String nombre, String tipo, int posicion, Jugador banca) {
        super(nombre, tipo, posicion, banca);
    }

    public Accion(String nombre, int posicion) {
        super(nombre, "accion", posicion);
    }

    public Accion(String nombre, int posicion, Jugador banca) {
        super(nombre, "accion", posicion, banca);
    }

    public abstract boolean accionAlCaer(Jugador jugador, Tablero tablero);

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean cartas) {
        return accionAlCaer(actual, tablero);
    }

    // Métodos auxiliares para acciones
    protected void pagarMultaParking(Jugador jugador, Tablero tablero, float cantidad) {
        if (jugador.puedePagar(cantidad)) {
            jugador.sumarFortuna(-cantidad);
            jugador.registrarTasa(cantidad);
            // Buscar parking y añadir al bote
            for (Casilla casilla : tablero.CasillasLineales()) {
                if (casilla instanceof Parking) {
                    ((Parking) casilla).sumarAlBote(cantidad);
                    break;
                }
            }
        } else {
            jugador.sumarFortuna(-cantidad);
            System.out.println(jugador.getNombre() + " no puede pagar " + (int)cantidad + "€.");
            System.out.println("Opciones disponibles:");
            System.out.println("   - 'hipotecar <casilla>' para obtener dinero");
            System.out.println("   - 'acabar turno' para declararse en bancarrota");
            jugador.setUltimoCobraAlquiler(tablero.getBanca());
        }
    }

    protected void pagarAosDemais(Jugador pagador, ArrayList<Jugador> jugadores, float cantidad, Tablero tablero) {
        int numJugadoresAPagar = 0;
        for (Jugador j : jugadores) {
            if (j != pagador && !j.isEnBancarrota()) {
                numJugadoresAPagar++;
            }
        }

        float total = numJugadoresAPagar * cantidad;

        if (pagador.puedePagar(total)) {
            for (Jugador j : jugadores) {
                if (j != pagador && !j.isEnBancarrota()) {
                    pagador.pagarJugador(j, cantidad, tablero);
                }
            }
        } else {
            pagador.sumarFortuna(-total);
            System.out.println("\n" + pagador.getNombre() + " no puede pagar " + (int)cantidad + "€.");
            System.out.println("Opciones disponibles:");
            System.out.println("   - 'hipotecar <casilla>' para obtener dinero");
            System.out.println("   - 'acabar turno' para declararse en bancarrota");
            pagador.setUltimoCobraAlquiler(tablero.getBanca());
        }
    }

    // Implementación de métodos abstractos de Casilla
    @Override
    public String infoCasilla() {
        return "{\n" +
                "tipo: " + getTipo() + ",\n" +
                "nombre: " + getNombre() + ",\n" +
                "jugadores: [" + getAvataresString() + "]\n" +
                "}";
    }

    @Override
    public String casEnVenta() {
        return ""; // Las casillas de acción no se pueden comprar
    }

    @Override
    public void comprarCasilla(Jugador solicitante, Jugador banca) {
        System.out.println("Non se pode comprar a casilla de acción " + getNombre());
    }

    @Override
    public void hipotecar(Jugador jugador) {
        System.out.println("Non se pode hipotecar a casilla de acción " + getNombre());
    }

    @Override
    public void deshipotecar(Jugador jugador) {
        System.out.println("Non se pode deshipotecar a casilla de acción " + getNombre());
    }
}