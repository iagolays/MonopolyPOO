package monopoly.Casilla;

import partida.Jugador;
import monopoly.Tablero;
import monopoly.Carta.CartaComunidad;
import monopoly.Carta.Balneario;
import monopoly.Carta.IrCarcelComunidad;
import monopoly.Carta.IrSalida;
import monopoly.Carta.DevolucionFacenda;
import monopoly.Carta.RetrocederSolar1;
import monopoly.Carta.IrSolar20;
import java.util.ArrayList;

public final class CajaComunidad extends Accion {
    private ArrayList<CartaComunidad> cartas;
    private int indiceActual;

    public CajaComunidad(int posicion) {
        super("Caja de Comunidad", "comunidad", posicion);
        inicializarCartas();
    }

    public CajaComunidad(int posicion, Jugador banca) {
        super("Caja de Comunidad", "comunidad", posicion, banca);
        inicializarCartas();
    }

    private void inicializarCartas() {
        cartas = new ArrayList<>();

        // Orden secuencial según Apéndice A
        cartas.add(new Balneario());       // Carta 1
        cartas.add(new IrCarcelComunidad());// Carta 2
        cartas.add(new IrSalida());        // Carta 3
        cartas.add(new DevolucionFacenda());// Carta 4
        cartas.add(new RetrocederSolar1());// Carta 5
        cartas.add(new IrSolar20());       // Carta 6

        indiceActual = 0;
    }

    @Override
    public boolean accionAlCaer(Jugador jugador, Tablero tablero) {
        System.out.println(jugador.getNombre() + " cae en Caja de Comunidad.");

        CartaComunidad carta = cartas.get(indiceActual);
        System.out.println("Carta de Comunidad: " + carta.getDescripcion());

        carta.accion(jugador, tablero, tablero.getJugadores());

        // Avanzar al siguiente índice, volver al inicio si llegamos al final
        indiceActual = (indiceActual + 1) % cartas.size();

        return !jugador.isEnBancarrota();
    }

    @Override
    public String toString() {
        return super.toString() + " [Acción: Caja Comunidad]";
    }
}