package monopoly.Casilla;

import partida.Jugador;
import java.util.ArrayList;

public class Grupo {
    // RELACIÓN DE COMPOSICIÓN REQUERIDA
    private ArrayList<Propiedad> miembros; // Grupo COMPONE Propiedades
    private String colorGrupo;

    public Grupo(String colorGrupo) {
        this.miembros = new ArrayList<>();
        this.colorGrupo = colorGrupo;
    }

    // Constructores para grupos específicos
    public Grupo(Propiedad prop1, Propiedad prop2, String colorGrupo) {
        this.miembros = new ArrayList<>();
        this.miembros.add(prop1);
        this.miembros.add(prop2);
        this.colorGrupo = colorGrupo;
        prop1.setGrupo(this);
        prop2.setGrupo(this);
    }

    public Grupo(Propiedad prop1, Propiedad prop2, Propiedad prop3, String colorGrupo) {
        this.miembros = new ArrayList<>();
        this.miembros.add(prop1);
        this.miembros.add(prop2);
        this.miembros.add(prop3);
        this.colorGrupo = colorGrupo;
        prop1.setGrupo(this);
        prop2.setGrupo(this);
        prop3.setGrupo(this);
    }

    // Métodos de gestión del grupo
    public void anhadirPropiedad(Propiedad propiedad) {
        if (propiedad != null && !miembros.contains(propiedad)) {
            miembros.add(propiedad);
            propiedad.setGrupo(this);
            System.out.println("Propiedad " + propiedad.getNombre() + " añadida al grupo " + colorGrupo);
        }
    }

    public boolean esDuenhoGrupo(Jugador jugador) {
        if (jugador == null || miembros.isEmpty()) return false;
        for (Propiedad prop : miembros) {
            if (!prop.perteneceAJugador(jugador)) return false;
        }
        return true;
    }

    //obtenerInfoEdificios
    public String obtenerInfoEdificios() {
        StringBuilder info = new StringBuilder();
        boolean primerElemento = true;
        boolean haySolares = false;

        for (Propiedad propiedad : miembros) {
            if (propiedad instanceof Solar) {
                Solar solar = (Solar) propiedad;
                if (!primerElemento) {
                    info.append(",\n");
                }
                primerElemento = false;
                haySolares = true;
                Jugador duenho = solar.getDuenho();

                info.append("{\n");
                info.append("propiedad: ").append(solar.getNombre()).append(",\n");

                if (duenho != null) {
                    // ✅ USAR LOS GETTERS CORRECTOS DE SOLAR
                    info.append("hoteles: ").append(solar.getNumHoteles()).append(",\n");
                    info.append("casas: ").append(solar.getNumCasas()).append(",\n");
                    info.append("piscinas: ").append(solar.getNumPiscinas()).append(",\n");
                    info.append("pistasDeDeporte: ").append(solar.getNumPistas()).append(",\n");
                } else {
                    info.append("hoteles: -,\n");
                    info.append("casas: -,\n");
                    info.append("piscinas: -,\n");
                    info.append("pistasDeDeporte: -,\n");
                }
                // ✅ LLAMAR AL MÉTODO calcularAlquiler() DE SOLAR
                float alquiler = solar.calcularAlquiler();
                info.append("alquiler: ").append((int) alquiler).append("\n");
                info.append("}");
            }
        }

        if (!haySolares) {
            return "Non hai solares neste grupo.";
        }
        return info.toString();
    }

    //obtenerInfoConstruccionPosible
    public String obtenerInfoConstruccionPosible(Jugador jugadorActual) {
        int casasDisponibles = 0;
        boolean puedeHotel = false;
        boolean puedePiscina = false;
        boolean puedePista = false;


        for (Propiedad propiedad : miembros) {
            if (propiedad instanceof Solar) {
                Solar solar = (Solar) propiedad;
                Jugador duenho = solar.getDuenho();

                if (duenho != null && duenho.equals(jugadorActual)) {
                    // Para la información de construcción, NO verificar posición del avatar
                    // Solo verificar reglas de construcción generales

                    // Casas disponibles
                    if (solar.getNumHoteles() == 0) {
                        casasDisponibles += (4 - solar.getNumCasas());
                    }

                    // Hotel disponible
                    if (solar.getNumCasas() == 4 && solar.getNumHoteles() == 0) {
                        puedeHotel = true;
                    }

                    // Piscina disponible
                    if (solar.getNumHoteles() == 1 && solar.getNumPiscinas() == 0) {
                        puedePiscina = true;
                    }

                    // Pista disponible
                    if (solar.getNumHoteles() == 1 && solar.getNumPiscinas() == 1 && solar.getNumPistas() == 0) {
                        puedePista = true;
                    }
                }
            }
        }

        StringBuilder info = new StringBuilder();
        ArrayList<String> disponibles = new ArrayList<>();

        if (casasDisponibles > 0) {
            disponibles.add("ata " + casasDisponibles + " casas");
        }
        if (puedeHotel) disponibles.add("un hotel");
        if (puedePiscina) disponibles.add("unha piscina");
        if (puedePista) disponibles.add("unha pista de deporte");

        if (disponibles.isEmpty()) {
            info.append("Xa non se poden construír máis edificios neste grupo.");
        } else {
            info.append("Aínda se poden edificar ");
            for (int i = 0; i < disponibles.size(); i++) {
                info.append(disponibles.get(i));
                if (i < disponibles.size() - 2) info.append(", ");
                else if (i == disponibles.size() - 2) info.append(" e ");
            }
            info.append(".");
        }

        return info.toString();
    }

    //Verificar si se puede construir en el grupo
    public boolean sePuedeConstruirEnGrupo(Jugador jugador, String tipoEdificio) {
        if (!esDuenhoGrupo(jugador)) {
            return false;
        }

        for (Propiedad propiedad : miembros) {
            if (propiedad instanceof Solar) {
                Solar solar = (Solar) propiedad;
                if (solar.puedeConstruir(jugador, tipoEdificio)) {
                    return true;
                }
            }
        }
        return false;
    }

    //Obtener solares donde se puede construir
    public ArrayList<Solar> obtenerSolaresParaConstruir(Jugador jugador, String tipoEdificio) {
        ArrayList<Solar> solaresDisponibles = new ArrayList<>();

        if (!esDuenhoGrupo(jugador)) {
            return solaresDisponibles;
        }

        for (Propiedad propiedad : miembros) {
            if (propiedad instanceof Solar) {
                Solar solar = (Solar) propiedad;
                if (solar.puedeConstruir(jugador, tipoEdificio)) {
                    solaresDisponibles.add(solar);
                }
            }
        }
        return solaresDisponibles;
    }

    // Método para calcular color según posición
    public static String calcularColor(Casilla propiedad) {
        int pos = propiedad.getPosicion();
        final String RESET = "\u001B[0m";

        final String MARRON = "\u001B[38;5;130m";
        final String AZUL_CL = "\u001B[36m";
        final String ROSA = "\u001B[35m";
        final String NARANJA = "\u001B[33m";
        final String ROJO = "\u001B[31m";
        final String AMARILLO = "\u001B[93m";
        final String VERDE = "\u001B[32m";
        final String AZUL_OSC = "\u001B[34m";

        if (pos == 1 || pos == 3)
            return MARRON + propiedad.getNombre() + RESET;
        if (pos == 6 || pos == 8 || pos == 9)
            return AZUL_CL + propiedad.getNombre() + RESET;
        if (pos == 11 || pos == 13 || pos == 14)
            return ROSA + propiedad.getNombre() + RESET;
        if (pos == 16 || pos == 18 || pos == 19)
            return NARANJA + propiedad.getNombre() + RESET;
        if (pos == 21 || pos == 23 || pos == 24)
            return ROJO + propiedad.getNombre() + RESET;
        if (pos == 26 || pos == 27 || pos == 29)
            return AMARILLO + propiedad.getNombre() + RESET;
        if (pos == 31 || pos == 32 || pos == 34)
            return VERDE + propiedad.getNombre() + RESET;
        if (pos == 37 || pos == 39)
            return AZUL_OSC + propiedad.getNombre() + RESET;

        return propiedad.getNombre();
    }

    public String obtenerColor() {
        switch (this.colorGrupo.toLowerCase()) {
            case "marrón":
            case "marron":
            case "brown":
                return "\u001B[38;5;130m";
            case "azul_claro":
            case "azul claro":
            case "light_blue":
                return "\u001B[36m";
            case "rosa":
            case "pink":
                return "\u001B[35m";
            case "naranja":
            case "orange":
                return "\u001B[33m";
            case "rojo":
            case "red":
                return "\u001B[31m";
            case "amarillo":
            case "yellow":
                return "\u001B[93m";
            case "verde":
            case "green":
                return "\u001B[32m";
            case "azul_oscuro":
            case "azul oscuro":
            case "dark blue":
                return "\u001B[34m";
            default:
                return "\u001B[97m";
        }
    }

    //Verificar si alguna propiedad del grupo está hipotecada
    public boolean tieneAlgunaHipoteca() {
        for (Propiedad propiedad : miembros) {
            if (propiedad.isHipotecada()) {
                return true;
            }
        }
        return false;
    }

    //Obtener número total de edificios en el grupo
    public int getTotalEdificios() {
        int total = 0;
        for (Propiedad propiedad : miembros) {
            if (propiedad instanceof Solar) {
                Solar solar = (Solar) propiedad;
                total += solar.getNumCasas() + solar.getNumHoteles() +
                        solar.getNumPiscinas() + solar.getNumPistas();
            }
        }
        return total;
    }

    // Getters
    public ArrayList<Propiedad> getMiembros() {
        return miembros;
    }

    public String getColorGrupo() {
        return colorGrupo;
    }

    @Override
    public String toString() {
        return "Grupo{color='" + colorGrupo + "', propiedades=" + miembros.size() + "}";
    }
}