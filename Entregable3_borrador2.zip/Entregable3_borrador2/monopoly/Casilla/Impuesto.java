package monopoly.Casilla;

import partida.Jugador;
import monopoly.Tablero;

public class Impuesto extends Casilla {
    private float monto;

    public Impuesto(String nombre, int posicion, float monto) {
        super(nombre, "impuesto", posicion);
        this.monto = monto;
    }

    public Impuesto(String nombre, int posicion, float monto, Jugador banca) {
        super(nombre, "impuesto", posicion, banca);
        this.monto = monto;
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean cartas) {
        if (actual.puedePagar(monto)) {
            actual.sumarFortuna(-monto);
            actual.registrarTasa(monto);
            // Añadir al parking
            for (Casilla casilla : tablero.CasillasLineales()) {
                if (casilla instanceof Parking) {
                    ((Parking) casilla).sumarAlBote(monto);
                    System.out.println("Impuesto de " + (int)monto + "€ añadido al Parking. Bote actual: " + (int)((Parking) casilla).getBote() + "€");
                    break;
                }
            }
            return true;
        } else {
            actual.sumarFortuna(-monto);
            System.out.println("\n" + actual.getNombre() + " no puede pagar el impuesto de " + (int)monto + "€.");
            System.out.println("Opciones disponibles:");
            System.out.println("   - 'hipotecar <casilla>' para obtener dinero");
            System.out.println("   - 'acabar turno' para declararse en bancarrota");
            actual.setUltimoCobraAlquiler(tablero.getBanca());
            return false;
        }
    }

    public float getMonto() {
        return monto;
    }

    @Override
    public String infoCasilla() {
        return "{\n" +
                "tipo: impuesto,\n" +
                "nombre: " + getNombre() + ",\n" +
                "a pagar: " + (int)monto + "\n" +
                "}";
    }

    @Override
    public String casEnVenta() {
        return ""; // Los impuestos no se pueden comprar
    }

    @Override
    public void comprarCasilla(Jugador solicitante, Jugador banca) {
        System.out.println("Non se pode comprar a casilla de imposto " + getNombre());
    }

    @Override
    public void hipotecar(Jugador jugador) {
        System.out.println("Non se pode hipotecar a casilla de imposto " + getNombre());
    }

    @Override
    public void deshipotecar(Jugador jugador) {
        System.out.println("Non se pode deshipotecar a casilla de imposto " + getNombre());
    }

    @Override
    public String toString() {
        return super.toString() + " [Impuesto: " + (int)monto + "€]";
    }
}