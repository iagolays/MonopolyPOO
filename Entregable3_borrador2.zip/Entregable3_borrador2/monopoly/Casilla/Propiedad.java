package monopoly.Casilla;

import partida.Jugador;
import monopoly.Tablero;
import java.util.ArrayList;

public abstract class Propiedad extends Casilla {
    protected float valor;
    protected boolean hipotecada;
    protected Grupo grupo;
    protected float hipoteca;
    protected float impuesto;
    protected ArrayList<String> idsEdificiosCasilla;

    public Propiedad(String nombre, String tipo, int posicion, float valor, float impuesto) {
        super(nombre, tipo, posicion);
        this.valor = valor;
        this.impuesto = impuesto;
        this.hipotecada = false;
        this.grupo = null;
        this.hipoteca = valor / 2;
        this.idsEdificiosCasilla = new ArrayList<>();
    }

    public Propiedad(String nombre, String tipo, int posicion, float valor, Jugador banca) {
        this(nombre, tipo, posicion, valor, 0);
        this.duenho = banca;
    }

    public boolean perteneceAJugador(Jugador jugador) {
        return duenho != null && duenho.equals(jugador);
    }

    // MÉTODOS ABSTRACTOS REQUERIDOS
    public abstract boolean alquiler();
    public abstract float valor();

    // Método comprar requerido
    public void comprar(Jugador jugador) {
        if (duenho == null && jugador.puedePagar(valor)) {
            jugador.sumarFortuna(-valor);
            jugador.sumarInversion(valor);
            this.duenho = jugador;
            jugador.anhadirPropiedad(this);
            System.out.println("El jugador " + jugador.getNombre() + " compra la casilla " + this.nombre +
                    " por " + (int)this.valor + "€. Su fortuna actual es " + (int)jugador.getFortuna() + "€.");
        } else if (duenho != null) {
            System.out.println("La casilla " + this.nombre + " ya tiene propietario: " + duenho.getNombre());
        } else {
            System.out.println(jugador.getNombre() + " no tiene dinero suficiente para comprar " + this.nombre);
        }
    }

    // Implementación de métodos abstractos de Casilla
    @Override
    public String casEnVenta() {
        Jugador duenhoActual = this.getDuenho();
        boolean disponible = (duenhoActual == null) ||
                ("Banca".equalsIgnoreCase(duenhoActual.getNombre()));

        if (disponible && ("solar".equalsIgnoreCase(tipo) ||
                "transporte".equalsIgnoreCase(tipo) ||
                "servicio".equalsIgnoreCase(tipo))) {
            return "{\n" +
                    "nombre: " + this.nombre + ",\n" +
                    "tipo: " + this.tipo +
                    (grupo != null ? ",\ngrupo: " + grupo.getColorGrupo() : "") +
                    ",\nvalor: " + (int)this.valor + "\n" +
                    "}";
        }
        return "";
    }

    @Override
    public void comprarCasilla(Jugador solicitante, Jugador banca) {
        Jugador duenhoActual = this.getDuenho();
        boolean propiedadDisponible = false;

        if (duenhoActual == null) {
            propiedadDisponible = true;
        } else if (banca != null && duenhoActual.equals(banca)) {
            propiedadDisponible = true;
        } else if ("Banca".equalsIgnoreCase(duenhoActual.getNombre())) {
            propiedadDisponible = true;
        }

        if (!propiedadDisponible) {
            System.out.println("La casilla " + this.nombre + " ya tiene propietario: " + duenhoActual.getNombre());
            return;
        }

        if (!solicitante.puedePagar(this.valor)) {
            System.out.println(solicitante.getNombre() +
                    " no tiene dinero suficiente para comprar " + this.nombre +
                    " (" + (int)this.valor + "€). Fortuna actual: " +
                    (int)solicitante.getFortuna() + "€.");
            return;
        }

        // Realizar la compra
        solicitante.sumarFortuna(-this.valor);
        solicitante.sumarInversion(this.valor);
        this.duenho = solicitante;
        solicitante.anhadirPropiedad(this);

        System.out.println(solicitante.getNombre() + " compra " +
                this.nombre + " por " + (int)this.valor + "€. Fortuna actual: " +
                (int)solicitante.getFortuna() + "€.");


    }

    // Métodos para gestión de pagos
    protected boolean evaluarPago(Jugador actual, Jugador banca, Tablero tablero, float cantidad) {
        boolean resultado = actual.pagarJugador(duenho, cantidad, tablero);
        if (!resultado) {
            if (duenho != banca && duenho != null) {
                actual.setUltimoCobraAlquiler(this.duenho);
            }
            return false;
        } else {
            registrarAlquilerCobrado(cantidad);
            if (duenho != null) {
                duenho.registrarCobroAlquiler(cantidad);
            }
            actual.registrarPagoAlquiler(cantidad);
        }
        return true;
    }

    @Override
    public void hipotecar(Jugador jugador) {
        if (!hipotecada && duenho != null && duenho.equals(jugador)) {
            hipotecada = true;
            jugador.sumarFortuna(hipoteca);
            jugador.anhadirHipoteca(this);
            System.out.println(jugador.getNombre() + " recibe " + (int)hipoteca + "€ por la hipoteca de " + nombre);
        }
    }

    @Override
    public void deshipotecar(Jugador jugador) {
        if (hipotecada && perteneceAJugador(jugador)) {
            if (jugador.puedePagar(hipoteca)) {
                hipotecada = false;
                jugador.sumarFortuna(-hipoteca);
                jugador.eliminarHipoteca(this);
                System.out.println(jugador.getNombre() + " paga " + (int)hipoteca + "€ por deshipotecar " + nombre);
            }
        }
    }

    // Sobrescribir métodos de Casilla
    @Override
    public boolean isHipotecada() {
        return hipotecada;
    }

    public void setHipotecada(boolean hipotecada) {
        this.hipotecada = hipotecada;
    }

    @Override
    public Grupo getGrupo() {
        return grupo;
    }

    public void setGrupo(Grupo grupo) {
        this.grupo = grupo;
    }

    @Override
    public float getValor() {
        return valor;
    }

    public void sumarValor(float suma) {
        this.valor += suma;
    }

    @Override
    public ArrayList<String> getIdsEdificiosCasilla() {
        return idsEdificiosCasilla;
    }

    @Override
    public void anhadirIdEdificio(String idEdificio) {
        if (!idsEdificiosCasilla.contains(idEdificio)) {
            idsEdificiosCasilla.add(idEdificio);
        }
    }

    @Override
    public void eliminarIdEdificio(String idEdificio) {
        idsEdificiosCasilla.remove(idEdificio);
    }

    // Getters adicionales
    public float getHipoteca() {
        return hipoteca;
    }

    public float getImpuesto() {
        return impuesto;
    }
}