package monopoly.Casilla;

import partida.Jugador;
import monopoly.Tablero;
import monopoly.Valor;

public final class Transporte extends Propiedad {
    public Transporte(String nombre, int posicion, float valor) {
        super(nombre, "transporte", posicion, valor, Valor.TRANSPORTE_ALQUILER);
    }

    public Transporte(String nombre, int posicion, float valor, Jugador banca) {
        super(nombre, "transporte", posicion, valor, banca);
    }

    @Override
    public boolean alquiler() {
        return true;
    }

    @Override
    public float valor() {
        return valor;
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean cartas) {
        if (duenho == null || duenho == banca) {
            System.out.println("O transporte está dispoñible para comprar por " + (int)valor + "€");
            return true;
        } else if (duenho == actual) {
            System.out.println(actual.getNombre() + " é o dono deste transporte");
            return true;
        } else if (!hipotecada) {
            float alquilerTransporte = this.impuesto;
            if (cartas) {
                alquilerTransporte *= 2;
            }
            System.out.println(actual.getNombre() + " debe pagar " + (int)alquilerTransporte + "€ de aluguer a " + duenho.getNombre());
            boolean pagoExitoso = evaluarPago(actual, banca, tablero, alquilerTransporte);
            if (!pagoExitoso && duenho != banca) {
                actual.setUltimoCobraAlquiler(this.duenho);
            }
            return pagoExitoso;
        }
        return true;
    }

    @Override
    public String infoCasilla() {
        return "{\n" +
                "tipo: transporte,\n" +
                "nombre: " + getNombre() + ",\n" +
                "propietario: " + (getDuenho() != null ? getDuenho().getNombre() : "Banca") + ",\n" +
                "valor: " + (int)getValor() + ",\n" +
                "alquiler: " + (int)getImpuesto() + "\n" +
                "}";
    }

    @Override
    public String toString() {
        return super.toString() + " [Transporte, Valor: " + (int)valor + "€]";
    }
}