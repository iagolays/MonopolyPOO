package monopoly.Casilla;

import partida.Jugador;
import monopoly.Tablero;
import monopoly.Valor;

public final class Servicio extends Propiedad {
    public Servicio(String nombre, int posicion, float valor) {
        super(nombre, "servicio", posicion, valor, 0);
    }

    public Servicio(String nombre, int posicion, float valor, Jugador banca) {
        super(nombre, "servicio", posicion, valor, banca);
    }

    @Override
    public boolean alquiler() {
        return true;
    }

    @Override
    public float valor() {
        return valor;
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean cartas) {
        if (duenho == null || duenho == banca) {
            System.out.println("O servizo " + this.nombre + " está dispoñible para comprar por " + (int)this.valor + "€");
            return true;
        } else if (duenho == actual) {
            System.out.println("É o dono deste servizo");
            return true;
        } else if (!hipotecada) {
            float pago = tirada * Valor.FACTOR_SERVICIO * 4;
            System.out.println(actual.getNombre() + " debe pagar " + (int)pago + "€ de aluguer a " + duenho.getNombre());
            boolean pagoExitoso = evaluarPago(actual, banca, tablero, pago);
            if (!pagoExitoso && duenho != banca) {
                actual.setUltimoCobraAlquiler(this.duenho);
            }
            return pagoExitoso;
        }
        return true;
    }

    @Override
    public String infoCasilla() {
        return "{\n" +
                "tipo: servicio,\n" +
                "nombre: " + getNombre() + ",\n" +
                "propietario: " + (getDuenho() != null ? getDuenho().getNombre() : "Banca") + ",\n" +
                "valor: " + (int)getValor() + "\n" +
                "}";
    }

    @Override
    public String toString() {
        return super.toString() + " [Servicio, Valor: " + (int)valor + "€]";
    }
}