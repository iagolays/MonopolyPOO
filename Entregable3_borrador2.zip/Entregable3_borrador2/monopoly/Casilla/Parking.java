package monopoly.Casilla;

import partida.Jugador;
import monopoly.Tablero;

public final class Parking extends Accion {
    private float bote;

    public Parking(int posicion) {
        super("Parking", "parking", posicion);
        this.bote = 0;
    }

    public Parking(int posicion, Jugador banca) {
        super("Parking", "parking", posicion, banca);
        this.bote = 0;
    }

    @Override
    public boolean accionAlCaer(Jugador jugador, Tablero tablero) {
        System.out.println(jugador.getNombre() + " cae en Parking.");

        if (bote > 0) {
            System.out.println(jugador.getNombre() + " cobra el bote del Parking: " + (int)bote + "€.");
            jugador.sumarFortuna(bote);
            jugador.registrarPremio(bote);
            bote = 0;
        } else {
            System.out.println("El Parking está vacío.");
        }

        return true;
    }

    public void sumarAlBote(float cantidad) {
        if (cantidad > 0) {
            bote += cantidad;
            System.out.println("Se añade " + (int)cantidad + "€ al Parking. Bote actual: " + (int)bote + "€.");
        }
    }

    public float getBote() {
        return bote;
    }

    @Override
    public String infoCasilla() {
        return "{\n" +
                "tipo: parking,\n" +
                "nombre: " + getNombre() + ",\n" +
                "bote: " + (int)bote + ",\n" +
                "jugadores: [" + getAvataresString() + "]\n" +
                "}";
    }

    @Override
    public String toString() {
        return super.toString() + " [Parking, Bote: " + (int)bote + "€]";
    }
}