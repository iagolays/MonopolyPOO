package monopoly.Casilla.Edificio;

import partida.Jugador;
import monopoly.Casilla.Solar;

public class PistaDeporte extends Edificio {
    public PistaDeporte(String id, float coste, float precioVenta, float alquiler,
                        Jugador propietario, String idSolar) {
        super(id, "pista", coste, precioVenta, alquiler, propietario, idSolar);
    }

    @Override
    public String getDescripcion() {
        return "Pista de deporte en " + getIdSolar();
    }

    @Override
    public boolean puedeConstruirseEn(Solar solar) {
        int hotelesActuales = solar.contarEdificiosPorTipo("hotel");
        int piscinasActuales = solar.contarEdificiosPorTipo("piscina");
        int pistasActuales = solar.contarEdificiosPorTipo("pista");

        if (hotelesActuales < 1) {
            System.out.println("No se puede construir una pista en " + solar.getNombre() + " porque no se dispone de un hotel.");
            return false;
        }
        if (piscinasActuales < 1) {
            System.out.println("No se puede construir una pista en " + solar.getNombre() + " porque no se dispone de una piscina.");
            return false;
        }
        if (pistasActuales >= 1) {
            System.out.println("No se puede construir más de 1 pista en " + solar.getNombre() + ".");
            return false;
        }
        return true;
    }
}