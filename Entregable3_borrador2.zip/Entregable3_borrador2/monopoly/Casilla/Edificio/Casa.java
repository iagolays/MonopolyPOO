package monopoly.Casilla.Edificio;

import partida.Jugador;
import monopoly.Casilla.Solar;

public class Casa extends Edificio {
    public Casa(String id, float coste, float precioVenta, float alquiler,
                Jugador propietario, String idSolar) {
        super(id, "casa", coste, precioVenta, alquiler, propietario, idSolar);
    }

    @Override
    public String getDescripcion() {
        return "Casa residencial en " + getIdSolar();
    }

    @Override
    public boolean puedeConstruirseEn(Solar solar) {
        int casasActuales = solar.contarEdificiosPorTipo("casa");
        int hotelesActuales = solar.contarEdificiosPorTipo("hotel");

        if (casasActuales >= 4) {
            System.out.println("No se pueden construir más de 4 casas en " + solar.getNombre() + ".");
            return false;
        }
        if (hotelesActuales >= 1) {
            System.out.println("No se pueden construir casas en " + solar.getNombre() + " porque ya hay un hotel.");
            return false;
        }
        return true;
    }
}