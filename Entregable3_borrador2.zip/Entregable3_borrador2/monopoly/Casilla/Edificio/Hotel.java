package monopoly.Casilla.Edificio;

import partida.Jugador;
import monopoly.Casilla.Solar;

public class Hotel extends Edificio {
    public Hotel(String id, float coste, float precioVenta, float alquiler,
                 Jugador propietario, String idSolar) {
        super(id, "hotel", coste, precioVenta, alquiler, propietario, idSolar);
    }

    @Override
    public String getDescripcion() {
        return "Hotel de lujo en " + getIdSolar();
    }

    @Override
    public boolean puedeConstruirseEn(Solar solar) {
        int casasActuales = solar.contarEdificiosPorTipo("casa");
        int hotelesActuales = solar.contarEdificiosPorTipo("hotel");

        if (casasActuales < 4) {
            System.out.println("No se puede construir un hotel en " + solar.getNombre() + " porque no hay 4 casas.");
            return false;
        }
        if (hotelesActuales >= 1) {
            System.out.println("No se puede construir más de 1 hotel en " + solar.getNombre() + ".");
            return false;
        }
        return true;
    }
}