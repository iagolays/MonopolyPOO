package monopoly.Casilla.Edificio;

import partida.Jugador;
import monopoly.Casilla.Solar;

public class Piscina extends Edificio {
    public Piscina(String id, float coste, float precioVenta, float alquiler,
                   Jugador propietario, String idSolar) {
        super(id, "piscina", coste, precioVenta, alquiler, propietario, idSolar);
    }

    @Override
    public String getDescripcion() {
        return "Piscina olímpica en " + getIdSolar();
    }

    @Override
    public boolean puedeConstruirseEn(Solar solar) {
        int hotelesActuales = solar.contarEdificiosPorTipo("hotel");
        int piscinasActuales = solar.contarEdificiosPorTipo("piscina");

        if (hotelesActuales < 1) {
            System.out.println("No se puede construir una piscina en " + solar.getNombre() + " porque no se dispone de un hotel.");
            return false;
        }
        if (piscinasActuales >= 1) {
            System.out.println("No se puede construir más de 1 piscina en " + solar.getNombre() + ".");
            return false;
        }
        return true;
    }
}