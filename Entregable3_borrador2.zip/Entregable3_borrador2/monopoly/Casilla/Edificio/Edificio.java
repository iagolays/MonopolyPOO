package monopoly.Casilla.Edificio;

import partida.Jugador;
import monopoly.Casilla.Solar;

public abstract class Edificio {
    private String id;
    private String tipo;
    private float coste;
    private float precioVenta;
    private float alquiler;
    private Jugador propietario;
    private String idSolar;

    public Edificio(String id, String tipo, float coste, float precioVenta, float alquiler,
                    Jugador propietario, String idSolar) {
        this.id = id;
        this.tipo = tipo;
        this.coste = coste;
        this.precioVenta = precioVenta;
        this.alquiler = alquiler;
        this.propietario = propietario;
        this.idSolar = idSolar;
    }

    // Métodos abstractos
    public abstract String getDescripcion();
    public abstract boolean puedeConstruirseEn(Solar solar);

    // Getters y setters
    public String getId() { return id; }
    public String getTipo() { return tipo; }
    public float getCoste() { return coste; }
    public float getPrecioVenta() { return precioVenta; }
    public float getAlquiler() { return alquiler; }
    public Jugador getPropietario() { return propietario; }
    public String getIdSolar() { return idSolar; }

    public void setPropietario(Jugador propietario) {
        this.propietario = propietario;
    }

    @Override
    public String toString() {
        return tipo + "-" + id;
    }

    public String infoDetallada() {
        return "{\n" +
                "  id: " + id + ",\n" +
                "  tipo: " + tipo + ",\n" +
                "  solar: " + idSolar + ",\n" +
                "  propietario: " + (propietario != null ? propietario.getNombre() : "ninguno") + ",\n" +
                "  coste: " + (int)coste + ",\n" +
                "  precioVenta: " + (int)precioVenta + ",\n" +
                "  alquiler: " + (int)alquiler + "\n" +
                "}";
    }
}