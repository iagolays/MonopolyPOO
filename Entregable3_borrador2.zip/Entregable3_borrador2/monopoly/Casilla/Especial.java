package monopoly.Casilla;

import partida.Jugador;
import monopoly.Tablero;
import monopoly.Valor;

public class Especial extends Casilla {
    private String tipoEspecial;

    public Especial(String nombre, int posicion, String tipoEspecial) {
        super(nombre, "especial", posicion);
        this.tipoEspecial = tipoEspecial;
    }

    public Especial(String nombre, int posicion, String tipoEspecial, Jugador banca) {
        super(nombre, "especial", posicion, banca);
        this.tipoEspecial = tipoEspecial;
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean cartas) {
        switch (this.tipoEspecial.toLowerCase()) {
            case "parking":
                System.out.println(actual.getNombre() + " cae en Parking.");
                // La funcionalidad completa está en la clase Parking
                return true;
            case "ircarcel":
                System.out.println(actual.getNombre() + " vai directamente ao cárcere.");
                actual.encarcelar(tablero.getPosiciones(), tablero);
                return true;
            case "carcel":
                System.out.println(actual.getNombre() + " está de visita no cárcere.");
                return true;
            case "salida":
                System.out.println(actual.getNombre() + " pasa por Salida e recibe " + (int)Valor.SUMA_VUELTA + "€.");
                actual.sumarFortuna(Valor.SUMA_VUELTA);
                actual.registrarPasoSalida(Valor.SUMA_VUELTA);
                return true;
            default:
                System.out.println("Casilla especial descoñecida: " + tipoEspecial);
                return true;
        }
    }

    public String getTipoEspecial() {
        return tipoEspecial;
    }

    @Override
    public String infoCasilla() {
        StringBuilder info = new StringBuilder();
        info.append("{\n");
        info.append("tipo: ").append(tipoEspecial).append(",\n");
        info.append("nombre: ").append(getNombre()).append(",\n");
        if ("carcel".equalsIgnoreCase(tipoEspecial)) {
            info.append("salir: ").append((int)Valor.CARCEL_SALIDA).append(",\n");
        }
        info.append("jugadores: [").append(getAvataresString()).append("]\n");
        info.append("}");
        return info.toString();
    }

    @Override
    public String casEnVenta() {
        return ""; // Las casillas especiales no se pueden comprar
    }

    @Override
    public void comprarCasilla(Jugador solicitante, Jugador banca) {
        System.out.println("Non se pode comprar a casilla especial " + getNombre());
    }

    @Override
    public void hipotecar(Jugador jugador) {
        System.out.println("Non se pode hipotecar a casilla especial " + getNombre());
    }

    @Override
    public void deshipotecar(Jugador jugador) {
        System.out.println("Non se pode deshipotecar a casilla especial " + getNombre());
    }

    @Override
    public String toString() {
        return super.toString() + " [Tipo: " + tipoEspecial + "]";
    }
}