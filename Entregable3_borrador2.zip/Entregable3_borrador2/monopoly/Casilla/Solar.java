package monopoly.Casilla;

import partida.Jugador;
import monopoly.Tablero;
import monopoly.Valor;
import monopoly.Casilla.Edificio.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

public final class Solar extends Propiedad {
    // CLASE INTERNA PARA DATOS DEL SOLAR (igual que antes)
    public static class DatosSolar {
        private float precio;
        private float alquiler;
        private float valorCasa;
        private float valorHotel;
        private float valorPiscina;
        private float valorPista;
        private float alquilerCasa;
        private float alquilerHotel;
        private float alquilerPiscina;
        private float alquilerPista;

        public DatosSolar(float precio, float alquiler, float valorCasa, float valorHotel,
                          float valorPiscina, float valorPista, float alquilerCasa,
                          float alquilerHotel, float alquilerPiscina, float alquilerPista) {
            this.precio = precio;
            this.alquiler = alquiler;
            this.valorCasa = valorCasa;
            this.valorHotel = valorHotel;
            this.valorPiscina = valorPiscina;
            this.valorPista = valorPista;
            this.alquilerCasa = alquilerCasa;
            this.alquilerHotel = alquilerHotel;
            this.alquilerPiscina = alquilerPiscina;
            this.alquilerPista = alquilerPista;
        }

        // Getters
        public float getPrecio() { return precio; }
        public float getAlquiler() { return alquiler; }
        public float getValorCasa() { return valorCasa; }
        public float getValorHotel() { return valorHotel; }
        public float getValorPiscina() { return valorPiscina; }
        public float getValorPista() { return valorPista; }
        public float getAlquilerCasa() { return alquilerCasa; }
        public float getAlquilerHotel() { return alquilerHotel; }
        public float getAlquilerPiscina() { return alquilerPiscina; }
        public float getAlquilerPista() { return alquilerPista; }
    }

    // CLASE INTERNA PARA DATOS DE EDIFICIOS (simplificada)
    public static class DatosEdificios {
        private int numCasas;
        private int numHoteles;
        private int numPiscinas;
        private int numPistas;

        public DatosEdificios() {
            this.numCasas = 0;
            this.numHoteles = 0;
            this.numPiscinas = 0;
            this.numPistas = 0;
        }

        public void actualizarDesdeEdificios(ArrayList<Edificio> edificios) {
            numCasas = 0;
            numHoteles = 0;
            numPiscinas = 0;
            numPistas = 0;

            for (Edificio edificio : edificios) {
                switch (edificio.getTipo().toLowerCase()) {
                    case "casa": numCasas++; break;
                    case "hotel": numHoteles++; break;
                    case "piscina": numPiscinas++; break;
                    case "pista": numPistas++; break;
                }
            }
        }

        public int getNumCasas() { return numCasas; }
        public int getNumHoteles() { return numHoteles; }
        public int getNumPiscinas() { return numPiscinas; }
        public int getNumPistas() { return numPistas; }

        public boolean tieneEdificios() {
            return (numCasas + numHoteles + numPiscinas + numPistas) > 0;
        }
    }

    // MAPA ESTÁTICO CON TODOS LOS DATOS DE SOLARES (igual que antes)
    private static final Map<String, DatosSolar> DATOS_SOLARES = new HashMap<>();

    // CONTADOR ESTÁTICO PARA IDs ÚNICOS
    private static int contadorIdsEdificios = 1;

    static {
        // Inicializar todos los solares (igual que tu código)
        DATOS_SOLARES.put("solar1", new DatosSolar(Valor.SOLAR1_PRECIO, Valor.SOLAR1_ALQUILER,
                Valor.SOLAR1_PRECIO_CASA, Valor.SOLAR1_PRECIO_HOTEL, Valor.SOLAR1_PRECIO_PISCINA,
                Valor.SOLAR1_PRECIO_PISTA, Valor.SOLAR1_ALQUILER_CASA, Valor.SOLAR1_ALQUILER_HOTEL,
                Valor.SOLAR1_ALQUILER_PISCINA, Valor.SOLAR1_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar2", new DatosSolar(Valor.SOLAR2_PRECIO, Valor.SOLAR2_ALQUILER,
                Valor.SOLAR2_PRECIO_CASA, Valor.SOLAR2_PRECIO_HOTEL, Valor.SOLAR2_PRECIO_PISCINA,
                Valor.SOLAR2_PRECIO_PISTA, Valor.SOLAR2_ALQUILER_CASA, Valor.SOLAR2_ALQUILER_HOTEL,
                Valor.SOLAR2_ALQUILER_PISCINA, Valor.SOLAR2_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar3", new DatosSolar(Valor.SOLAR3_PRECIO, Valor.SOLAR3_ALQUILER,
                Valor.SOLAR3_PRECIO_CASA, Valor.SOLAR3_PRECIO_HOTEL, Valor.SOLAR3_PRECIO_PISCINA,
                Valor.SOLAR3_PRECIO_PISTA, Valor.SOLAR3_ALQUILER_CASA, Valor.SOLAR3_ALQUILER_HOTEL,
                Valor.SOLAR3_ALQUILER_PISCINA, Valor.SOLAR3_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar4", new DatosSolar(Valor.SOLAR4_PRECIO, Valor.SOLAR4_ALQUILER,
                Valor.SOLAR4_PRECIO_CASA, Valor.SOLAR4_PRECIO_HOTEL, Valor.SOLAR4_PRECIO_PISCINA,
                Valor.SOLAR4_PRECIO_PISTA, Valor.SOLAR4_ALQUILER_CASA, Valor.SOLAR4_ALQUILER_HOTEL,
                Valor.SOLAR4_ALQUILER_PISCINA, Valor.SOLAR4_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar5", new DatosSolar(Valor.SOLAR5_PRECIO, Valor.SOLAR5_ALQUILER,
                Valor.SOLAR5_PRECIO_CASA, Valor.SOLAR5_PRECIO_HOTEL, Valor.SOLAR5_PRECIO_PISCINA,
                Valor.SOLAR5_PRECIO_PISTA, Valor.SOLAR5_ALQUILER_CASA, Valor.SOLAR5_ALQUILER_HOTEL,
                Valor.SOLAR5_ALQUILER_PISCINA, Valor.SOLAR5_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar6", new DatosSolar(Valor.SOLAR6_PRECIO, Valor.SOLAR6_ALQUILER,
                Valor.SOLAR6_PRECIO_CASA, Valor.SOLAR6_PRECIO_HOTEL, Valor.SOLAR6_PRECIO_PISCINA,
                Valor.SOLAR6_PRECIO_PISTA, Valor.SOLAR6_ALQUILER_CASA, Valor.SOLAR6_ALQUILER_HOTEL,
                Valor.SOLAR6_ALQUILER_PISCINA, Valor.SOLAR6_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar7", new DatosSolar(Valor.SOLAR7_PRECIO, Valor.SOLAR7_ALQUILER,
                Valor.SOLAR7_PRECIO_CASA, Valor.SOLAR7_PRECIO_HOTEL, Valor.SOLAR7_PRECIO_PISCINA,
                Valor.SOLAR7_PRECIO_PISTA, Valor.SOLAR7_ALQUILER_CASA, Valor.SOLAR7_ALQUILER_HOTEL,
                Valor.SOLAR7_ALQUILER_PISCINA, Valor.SOLAR7_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar8", new DatosSolar(Valor.SOLAR8_PRECIO, Valor.SOLAR8_ALQUILER,
                Valor.SOLAR8_PRECIO_CASA, Valor.SOLAR8_PRECIO_HOTEL, Valor.SOLAR8_PRECIO_PISCINA,
                Valor.SOLAR8_PRECIO_PISTA, Valor.SOLAR8_ALQUILER_CASA, Valor.SOLAR8_ALQUILER_HOTEL,
                Valor.SOLAR8_ALQUILER_PISCINA, Valor.SOLAR8_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar9", new DatosSolar(Valor.SOLAR9_PRECIO, Valor.SOLAR9_ALQUILER,
                Valor.SOLAR9_PRECIO_CASA, Valor.SOLAR9_PRECIO_HOTEL, Valor.SOLAR9_PRECIO_PISCINA,
                Valor.SOLAR9_PRECIO_PISTA, Valor.SOLAR9_ALQUILER_CASA, Valor.SOLAR9_ALQUILER_HOTEL,
                Valor.SOLAR9_ALQUILER_PISCINA, Valor.SOLAR9_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar10", new DatosSolar(Valor.SOLAR10_PRECIO, Valor.SOLAR10_ALQUILER,
                Valor.SOLAR10_PRECIO_CASA, Valor.SOLAR10_PRECIO_HOTEL, Valor.SOLAR10_PRECIO_PISCINA,
                Valor.SOLAR10_PRECIO_PISTA, Valor.SOLAR10_ALQUILER_CASA, Valor.SOLAR10_ALQUILER_HOTEL,
                Valor.SOLAR10_ALQUILER_PISCINA, Valor.SOLAR10_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar11", new DatosSolar(Valor.SOLAR11_PRECIO, Valor.SOLAR11_ALQUILER,
                Valor.SOLAR11_PRECIO_CASA, Valor.SOLAR11_PRECIO_HOTEL, Valor.SOLAR11_PRECIO_PISCINA,
                Valor.SOLAR11_PRECIO_PISTA, Valor.SOLAR11_ALQUILER_CASA, Valor.SOLAR11_ALQUILER_HOTEL,
                Valor.SOLAR11_ALQUILER_PISCINA, Valor.SOLAR11_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar12", new DatosSolar(Valor.SOLAR12_PRECIO, Valor.SOLAR12_ALQUILER,
                Valor.SOLAR12_PRECIO_CASA, Valor.SOLAR12_PRECIO_HOTEL, Valor.SOLAR12_PRECIO_PISCINA,
                Valor.SOLAR12_PRECIO_PISTA, Valor.SOLAR12_ALQUILER_CASA, Valor.SOLAR12_ALQUILER_HOTEL,
                Valor.SOLAR12_ALQUILER_PISCINA, Valor.SOLAR12_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar13", new DatosSolar(Valor.SOLAR13_PRECIO, Valor.SOLAR13_ALQUILER,
                Valor.SOLAR13_PRECIO_CASA, Valor.SOLAR13_PRECIO_HOTEL, Valor.SOLAR13_PRECIO_PISCINA,
                Valor.SOLAR13_PRECIO_PISTA, Valor.SOLAR13_ALQUILER_CASA, Valor.SOLAR13_ALQUILER_HOTEL,
                Valor.SOLAR13_ALQUILER_PISCINA, Valor.SOLAR13_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar14", new DatosSolar(Valor.SOLAR14_PRECIO, Valor.SOLAR14_ALQUILER,
                Valor.SOLAR14_PRECIO_CASA, Valor.SOLAR14_PRECIO_HOTEL, Valor.SOLAR14_PRECIO_PISCINA,
                Valor.SOLAR14_PRECIO_PISTA, Valor.SOLAR14_ALQUILER_CASA, Valor.SOLAR14_ALQUILER_HOTEL,
                Valor.SOLAR14_ALQUILER_PISCINA, Valor.SOLAR14_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar15", new DatosSolar(Valor.SOLAR15_PRECIO, Valor.SOLAR15_ALQUILER,
                Valor.SOLAR15_PRECIO_CASA, Valor.SOLAR15_PRECIO_HOTEL, Valor.SOLAR15_PRECIO_PISCINA,
                Valor.SOLAR15_PRECIO_PISTA, Valor.SOLAR15_ALQUILER_CASA, Valor.SOLAR15_ALQUILER_HOTEL,
                Valor.SOLAR15_ALQUILER_PISCINA, Valor.SOLAR15_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar16", new DatosSolar(Valor.SOLAR16_PRECIO, Valor.SOLAR16_ALQUILER,
                Valor.SOLAR16_PRECIO_CASA, Valor.SOLAR16_PRECIO_HOTEL, Valor.SOLAR16_PRECIO_PISCINA,
                Valor.SOLAR16_PRECIO_PISTA, Valor.SOLAR16_ALQUILER_CASA, Valor.SOLAR16_ALQUILER_HOTEL,
                Valor.SOLAR16_ALQUILER_PISCINA, Valor.SOLAR16_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar17", new DatosSolar(Valor.SOLAR17_PRECIO, Valor.SOLAR17_ALQUILER,
                Valor.SOLAR17_PRECIO_CASA, Valor.SOLAR17_PRECIO_HOTEL, Valor.SOLAR17_PRECIO_PISCINA,
                Valor.SOLAR17_PRECIO_PISTA, Valor.SOLAR17_ALQUILER_CASA, Valor.SOLAR17_ALQUILER_HOTEL,
                Valor.SOLAR17_ALQUILER_PISCINA, Valor.SOLAR17_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar18", new DatosSolar(Valor.SOLAR18_PRECIO, Valor.SOLAR18_ALQUILER,
                Valor.SOLAR18_PRECIO_CASA, Valor.SOLAR18_PRECIO_HOTEL, Valor.SOLAR18_PRECIO_PISCINA,
                Valor.SOLAR18_PRECIO_PISTA, Valor.SOLAR18_ALQUILER_CASA, Valor.SOLAR18_ALQUILER_HOTEL,
                Valor.SOLAR18_ALQUILER_PISCINA, Valor.SOLAR18_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar19", new DatosSolar(Valor.SOLAR19_PRECIO, Valor.SOLAR19_ALQUILER,
                Valor.SOLAR19_PRECIO_CASA, Valor.SOLAR19_PRECIO_HOTEL, Valor.SOLAR19_PRECIO_PISCINA,
                Valor.SOLAR19_PRECIO_PISTA, Valor.SOLAR19_ALQUILER_CASA, Valor.SOLAR19_ALQUILER_HOTEL,
                Valor.SOLAR19_ALQUILER_PISCINA, Valor.SOLAR19_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar20", new DatosSolar(Valor.SOLAR20_PRECIO, Valor.SOLAR20_ALQUILER,
                Valor.SOLAR20_PRECIO_CASA, Valor.SOLAR20_PRECIO_HOTEL, Valor.SOLAR20_PRECIO_PISCINA,
                Valor.SOLAR20_PRECIO_PISTA, Valor.SOLAR20_ALQUILER_CASA, Valor.SOLAR20_ALQUILER_HOTEL,
                Valor.SOLAR20_ALQUILER_PISCINA, Valor.SOLAR20_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar21", new DatosSolar(Valor.SOLAR21_PRECIO, Valor.SOLAR21_ALQUILER,
                Valor.SOLAR21_PRECIO_CASA, Valor.SOLAR21_PRECIO_HOTEL, Valor.SOLAR21_PRECIO_PISCINA,
                Valor.SOLAR21_PRECIO_PISTA, Valor.SOLAR21_ALQUILER_CASA, Valor.SOLAR21_ALQUILER_HOTEL,
                Valor.SOLAR21_ALQUILER_PISCINA, Valor.SOLAR21_ALQUILER_PISTA));

        DATOS_SOLARES.put("solar22", new DatosSolar(Valor.SOLAR22_PRECIO, Valor.SOLAR22_ALQUILER,
                Valor.SOLAR22_PRECIO_CASA, Valor.SOLAR22_PRECIO_HOTEL, Valor.SOLAR22_PRECIO_PISCINA,
                Valor.SOLAR22_PRECIO_PISTA, Valor.SOLAR22_ALQUILER_CASA, Valor.SOLAR22_ALQUILER_HOTEL,
                Valor.SOLAR22_ALQUILER_PISCINA, Valor.SOLAR22_ALQUILER_PISTA));
    }

    // ATRIBUTOS DE INSTANCIA - ¡IMPORTANTE: CAMBIADOS!
    private float alquilerBase;
    private ArrayList<Edificio> edificios;  // ✅ NUEVO: Lista de objetos Edificio
    private DatosEdificios datosEdificios;
    private boolean tieneEdificios;

    // CONSTRUCTORES
    public Solar(String nombre, int posicion, float valor, float alquilerBase) {
        super(nombre, "solar", posicion, valor, alquilerBase);
        this.alquilerBase = alquilerBase;
        this.edificios = new ArrayList<>();
        this.datosEdificios = new DatosEdificios();
        this.tieneEdificios = false;
    }

    public Solar(String nombre, int posicion, float valor, Jugador banca) {
        this(nombre, posicion, valor, 0);
        this.duenho = banca;
    }

    public Solar(String nombre, int posicion, float valor, float alquilerBase, Jugador banca) {
        super(nombre, "solar", posicion, valor, alquilerBase);
        this.alquilerBase = alquilerBase;
        this.edificios = new ArrayList<>();
        this.datosEdificios = new DatosEdificios();
        this.tieneEdificios = false;
        this.duenho = banca;
    }

    // ========== MÉTODOS PARA GESTIONAR EDIFICIOS ==========

    public int contarEdificiosPorTipo(String tipo) {
        int contador = 0;
        for (Edificio edificio : edificios) {
            if (edificio.getTipo().equalsIgnoreCase(tipo)) {
                contador++;
            }
        }
        return contador;
    }

    public ArrayList<Edificio> getEdificiosPorTipo(String tipo) {
        ArrayList<Edificio> resultado = new ArrayList<>();
        for (Edificio edificio : edificios) {
            if (edificio.getTipo().equalsIgnoreCase(tipo)) {
                resultado.add(edificio);
            }
        }
        return resultado;
    }

    public ArrayList<Edificio> getEdificios() {
        return new ArrayList<>(edificios);
    }

    public void anhadirEdificio(Edificio edificio) {
        if (!edificios.contains(edificio)) {
            edificios.add(edificio);
            actualizarEstadoEdificios();
        }
    }

    public boolean eliminarEdificio(String idEdificio) {
        Iterator<Edificio> iterator = edificios.iterator();
        while (iterator.hasNext()) {
            Edificio edificio = iterator.next();
            if (edificio.getId().equals(idEdificio)) {
                iterator.remove();
                actualizarEstadoEdificios();
                return true;
            }
        }
        return false;
    }

    public Edificio buscarEdificio(String idEdificio) {
        for (Edificio edificio : edificios) {
            if (edificio.getId().equals(idEdificio)) {
                return edificio;
            }
        }
        return null;
    }

    private void actualizarEstadoEdificios() {
        datosEdificios.actualizarDesdeEdificios(edificios);
        this.tieneEdificios = datosEdificios.tieneEdificios();
    }

    // ========== GETTERS PARA COMPATIBILIDAD ==========

    public int getNumCasas() {
        return datosEdificios.getNumCasas();
    }

    public int getNumHoteles() {
        return datosEdificios.getNumHoteles();
    }

    public int getNumPiscinas() {
        return datosEdificios.getNumPiscinas();
    }

    public int getNumPistas() {
        return datosEdificios.getNumPistas();
    }

    public boolean isTieneEdificios() {
        return tieneEdificios;
    }

    public float getAlquilerBase() {
        return alquilerBase;
    }

    public ArrayList<String> getIdsEdificiosCasilla() {
        ArrayList<String> ids = new ArrayList<>();
        for (Edificio edificio : edificios) {
            ids.add(edificio.getId());
        }
        return ids;
    }

    public DatosEdificios getDatosedificios() {
        return datosEdificios;
    }

    // ========== MÉTODOS ESTÁTICOS (iguales) ==========

    public static DatosSolar obtenerDatos(String nombreSolar) {
        return DATOS_SOLARES.get(nombreSolar.toLowerCase());
    }

    public static float obtenerPrecio(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.getPrecio() : 0;
    }

    public static float obtenerPrecioCasa(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.getValorCasa() : 0;
    }

    public static float obtenerPrecioHotel(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.getValorHotel() : 0;
    }

    public static float obtenerPrecioPiscina(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.getValorPiscina() : 0;
    }

    public static float obtenerPrecioPista(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.getValorPista() : 0;
    }

    // ========== MÉTODOS DE EDIFICACIÓN ==========

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean cartas) {
        if (getDuenho() == null || getDuenho() == banca) {
            float precioCompra = obtenerPrecio(getNombre());
            System.out.println("El solar está disponible para comprar por " + (int)precioCompra + "€");
            return true;
        }

        if (getDuenho() == actual) {
            System.out.println("Eres el dueño de esta propiedad");
            return true;
        }

        else if (!isHipotecada()) {
            float alquilerAPagar = calcularAlquiler();

            if (getGrupo() != null && getGrupo().esDuenhoGrupo(getDuenho()) && !this.tieneEdificios) {
                alquilerAPagar *= 2;
                System.out.println("El dueño tiene todo el grupo " + getGrupo().getColorGrupo() + ", el alquiler se duplica.");
            }

            System.out.println(actual.getNombre() + " debe pagar " + (int)alquilerAPagar + "€ de alquiler a " + getDuenho().getNombre());
            boolean pagoExitoso = evaluarPago(actual, banca, tablero, alquilerAPagar);
            if (!pagoExitoso && getDuenho() != banca) {
                actual.setUltimoCobraAlquiler(getDuenho());
            }
            return pagoExitoso;
        }

        else {
            System.out.println("El solar está hipotecado, no se paga alquiler.");
            return true;
        }
    }

    public float calcularAlquiler() {
        DatosSolar datos = obtenerDatos(getNombre());
        if (datos == null) return alquilerBase;

        float total = datos.getAlquiler();

        // Sumar alquileres de todos los edificios
        for (Edificio edificio : edificios) {
            total += edificio.getAlquiler();
        }

        return total;
    }

    public boolean puedeConstruir(Jugador jugador, String tipoEdificio) {
        // Verificar que el jugador está en esta casilla
        if (jugador.getAvatar() == null || jugador.getAvatar().getLugar() != this) {
            return false;
        }

        // Verificar propiedad
        if (getDuenho() == null || !getDuenho().equals(jugador)) {
            System.out.println("No se puede edificar en " + getNombre() + " porque " + jugador.getNombre() + " no es el propietario.");
            return false;
        }

        // Verificar hipoteca
        if (isHipotecada()) {
            System.out.println("No se puede edificar en " + getNombre() + " porque está hipotecada.");
            return false;
        }

        // Verificar propiedad del grupo completo
        if (getGrupo() == null || !getGrupo().esDuenhoGrupo(jugador)) {
            System.out.println("No se puede edificar en " + getNombre() + " porque no posee todo el grupo " +
                    (getGrupo() != null ? getGrupo().getColorGrupo() : "") + ".");
            return false;
        }

        // Verificar hipoteca en otras casillas del grupo
        if (getGrupo() != null) {
            for (Casilla c : getGrupo().getMiembros()) {
                if (c.isHipotecada()) {
                    System.out.println("No se puede edificar en " + getNombre() + " porque alguna casilla del grupo está hipotecada.");
                    return false;
                }
            }
        }

        // Crear un edificio temporal para verificar
        DatosSolar datos = obtenerDatos(getNombre());
        if (datos == null) return false;

        Edificio edificioTemp = crearEdificioTemporal(tipoEdificio, jugador, datos);
        if (edificioTemp == null) {
            System.out.println("Tipo de edificio desconocido: " + tipoEdificio);
            return false;
        }

        return edificioTemp.puedeConstruirseEn(this);
    }

    public boolean construirEdificio(Jugador jugador, String tipoEdificio) {
        if (!puedeConstruir(jugador, tipoEdificio)) {
            return false;
        }

        DatosSolar datos = obtenerDatos(getNombre());
        if (datos == null) return false;

        // Crear el edificio real
        Edificio nuevoEdificio = crearEdificioReal(tipoEdificio, jugador, datos);
        if (nuevoEdificio == null) {
            System.out.println("Error al crear el edificio de tipo: " + tipoEdificio);
            return false;
        }

        // Verificar coste
        if (!jugador.puedePagar(nuevoEdificio.getCoste())) {
            System.out.println("La fortuna de " + jugador.getNombre() +
                    " no es suficiente para edificar un " + tipoEdificio +
                    " en " + getNombre() + ".");
            return false;
        }

        if (tipoEdificio.equalsIgnoreCase("hotel")) {
            // Eliminar 4 casas
            if (contarEdificiosPorTipo("casa") < 4) {
                System.out.println("No hay suficientes casas para construir un hotel en " + getNombre() + ".");
                return false;
            }

            int casasEliminadas = 0;
            ArrayList<Edificio> casasAEliminar = new ArrayList<>();

            for (Edificio edificio : edificios) {
                if (edificio.getTipo().equalsIgnoreCase("casa") && casasEliminadas < 4) {
                    casasAEliminar.add(edificio);
                    casasEliminadas++;
                }
            }

            // Eliminar casas del jugador y del solar
            for (Edificio casa : casasAEliminar) {
                jugador.eliminarEdificio(casa);
                edificios.remove(casa);
            }

            if (casasEliminadas < 4) {
                System.out.println("Error: No hay suficientes casas para construir hotel.");
                return false;
            }
        }

        // Realizar el pago
        jugador.sumarFortuna(-nuevoEdificio.getCoste());
        jugador.sumarInversion(nuevoEdificio.getCoste());

        // Añadir edificio al solar y al jugador
        anhadirEdificio(nuevoEdificio);
        jugador.anhadirEdificio(nuevoEdificio);

        System.out.println("Se ha edificado un " + tipoEdificio + " en " + getNombre() +
                ". La fortuna de " + jugador.getNombre() +
                " se reduce en " + (int)nuevoEdificio.getCoste() + "€.");

        actualizarEstadoEdificios();
        return true;
    }

    private Edificio crearEdificioTemporal(String tipo, Jugador jugador, DatosSolar datos) {
        String idTemp = "temp-" + System.currentTimeMillis();

        switch (tipo.toLowerCase()) {
            case "casa":
                return new Casa(idTemp, datos.getValorCasa(),
                        datos.getValorCasa() * 0.75f,
                        datos.getAlquilerCasa(), jugador, getNombre());
            case "hotel":
                return new Hotel(idTemp, datos.getValorHotel(),
                        datos.getValorHotel() * 0.75f,
                        datos.getAlquilerHotel(), jugador, getNombre());
            case "piscina":
                return new Piscina(idTemp, datos.getValorPiscina(),
                        datos.getValorPiscina() * 0.75f,
                        datos.getAlquilerPiscina(), jugador, getNombre());
            case "pista":
                return new PistaDeporte(idTemp, datos.getValorPista(),
                        datos.getValorPista() * 0.75f,
                        datos.getAlquilerPista(), jugador, getNombre());
            default:
                return null;
        }
    }

    private Edificio crearEdificioReal(String tipo, Jugador jugador, DatosSolar datos) {
        String idUnico = generarIdUnicoEdificio(tipo);

        switch (tipo.toLowerCase()) {
            case "casa":
                return new Casa(idUnico, datos.getValorCasa(),
                        datos.getValorCasa() * 0.75f,
                        datos.getAlquilerCasa(), jugador, getNombre());
            case "hotel":
                return new Hotel(idUnico, datos.getValorHotel(),
                        datos.getValorHotel() * 0.75f,
                        datos.getAlquilerHotel(), jugador, getNombre());
            case "piscina":
                return new Piscina(idUnico, datos.getValorPiscina(),
                        datos.getValorPiscina() * 0.75f,
                        datos.getAlquilerPiscina(), jugador, getNombre());
            case "pista":
                return new PistaDeporte(idUnico, datos.getValorPista(),
                        datos.getValorPista() * 0.75f,
                        datos.getAlquilerPista(), jugador, getNombre());
            default:
                return null;
        }
    }

    private String generarIdUnicoEdificio(String tipo) {
        String id;
        do {
            id = tipo + "-" + (contadorIdsEdificios++);
        } while (buscarEdificio(id) != null);
        return id;
    }

    // ========== MÉTODO PARA VENDER EDIFICIOS ==========

    public boolean venderEdificio(Jugador jugador, String tipo, int cantidad) {
        if (!perteneceAJugador(jugador)) {
            System.out.println(jugador.getNombre() + " no es el propietario de " + getNombre());
            return false;
        }

        if (isHipotecada()) {
            System.out.println("No se pueden vender edificios en " + getNombre() +
                    " porque está hipotecada.");
            return false;
        }

        // Obtener edificios del tipo solicitado
        ArrayList<Edificio> edificiosDelTipo = getEdificiosPorTipo(tipo.toLowerCase());

        if (edificiosDelTipo.size() < cantidad) {
            System.out.println("Sólo hay " + edificiosDelTipo.size() + " " + tipo +
                    "(s) en " + getNombre() + ", no se pueden vender " + cantidad);
            return false;
        }

        // Vender los edificios
        float totalRecaudado = 0;
        int vendidos = 0;

        for (int i = 0; i < cantidad && i < edificiosDelTipo.size(); i++) {
            Edificio edificio = edificiosDelTipo.get(i);
            totalRecaudado += edificio.getPrecioVenta();

            // Eliminar del solar y del jugador
            eliminarEdificio(edificio.getId());
            jugador.eliminarEdificio(edificio);
            vendidos++;
        }

        // Pagar al jugador
        jugador.sumarFortuna(totalRecaudado);

        System.out.println(jugador.getNombre() + " vendió " + vendidos + " " + tipo +
                "(s) en " + getNombre() + " y recibió " +
                (int)totalRecaudado + "€.");

        actualizarEstadoEdificios();
        return true;
    }

    // ========== MÉTODOS DE HIPOTECA (iguales) ==========

    @Override
    public void hipotecar(Jugador jugador) {
        // Verificar propiedad
        if (!perteneceAJugador(jugador)) {
            System.out.println(jugador.getNombre() + " non é o propietario de " + getNombre());
            return;
        }

        // Verificar si ya está hipotecada
        if (isHipotecada()) {
            System.out.println(getNombre() + " xa está hipotecada.");
            return;
        }

        // Si tiene edificios, debe venderlos primero
        if (tieneEdificios) {
            System.out.println("Non se pode hipotecar " + getNombre() + " porque ten edificios. Venda os edificios primeiro.");
            return;
        }

        // Verificar que no haya edificios en el grupo completo
        if (getGrupo() != null && getGrupo().getTotalEdificios() > 0) {
            System.out.println("Non se pode hipotecar " + getNombre() + " porque hai edificios no grupo " + getGrupo().getColorGrupo());
            return;
        }

        // Realizar hipoteca
        setHipotecada(true);
        jugador.sumarFortuna(getHipoteca());
        jugador.anhadirHipoteca(this);
        System.out.println(jugador.getNombre() + " recibe " + (int)getHipoteca() +
                "€ pola hipoteca de " + getNombre());
    }

    @Override
    public void deshipotecar(Jugador jugador) {
        if (isHipotecada() && perteneceAJugador(jugador)) {
            if (jugador.puedePagar(getHipoteca())) {
                setHipotecada(false);
                jugador.sumarFortuna(-getHipoteca());
                jugador.eliminarHipoteca(this);
                System.out.println(jugador.getNombre() + " paga " + (int)getHipoteca() +
                        "€ por deshipotecar " + getNombre());
            } else {
                System.out.println(jugador.getNombre() + " non ten diñeiro suficiente para deshipotecar " + getNombre());
            }
        } else {
            System.out.println("Non se pode deshipotecar " + getNombre() + " (non está hipotecada ou non é propietario).");
        }
    }

    // ========== MÉTODOS DE INFORMACIÓN ==========

    @Override
    public String infoCasilla() {
        DatosSolar datos = obtenerDatos(getNombre());
        if (datos == null) return "{}";

        StringBuilder info = new StringBuilder();
        info.append("{\n");
        info.append("tipo: solar,\n");
        info.append("nombre: ").append(getNombre()).append(",\n");
        info.append("grupo: ").append(getGrupo() != null ? getGrupo().getColorGrupo() : "-").append(",\n");
        info.append("propietario: ").append(getDuenho() != null ? getDuenho().getNombre() : "Banca").append(",\n");
        info.append("valor: ").append((int)getValor()).append(",\n");
        info.append("alquiler base: ").append((int)alquilerBase).append(",\n");
        info.append("alquiler total: ").append((int)calcularAlquiler()).append(",\n");

        // Información de edificios
        info.append("edificios: {\n");
        info.append("  casas: ").append(getNumCasas()).append(",\n");
        info.append("  hoteles: ").append(getNumHoteles()).append(",\n");
        info.append("  piscinas: ").append(getNumPiscinas()).append(",\n");
        info.append("  pistas: ").append(getNumPistas()).append("\n");
        info.append("},\n");

        // Precios de construcción
        info.append("precios construccion: {\n");
        info.append("  casa: ").append((int)datos.getValorCasa()).append(",\n");
        info.append("  hotel: ").append((int)datos.getValorHotel()).append(",\n");
        info.append("  piscina: ").append((int)datos.getValorPiscina()).append(",\n");
        info.append("  pista: ").append((int)datos.getValorPista()).append("\n");
        info.append("}\n");
        info.append("}");

        return info.toString();
    }

    @Override
    public String toString() {
        return super.toString() + " [Solar: " + getNombre() +
                ", Casas: " + getNumCasas() + ", Hoteles: " + getNumHoteles() +
                ", Piscinas: " + getNumPiscinas() + ", Pistas: " + getNumPistas() + "]";
    }

    // ========== MÉTODOS DE COMPRA ==========

    @Override
    public void comprarCasilla(Jugador solicitante, Jugador banca) {
        super.comprarCasilla(solicitante, banca);
    }

    @Override
    public boolean alquiler() {
        return true;
    }

    @Override
    public float valor() {
        float valorTotal = getValor();
        // Sumar valor de los edificios
        for (Edificio edificio : edificios) {
            valorTotal += edificio.getCoste();
        }
        return valorTotal;
    }

    // Para mantener compatibilidad con método edificar() sin parámetros
    public void edificar(String tipoEdificio) {
        if (this.duenho != null) {
            construirEdificio(this.duenho, tipoEdificio);
        } else {
            System.out.println("No se puede edificar en " + getNombre() + " porque no tiene propietario.");
        }
    }

    private DatosSolar getDatos() {
        return obtenerDatos(getNombre());
    }
}
