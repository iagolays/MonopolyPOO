package monopoly.Casilla;

import partida.Jugador;
import monopoly.Tablero;
import monopoly.Carta.CartaSuerte;
import monopoly.Carta.ViajePlacer;
import monopoly.Carta.IrCarcelSuerte;
import monopoly.Carta.BoteLoteria;
import monopoly.Carta.PagarXogadores;
import monopoly.Carta.Retroceder3;
import monopoly.Carta.MultaMovil;
import monopoly.Carta.TransporteCercano;
import java.util.ArrayList;

public final class Suerte extends Accion {
    private ArrayList<CartaSuerte> cartas;
    private int indiceActual;

    public Suerte(int posicion) {
        super("Suerte", "suerte", posicion);
        inicializarCartas();
    }

    public Suerte(int posicion, Jugador banca) {
        super("Suerte", "suerte", posicion, banca);
        inicializarCartas();
    }

    private void inicializarCartas() {
        cartas = new ArrayList<>();

        // Orden secuencial según Apéndice A
        cartas.add(new ViajePlacer());        // Carta 1
        cartas.add(new IrCarcelSuerte());     // Carta 2
        cartas.add(new BoteLoteria());        // Carta 3
        cartas.add(new PagarXogadores());     // Carta 4
        cartas.add(new Retroceder3());        // Carta 5
        cartas.add(new MultaMovil());         // Carta 6
        cartas.add(new TransporteCercano());  // Carta 7

        indiceActual = 0;
    }

    @Override
    public boolean accionAlCaer(Jugador jugador, Tablero tablero) {
        System.out.println(jugador.getNombre() + " cae en Suerte.");

        CartaSuerte carta = cartas.get(indiceActual);
        System.out.println("Carta de Suerte: " + carta.getDescripcion());

        carta.accion(jugador, tablero, tablero.getJugadores());

        // Avanzar al siguiente índice, volver al inicio si llegamos al final
        indiceActual = (indiceActual + 1) % cartas.size();

        return !jugador.isEnBancarrota();
    }

    @Override
    public String toString() {
        return super.toString() + " [Acción: Suerte]";
    }
}