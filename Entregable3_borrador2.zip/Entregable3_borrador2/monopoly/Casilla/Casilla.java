package monopoly.Casilla;

import partida.Jugador;
import partida.Avatar;
import monopoly.Tablero;
import java.util.ArrayList;

public abstract class Casilla {
    protected String nombre;
    protected int posicion;
    protected ArrayList<Avatar> avatares;
    protected int vecesCaida;
    protected float totalAlquileresCobrados;
    protected Jugador duenho;
    protected String tipo;

    public Casilla(String nombre, String tipo, int posicion) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.posicion = posicion;
        this.avatares = new ArrayList<>();
        this.vecesCaida = 0;
        this.totalAlquileresCobrados = 0;
        this.duenho = null;
    }

    public Casilla(String nombre, String tipo, int posicion, Jugador banca) {
        this(nombre, tipo, posicion);
        this.duenho = banca;
    }

    public Casilla(String nombre, String tipo, int posicion, float valor, Jugador banca) {
        this(nombre, tipo, posicion, banca);
    }

    // Métodos comunes requeridos
    public boolean estaAvatar(Avatar avatar) {
        return avatares.contains(avatar);
    }

    public int frecuenciaVisita() {
        return vecesCaida;
    }

    @Override
    public String toString() {
        return nombre + " (visitas: " + vecesCaida + ")";
    }

    // Métodos para gestión de avatares
    public void anhadirAvatar(Avatar av) {
        if (av != null && !avatares.contains(av)) {
            avatares.add(av);
            vecesCaida++;
        }
    }

    public void eliminarAvatar(Avatar av) {
        avatares.remove(av);
    }

    public String getAvataresString() {
        if (avatares.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for(Avatar av : avatares){
            sb.append(av.getId());
            sb.append(" ");
        }
        return sb.toString().trim();
    }

    public abstract boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean cartas);
    public abstract String infoCasilla();
    public abstract String casEnVenta();
    public abstract void comprarCasilla(Jugador solicitante, Jugador banca);
    public abstract void hipotecar(Jugador jugador);
    public abstract void deshipotecar(Jugador jugador);

    // Métodos para acceso a propiedades (necesarios para jerarquía)
    public boolean isHipotecada() {
        return false;
    }

    public Grupo getGrupo() {
        return null;
    }

    public Object getDatosedificios() {
        return null;
    }

    public ArrayList<String> getIdsEdificiosCasilla() {
        return new ArrayList<>();
    }

    public void anhadirIdEdificio(String idEdificio) {
        // Implementación por defecto vacía
    }

    public void eliminarIdEdificio(String idEdificio) {
        // Implementación por defecto vacía
    }

    // Getters requeridos
    public String getNombre() {
        return nombre;
    }

    public int getPosicion() {
        return posicion;
    }

    public ArrayList<Avatar> getAvatares() {
        return avatares;
    }

    public int getVecesCaida() {
        return vecesCaida;
    }

    public float getTotalAlquileresCobrados() {
        return totalAlquileresCobrados;
    }

    public void registrarAlquilerCobrado(float cantidad) {
        this.totalAlquileresCobrados += cantidad;
    }

    public String getTipo() {
        return tipo;
    }

    public Jugador getDuenho() {
        return duenho;
    }

    public void setDuenho(Jugador duenho) {
        this.duenho = duenho;
    }

    public float getValor() {
        return 0;
    }
}