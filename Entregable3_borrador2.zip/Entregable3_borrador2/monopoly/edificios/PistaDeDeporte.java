package monopoly.edificios;

import monopoly.*;
import monopoly.casillas.Solar;
import partida.*;

//Clase que representa unha Pista de Deporte construída nun solar.
public class PistaDeDeporte extends Edificio {

    // Contador estático para xerar IDs únicos para as pistas
    private static int contador = 1;

    //Constructor da clase PistaDeDeporte.
    public PistaDeDeporte(Solar solar, Jugador propietario) {
        super(solar, propietario);
    }

    //Metodo que devolve o tipo de edificio.
    @Override
    protected String obterTipoEdificio() {
        return "pista";
    }

    //Metodo que obtén o seguinte número do contador de pistas.
    @Override
    protected int obterContador() {
        return contador++;
    }

    //Metodo que calcula o prezo da pista segundo o solar.
    @Override
    protected float calcularPrezo() {
        String nomeSolar = solar.getNombre().toLowerCase();

        switch(nomeSolar) {
            case "solar1": return Valor.SOLAR1_PRECIO_PISTA;
            case "solar2": return Valor.SOLAR2_PRECIO_PISTA;
            case "solar3": return Valor.SOLAR3_PRECIO_PISTA;
            case "solar4": return Valor.SOLAR4_PRECIO_PISTA;
            case "solar5": return Valor.SOLAR5_PRECIO_PISTA;
            case "solar6": return Valor.SOLAR6_PRECIO_PISTA;
            case "solar7": return Valor.SOLAR7_PRECIO_PISTA;
            case "solar8": return Valor.SOLAR8_PRECIO_PISTA;
            case "solar9": return Valor.SOLAR9_PRECIO_PISTA;
            case "solar10": return Valor.SOLAR10_PRECIO_PISTA;
            case "solar11": return Valor.SOLAR11_PRECIO_PISTA;
            case "solar12": return Valor.SOLAR12_PRECIO_PISTA;
            case "solar13": return Valor.SOLAR13_PRECIO_PISTA;
            case "solar14": return Valor.SOLAR14_PRECIO_PISTA;
            case "solar15": return Valor.SOLAR15_PRECIO_PISTA;
            case "solar16": return Valor.SOLAR16_PRECIO_PISTA;
            case "solar17": return Valor.SOLAR17_PRECIO_PISTA;
            case "solar18": return Valor.SOLAR18_PRECIO_PISTA;
            case "solar19": return Valor.SOLAR19_PRECIO_PISTA;
            case "solar20": return Valor.SOLAR20_PRECIO_PISTA;
            case "solar21": return Valor.SOLAR21_PRECIO_PISTA;
            case "solar22": return Valor.SOLAR22_PRECIO_PISTA;
            default: return 200000f; // Prezo por defecto
        }
    }

    //Metodo que obtén o aluguer que aporta esta pista de deporte.
    @Override
    public float obterAluguer() {
        String nomeSolar = solar.getNombre().toLowerCase();

        switch(nomeSolar) {
            case "solar1": return Valor.SOLAR1_ALQUILER_PISTA;
            case "solar2": return Valor.SOLAR2_ALQUILER_PISTA;
            case "solar3": return Valor.SOLAR3_ALQUILER_PISTA;
            case "solar4": return Valor.SOLAR4_ALQUILER_PISTA;
            case "solar5": return Valor.SOLAR5_ALQUILER_PISTA;
            case "solar6": return Valor.SOLAR6_ALQUILER_PISTA;
            case "solar7": return Valor.SOLAR7_ALQUILER_PISTA;
            case "solar8": return Valor.SOLAR8_ALQUILER_PISTA;
            case "solar9": return Valor.SOLAR9_ALQUILER_PISTA;
            case "solar10": return Valor.SOLAR10_ALQUILER_PISTA;
            case "solar11": return Valor.SOLAR11_ALQUILER_PISTA;
            case "solar12": return Valor.SOLAR12_ALQUILER_PISTA;
            case "solar13": return Valor.SOLAR13_ALQUILER_PISTA;
            case "solar14": return Valor.SOLAR14_ALQUILER_PISTA;
            case "solar15": return Valor.SOLAR15_ALQUILER_PISTA;
            case "solar16": return Valor.SOLAR16_ALQUILER_PISTA;
            case "solar17": return Valor.SOLAR17_ALQUILER_PISTA;
            case "solar18": return Valor.SOLAR18_ALQUILER_PISTA;
            case "solar19": return Valor.SOLAR19_ALQUILER_PISTA;
            case "solar20": return Valor.SOLAR20_ALQUILER_PISTA;
            case "solar21": return Valor.SOLAR21_ALQUILER_PISTA;
            case "solar22": return Valor.SOLAR22_ALQUILER_PISTA;
            default: return 500000f; // Aluguer por defecto
        }
    }
}