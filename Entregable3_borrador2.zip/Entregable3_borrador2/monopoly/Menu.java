package monopoly;

import java.util.Scanner;

public class Menu {
    private Juego juego;
    private Scanner scanner;

    public Menu(Juego juego) {
        this.juego = juego;
        this.scanner = new Scanner(System.in);
    }

    public void iniciarInteractivo() {
        mostrarBienvenida();

        while (true) {
            System.out.print("\n$> ");
            String comando = scanner.nextLine().trim();

            if (comando.equalsIgnoreCase("salir")) {
                System.out.println("\nSaliendo del juego...");
                System.out.println("¡Hasta pronto!");
                break;
            } else if (comando.startsWith("comandos ")) {
                String nomeFicheiro = comando.substring(9);
                juego.leerFicheiroComandos(nomeFicheiro);
            } else {
                // Llama al método procesarComando de Juego
                juego.procesarComando(comando);
            }
        }
        scanner.close();
    }

    private void mostrarBienvenida() {
        System.out.println("Bienvenido al Monopoly ETSE!");
        System.out.println("\nComandos disponibles:");
        System.out.println("- crear jugador <nombre> <avatar>");
        System.out.println("- jugador");
        System.out.println("- listar jugadores");
        System.out.println("- lanzar dados [suma]");
        System.out.println("- acabar turno");
        System.out.println("- salir carcel");
        System.out.println("- describir <NombreCasilla>");
        System.out.println("- describir jugador <Nombre>");
        System.out.println("- comprar <NombrePropiedad>");
        System.out.println("- listar enventa");
        System.out.println("- ver tablero");
        System.out.println("- edificar <tipoEdificacion> (casa, hotel, piscina, pista)");
        System.out.println("- listar edificios");
        System.out.println("- listar edificios <colorGrupo>");
        System.out.println("- hipotecar <NombreCasilla>");
        System.out.println("- deshipotecar <NombreCasilla>");
        System.out.println("- vender <tipo> <NombreCasilla> <cantidad>");
        System.out.println("- estadisticas [nombreJugador]");
        System.out.println("- comandos <NombreFichero>");
        System.out.println("- salir");
        System.out.println();
    }
}