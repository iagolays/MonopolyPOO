package monopoly.cartas;

import partida.*;
import monopoly.*;
import monopoly.casillas.*;
import java.util.ArrayList;

public class Suerte extends Carta {

    private TipoAccion tipoAccion;

    public Suerte(String descripcion, int id, TipoAccion tipoAccion) {
        super(descripcion, id);
        this.tipoAccion = tipoAccion;
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero) {
        switch(tipoAccion) {
            case AVANZAR_SOLAR19:
                avanzarASolar19(jugador, tablero);
                break;
            case IR_CARCEL:
                irCarcel(jugador, tablero);
                break;
            case LOTERIA:
                ganarLoteria(jugador);
                break;
            case PAGAR_TODOS:
                pagarATodos(jugador, tablero);
                break;
            case RETROCEDER3:
                retroceder3(jugador, tablero);
                break;
            case MULTA_MOVIL:
                multaMovil(jugador, tablero);
                break;
            case AVANZAR_TRANSPORTE:
                avanzarTransporte(jugador, tablero);
                break;
        }
    }

    private void avanzarASolar19(Jugador jugador, Tablero tablero) {
        jugador.getAvatar().moverAvatarHasta("Solar19", tablero.getCasillas(), tablero, true);
        Casilla destino = tablero.encontrar_casilla("Solar19");
        if (destino != null) {
            destino.evaluarCasilla(jugador, tablero.getBanca(), 0, tablero, false);
        }
    }

    private void irCarcel(Jugador jugador, Tablero tablero) {
        Casilla carcel = tablero.encontrar_casilla("Carcel");
        if (carcel != null) {
            jugador.encarcelar(tablero.getPosiciones(), tablero);
        }
    }

    private void ganarLoteria(Jugador jugador) {
        jugador.sumarFortuna(1000000);
        jugador.registrarPremio(1000000);
    }

    private void pagarATodos(Jugador pagador, Tablero tablero) {
        ArrayList<Jugador> todosJugadores = tablero.getJugadores();
        int numJugadoresAPagar = 0;

        for (Jugador j : todosJugadores) {
            if (j != pagador && !j.isEnBancarrota()) {
                numJugadoresAPagar++;
            }
        }

        float total = numJugadoresAPagar * 250000f;

        if (pagador.puedePagar(total)) {
            for (Jugador j : todosJugadores) {
                if (j != pagador && !j.isEnBancarrota()) {
                    pagador.pagarJugador(j, 250000f, tablero);
                }
            }
        } else {
            pagador.sumarFortuna(-total);
        }
    }

    private void retroceder3(Jugador jugador, Tablero tablero) {
        jugador.getAvatar().moverAvatar(tablero.getPosiciones(), -3, tablero, false);
    }

    private void multaMovil(Jugador jugador, Tablero tablero) {
        float multa = 150000f;
        if (jugador.puedePagar(multa)) {
            jugador.sumarFortuna(-multa);
            jugador.registrarTasa(multa);

            Casilla parking = tablero.encontrar_casilla("Parking");
            if (parking != null) {
                parking.sumarValor(multa);
            }
        } else {
            jugador.sumarFortuna(-multa);
        }
    }

    private void avanzarTransporte(Jugador jugador, Tablero tablero) {
        ArrayList<Casilla> todasCasillas = tablero.CasillasLineales();
        Casilla actual = jugador.getAvatar().getLugar();

        int posActual = todasCasillas.indexOf(actual);
        Casilla destino = null;

        do {
            posActual = (posActual + 1) % todasCasillas.size();
            Casilla casillaActual = todasCasillas.get(posActual);
            if (casillaActual instanceof Transporte) {
                destino = casillaActual;
                break;
            }
        } while (posActual != todasCasillas.indexOf(actual));

        if (destino != null) {
            jugador.getAvatar().moverAvatarHasta(destino.getNombre(), tablero.getCasillas(), tablero, false);
            destino.evaluarCasilla(jugador, tablero.getBanca(), 0, tablero, true);
        }
    }

    public enum TipoAccion {
        AVANZAR_SOLAR19,
        IR_CARCEL,
        LOTERIA,
        PAGAR_TODOS,
        RETROCEDER3,
        MULTA_MOVIL,
        AVANZAR_TRANSPORTE
    }

    public TipoAccion getTipoAccion() {
        return tipoAccion;
    }
}