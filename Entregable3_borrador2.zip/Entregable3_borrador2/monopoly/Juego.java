package monopoly;

import monopoly.Casilla.Casilla;
import monopoly.Casilla.Solar;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import partida.*;

public class Juego {
    // Atributos del juego
    private ArrayList<Jugador> jugadores;
    private ArrayList<Avatar> avatares;
    private int turno = 0;
    private int lanzamientos;
    private Tablero tablero;
    private Dado dado1;
    private Dado dado2;
    private Jugador banca;
    private boolean tirado;
    private boolean solvente;
    private boolean dadosLanzados;

    // Constructor - SOLO inicializa instancias
    public Juego() {
        this.jugadores = new ArrayList<>();
        this.avatares = new ArrayList<>();
        this.banca = new Jugador();
        this.banca.setNombre("Banca");
        this.tablero = new Tablero(banca, this);
        this.dado1 = new Dado();
        this.dado2 = new Dado();

        this.turno = 0;
        this.lanzamientos = 0;
        this.tirado = false;
        this.solvente = true;
        this.dadosLanzados = false;
    }

    // ========== MÉTODOS PÚBLICOS PARA MANIPULAR EL ESTADO ==========

    public void crearJugador(String nombre, String tipoAvatar) {
        if (this.jugadores.size() >= 4) {
            System.out.println("Xa hai 4 xogadores, non poden engadrse mais.");
            return;
        }

        for (Jugador j : this.jugadores) {
            if (j.getNombre().equalsIgnoreCase(nombre)) {
                System.out.println("Xa existe un xogador con ese nome");
                return;
            }
        }

        String[] tiposValidos = {"Coche", "Esfinge", "Sombrero", "Pelota"};
        boolean tipoValido = false;
        for (String tipo : tiposValidos) {
            if (tipo.equalsIgnoreCase(tipoAvatar)) {
                tipoValido = true;
                break;
            }
        }
        if (!tipoValido) {
            System.out.println("Tipo de avatar non válido. Usa: Coche, Esfinge, Sombrero ou Pelota.");
            return;
        }

        for (Avatar av : this.avatares) {
            if (av.getTipo().equalsIgnoreCase(tipoAvatar)) {
                System.out.println("O tipo de avatar '" + tipoAvatar + "' xa está en uso por outro xogador.");
                return;
            }
        }

        Casilla salida = this.tablero.encontrar_casilla("Salida");
        if (salida == null) {
            System.out.println("Non se atopou a casilla Salida");
            return;
        }

        if (dadosLanzados) {
            System.out.println("Non se poden crear xogadores unha vez comezada a partida.");
            return;
        }

        Jugador novoJugador = new Jugador(nombre, tipoAvatar, salida, this.avatares);
        this.jugadores.add(novoJugador);
        this.avatares.add(novoJugador.getAvatar());

        System.out.println("{\n" +
                "nombre: " + novoJugador.getNombre() + ",\n" +
                "avatar: " + novoJugador.getAvatar().getId() + "\n" +
                "}");

        System.out.println(this.getTableroString());

    }

    public void lanzarDados() {
        if (this.jugadores.isEmpty()) {
            System.out.println("Non hai xogadores na partida, non se poden lanzar os dados.");
            return;
        } else if (this.jugadores.size() < 2){
            System.out.println("Non se poden lanzar os dados ata que haxa polo menos 2 xogadores.");
            return;
        }

        Jugador actual = this.jugadores.get(this.turno);

        if (actual.isEnCarcel()) {
            if (!this.tirado){
                int resultado = actual.intentarSalirCarcel(this.dado1, this.dado2, this.tablero, false, 0, 0);
                if (resultado == -1){
                    return;
                } else if (resultado == 0) {
                    this.tirado = true;
                    return;
                }
                else {
                    int valor1 = this.dado1.getValor();
                    int valor2 = this.dado2.getValor();
                    this.tirado = true;
                    gestionarTirada(actual, valor1, valor2, this.tablero);
                }
            }else {
                System.out.println("Xa se tiraron os dados, remata o turno.");
            }
        } else {
            if (!this.tirado){
                int valor1 = this.dado1.hacerTirada();
                int valor2 = this.dado2.hacerTirada();

                gestionarTirada(actual, valor1, valor2, this.tablero);
                this.dadosLanzados = true;
            } else {
                System.out.println("Xa se tiraron os dados, remata o turno.");
            }
        }
    }

    public void lanzarDadosForzados(String valores) {
        if (this.jugadores.isEmpty()) {
            System.out.println("Non hai xogadores na partida");
            return;
        } else if (this.jugadores.size() < 2){
            System.out.println("Non se poden lanzar os dados ata que haxa polo menos 2 xogadores.");
            return;
        }

        Jugador actual = this.jugadores.get(this.turno);
        int[] valoresDados = Dado.procesarTiradaForzada(valores);

        if (valoresDados == null) {
            System.out.println("Formato de tirada forzada inválido. Use 'numero + numero'");
            return;
        }

        if (actual.isEnCarcel()) {
            if (!this.tirado) {
                int resultado = actual.intentarSalirCarcel(this.dado1, this.dado2, this.tablero, true, valoresDados[0], valoresDados[1]);
                if (resultado == -1){
                    return;
                } else if (resultado == 0) {
                    this.tirado = true;
                    return;
                }
                else {
                    this.tirado = true;
                    gestionarTirada(actual, valoresDados[0], valoresDados[1], this.tablero);
                }
            } else {
                System.out.println("Os dados xa foron tirados, remate o turno.");
            }
        } else {
            if (!tirado) {
                this.dado1.lanzarForzado(valoresDados[0]);
                this.dado2.lanzarForzado(valoresDados[1]);

                this.tirado = true;
                gestionarTirada(actual, valoresDados[0], valoresDados[1], tablero);
                this.dadosLanzados = true;
            } else {
                System.out.println("Os dados xa foron tirados, remate o turno.");
            }
        }
    }

    public void comprar(String nombreCasilla) {
        if (this.jugadores.isEmpty()) {
            System.out.println("Non hai xogadores na partida, non se poden comprar casillas.");
            return;
        }

        Jugador jugadorActual = this.jugadores.get(this.turno);
        Casilla casilla = this.tablero.encontrar_casilla(nombreCasilla);

        if (casilla == null) {
            System.out.println("Propiedade non atopada: " + nombreCasilla);
            return;
        }

        if (!jugadorActual.getAvatar().getLugar().equals(casilla)) {
            System.out.println("Só podes comprar a casilla na que estás actualmente: " +
                    jugadorActual.getAvatar().getLugar().getNombre());
            return;
        }

        if (!casilla.getTipo().equalsIgnoreCase("solar") &&
                !casilla.getTipo().equalsIgnoreCase("transporte") &&
                !casilla.getTipo().equalsIgnoreCase("servicio")) {
            System.out.println("Non se pode comprar a casilla " + nombreCasilla + " (tipo: " + casilla.getTipo() + ")");
            return;
        }

        Jugador duenhoActual = casilla.getDuenho();
        boolean propiedadDisponible = false;

        if (duenhoActual == null) {
            propiedadDisponible = true;
        } else if (this.banca != null && duenhoActual.equals(this.banca)) {
            propiedadDisponible = true;
        } else if ("Banca".equalsIgnoreCase(duenhoActual.getNombre())) {
            propiedadDisponible = true;
        }

        if (!propiedadDisponible) {
            System.out.println("A casilla " + nombreCasilla + " xa ten propietario: " + duenhoActual.getNombre());
            return;
        }

        float precio = casilla.getValor();
        if (!jugadorActual.puedePagar(precio)) {
            System.out.println(jugadorActual.getNombre() +
                    " non ten diñeiro suficiente para comprar " + nombreCasilla +
                    " (" + (int)precio + "€). Fortuna actual: " +
                    (int)jugadorActual.getFortuna() + "€.");
            return;
        }

        casilla.comprarCasilla(jugadorActual, this.banca);
    }

    public void hipotecar(String nombreCasilla) {
        if (this.jugadores.isEmpty()) {
            System.out.println("Non hai xogadores na partida.");
            return;
        }

        Casilla c = this.tablero.encontrar_casilla(nombreCasilla);
        if (c != null) {
            c.hipotecar(this.jugadores.get(this.turno));
        } else {
            System.out.println("Non se atopou a casilla: " + nombreCasilla);
        }
    }

    public void deshipotecar(String nombreCasilla) {
        if (this.jugadores.isEmpty()) {
            System.out.println("Non hai xogadores na partida.");
            return;
        }

        Casilla c = this.tablero.encontrar_casilla(nombreCasilla);
        if (c != null) {
            c.deshipotecar(this.jugadores.get(this.turno));
        } else {
            System.out.println("Non se atopou a casilla: " + nombreCasilla);
        }
    }

    public void edificar(String tipoEdificio) {
        if (this.jugadores.isEmpty()) {
            System.out.println("Non hai xogadores na partida.");
            return;
        }


        Jugador jugadorActual = this.jugadores.get(this.turno);

        if (!tipoEdificio.equals("casa") && !tipoEdificio.equals("hotel") &&
                !tipoEdificio.equals("piscina") && !tipoEdificio.equals("pista")) {
            System.out.println("Tipo de edificio non válido. Use: casa, hotel, piscina ou pista.");
            return;
        }

        Casilla casillaActual = jugadorActual.getAvatar().getLugar();
        if(!"solar".equals(casillaActual.getTipo())) {
            System.out.println("Só podes edificar nun solar.");
        }
        /*if (casillaActual == null || !"solar".equalsIgnoreCase(casillaActual.getTipo())) {
            System.out.println("Só podes edificar nun solar e debes estar na casilla onde queres edificar.");
            return;
        }*/

        boolean exito = construirEdificio(casillaActual, jugadorActual, tipoEdificio);
        if (exito) {
            System.out.println(this.tablero);
        }
    }

    public void venderEdificio(String tipo, String nombreCasilla, int cantidad) {
        if (this.jugadores.isEmpty()) {
            System.out.println("Non hai xogadores na partida.");
            return;
        }

        Casilla c = this.tablero.encontrar_casilla(nombreCasilla);
        if (c != null) {
            venderEdificio(c, this.jugadores.get(this.turno), tipo, cantidad);
        } else {
            System.out.println("Non se atopou a casilla: " + nombreCasilla);
        }
    }

    public void salirCarcel() {
        if (this.jugadores.isEmpty()){
            System.out.println("Non hai xogadores na partida.");
            return;
        }

        Jugador jugador = this.jugadores.get(this.turno);

        if (!jugador.isEnCarcel()) {
            System.out.println(jugador.getNombre() + " non está no cárcere.");
            return;
        }

        jugador.salirCarcel(tablero);
    }

    public void acabarTurno() {
        if (this.jugadores.isEmpty()) {
            System.out.println("Non hai xogadores");
            return;
        }
        Jugador actual = this.jugadores.get(this.turno);

        if (!this.tirado) {
            System.out.println("Non podes acabar o turno sen lanzar os dados.");
            return;
        }
        boolean tenDebedas = (actual.getFortuna() < 0 && !actual.isEnBancarrota());

        if (tenDebedas) {
            Jugador pagarA = detectarPagar(actual);
            actual.declararBancarrota(this.tablero, pagarA);
            gestionarBancarrota(actual);
        } else {
            this.turno = (this.turno + 1) % this.jugadores.size();
            this.tirado = false;
            this.solvente = true;

            Jugador siguiente = this.jugadores.get(this.turno);
            System.out.println("É o turno de: " + siguiente.getNombre() + ".");
            System.out.println("Estado actual: " + siguiente);
        }
    }

    // ========== MÉTODOS DE CONSULTA ==========

    public String getInfoJugador(String nombreBuscar) {
        Jugador jugador = null;

        for (Jugador j: jugadores) {
            if (j.getNombre().equalsIgnoreCase(nombreBuscar)) {
                jugador = j;
                break;
            }
        }

        if (jugador == null) {
            return "Non existe ningún xogador con ese nome.";
        }
        return jugador.infoJugador();
    }

    public String getInfoCasilla(String nombre) {
        Casilla c = this.tablero.encontrar_casilla(nombre);
        if (c == null) {
            return "Non se atopou a casilla: " + nombre;
        }
        return c.infoCasilla();
    }

    public String getTableroString() {
        return this.tablero.toString();
    }

    public String getListaJugadores() {
        if (jugadores.isEmpty()) {
            return "Non hai xogadores na partida.";
        }

        StringBuilder sb = new StringBuilder();
        for (Jugador j : this.jugadores) {
            sb.append(j.infoJugador()).append("\n");
        }
        return sb.toString();
    }

    public String getPropiedadesEnVenta() {
        StringBuilder sb = new StringBuilder();
        boolean hayPropiedades = false;

        for (int lado = 0; lado < 4; lado++) {
            ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
            for (Casilla casilla : casillasLado) {
                String infoVenta = casilla.casEnVenta();
                if (!infoVenta.isEmpty()) {
                    sb.append(infoVenta).append("\n");
                    hayPropiedades = true;
                }
            }
        }

        if (!hayPropiedades) {
            return "Non hai propiedades en venda";
        }
        return sb.toString();
    }

    public String getEstadisticasJuego() {
        return "{\n" +
                "casillaMasRentable: " + obtenerCasillaMasRentable() + ",\n" +
                "grupoMasRentable: " + obtenerGrupoMasRentable() + ",\n" +
                "casillaMasFrecuentada: " + obtenerCasillaMasFrecuentada() + ",\n" +
                "jugadorMasVueltas: " + obtenerJugadorMasVueltas() + ",\n" +
                "jugadorEnCabeza: " + obtenerJugadorEnCabeza() + "\n" +
                "}";
    }

    public String getEstadisticasJugador(String nombreJugador) {
        Jugador jugador = null;
        for (Jugador j : jugadores) {
            if (j.getNombre().equalsIgnoreCase(nombreJugador)) {
                jugador = j;
                break;
            }
        }
        if (jugador != null) {
            return jugador.mostrarEstadisticas();
        } else {
            return "Xogador non atopado: " + nombreJugador;
        }
    }

    public String getJugadorActualInfo() {
        if (this.jugadores.isEmpty()) {
            return "Non hai xogadores na partida";
        }

        Jugador actual = this.jugadores.get(this.turno);
        return "Es el turno de: " + actual.getNombre() + ".\n" +
                "Estado actual: " + actual;
    }

    public void listarEdificios() {
        boolean hayEdificios = false;

        for (Jugador j : jugadores) {
            for (String idEdificio : j.getEdificios()) {
                String[] partes = idEdificio.split("-");
                if (partes.length >= 2) {
                    String tipo = partes[0];

                    Casilla casillaEdificio = null;
                    for (Casilla propiedad : j.getPropiedades()) {
                        if ("solar".equalsIgnoreCase(propiedad.getTipo())) {
                            Solar solar = (Solar) propiedad;
                            if (solar.getIdsEdificiosCasilla().contains(idEdificio)) {
                                casillaEdificio = propiedad;
                                break;
                            }
                        }
                    }

                    if (casillaEdificio != null) {
                        float coste = 0;
                        switch (tipo.toLowerCase()) {
                            case "casa":
                                coste = obtenerPrecioCasa(casillaEdificio.getNombre());
                                break;
                            case "hotel":
                                coste = obtenerPrecioHotel(casillaEdificio.getNombre());
                                break;
                            case "piscina":
                                coste = obtenerPrecioPiscina(casillaEdificio.getNombre());
                                break;
                            case "pista":
                                coste = obtenerPrecioPista(casillaEdificio.getNombre());
                                break;
                        }

                        StringBuilder info = new StringBuilder();
                        info.append("{\n");
                        info.append("id: ").append(idEdificio).append(",\n");
                        info.append("propietario: ").append(j.getNombre()).append(",\n");
                        info.append("casilla: ").append(casillaEdificio.getNombre()).append(",\n");
                        info.append("grupo: ").append(casillaEdificio.getGrupo() != null ?
                                casillaEdificio.getGrupo().getColorGrupo() : "-").append(",\n");
                        info.append("coste: ").append((int)coste).append("\n");
                        info.append("}");

                        System.out.println(info.toString());
                        hayEdificios = true;
                    }
                }
            }
        }

        if (!hayEdificios) {
            System.out.println("Non hai edificios construidos.");
        }
    }

    public void listarEdificiosGrupo(String colorGrupo) {
        if (this.jugadores.isEmpty()) {
            System.out.println("Non hai xogadores na partida.");
            return;
        }

        Jugador jugadorActual = this.jugadores.get(this.turno);
        colorGrupo = colorGrupo.trim().toLowerCase();

        monopoly.Casilla.Grupo grupoEncontrado = null;
        for (Jugador jugador : jugadores) {
            for (Casilla propiedad : jugador.getPropiedades()) {
                monopoly.Casilla.Grupo grupo = propiedad.getGrupo();
                if (grupo != null && grupo.getColorGrupo().equalsIgnoreCase(colorGrupo)) {
                    grupoEncontrado = grupo;
                    break;
                }
            }
            if (grupoEncontrado != null) break;
        }

        if (grupoEncontrado == null) {
            for (int lado = 0; lado < 4; lado++) {
                ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
                for (Casilla casilla : casillasLado) {
                    monopoly.Casilla.Grupo grupo = casilla.getGrupo();
                    if (grupo != null && grupo.getColorGrupo().equalsIgnoreCase(colorGrupo)) {
                        grupoEncontrado = grupo;
                        break;
                    }
                }
                if (grupoEncontrado != null) break;
            }
        }

        if (grupoEncontrado == null) {
            System.out.println("Non se atopou ningún grupo co color " + colorGrupo + ".");
            return;
        }

        String infoEdificios = grupoEncontrado.obtenerInfoEdificios();
        String infoConstruccion = grupoEncontrado.obtenerInfoConstruccionPosible(jugadorActual);

        System.out.println(infoEdificios);
        System.out.println(infoConstruccion);
    }


    public void procesarComando(String comando) {
        String[] partes = comando.trim().split("\\s+");

        if (partes.length == 0){
            return;
        }

        if (!this.jugadores.isEmpty()) {
            Jugador actual = this.jugadores.get(this.turno);
            if (actual.getFortuna() < 0 && !actual.isEnBancarrota()) {
                System.out.println(actual.getNombre() + " aínda ten débedas pendentes (" + (int)Math.abs(actual.getFortuna()) + "€).");
                System.out.println("Use 'hipotecar <casilla>' ou 'acabar turno' para resolver.");
            }
        }

        switch (partes[0].toLowerCase()) {
            case "crear":
                if (partes.length >= 4 && partes[1].equalsIgnoreCase("jugador")) {
                    this.crearJugador(partes[2], partes[3]);
                } else {
                    System.out.println("Formato incorrecto. Use: crear jugador <nome> <avatar>");
                }
                break;
            case "jugador":
                System.out.println(this.getJugadorActualInfo());
                break;
            case "listar":
                procesarComandoListar(partes);
                break;
            case "lanzar":
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("dados")) {
                    if (partes.length >= 3) {
                        this.lanzarDadosForzados(partes[2]);
                    } else {
                        this.lanzarDados();
                    }
                } else {
                    System.out.println("Formato incorrecto. Use: lanzar dados [valor]");
                }
                break;
            case "describir":
                if (partes.length >= 3 && partes[1].equalsIgnoreCase("jugador")) {
                    System.out.println(this.getInfoJugador(partes[2]));
                } else if (partes.length >= 2) {
                    System.out.println(this.getInfoCasilla(partes[1]));
                } else {
                    System.out.println("Formato incorrecto. Use: describir jugador <nome> OU describir <casilla>");
                }
                break;
            case "comprar":
                if (partes.length >= 2) {
                    this.comprar(partes[1]);
                } else {
                    System.out.println("Formato incorrecto. Use: comprar <nomeCasilla>");
                }
                break;
            case "salir":
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("carcel")) {
                    this.salirCarcel();
                } else {
                    System.out.println("Formato incorrecto. Use: salir carcel");
                }
                break;
            case "acabar":
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("turno")) {
                    this.acabarTurno();
                } else {
                    System.out.println("Formato incorrecto. Use: acabar turno");
                }
                break;
            case "ver":
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("tablero")) {
                    System.out.println(this.getTableroString());
                } else {
                    System.out.println("Formato incorrecto. Use: ver tablero");
                }
                break;
            case "edificar":
                if (partes.length >= 2) {
                    this.edificar(partes[1]);
                } else {
                    System.out.println("Formato incorrecto. Use: edificar <tipo>");
                }
                break;
            case "hipotecar":
                if (partes.length >= 2) {
                    this.hipotecar(partes[1]);
                } else {
                    System.out.println("Formato incorrecto. Use: hipotecar <nomeCasilla>");
                }
                break;
            case "deshipotecar":
                if (partes.length >= 2) {
                    this.deshipotecar(partes[1]);
                } else {
                    System.out.println("Formato incorrecto. Use: deshipotecar <nomeCasilla>");
                }
                break;
            case "vender":
                if (partes.length >= 4){
                    String tipo = partes[1];
                    String nombreCasilla = partes[2];
                    int cantidad = Integer.parseInt(partes[3]);
                    this.venderEdificio(tipo, nombreCasilla, cantidad);
                } else {
                    System.out.println("Formato incorrecto. Use: vender <tipo> <nomeCasilla> <cantidade>");
                }
                break;
            case "estadisticas":
                if (partes.length >= 2) {
                    System.out.println(this.getEstadisticasJugador(partes[1]));
                } else {
                    System.out.println(this.getEstadisticasJuego());
                }
                break;
            default:
                System.out.println("Comando non recoñecido: " + comando);
        }
    }

    public void leerFicheiroComandos(String nomeFicheiro) {
        // Este método ahora es solo para leer ficheros
        // La lógica de procesamiento está en procesarComando()
        File ficheiro = new File(nomeFicheiro);

        if (!ficheiro.exists()) {
            System.out.println("O ficheiro non existe: " + nomeFicheiro);
            return;
        }

        Scanner scanner = null;
        try {
            scanner = new Scanner(ficheiro);
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine().trim();
                if (!linea.isEmpty() && !linea.startsWith("#")) {
                    System.out.println("$> " + linea);
                    this.procesarComando(linea);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Non se pode abrir o ficheiro: " + e.getMessage());
        } finally {
            if (scanner != null) {
                scanner.close();
            }
        }
    }

    // ========== MÉTODOS PRIVADOS DE LÓGICA INTERNA ==========

    private void procesarComandoListar(String[] partes) {
        if (partes.length < 2){
            System.out.println("Formato incorrecto. Use: listar jugadores|edificios|enventa");
            return;
        }

        switch (partes[1].toLowerCase()) {
            case "jugadores":
                System.out.println(this.getListaJugadores());
                break;
            case "edificios":
                if (partes.length == 2) {
                    this.listarEdificios();
                } else {
                    StringBuilder colorGrupoBuilder = new StringBuilder();
                    for (int i = 2; i < partes.length; i++) {
                        if (i > 2){
                            colorGrupoBuilder.append(" ");
                        }
                        colorGrupoBuilder.append(partes[i]);
                    }
                    this.listarEdificiosGrupo(colorGrupoBuilder.toString());
                }
                break;
            case "enventa":
                System.out.println(this.getPropiedadesEnVenta());
                break;
            default:
                System.out.println("Subcomando listar non recoñecido: " + partes[1]);
        }
    }

    private void gestionarTirada(Jugador actual, int valor1, int valor2, Tablero tablero) {
        int total = valor1 + valor2;

        if (valor1 == valor2) {
            actual.incrementarDobles();

            if (actual.getDoblesConsecutivos() == 3) {
                System.out.println(actual.getNombre() + " sacó dobles 3 veces seguidas, va directamente a la cárcel.");
                actual.encarcelar(tablero.getPosiciones(), tablero);
                actual.resetearDobles();
                this.tirado = true;
                return;
            } else {
                this.procesarMovimiento(actual, total);
                System.out.println("¡Dobles! " + actual.getNombre() + " tira otra vez.");
                this.lanzamientos++;

                this.tirado = false;
                if (actual.isEnBancarrota() || actual.getFortuna() < 0) {
                    this.tirado = true;
                    gestionarBancarrota(actual);
                }
                return;
            }
        } else {
            actual.resetearDobles();
            this.procesarMovimiento(actual, total);
            this.lanzamientos++;
            this.tirado = true;
        }

        if (actual.getFortuna() <= 0) {
            System.out.println(actual.getNombre() + " tiene deudas pendentes.");
        }
    }

    private void procesarMovimiento(Jugador actual, int total) {
        Avatar avatar = actual.getAvatar();

        ArrayList<ArrayList<Casilla>> todasCasillas = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            todasCasillas.add(this.tablero.getLado(i));
        }

        avatar.moverAvatar(todasCasillas, total, tablero, true);

        Casilla casillaActual = avatar.getLugar();

        String tipo = casillaActual.getTipo().toLowerCase();

        if ("suerte".equals(tipo)) {
            this.solvente = casillaActual.evaluarCasilla(actual, this.banca, total, this.tablero, false);
            if (actual.getFortuna() < 0 && solvente){
                System.out.println(actual.getNombre() + " ten débedas pendentes tras a carta de Suerte.");
            }
        } else if ("comunidad".equals(tipo)) {
            this.solvente = casillaActual.evaluarCasilla(actual, this.banca, total, this.tablero, false);
            if (actual.getFortuna() < 0 && solvente){
                System.out.println(actual.getNombre() + " ten débedas pendentes tras a carta de Comunidad.");
            }
        } else {
            this.solvente = casillaActual.evaluarCasilla(actual, this.banca, total, this.tablero, false);
        }

        if (actual.getFortuna() < 0 && this.solvente){
            System.out.println(actual.getNombre() + " ten débedas pendentes.");
        }

        System.out.println(this.tablero);
        this.tirado = true;
    }

    private Jugador detectarPagar(Jugador deudor) {
        if (deudor.getUltimoCobraAlquiler() != null) {
            return deudor.getUltimoCobraAlquiler();
        } else {
            return this.banca;
        }
    }

    private void gestionarBancarrota(Jugador jugadorEnBancarrota) {
        this.jugadores.remove(jugadorEnBancarrota);

        if (this.jugadores.isEmpty()) {
            System.out.println("\nTodos os xogadores en bancarrota! Xogo rematado.");
            System.exit(0);
        }

        if (this.turno >= this.jugadores.size()) {
            this.turno = 0;
        }

        if (this.jugadores.size() == 1) {
            Jugador ganador = this.jugadores.get(0);
            System.out.println("\nO xogo rematou!");
            System.out.println("O gañador é " + ganador.getNombre() + " cunha fortuna de " + (int)ganador.getFortuna() + "€.");
            System.out.println("\nEstatísticas finais:");
            System.out.println(ganador.mostrarEstadisticas());
            System.exit(0);
        } else {
            System.out.println("Quedan " + this.jugadores.size() + " xogadores en xogo.\n");

            Jugador siguiente = this.jugadores.get(this.turno);
            System.out.println("É o turno de: " + siguiente.getNombre() + ".");
            System.out.println("Estado actual: " + siguiente);
        }
    }

    // ========== MÉTODOS PRIVADOS DE ESTADÍSTICAS ==========

    private String obtenerCasillaMasRentable() {
        float maxRentabilidad = 0;
        String casillaMasRentable = "-";

        for (int lado = 0; lado < 4; lado++) {
            ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
            for (Casilla casilla : casillasLado) {
                if (casilla != null){
                    float rentabilidad = casilla.getTotalAlquileresCobrados();
                    if (rentabilidad > maxRentabilidad) {
                        maxRentabilidad = rentabilidad;
                        casillaMasRentable = casilla.getNombre();
                    }
                }
            }
        }
        return casillaMasRentable;
    }

    private String obtenerGrupoMasRentable() {
        Map<String, Float> rentabilidadesGrupos = new HashMap<>();
        Map<String, String> nombresGrupos = new HashMap<>();

        for (int lado = 0; lado < 4; lado++) {
            ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
            for (Casilla casilla : casillasLado) {
                if (casilla != null && casilla.getGrupo() != null) {
                    String colorGrupo = casilla.getGrupo().getColorGrupo();
                    float alquileresCobrados = casilla.getTotalAlquileresCobrados();

                    rentabilidadesGrupos.put(colorGrupo, rentabilidadesGrupos.getOrDefault(colorGrupo, 0f) + alquileresCobrados);
                    nombresGrupos.put(colorGrupo, colorGrupo);
                }
            }
        }

        String grupoMasRentable = "-";
        float maxRentabilidad = 0;
        for (Map.Entry<String, Float> entrada : rentabilidadesGrupos.entrySet()) {
            if (entrada.getValue() > maxRentabilidad) {
                maxRentabilidad = entrada.getValue();
                grupoMasRentable = nombresGrupos.get(entrada.getKey());
            }
        }
        return grupoMasRentable;
    }

    private String obtenerCasillaMasFrecuentada() {
        int maxVeces = 0;
        String casillaMasFrecuentada = "-";

        for (int lado = 0; lado < 4; lado++) {
            ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
            for (Casilla casilla : casillasLado) {
                if (casilla != null && casilla.getVecesCaida() > maxVeces) {
                    maxVeces = casilla.getVecesCaida();
                    casillaMasFrecuentada = casilla.getNombre();
                }
            }
        }
        return casillaMasFrecuentada;
    }

    private String obtenerJugadorMasVueltas() {
        int maxVueltas = 0;
        String jugadorMasVueltas = "-";

        for (Jugador j : jugadores) {
            if (j.getVueltas() > maxVueltas) {
                maxVueltas = j.getVueltas();
                jugadorMasVueltas = j.getNombre();
            }
        }
        return jugadorMasVueltas;
    }

    private String obtenerJugadorEnCabeza() {
        float maxFortuna = 0;
        String jugadorEnCabeza = "-";

        for (Jugador j : jugadores) {
            float fortunaTotal = j.getFortuna();

            for (Casilla propiedad : j.getPropiedades()) {
                fortunaTotal += propiedad.getValor();

                if (propiedad instanceof Solar) {
                    Solar solar = (Solar) propiedad;
                    Solar.DatosSolar datos = Solar.obtenerDatos(propiedad.getNombre());
                    if (datos != null) {
                        fortunaTotal += solar.getNumCasas() * datos.getValorCasa();
                        fortunaTotal += solar.getNumHoteles() * datos.getValorHotel();
                        fortunaTotal += solar.getNumPiscinas() * datos.getValorPiscina();
                        fortunaTotal += solar.getNumPistas() * datos.getValorPista();
                    }
                }
            }

            if (fortunaTotal > maxFortuna) {
                maxFortuna = fortunaTotal;
                jugadorEnCabeza = j.getNombre();
            }
        }
        return jugadorEnCabeza;
    }

    // ========== GETTERS ==========

    public ArrayList<Jugador> getJugadores() {
        return jugadores;
    }

    public Tablero getTablero() {
        return this.tablero;
    }

    public Jugador getJugadorActual() {
        return jugadores.isEmpty() ? null : jugadores.get(turno);
    }

    public int getTurno() {
        return turno;
    }

    public boolean isTirado() {
        return tirado;
    }

    public boolean isDadosLanzados() {
        return dadosLanzados;
    }

    // ========== MÉTODOS ESTÁTICOS AUXILIARES ==========

    private static boolean construirEdificio(Casilla casilla, Jugador jugador, String tipoEdificio) {
        if (casilla instanceof Solar) {
            Solar solar = (Solar) casilla;
            return solar.construirEdificio(jugador, tipoEdificio);
        }
        return false;
    }

    private static void venderEdificio(Casilla casilla, Jugador jugador, String tipo, int cantidad) {
        if (casilla instanceof Solar) {
            Solar solar = (Solar) casilla;
            solar.venderEdificio(jugador, tipo, cantidad);
        } else {
            System.out.println("Só se poden vender edificios en solares.");
        }
    }

    private static float obtenerPrecioCasa(String nombreSolar) {
        return Solar.obtenerPrecioCasa(nombreSolar);
    }

    private static float obtenerPrecioHotel(String nombreSolar) {
        return Solar.obtenerPrecioHotel(nombreSolar);
    }

    private static float obtenerPrecioPiscina(String nombreSolar) {
        return Solar.obtenerPrecioPiscina(nombreSolar);
    }

    private static float obtenerPrecioPista(String nombreSolar) {
        return Solar.obtenerPrecioPista(nombreSolar);
    }

    private static Solar.DatosSolar obtenerDatos(String nombreSolar) {
        return Solar.obtenerDatos(nombreSolar);
    }
}