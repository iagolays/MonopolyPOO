package monopoly.exceptions;

//excepción para cando un xogador non ten diñeiro suficiente

public class DiñeiroInsuficienteException extends TransaccionException{
    public DiñeiroInsuficienteException(String nomeXogador, double diñeiroNecesario, double diñeiroActual) {
        super(nomeXogador, "Banco", "diñeiro insuficiente. Necesita " + diñeiroNecesario + ", pero só ten " + diñeiroActual + '€');
    }

    //constructor para erros de diñeiro insuficiente nunha transacción entre xogadores
    public DiñeiroInsuficienteException(String xogadorDevedor, String xogadorAcreedor, double diñeiroNecesario, double diñeiroActual) {
        super(xogadorDevedor, xogadorAcreedor, "diñeiro insuficiente. Necesita " + diñeiroNecesario + ", pero só ten " + diñeiroActual + '€');
    }
}
