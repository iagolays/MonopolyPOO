package monopoly.exceptions;

//excepción para erros das transaccións económicas no xogo

public class TransaccionException extends MonopolyException {
    public TransaccionException(String mensaxe) {
        super(mensaxe);
    }

    //constructor para erros de transaccións entre xogadores
    public TransaccionException(String xogadorDevedor, String xogadorAcreedor, String problema) {
        super("Erro na transacción entre " + xogadorDevedor + " e " + xogadorAcreedor + ". Fallou: " + problema);
    }
}
