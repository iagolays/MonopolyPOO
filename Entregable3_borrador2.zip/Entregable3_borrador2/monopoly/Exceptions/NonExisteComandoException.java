package monopoly.Exceptions;

//excepción para comandos que non existen no xogo ou non son válidos

public class NonExisteComandoException extends ComandoInvalidoException{
    //constructor para comandos que non existen
    public NonExisteComandoException(String nomeComando) {
        super("Comando " + nomeComando + " non recoñecido.");
    }
}
