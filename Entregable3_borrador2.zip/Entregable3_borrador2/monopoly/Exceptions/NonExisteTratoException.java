package monopoly.Exceptions;

public class NonExisteTratoException extends NonExisteExcepcion{
    public NonExisteTratoException(String nomeTrato) {
        super("trato", nomeTrato);
    }
}
