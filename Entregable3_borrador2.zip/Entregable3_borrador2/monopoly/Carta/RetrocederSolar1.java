package monopoly.Carta;

import partida.Jugador;
import monopoly.Tablero;
import java.util.ArrayList;

public final class RetrocederSolar1 extends CartaComunidad {
    public RetrocederSolar1() {
        super("Retrocede ata Solar1 para comprar antigüidades exóticas.");
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero, ArrayList<Jugador> jugadores) {
        jugador.getAvatar().moverAvatarHasta("Solar1", tablero.getCasillas(), tablero, false);
    }
}