package monopoly.Carta;

import partida.Jugador;
import monopoly.Tablero;
import java.util.ArrayList;

public final class Retroceder3 extends CartaSuerte {
    public Retroceder3() {
        super("Hora punta de tráfico! Retrocede 3 casillas.");
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero, ArrayList<Jugador> jugadores) {
        jugador.getAvatar().moverAvatar(tablero.getPosiciones(), -3, tablero, false);
    }
}