package monopoly.Carta;

import partida.Jugador;
import monopoly.Tablero;
import java.util.ArrayList;

public final class DevolucionFacenda extends CartaComunidad {
    public DevolucionFacenda() {
        super("Devolución de Facenda. Cobra 500.000€.");
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero, ArrayList<Jugador> jugadores) {
        jugador.sumarFortuna(500000);
        jugador.registrarPremio(500000);
    }
}