package monopoly.Carta;

import partida.Jugador;
import monopoly.Tablero;
import monopoly.Casilla.Parking;
import java.util.ArrayList;

public final class Balneario extends CartaComunidad {
    public Balneario() {
        super("Paga 500.000€ por un fin de weekend nun balneario de 5 estrelas.");
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero, ArrayList<Jugador> jugadores) {
        if (jugador.puedePagar(500000)) {
            jugador.sumarFortuna(-500000);
            jugador.registrarTasa(500000);

            for (monopoly.Casilla.Casilla casilla : tablero.CasillasLineales()) {
                if (casilla instanceof Parking) {
                    ((Parking) casilla).sumarAlBote(500000);
                    break;
                }
            }
        } else {
            jugador.sumarFortuna(-500000);
            System.out.println("\n" + jugador.getNombre() + " non pode pagar 500.000€.");
            jugador.setUltimoCobraAlquiler(tablero.getBanca());
        }
    }
}