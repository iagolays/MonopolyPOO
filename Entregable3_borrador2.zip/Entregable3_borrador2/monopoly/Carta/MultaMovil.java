package monopoly.Carta;

import partida.Jugador;
import monopoly.Tablero;
import monopoly.Casilla.Parking;
import java.util.ArrayList;

public final class MultaMovil extends CartaSuerte {
    public MultaMovil() {
        super("Multante por usar o móbil mentres conduces. Paga 150.000€.");
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero, ArrayList<Jugador> jugadores) {
        if (jugador.puedePagar(150000)) {
            jugador.sumarFortuna(-150000);
            jugador.registrarTasa(150000);

            for (monopoly.Casilla.Casilla casilla : tablero.CasillasLineales()) {
                if (casilla instanceof Parking) {
                    ((Parking) casilla).sumarAlBote(150000);
                    break;
                }
            }
        } else {
            jugador.sumarFortuna(-150000);
            System.out.println("\n" + jugador.getNombre() + " non pode pagar 150.000€.");
            jugador.setUltimoCobraAlquiler(tablero.getBanca());
        }
    }
}