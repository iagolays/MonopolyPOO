package monopoly.Carta;

import partida.Jugador;
import monopoly.Tablero;
import java.util.ArrayList;

public final class ViajePlacer extends CartaSuerte {
    public ViajePlacer() {
        super("Decides facer unha viaxe de pracer. Avanza ata Solar19. Se pasas pola Saída, cobra 2.000.000€.");
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero, ArrayList<Jugador> jugadores) {
        jugador.getAvatar().moverAvatarHasta("Solar19", tablero.getCasillas(), tablero, true);
    }
}