package monopoly.Carta;

import partida.Jugador;
import monopoly.Tablero;
import java.util.ArrayList;

public final class PagarXogadores extends CartaSuerte {
    public PagarXogadores() {
        super("Foches elixido presidente da xunta directiva. Paga a cada xogador 250.000€.");
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero, ArrayList<Jugador> jugadores) {
        int numJogadoresAPagar = 0;
        for (Jugador j : jugadores) {
            if (j != jugador && !j.isEnBancarrota()) {
                numJogadoresAPagar++;
            }
        }

        float total = numJogadoresAPagar * 250000;

        if (jugador.puedePagar(total)) {
            for (Jugador j : jugadores) {
                if (j != jugador && !j.isEnBancarrota()) {
                    jugador.pagarJugador(j, 250000, tablero);
                }
            }
        } else {
            jugador.sumarFortuna(-total);
            System.out.println("\n" + jugador.getNombre() + " non pode pagar 250.000€.");
            jugador.setUltimoCobraAlquiler(tablero.getBanca());
        }
    }
}
