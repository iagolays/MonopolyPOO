package monopoly.Carta;

import partida.Jugador;
import monopoly.Tablero;
import java.util.ArrayList;

public final class IrSalida extends CartaComunidad {
    public IrSalida() {
        super("Colócate na casilla de Saída. Cobra 2.000.000€.");
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero, ArrayList<Jugador> jugadores) {
        jugador.getAvatar().moverAvatarHasta("Salida", tablero.getCasillas(), tablero, true);
    }
}