package monopoly.Carta;

import partida.Jugador;
import monopoly.Tablero;
import java.util.ArrayList;

public final class BoteLoteria extends CartaSuerte {
    public BoteLoteria() {
        super("Ganas o bote da lotería. Recibe 1.000.000€.");
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero, ArrayList<Jugador> jugadores) {
        jugador.sumarFortuna(1000000);
        jugador.registrarPremio(1000000);
    }
}
