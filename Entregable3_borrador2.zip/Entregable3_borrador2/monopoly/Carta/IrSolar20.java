package monopoly.Carta;

import partida.Jugador;
import monopoly.Tablero;
import java.util.ArrayList;

public final class IrSolar20 extends CartaComunidad {
    public IrSolar20() {
        super("Vai a Solar20 para gozar do San Fermín. Se pasas pola Saída, cobra 2.000.000€.");
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero, ArrayList<Jugador> jugadores) {
        jugador.getAvatar().moverAvatarHasta("Solar20", tablero.getCasillas(), tablero, true);
    }
}