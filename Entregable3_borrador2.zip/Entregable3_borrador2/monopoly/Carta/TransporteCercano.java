package monopoly.Carta;

import partida.Jugador;
import monopoly.Tablero;
import monopoly.Casilla.Casilla;
import java.util.ArrayList;

public final class TransporteCercano extends CartaSuerte {
    public TransporteCercano() {
        super("Avanza ata a casilla de transporte máis cercana. Se non te dono, podes comprala. Se ten dono, paga ao dono o dobre da operación indicada");
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero, ArrayList<Jugador> jugadores) {
        ArrayList<ArrayList<Casilla>> casillasTablero = tablero.getCasillas();
        ArrayList<Casilla> todasCasillas = tablero.CasillasLineales();
        Casilla actual = jugador.getAvatar().getLugar();

        int posActual = todasCasillas.indexOf(actual);
        Casilla destino = null;
        do {
            posActual = (posActual + 1) % todasCasillas.size();
            if ("transporte".equalsIgnoreCase(todasCasillas.get(posActual).getTipo())) {
                destino = todasCasillas.get(posActual);
                break;
            }
        } while (posActual != todasCasillas.indexOf(actual));

        if (destino != null) {
            System.out.println("Avanzas ata a casilla de transporte máis cercana: " + destino.getNombre() + ".");
            jugador.getAvatar().moverAvatarHasta(destino.getNombre(), casillasTablero, tablero, false);
            destino.evaluarCasilla(jugador, tablero.getBanca(), 0, tablero, true);
        } else {
            System.out.println("Non se atopou ningunha casilla de transporte.");
        }
    }
}