package monopoly.Carta;

public abstract class CartaSuerte extends Carta {
    public CartaSuerte(String descripcion) {
        super(descripcion);
    }
}