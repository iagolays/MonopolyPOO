package monopoly.Carta;

public abstract class CartaComunidad extends Carta {
    public CartaComunidad(String descripcion) {
        super(descripcion);
    }
}