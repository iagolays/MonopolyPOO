package monopoly.Carta;

import partida.Jugador;
import monopoly.Tablero;
import java.util.ArrayList;

public final class IrCarcelComunidad extends CartaComunidad {
    public IrCarcelComunidad() {
        super("Investígante por fraude de identidade. Vai ao cárcere. Vai directamente sen pasar pola Saída e sen cobrar os 2.000.000€.");
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero, ArrayList<Jugador> jugadores) {
        jugador.encarcelar(tablero.getPosiciones(), tablero);
    }
}