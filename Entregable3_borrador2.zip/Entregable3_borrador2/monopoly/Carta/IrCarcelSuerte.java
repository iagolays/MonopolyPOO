package monopoly.Carta;

import partida.Jugador;
import monopoly.Tablero;
import java.util.ArrayList;

public final class IrCarcelSuerte extends CartaSuerte {
    public IrCarcelSuerte() {
        super("Os acredores persíguenche por impago. Vai direcamente ao cárcere, sen pasar pola saída e sen cobrar os 2.000.000€.");
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero, ArrayList<Jugador> jugadores) {
        jugador.encarcelar(tablero.getPosiciones(), tablero);
    }
}
