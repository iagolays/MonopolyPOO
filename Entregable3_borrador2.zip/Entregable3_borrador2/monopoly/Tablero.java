package monopoly;

import monopoly.Casilla.*;
import partida.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Tablero {
    private ArrayList<ArrayList<Casilla>> posiciones;
    private HashMap<String, Grupo> grupos;
    private Jugador banca;
    private Juego juego; //Referencia al juego para acceder a los jugadores

    public Tablero(Jugador banca, Juego juego) { //Añadir referencia al juego
        this.banca = banca;
        this.juego = juego;
        this.posiciones = new ArrayList<>();
        this.grupos = new HashMap<>();

        for(int i = 0; i < 4; i++){
            this.posiciones.add(new ArrayList<Casilla>());
        }

        this.generarCasillas();
        this.inicializarGrupos();
    }

    private void generarCasillas() {
        this.insertarLadoSur();
        this.insertarLadoOeste();
        this.insertarLadoNorte();
        this.insertarLadoEste();
    }

    private void insertarLadoSur() {
        ArrayList<Casilla> sur = posiciones.get(0);

        sur.add(new Especial("Salida", 0, "salida", banca));
        sur.add(new Solar("Solar1", 1, Valor.SOLAR1_PRECIO, Valor.SOLAR1_ALQUILER, banca));
        sur.add(new CajaComunidad(2, banca));
        sur.add(new Solar("Solar2", 3, Valor.SOLAR2_PRECIO, Valor.SOLAR2_ALQUILER, banca));
        sur.add(new Impuesto("Imp1", 4, Valor.IMPUESTO_VALOR, banca));
        sur.add(new Transporte("Trans1", 5, Valor.TRANSPORTE_PRECIO, banca));
        sur.add(new Solar("Solar3", 6, Valor.SOLAR3_PRECIO, Valor.SOLAR3_ALQUILER, banca));
        sur.add(new Suerte(7, banca));
        sur.add(new Solar("Solar4", 8, Valor.SOLAR4_PRECIO, Valor.SOLAR4_ALQUILER, banca));
        sur.add(new Solar("Solar5", 9, Valor.SOLAR5_PRECIO, Valor.SOLAR5_ALQUILER, banca));
        sur.add(new Especial("Carcel", 10, "carcel", banca));
    }

    private void insertarLadoOeste() {
        ArrayList<Casilla> oeste = posiciones.get(1);

        oeste.add(new Solar("Solar6", 11, Valor.SOLAR6_PRECIO, Valor.SOLAR6_ALQUILER, banca));
        oeste.add(new Servicio("Serv1", 12, Valor.SERVICIO_PRECIO, banca));
        oeste.add(new Solar("Solar7", 13, Valor.SOLAR7_PRECIO, Valor.SOLAR7_ALQUILER, banca));
        oeste.add(new Solar("Solar8", 14, Valor.SOLAR8_PRECIO, Valor.SOLAR8_ALQUILER, banca));
        oeste.add(new Transporte("Trans2", 15, Valor.TRANSPORTE_PRECIO, banca));
        oeste.add(new Solar("Solar9", 16, Valor.SOLAR9_PRECIO, Valor.SOLAR9_ALQUILER, banca));
        oeste.add(new CajaComunidad(17, banca));
        oeste.add(new Solar("Solar10", 18, Valor.SOLAR10_PRECIO, Valor.SOLAR10_ALQUILER, banca));
        oeste.add(new Solar("Solar11", 19, Valor.SOLAR11_PRECIO, Valor.SOLAR11_ALQUILER, banca));
    }

    private void insertarLadoNorte() {
        ArrayList<Casilla> norte = posiciones.get(2);

        norte.add(new Parking(20, banca));
        norte.add(new Solar("Solar12", 21, Valor.SOLAR12_PRECIO, Valor.SOLAR12_ALQUILER, banca));
        norte.add(new Suerte(22, banca));
        norte.add(new Solar("Solar13", 23, Valor.SOLAR13_PRECIO, Valor.SOLAR13_ALQUILER, banca));
        norte.add(new Solar("Solar14", 24, Valor.SOLAR14_PRECIO, Valor.SOLAR14_ALQUILER, banca));
        norte.add(new Transporte("Trans3", 25, Valor.TRANSPORTE_PRECIO, banca));
        norte.add(new Solar("Solar15", 26, Valor.SOLAR15_PRECIO, Valor.SOLAR15_ALQUILER, banca));
        norte.add(new Solar("Solar16", 27, Valor.SOLAR16_PRECIO, Valor.SOLAR16_ALQUILER, banca));
        norte.add(new Servicio("Serv2", 28, Valor.SERVICIO_PRECIO, banca));
        norte.add(new Solar("Solar17", 29, Valor.SOLAR17_PRECIO, Valor.SOLAR17_ALQUILER, banca));
        norte.add(new Especial("IrCarcel", 30, "ircarcel", banca));
    }

    private void insertarLadoEste() {
        ArrayList<Casilla> este = posiciones.get(3);

        este.add(new Solar("Solar18", 31, Valor.SOLAR18_PRECIO, Valor.SOLAR18_ALQUILER, banca));
        este.add(new Solar("Solar19", 32, Valor.SOLAR19_PRECIO, Valor.SOLAR19_ALQUILER, banca));
        este.add(new CajaComunidad(33, banca));
        este.add(new Solar("Solar20", 34, Valor.SOLAR20_PRECIO, Valor.SOLAR20_ALQUILER, banca));
        este.add(new Transporte("Trans4", 35, Valor.TRANSPORTE_PRECIO, banca));
        este.add(new Suerte(36, banca));
        este.add(new Solar("Solar21", 37, Valor.SOLAR21_PRECIO, Valor.SOLAR21_ALQUILER, banca));
        este.add(new Impuesto("Imp2", 38, Valor.IMPUESTO_VALOR, banca));
        este.add(new Solar("Solar22", 39, Valor.SOLAR22_PRECIO, Valor.SOLAR22_ALQUILER, banca));
    }

    //Obtener la lista de jugadores desde el juego
    public ArrayList<Jugador> getJugadores() {
        if (juego != null) {
            return juego.getJugadores();
        }
        return new ArrayList<>(); // Lista vacía si no hay referencia al juego
    }

    //Para imprimir el tablero
    @Override
    public String toString() {
        ArrayList<Casilla> sur = posiciones.get(0);
        ArrayList<Casilla> oeste = posiciones.get(1);
        ArrayList<Casilla> norte = posiciones.get(2);
        ArrayList<Casilla> este = posiciones.get(3);

        StringBuilder sb = new StringBuilder();
        sb.append("\n                                 ======= TABLERO MONOPOLY =======\n\n");

        int ancho = 12;
        int alto = 4;

        // Calcular espacio central
        int espacioCentral = (norte.size() * ancho) - (2 * ancho);

        // LADO NORTE
        for (int fila = 0; fila < alto; fila++) {
            for (Casilla c : norte) {
                sb.append(getContenidoCasilla(c, fila, ancho));
            }
            sb.append("\n");
        }

        // LADOS OESTE y ESTE
        int maxFilas = Math.max(oeste.size(), este.size());
        for (int i = 0; i < maxFilas; i++) {
            Casilla izq = (i < oeste.size()) ? oeste.get(oeste.size() - 1 - i) : null;
            Casilla der = (i < este.size()) ? este.get(i) : null;

            for (int fila = 0; fila < alto; fila++) {
                // Lado Oeste
                if (izq != null) {
                    sb.append(getContenidoCasilla(izq, fila, ancho));
                } else {
                    sb.append(" ".repeat(ancho));
                }

                // Espacio central
                sb.append(" ".repeat(espacioCentral));

                // Lado Este
                if (der != null) {
                    sb.append(getContenidoCasilla(der, fila, ancho));
                }
                sb.append("\n");
            }
        }

        // LADO SUR
        for (int fila = 0; fila < alto; fila++) {
            for (int i = sur.size() - 1; i >= 0; i--) {
                Casilla c = sur.get(i);
                sb.append(getContenidoCasilla(c, fila, ancho));
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    //Metodo usado para buscar la casilla con el nombre pasado como argumento:
    public Casilla encontrar_casilla(String nombre) {
        for (ArrayList<Casilla> lado : posiciones) {
            for (Casilla casilla : lado) {
                if (casilla.getNombre().equalsIgnoreCase(nombre)) {
                    return casilla;
                }
            }
        }
        return null;
    }

    public ArrayList<Casilla> getLado(int indice) {
        if(indice >= 0 && indice < posiciones.size()){
            return posiciones.get(indice);
        } else {
            return null;
        }
    }

    private String getContenidoCasilla(Casilla c, int fila, int ancho) {
        String nombre = c.getNombre();
        String tipo = c.getTipo();

        // Fila 0 → borde superior
        if (fila == 0) {
            return "┌" + "─".repeat(ancho - 2) + "┐";
        }

        // Fila 1 → nombre de la casilla
        if (fila == 1) {
            String nombreCorto = acortarNombre(nombre);
            String colorCode = obtenerColorCode(c);

            int espacio = ancho - 2 - nombreCorto.length();
            int izq = espacio / 2;
            int der = espacio - izq;

            return "│" + " ".repeat(izq) + colorCode + nombreCorto + "\u001B[0m" + " ".repeat(der) + "│";
        }

        // Fila 2 → tipo de casilla
        if (fila == 2) {
            String tipoAbreviado = getTipoAbreviado(tipo);
            int espacio = ancho - 2 - tipoAbreviado.length();
            int izq = espacio / 2;
            int der = espacio - izq;

            return "│" + " ".repeat(izq) + tipoAbreviado + " ".repeat(der) + "│";
        }

        // Fila 3 → avatares
        if (fila == 3) {
            String avatares = c.getAvataresString();
            if (avatares.length() > ancho - 2) {
                avatares = avatares.substring(0, ancho - 2);
            }
            int espacio = ancho - 2 - avatares.length();
            int izq = espacio / 2;
            int der = espacio - izq;

            return "│" + " ".repeat(izq) + avatares + " ".repeat(der) + "│";
        }

        return "";
    }

    // Método para obtener solo el código de color
    private String obtenerColorCode(Casilla c) {
        if (c instanceof Solar) {
            String nombre = c.getNombre();

            switch (nombre) {
                case "Solar1":
                case "Solar2":
                    return "\u001B[38;5;94m";
                case "Solar3":
                case "Solar4":
                case "Solar5":
                    return "\u001B[36m";
                case "Solar6":
                case "Solar7":
                case "Solar8":
                    return "\u001B[95m";
                case "Solar9":
                case "Solar10":
                case "Solar11":
                    return "\u001B[38;5;214m";
                case "Solar12":
                case "Solar13":
                case "Solar14":
                    return "\u001B[31m";
                case "Solar15":
                case "Solar16":
                case "Solar17":
                    return "\u001B[33m";
                case "Solar18":
                case "Solar19":
                case "Solar20":
                    return "\u001B[32m";
                case "Solar21":
                case "Solar22":
                    return "\u001B[34m";
            }
        }
        return "";
    }

    // Método para acortar nombres largos
    private String acortarNombre(String nombre) {
        if (nombre == null) return "";

        switch (nombre) {
            case "Caja de Comunidad":
                return "Comunidad";
            case "IrCarcel":
                return "IrCarcel";
            case "Salida":
                return "Salida";
            case "Carcel":
                return "Cárcel";
            case "Parking":
                return "Parking";
            default:
                if (nombre.startsWith("Solar")) {
                    return nombre.length() > 8 ? nombre.substring(0, 8) : nombre;
                }
                if (nombre.startsWith("Trans")) {
                    return nombre.length() > 6 ? nombre.substring(0, 6) : nombre;
                }
                if (nombre.startsWith("Serv")) {
                    return nombre.length() > 5 ? nombre.substring(0, 5) : nombre;
                }
                if (nombre.startsWith("Imp")) {
                    return nombre.length() > 4 ? nombre.substring(0, 4) : nombre;
                }
                return nombre.length() > 10 ? nombre.substring(0, 10) : nombre;
        }
    }

    // Método para obtener tipos abreviados
    private String getTipoAbreviado(String tipo) {
        if (tipo == null) return "";

        switch (tipo.toLowerCase()) {
            case "comunidad":
                return "comunidad";
            case "transporte":
                return "transporte";
            case "servicio":
                return "servicio";
            case "especial":
                return "especial";
            case "impuesto":
                return "impuesto";
            case "parking":
                return "parking";
            case "suerte":
                return "suerte";
            case "solar":
                return "solar";
            case "ircarcel":
                return "irCarcel";
            default:
                return tipo.length() > 10 ? tipo.substring(0, 10) : tipo;
        }
    }

    // Metodo para inicializar os grupos de solares
    private void inicializarGrupos() {
        // Grupo Marrón (Solar1 e Solar2)
        Casilla solar1 = encontrar_casilla("Solar1");
        Casilla solar2 = encontrar_casilla("Solar2");
        if (solar1 != null && solar2 != null) {
            Grupo grupoMarron = new Grupo((Propiedad)solar1, (Propiedad)solar2, "Marrón");
            this.grupos.put("Marrón", grupoMarron);
        }

        // Grupo Azul Claro (Solar3, Solar4, Solar5)
        Casilla solar3 = encontrar_casilla("Solar3");
        Casilla solar4 = encontrar_casilla("Solar4");
        Casilla solar5 = encontrar_casilla("Solar5");
        if (solar3 != null && solar4 != null && solar5 != null) {
            Grupo grupoAzulClaro = new Grupo((Propiedad)solar3, (Propiedad)solar4, (Propiedad)solar5, "Azul Claro");
            this.grupos.put("Azul Claro", grupoAzulClaro);
        }

        // Grupo Rosa (Solar6, Solar7, Solar8)
        Casilla solar6 = encontrar_casilla("Solar6");
        Casilla solar7 = encontrar_casilla("Solar7");
        Casilla solar8 = encontrar_casilla("Solar8");
        if (solar6 != null && solar7 != null && solar8 != null) {
            Grupo grupoRosa = new Grupo((Propiedad)solar6, (Propiedad)solar7, (Propiedad)solar8, "Rosa");
            this.grupos.put("Rosa", grupoRosa);
        }

        // Grupo Laranxa (Solar9, Solar10, Solar11)
        Casilla solar9 = encontrar_casilla("Solar9");
        Casilla solar10 = encontrar_casilla("Solar10");
        Casilla solar11 = encontrar_casilla("Solar11");
        if (solar9 != null && solar10 != null && solar11 != null) {
            Grupo grupoLaranxa = new Grupo((Propiedad)solar9, (Propiedad)solar10, (Propiedad)solar11, "Laranxa");
            this.grupos.put("Laranxa", grupoLaranxa);
        }

        // Grupo Vermello (Solar12, Solar13, Solar14)
        Casilla solar12 = encontrar_casilla("Solar12");
        Casilla solar13 = encontrar_casilla("Solar13");
        Casilla solar14 = encontrar_casilla("Solar14");
        if (solar12 != null && solar13 != null && solar14 != null) {
            Grupo grupoVermello = new Grupo((Propiedad)solar12, (Propiedad)solar13, (Propiedad)solar14, "Vermello");
            this.grupos.put("Vermello", grupoVermello);
        }

        // Grupo Amarelo (Solar15, Solar16, Solar17)
        Casilla solar15 = encontrar_casilla("Solar15");
        Casilla solar16 = encontrar_casilla("Solar16");
        Casilla solar17 = encontrar_casilla("Solar17");
        if (solar15 != null && solar16 != null && solar17 != null) {
            Grupo grupoAmarelo = new Grupo((Propiedad)solar15, (Propiedad)solar16, (Propiedad)solar17, "Amarelo");
            this.grupos.put("Amarelo", grupoAmarelo);
        }

        // Grupo Verde (Solar18, Solar19, Solar20)
        Casilla solar18 = encontrar_casilla("Solar18");
        Casilla solar19 = encontrar_casilla("Solar19");
        Casilla solar20 = encontrar_casilla("Solar20");
        if (solar18 != null && solar19 != null && solar20 != null) {
            Grupo grupoVerde = new Grupo((Propiedad)solar18, (Propiedad)solar19, (Propiedad)solar20, "Verde");
            this.grupos.put("Verde", grupoVerde);
        }

        // Grupo Azul Escuro (Solar21, Solar22)
        Casilla solar21 = encontrar_casilla("Solar21");
        Casilla solar22 = encontrar_casilla("Solar22");
        if (solar21 != null && solar22 != null) {
            Grupo grupoAzulEscuro = new Grupo((Propiedad)solar21, (Propiedad)solar22, "Azul Escuro");
            this.grupos.put("Azul Escuro", grupoAzulEscuro);
        }
    }

    //Metodo para construir unha lista lineal con todas as casillas do taboleiro
    public ArrayList<Casilla> CasillasLineales() {
        ArrayList<Casilla> lista = new ArrayList<>();
        for (ArrayList<Casilla> lado : this.posiciones) {
            lista.addAll(lado);
        }
        return lista;
    }

    // ========== GETTERS ==========

    public Jugador getBanca() {
        return banca;
    }

    public ArrayList<ArrayList<Casilla>> getPosiciones() {
        return posiciones;
    }

    public ArrayList<ArrayList<Casilla>> getCasillas() {
        return posiciones;
    }

    public HashMap<String, Grupo> getGrupos() {
        return grupos;
    }

}