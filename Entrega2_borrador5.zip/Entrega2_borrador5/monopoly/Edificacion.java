package monopoly;

import partida.*;

public class Edificacion {
    private static int contadorGlobal = 1;
    private String id;
    private String tipo; // casa, hotel, piscina, pista_deporte
    private Jugador propietario;
    private Casilla casilla;
    private float coste;

    public Edificacion(String tipo, Jugador propietario, Casilla casilla, float coste) {
        this.tipo = tipo.toLowerCase();
        this.propietario = propietario;
        this.casilla = casilla;
        this.coste = coste;
        this.id = this.tipo + "-" + contadorGlobal++;
    }

    public String getId() { return id; }
    public String getTipo() { return tipo; }
    public Jugador getPropietario() { return propietario; }
    public Casilla getCasilla() { return casilla; }
    public float getCoste() { return coste; }

    @Override
    public String toString() {
        return "{ id: " + id +
                ", propietario: " + propietario.getNombre() +
                ", casilla: " + casilla.getNombre() +
                ", grupo: " + casilla.getGrupo() +
                ", coste: " + (int) coste + " }";
    }
}
