package monopoly;

import partida.Jugador;
import java.util.ArrayList;

public class CartasSuerte {

    private int indiceSuerte;
    private int indiceComunidad;

    //sacar carta de suerte
    public void sacarCartaSuerte(Jugador jugador, Tablero tablero, ArrayList<Jugador> jugadores) {
        this.indiceSuerte = (this.indiceSuerte % 7) + 1; //7 cartas de sorte, reiniciamos o indice se pasamos de 7 (empezando por 0)
        System.out.println(jugador.getNombre() + ", saca unha carta de Sorte: " + indiceSuerte + ".");

        switch (this.indiceSuerte) {
            case 1:
                System.out.println("Acción: Decides facer unha viaxe de pracer. Avanza ata Solar19. Se pasas pola Saída, cobra 2.000.000€.");
                jugador.getAvatar().moverAvatarHasta("Solar19", tablero.getCasillas(), tablero);
                break;

            case 2:
                System.out.println("Acción: Os acredores persíguenche por impago. Vai direcamente ao cárcere, sen pasar pola saída e sen cobrar os 2.000.000€.");
                jugador.encarcelar(tablero.getPosiciones(), tablero);
                break;

            case 3:
                System.out.println("Acción: Ganas o bote da lotería. Recibe 1.000.000€.");
                jugador.sumarFortuna(1000000);
                jugador.registrarPremio(1000000);
                break;

            case 4:
                System.out.println("Acción: Foches elixido presidente da xunta directiva. Paga a cada xogador 250.000€.");
                pagarAosDemais(jugador, jugadores, 250000, tablero);
                break;

            case 5:
                System.out.println("Acción: Hora punta de tráfico! Retrocede 3 casillas.");
                jugador.getAvatar().moverAvatar(tablero.getPosiciones(), -3, tablero);
                break;

            case 6:
                System.out.println("Acción: Multante por usar o móbil mentres conduces. Paga 150.000€.");
                pagarMultaParking(jugador, tablero, 150000);
                break;
            case 7:
                System.out.println("Acción: Avanza ata a casilla de transporte máis cercana. Se non te dono, podes comprala. Se ten dono, paga ao dono o dobre da operación indicada");
                avanzarTransporteMaisCercano(jugador, tablero);
                break;
        }
    }

    //Metodo para sacar a carta da caixa de Comunidade
    public void sacarCartaComunidad(Jugador jugador, Tablero tablero) {
        this.indiceComunidad = (this.indiceComunidad % 6) + 1; //6 cartas de comunidade, reiniciamos o indice se pasamos de 6 (empezando por 0)
        System.out.println(jugador.getNombre() + ", saca unha carta de Caixa de Comunidade: " + indiceComunidad + ".");

        switch (this.indiceComunidad) {
            case 1:
                System.out.println("Acción: Paga 500.000€ por un fin de semana nun balneario de 5 estrelas.");
                pagarMultaParking(jugador, tablero, 500000);
                break;
            case 2:
                System.out.println("Acción: Investígante por fraude de identidade. Vai ao cárcere. Vai directamente sen pasar pola Saída e sen cobrar os 2.000.000€.");
                jugador.encarcelar(tablero.getPosiciones(), tablero);
                break;
            case 3:
                System.out.println("Acción: Colócate na casilla de Saída. Cobra 2.000.000€.");
                jugador.getAvatar().moverAvatarHasta("Salida", tablero.getCasillas(), tablero);
                break;
            case 4:
                System.out.println("Acción: Devolución de Facenda. Cobra 500.000€.");
                jugador.sumarFortuna(500000);
                jugador.registrarPremio(500000);
                break;

            case 5:
                System.out.println("Acción: Retrocede ata Solar1 para comprar antigüidades exóticas.");
                jugador.getAvatar().moverAvatarHasta("Solar1", tablero.getCasillas(), tablero);
                break;

            case 6:
                System.out.println("Acción: Vai a Solar20 para gozar do San Fermín. Se pasas pola Saída, cobra 2.000.000€.");
                jugador.getAvatar().moverAvatarHasta("Solar20", tablero.getCasillas(), tablero);
        }
    }

    //O xogador paga unha multa e o diñeiro vai ao Parking.
    private void pagarMultaParking(Jugador jugador, Tablero tablero, float cantidade) {
        if (jugador.puedePagar(cantidade)) {
            jugador.sumarFortuna(-cantidade);
            jugador.sumarGastos(cantidade);
            jugador.registrarTasa(cantidade);
            Casilla parking = tablero.encontrar_casilla("Parking");
            if (parking != null){
                parking.sumarValor(cantidade);
            }
        } else {
            System.out.println(jugador.getNombre() + " non pode pagar " + (int) cantidade + "€. Debe hipotecar ou declararse en bancarrota.");
        }
    }

    //Metodo para que o xogador pague a cada un dos outros xogadores unha cantidade determinada
    public void pagarAosDemais(Jugador pagador, ArrayList<Jugador> jugadores, float cantidade, Tablero tablero) {
        // Calcular canto precisa pagar en total
        int numJugadoresAPagar = 0;
        for (Jugador j : jugadores) {
            if (j != pagador && !j.isEnBancarrota()) {
                numJugadoresAPagar++;
            }
        }

        float total = numJugadoresAPagar * 250000;

        // Se pode pagar, realiza os pagos
        if (pagador.puedePagar(total)) {
            for (Jugador j : jugadores) {
                if (j != pagador && !j.isEnBancarrota()) {
                    pagador.pagarJugador(j, 250000, tablero);
                }
            }
        } else {
            System.out.println(pagador.getNombre() + " non ten diñeiro suficiente para pagar a todos os xogadores (" + (int)total + "€). Debe hipotecar propiedades ou declararse en bancarrota.");
        }
    }

    //metodo para avanzar ao transporte mais cercano
    private void avanzarTransporteMaisCercano(Jugador jugador, Tablero tablero) {
        ArrayList<ArrayList<Casilla>> casillasTablero = tablero.getCasillas();

        // Obtemos unha lista plana de todas as casillas do taboleiro
        ArrayList<Casilla> todasCasillas = tablero.CasillasLineales();

        Casilla actual = jugador.getAvatar().getLugar();

        //Busca o seguinte transporte
        int posActual = todasCasillas.indexOf(actual);
        Casilla destino = null;
        do {
            posActual = (posActual + 1) % todasCasillas.size();
            if ("transporte".equalsIgnoreCase(todasCasillas.get(posActual).getTipo())) {
                destino = todasCasillas.get(posActual);
                break;
            }
        } while (posActual != todasCasillas.indexOf(actual));

        if (destino != null) {
            System.out.println("Avanzas ata a casilla de transporte máis cercana: " + destino.getNombre() + ".");
            jugador.getAvatar().moverAvatarHasta(destino.getNombre(), casillasTablero, tablero);
            destino.evaluarCasilla(jugador, tablero.getBanca(), 0, tablero);
        } else {
            System.out.println("Non se atopou ningunha casilla de transporte.");
        }
    }
    //todo lo que se paga pagoTasasEImpuestos, y todo lo que el jugador recibe registrarPremio
}