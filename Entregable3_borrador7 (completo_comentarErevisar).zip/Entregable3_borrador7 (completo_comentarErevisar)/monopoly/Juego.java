package monopoly;

import monopoly.cartas.CartaSuerte;
import partida.*; //impórtanse todas as clases do paquete partida
import monopoly.casillas.*;
import monopoly.edificios.*;
import monopoly.cartas.*;
import monopoly.exceptions.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner; //Para ler a entrada do usuario
import java.io.File; // Para xestionar ficheiros
import java.io.FileNotFoundException; //obligatorio para que funcione new Scanner ao ler o arquivo

public class Juego implements Comando{

    //Atributos
    private static Consola consola; //Consola para interacción co usuario

    private ArrayList<Jugador> jugadores; //Jugadores de la partida.
    private ArrayList<Avatar> avatares; //Avatares en la partida.
    private int turno = 0; //Índice correspondiente a la posición en el arrayList del jugador (y el avatar) que tienen el turno
    private int lanzamientos; //Variable para contar el número de lanzamientos de un jugador en un turno.
    private Tablero tablero; //Tablero en el que se juega.
    private Dado dado1; //Dos dados para lanzar y avanzar casillas.
    private Dado dado2;
    private Jugador banca; //El jugador banca.
    private boolean tirado; //Booleano para comprobar si el jugador que tiene el turno ha tirado o no.
    private boolean solvente; //Booleano para comprobar si el jugador que tiene el turno es solvente, es decir, si ha pagado sus deudas.
    private boolean dadosLanzados; //Comprobar que os dados foron lanzados e xa comezou a partida

    private ArrayList<Carta> mazoSuerte; // mazo de cartas de sorte
    private ArrayList<Carta> mazoComunidad; // mazo de cartas de comunidade
    private int indiceSuerte = 0; // índice para seguir a carta de sorte actual
    private int indiceComunidad = 0; // índice para seguir a carta de comunidade actual

    private int contadorTratos = 0; // contador para xerar ids de trato
    private ArrayList<Trato> tratosPendentes; // lista de tratos pendentes

    public Juego(boolean modoInteractivo) { //constructor do menú se non se recibe un arquivo

        if (consola == null){
            consola = new ConsolaNormal(); // Inicializamos a consola estática para a interacción
        }

        // Inicializamos as listas de xogadores e avatares
        this.jugadores = new ArrayList<>();
        this.avatares = new ArrayList<>();
        this.tratosPendentes = new ArrayList<>();
        this.banca = new Jugador(); // Creamos a banca do xogo
        this.tablero = new Tablero(banca); // Creamos o taboleiro asociado á banca

        // Creamos os dous dados para o xogo
        this.dado1 = new Dado();
        this.dado2 = new Dado();

        //this.cartasSuerte = new CartasSuerte();
        this.mazoSuerte = new ArrayList<>();
        this.mazoComunidad = new ArrayList<>();
        this.indiceSuerte = -1;  // Empieza en -1, así a primeira será 0
        this.indiceComunidad = -1;
        inicializarMazosCartas();

        this.turno = 0; // Comeza o primeiro xogador
        this.lanzamientos = 0; // Aínda non houbo lanzamentos
        this.tirado = false; // Aínda non se lanzaron dados
        this.solvente = true; // Asumimos que é solvente inicialmente
        this.dadosLanzados = false; // Inicialmente non se lanzaron dados

        if (modoInteractivo) {
            this.iniciarPartida(); // Iniciamos a partida en modo interactivo
        }
    }

    // Metodo para iniciar unha partida: crea os xogadores e avatares
    private void iniciarPartida() {
        consola.imprimir("Benvido ao Monopoly ETSE!");
        mostrarAyuda();

        // Scanner permite ler entrada de texto. Neste caso, do teclado (System.in)
        //Scanner sc = new Scanner(System.in); (xa non se usa ao facer consola.ler)

        while (true) { // Bucle infinito
            try {
                String comando = consola.ler("\n$> ").trim();

                /*System.out.print("\n$> "); // Mostramos o prompt para o comando
                String comando = sc.nextLine().trim(); (xa non se usa ao facer consola.ler)*/

                /* sc.nextLine(), le unha liña completa do teclado ata premer Enter
                 * trim(), elimina espazos en branco do inicio e final da liña
                 */

                if (comando.equalsIgnoreCase("salir")) { //Se o comando é "salir", saímos do xogo
                    consola.imprimir("\nSaíndo do xogo... Ata pronto!");
                    break; // Saímos do bucle

                } else if (comando.startsWith("comandos ")) { //Se o comando empeza por "comandos ", lense os comandos dende un ficheiro
                    String nomeFicheiro = comando.substring(9);
                    /* substring(9), toma a parte da cadea que vai desde a posición 9 ata o final.
                     * Isto elimina a palabra "comandos " e deixa só o nome do ficheiro
                     */
                    this.lerFicheiroComandos(nomeFicheiro);

                } else { // Calquera outro comando envíase ao metodo que interpreta comandos
                    this.analizarComando(comando);
                }
            } catch (MonopolyException e) {
                consola.imprimir("Erro: " + e.getMessage());
            } catch (Exception e) {
                consola.imprimir("Erro inesperado: " + e.getMessage());
            }
        }
        //sc.close(); // Pechamos o scanner ao saír do xogo (xa non se usa ao facer consola.ler)
    }

    //Metodo para inicializar os mazos de cartas
    private void inicializarMazosCartas() {
        mazoSuerte.add(new CartaSuerte("Decides facer unha viaxe de pracer. Avanza ata Solar19. Se pasas pola Saída, cobra 2.000.000€.", 1, CartaSuerte.TipoAccion.AVANZAR_SOLAR19));
        mazoSuerte.add(new CartaSuerte("Os acredores persíguenche por impago. Vai direcamente ao cárcere, sen pasar pola saída e sen cobrar os 2.000.000€.", 2, CartaSuerte.TipoAccion.IR_CARCEL));
        mazoSuerte.add(new CartaSuerte("Ganas o bote da lotería. Recibe 1.000.000€.", 3, CartaSuerte.TipoAccion.LOTERIA));
        mazoSuerte.add(new CartaSuerte("Foches elixido presidente da xunta directiva. Paga a cada xogador 250.000€.", 4, CartaSuerte.TipoAccion.PAGAR_TODOS));
        mazoSuerte.add(new CartaSuerte("Hora punta de tráfico! Retrocede 3 casillas.", 5, CartaSuerte.TipoAccion.RETROCEDER3));
        mazoSuerte.add(new CartaSuerte("Multante por usar o móbil mentres conduces. Paga 150.000€.", 6, CartaSuerte.TipoAccion.MULTA_MOVIL));
        mazoSuerte.add(new CartaSuerte("Avanza ata a casilla de transporte máis cercana. Se non te dono, podes comprala. Se ten dono, paga ao dono o dobre da operación indicada", 7, CartaSuerte.TipoAccion.AVANZAR_TRANSPORTE));

        // Inicializar cartas de Comunidade
        mazoComunidad.add(new CartaCajaComunidad("Paga 500.000€ por un fin de semana nun balneario de 5 estrelas.", 1, CartaCajaComunidad.TipoAccion.PAGAR_BALNEARIO));
        mazoComunidad.add(new CartaCajaComunidad("Investígante por fraude de identidade. Vai ao cárcere. Vai directamente sen pasar pola Saída e sen cobrar os 2.000.000€.", 2, CartaCajaComunidad.TipoAccion.IR_CARCEL_FRAUDE));
        mazoComunidad.add(new CartaCajaComunidad("Colócate na casilla de Saída. Cobra 2.000.000€.", 3, CartaCajaComunidad.TipoAccion.IR_SALIDA));
        mazoComunidad.add(new CartaCajaComunidad("Devolución de Facenda. Cobra 500.000€.", 4, CartaCajaComunidad.TipoAccion.DEVOLUCION_FACENDA));
        mazoComunidad.add(new CartaCajaComunidad("Retrocede ata Solar1 para comprar antigüidades exóticas.", 5, CartaCajaComunidad.TipoAccion.RETROCEDER_SOLAR1));
        mazoComunidad.add(new CartaCajaComunidad("Vai a Solar20 para gozar do San Fermín. Se pasas pola Saída, cobra 2.000.000€.", 6, CartaCajaComunidad.TipoAccion.IR_SOLAR20));
    }

    /* Metodo que interpreta o comando introducido e toma a acción correspondente
     * Parámetro: cadea de caracteres (o comando)
     */
    @Override
    public void analizarComando(String comando) throws MonopolyException {
        // Separa a cadea por espazos entre palabras
        String[] partes = comando.trim().split("\\s+");
        //split("\\s+"), divide a cadea en partes usando un ou varios espazos como separador

        if (partes.length == 0){
            return; // Se está baleiro, non facemos nada
        }

        if (!this.jugadores.isEmpty()) {
            Jugador actual = this.jugadores.get(this.turno);
            if (actual.getFortuna() < 0 && !actual.isEnBancarrota()) { //se o xogador ten débedas pendentes
                consola.imprimir(actual.getNombre() + " aínda ten débedas pendentes (" + (int)Math.abs(actual.getFortuna()) + "€).");
                consola.imprimir("Use 'hipotecar <casilla>' ou 'acabar turno' para resolver.");
            }
        }

        switch (partes[0].toLowerCase()) { //Analiza o primeiro termo do comando en minúsculas

            case "crear": // Comando: crear jugador <nombre> <tipoAvatar>
                if (partes.length >= 4 && partes[1].equalsIgnoreCase("jugador")) {
                    this.crearJugador(partes[2], partes[3]); // Creamos o novo xogador
                } else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: crear jugador <nome> <avatar>");
                }
                break;
            case "jugador": // Comando: jugador - mostra o xogador actual
                this.mostrarJugadorActual();
                break;
            case "listar":
                comandoListar(partes);
                break;
            case "lanzar": // Comando: lanzar dados [valor]
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("dados")) {
                    if (partes.length >= 3) {
                        this.forzarDados(partes[2]); // Lanzamento forzado
                        this.dadosLanzados = true;
                    } else {
                        this.lanzarDados(); // Lanzamento aleatorio
                        this.dadosLanzados = true;
                    }
                }else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: lanzar dados [valor]");
                }
                break;
            case "describir": // Comando: describir jugador <nome> ou describir <casilla>
                if (partes.length >= 3 && partes[1].equalsIgnoreCase("jugador")) {
                    this.descJugador(partes[2]); //Describir Jugador
                } else if (partes.length >= 2) {
                    this.descCasilla(partes[1]); // Describir casilla
                } else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: describir jugador <nome> OU describir <casilla>");
                }
                break;
            case "comprar": // Comando: comprar <propiedade>
                if (partes.length >= 2) {
                    this.comprar(partes[1]);
                } else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: comprar <nomeCasilla>");
                }
                break;
            case "salir": // Comando: salir carcel
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("carcel")) {
                    this.salirCarcere();
                } else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: salir carcel");
                }
                break;
            case "acabar": // Comando: acabar turno
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("turno")) {
                    this.acabarTurno();
                } else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: acabar turno");
                }
                break;
            case "ver": // Comando: ver tablero
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("tablero")) {
                    this.verTablero();
                } else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: ver tablero");
                }
                break;
            case "edificar":
                comandoEdificar(partes);
                break;
            case "hipotecar":
                hipotecar(partes);
                break;
            case "deshipotecar":
                deshipotecar(partes);
                break;
            case "vender":
                comandoVender(partes);
                break;
            case "estadisticas":
                if (partes.length >= 2) {
                    this.estadisticasJugador(partes[1]);
                } else {
                    this.estadisticasJuego();
                }
                break;
            case "trato":  // ex: trato Maria: cambiar (Solar1, Solar14 y 300000)
                proponerTrato(comando);  // pásase a liña completa
                break;

            case "aceptar":  // ex: aceptar trato20
                if (partes.length >= 3 && partes[1].equalsIgnoreCase("trato")) {
                    aceptarTrato(partes[2]);
                } else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: aceptar trato <idTrato>");
                }
                break;

            case "eliminar":  // ex: eliminar trato20
                if (partes.length >= 3 && partes[1].equalsIgnoreCase("trato")) {
                    eliminarTrato(partes[2]);
                } else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: eliminar trato <idTrato>");
                }
                break;

            case "tratos":   // lista tratos do xogador actual
                listarTratos();
                break;
            default:
                throw new NonExisteComandoException(comando);
        }
    }

    /* Metodo que realiza as accións asociadas ao comando 'describir jugador'
     * Parámetro: comando introducido
     */
    @Override
    public void descJugador(String nombreBuscar) throws MonopolyException{

        Jugador jugador = null;

        for (Jugador j: jugadores) { // Buscamos o xogador na lista de xogadores
            if (j.getNombre().equalsIgnoreCase(nombreBuscar)) {
                jugador = j;
                break;
            }
        }

        if (jugador == null) { // Se non atopamos o xogador, mostramos erro
            throw new NonExisteXogadorException(nombreBuscar);
        }
        consola.imprimir(jugador.infoJugador()); // Mostramos a información do xogador
    }

    /* Metodo que realiza as accións asociadas ao comando 'describir nombre_casilla'
     * Parámetros: nome da casilla a describir
     */
    @Override
    public void descCasilla(String nombre) throws MonopolyException{
        Casilla c = this.tablero.encontrar_casilla(nombre); // Buscamos a casilla no taboleiro
        if (c == null) { // Se non se atopa a casilla, mostramos erro
            throw new NonExisteCasillaException(nombre);
        }
        consola.imprimir(c.infoCasilla()); // Mostramos a información da casilla
    }

    @Override
    public void comandoEdificar(String[] partes) throws MonopolyException {
        if (this.jugadores.isEmpty()) {
            throw new EstadoXogoException("Non hai xogadores na partida.");
        }

        if (partes.length < 2) {
            throw new ComandoInvalidoException("Formato incorrecto. Use: edificar <tipo>");
        }

        Jugador jugadorActual = this.jugadores.get(this.turno);
        String tipoEdificio = partes[1].toLowerCase();

        // Validar tipo de edificio
        if (!tipoEdificio.equals("casa") && !tipoEdificio.equals("hotel") && !tipoEdificio.equals("piscina") && !tipoEdificio.equals("pista")) {
            throw new NonExisteEdificioException(tipoEdificio, "solar");
        }

        // Verificar que o xogador está nun solar
        Casilla casillaActual = jugadorActual.getAvatar().getLugar();
        if (casillaActual == null || !(casillaActual instanceof Solar)) {
            throw new EstadoXogoException("Só podes edificar nun solar e debes estar na casilla onde queres edificar.");
        }

        Solar solar = (Solar) casillaActual;

        // Intentar edificar
        try {
            solar.construirEdificio(tipoEdificio, jugadorActual);
            consola.imprimir("Constrúese un " + tipoEdificio + " en " + solar.getNombre() + ".");
        } catch (MonopolyException e) {
            throw e;
        } catch (Exception e) {
            throw new EstadoXogoException("Erro ao edificar: " + e.getMessage());
        }
    }

    @Override
    public void comandoListar(String[] partes) throws MonopolyException{
        if (partes.length < 2){
            throw new ComandoInvalidoException("Formato incorrecto. Use: listar jugadores|edificios|enventa");
        }

        switch (partes[1].toLowerCase()) {
            case "jugadores":
                listarJugadores();
                break;
            case "edificios":
                if (partes.length == 2) {
                    listarTodosEdificios();
                } else {
                    // Reconstruimos o nombre completo do grupo
                    StringBuilder colorGrupoBuilder = new StringBuilder();
                    for (int i = 2; i < partes.length; i++) {
                        if (i > 2){
                            colorGrupoBuilder.append(" "); // añadimos espacio entre palabras
                        }
                        colorGrupoBuilder.append(partes[i]);
                    }
                    listarEdificiosGrupo(colorGrupoBuilder.toString());
                }
                break;
            case "enventa":
                listarVenta();
                break;
            default:
                throw new ComandoInvalidoException("Subcomando listar non recoñecido: " + partes[1]);
        }
    }

    private void listarTodosEdificios() {
        boolean hayEdificios = false;

        for (Jugador j : jugadores) {
            // Listar directamente os edificios do xogador (teñen IDs únicos)
            for (Edificio edificio : j.getEdificios()) {
                consola.imprimir(edificio.toString());
                hayEdificios = true;
            }
        }

        if (!hayEdificios) {
            consola.imprimir("Non hai edificios construidos.");
        }
    }


    private void listarEdificiosGrupo(String colorGrupo) {
        boolean hayEdificios = false; // bandera para saber si hay edificios

        // Percorrer todos os xogadores e buscar edificios en solares do grupo especificado
        for (Jugador j : jugadores) {
            for (Casilla propiedad : j.getPropiedades()) {
                if (propiedad instanceof Solar) {
                    Solar solar = (Solar) propiedad;

                    if (solar.getGrupo() != null && solar.getGrupo().getColorGrupo().equalsIgnoreCase(colorGrupo)) {
                        // Mostrar edificios deste solar
                        for (Edificio e : j.getEdificios()) {
                            // Verificar se o edificio está neste solar (precisa implementación adicional)
                            consola.imprimir(e.toString());
                            hayEdificios = true;
                        }
                    }
                }
            }
        }

        if (!hayEdificios) {
            consola.imprimir("Non hai edificios no grupo " + colorGrupo + ".");
        }
    }

    // Metodo que executa todas as accións relacionadas co comando 'lanzar dados'
    @Override
    public void lanzarDados() throws MonopolyException{
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            throw new EstadoXogoException("Non hai xogadores na partida.");
        }
        if (this.jugadores.size() < 2){
            throw new EstadoXogoException("Non se poden lanzar os dados ata que haxa polo menos 2 xogadores.");
        }

        Jugador actual = this.jugadores.get(this.turno); // Obtenemos o xogador actual

        if (actual.isEnCarcel()) { // Verificamos se o xogador está no cárcere
            if (!this.tirado){
                //intenta salir de carcel
                int resultado = actual.intentarSalirCarcel(this.dado1, this.dado2, this.tablero, false, 0, 0);
                if (resultado == -1){
                    return; //está en bancarrota, non pode sair
                } else if (resultado == 0) {
                    //segue no carcere, non se move
                    this.tirado = true;
                    return;
                }
                else {
                    // resultado == 1: Sae do carcere e movese cos dados
                    int valor1 = this.dado1.getValor(); // Usamos o valor xa tirado
                    int valor2 = this.dado2.getValor();
                    this.tirado = true;
                    gestionarTirada(actual, valor1, valor2);
                }
            }else {
                throw new EstadoXogoException("Xa se tiraron os dados, remata o turno.");
            }
        } else {
            if (!this.tirado){ //só se non se tirou con anterioridade
                // Facemos a tirada aleatoria dos dados
                int valor1 = this.dado1.hacerTirada();
                int valor2 = this.dado2.hacerTirada();

                gestionarTirada(actual, valor1, valor2);
            } else {
                throw new EstadoXogoException("Xa se tiraron os dados, remata o turno.");
            }
        }
    }

    /* Metodo que executa todas as accións realizadas co comando 'comprar nombre_casilla'
     * Parámetro: cadea de caracteres co nome da casilla
     */
    @Override
    public void comprar(String nombre) throws MonopolyException {
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            throw new EstadoXogoException("Non hai xogadores na partida.");
        }

        Jugador jugadorActual = this.jugadores.get(this.turno); // Xogador que ten o turno
        Casilla casilla = this.tablero.encontrar_casilla(nombre); // Buscamos a casilla no taboleiro

        if (casilla == null) { // Verificamos que a casilla exista
            throw new NonExisteCasillaException(nombre);
        }

        // Verificamos que o xogador está na casilla que quere comprar
        if (!jugadorActual.getAvatar().getLugar().equals(casilla)) {
            //equalsIgnoreCase só funciona con String, pero casilla é un obxecto Casilla polo que se usa equals
            throw new EstadoXogoException("Só podes comprar a casilla na que estás actualmente: " + jugadorActual.getAvatar().getLugar().getNombre());
        }

        // Verificamos que a casilla sexa comprable (que sexa unha propiedade)
        if (!(casilla instanceof Propiedad)) {
            throw new EstadoXogoException("Non se pode comprar a casilla " + nombre + ".");
        }

        Propiedad propiedad = (Propiedad) casilla;

        // Verificamos que a casilla non teña dono ou sexa da banca
        if (propiedad.getDuenho() != null && !propiedad.getDuenho().equals(banca)) {
            throw new PropiedadeNonPertenceException(jugadorActual.getNombre(), propiedad.getDuenho().getNombre(), nombre);
        }

        // Verificar que ten diñeiro suficiente
        if (!jugadorActual.puedePagar(propiedad.getValor())) {
            throw new DiñeiroInsuficienteException(jugadorActual.getNombre(), propiedad.getValor(), jugadorActual.getFortuna());
        }

        // Comprar a propiedade
        propiedad.comprar(jugadorActual);
    }

    @Override
    public void comandoVender(String[] partes) throws MonopolyException {
        if (jugadores.isEmpty()) {
            throw new EstadoXogoException("Non hai xogadores na partida.");
        }

        if (partes.length < 4) {
            throw new ComandoInvalidoException("Formato incorrecto. Use: vender <tipo> <nomeCasilla> <cantidade>");
        }

        String tipo = partes[1];
        String nombreCasilla = partes[2];
        int cantidad = Integer.parseInt(partes[3]);

        Casilla casilla = tablero.encontrar_casilla(nombreCasilla);
        if (casilla == null) {
            throw new NonExisteCasillaException(nombreCasilla);
        }

        // Verificamos que a casilla sexa vendible (que sexa unha propiedade)
        if (!(casilla instanceof Propiedad)) {
            throw new EstadoXogoException("Non se pode vender a casilla " + nombreCasilla + ".");
        }

        Propiedad propiedad = (Propiedad) casilla;
        Jugador jugadorActual = jugadores.get(turno);

        if (!propiedad.getDuenho().equals(jugadorActual)) {
            throw new PropiedadeNonPertenceException(jugadorActual.getNombre(), nombreCasilla);
        }

        // Só se poden vender edificios en Solares
        if (!(propiedad instanceof Solar)) {
            throw new EstadoXogoException("Só se poden vender edificios en solares.");
        }

        Solar solar = (Solar) propiedad;

        // Intentar vender o edificio
        try {
            boolean vendido;
            for (Edificio edificio : jugadorActual.getEdificios()) {
                if (edificio.getSolar().equals(solar) && edificio.obterTipoEdificio().equalsIgnoreCase(tipo)) {
                    vendido = edificio.vender();
                    if (vendido){
                        cantidad--;
                    }
                    if (cantidad == 0){
                        break;
                    }
                }
            }
            consola.imprimir("Vendéronse " + cantidad + " " + tipo + "(s) en " + nombreCasilla + ".");
        } catch (MonopolyException e) {
            throw e;
        } catch (Exception e) {
            throw new EstadoXogoException("Erro ao vender edificio: " + e.getMessage());
        }
    }

    public void hipotecar(String[] partes) throws MonopolyException {
        if (partes.length < 2) {
            throw new ComandoInvalidoException("Formato incorrecto. Use: hipotecar <nomeCasilla>");
        }

        String nombreCasilla = partes[1];
        Casilla c = tablero.encontrar_casilla(nombreCasilla);
        if (c == null) {
            throw new NonExisteCasillaException(nombreCasilla);
        }

        Jugador jugadorActual = jugadores.get(turno);

        // Só se poden hipotecar Solares
        if (!(c instanceof Solar)) {
            throw new EstadoXogoException("Só se poden hipotecar solares.");
        }

        Solar solar = (Solar) c;

        if (solar.estaHipotecada()) {
            throw new PropiedadeHipotecadaException(nombreCasilla);
        }

        if (!solar.getDuenho().equals(jugadorActual)) {
            throw new PropiedadeNonPertenceException(jugadorActual.getNombre(), nombreCasilla);
        }

        // Verificar que non ten edificios
        if (solar.tieneEdificios()) {
            throw new PropiedadeEdificiosException(nombreCasilla);
        }

        // Hipotecar o solar
        try {
            solar.hipotecar(jugadorActual);
            consola.imprimir(jugadorActual.getNombre() + " hipotecou " + nombreCasilla +
                    " por " + (int)solar.getHipoteca() + "€.");
        } catch (MonopolyException e) {
            throw e;
        } catch (Exception e) {
            throw new EstadoXogoException("Erro ao hipotecar: " + e.getMessage());
        }
    }

    @Override
    public void deshipotecar(String[] partes) throws MonopolyException {
        if (partes.length < 2) {
            throw new ComandoInvalidoException("Formato incorrecto. Use: deshipotecar <nomeCasilla>");
        }

        String nombreCasilla = partes[1];
        Casilla c = tablero.encontrar_casilla(nombreCasilla);
        if (c == null) {
            throw new NonExisteCasillaException(nombreCasilla);
        }

        Jugador jugadorActual = jugadores.get(turno);

        // Só se poden deshipotecar Solares
        if (!(c instanceof Solar)) {
            throw new EstadoXogoException("Só se poden deshipotecar solares.");
        }

        Solar solar = (Solar) c;

        if (!solar.estaHipotecada()) {
            throw new EstadoXogoException("A casilla non está hipotecada.");
        }

        if (!solar.getDuenho().equals(jugadorActual)) {
            throw new PropiedadeNonPertenceException(jugadorActual.getNombre(), nombreCasilla);
        }

        float valorDeshipoteca = solar.getHipoteca();
        if (!jugadorActual.puedePagar(valorDeshipoteca)) {
            throw new DiñeiroInsuficienteException(jugadorActual.getNombre(), valorDeshipoteca,
                    jugadorActual.getFortuna());
        }

        // Deshipotecar
        try {
            solar.deshipotecar(jugadorActual);
            consola.imprimir(jugadorActual.getNombre() + " deshipotecou " + nombreCasilla + " por " + (int)valorDeshipoteca + "€.");
        } catch (MonopolyException e) {
            throw e;
        } catch (Exception e) {
            throw new EstadoXogoException("Erro ao deshipotecar: " + e.getMessage());
        }
    }

    // Metodo que executa todas as accións relacionadas co comando 'salir carcel'
    @Override
    public void salirCarcere() throws MonopolyException{
        if (this.jugadores.isEmpty()){
            throw new EstadoXogoException("Non hai xogadores.");
        }

        Jugador jugador = this.jugadores.get(this.turno); // Xogador que ten o turno

        if (!jugador.isEnCarcel()) { // Verificamos que o xogador estea no cárcere
            throw new XogadorCarcelException(jugador.getNombre(), "sair do cárcere (non está no cárcere)");
        }

        jugador.salirCarcel(tablero);
    }

    // Metodo que realiza as accións asociadas ao comando 'listar enventa'
    private void listarVenta() {
        boolean hayPropiedades = false; // Inicializamos unha bandeira para saber se hai propiedades en venda

        // Percorrer todas as casillas do taboleiro
        for (ArrayList<Casilla> lado : tablero.getPosiciones()) {
            for (Casilla casilla : lado) {
                if (casilla instanceof Propiedad) {
                    Propiedad propiedad = (Propiedad) casilla;
                    if (propiedad.getDuenho() == null || propiedad.getDuenho().equals(banca)) {
                        consola.imprimir(propiedad.toString());
                        hayPropiedades = true;
                    }
                }
            }
        }

        if (!hayPropiedades) {
            consola.imprimir("Non hai propiedades en venda.");
        }
    }

    // Metodo que realiza as accións asociadas ao comando 'listar jugadores'
    private void listarJugadores() {
        if (jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            consola.imprimir("Non hai xogadores na partida.");
            return;
        }

        // Percorremos todos os xogadores e mostramos a súa información
        for (Jugador j : this.jugadores) {
            consola.imprimir(j.infoJugador()); // Mostramos a información dos xogadores
        }
    }

    // Metodo que realiza as accións asociadas ao comando 'acabar turno'
    @Override
    public void acabarTurno() throws MonopolyException{

        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            throw new EstadoXogoException("Non hai xogadores.");
        }

        Jugador actual = this.jugadores.get(this.turno);
        //verificamos que o xogador actual teña tirado e sexa solvente
        if (!this.tirado) {
            throw new EstadoXogoException("Non podes acabar o turno sen lanzar os dados.");
        }

        boolean tenDebedas = (actual.getFortuna() < 0 && !actual.isEnBancarrota());

        if (tenDebedas) {
            Jugador pagarA = detectarPagar(actual); //detecta a quen lle debe o xogador actual
            actual.declararBancarrota(this.tablero, pagarA);
            xestionarBancarrota(actual);
        } else {
            this.turno = (this.turno + 1) % this.jugadores.size(); // Avanzamos ao seguinte xogador
            this.tirado = false; // Marcamos que non se lanzaron dados no novo turno
            this.solvente = true; // Asumimos que o novo xogador é solvent

            Jugador siguiente = this.jugadores.get(this.turno); // Obtenemos o novo xogador actual
            consola.imprimir("É o turno de: " + siguiente.getNombre() + "."); // Mostramos quen é o novo xogador
            consola.imprimir("Estado actual: " + siguiente); //toString creado en jugador
            mostrarTratosPendentes(siguiente);
        }
    }

    //Metodo para detectar a quen debe pagar o xogador en bancarrota e pasar as propiedades
    private Jugador detectarPagar(Jugador deudor) {
        if (deudor.getUltimoCobraAlquiler() != null) {
            return deudor.getUltimoCobraAlquiler();
        } else {
            return this.banca;
        }
    }

    // Metodo para ler o ficheiro cos comandos introducidos
    @Override
    public void lerFicheiroComandos(String nomeFicheiro) throws MonopolyException{
        File ficheiro = new File(nomeFicheiro); // Creamos un obxecto File co nome do ficheiro

        if (!ficheiro.exists()) { // Comprobamos se o ficheiro existe
            throw new MonopolyException("O ficheiro non existe: " + nomeFicheiro);
        }

        Scanner scanner = null; //declara o scanner pero non o inicializa
        try {
            scanner = new Scanner(ficheiro); // Ábrese o ficheiro en modo lectura
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine().trim(); //lemos a seguinte liña e eniminamos espazos en branco ao inicio/fin
                if (!linea.isEmpty() && !linea.startsWith("#")) { // Ignoramos liñas baleiras e comentarios
                    consola.imprimir("$> " + linea); // Mostramos o comando que se vai executar
                    this.analizarComando(linea); // Procesamos o comando
                }
            }
        } catch (FileNotFoundException e) { // Mostramos erro se non se pode abrir o ficheiro
            throw new MonopolyException("Non se pode abrir o ficheiro: " + e.getMessage());
        } finally {
            if (scanner != null) {
                scanner.close(); // Aseguramos que pechamos o scanner
            }
        }
    }

    // Metodo auxiliar para procesar o movemento despois de lanzar dados
    private void procesarMovimento(Jugador actual, int total) throws MonopolyException {
        Avatar avatar = actual.getAvatar();
        avatar.moverAvatar(this.tablero.getPosiciones(), total, tablero, true);
        Casilla casillaActual = avatar.getLugar();

        // Prepara los índices en un array
        int[] indices = new int[]{this.indiceSuerte, this.indiceComunidad};

        // Evaluar la casilla pasando los mazos
        try {
            this.solvente = casillaActual.evaluarCasilla(actual, banca, total, tablero, false,
                    mazoSuerte, mazoComunidad, indices);

            // Actualiza los índices
            this.indiceSuerte = indices[0];
            this.indiceComunidad = indices[1];

        } catch (MonopolyException e) {
            throw e;
        } catch (Exception e) {
            throw new EstadoXogoException("Erro ao avaliar a casilla: " + e.getMessage());
        }

        if (actual.getFortuna() < 0 && solvente) {
            consola.imprimir(actual.getNombre() + " ten débedas pendentes.");
        }

        consola.imprimir(tablero.toString());
        tirado = true;
    }

    //metodo para dobles
    public void gestionarTirada(Jugador actual, int valor1, int valor2) throws MonopolyException {
        int total = valor1 + valor2; // Calculamos o total da tirada

        if (valor1 == valor2) { // Comprobar dobres
            actual.incrementarDobles(); // Incrementamos dobles consecutivos

            if (actual.getDoblesConsecutivos() == 3) { // Tres dobles consecutivos implica que debe ir ao cárcere
                consola.imprimir(actual.getNombre() + " sacou dobles 3 veces seguidas, vai directamente ao cárcere.");
                actual.encarcelar(this.tablero.getPosiciones(), this.tablero);
                actual.resetearDobles();
                this.tirado = true;
                try{
                    acabarTurno();
                } catch (MonopolyException e){
                    consola.imprimir("Erro: " + e.getMessage());
                }
                return;
            } else {
                this.procesarMovimento(actual, total);
                consola.imprimir("¡Dobles! " + actual.getNombre() + " tira outra vez.");
                this.lanzamientos++;

                //permitir novo lanzamiento se é solvente
                this.tirado = false;
                if (actual.isEnBancarrota() || actual.getFortuna() < 0) {
                    this.tirado = true; // Non pode tirar de novo se está en bancarrota
                    xestionarBancarrota(actual);
                }
                return;
            }
        } else { // No son dobles
            actual.resetearDobles();
            this.procesarMovimento(actual, total);
            this.lanzamientos++;
            this.tirado = true; // Turno terminado
        }
        //comprobamos que non esté en bancarrota
        if (actual.getFortuna() <= 0) {
            consola.imprimir(actual.getNombre() + " ten débedas pendentes.");
            // Non declarar bancarrota automática - esperar a que o xogador decida
        }
    }

    // Metodo para lanzar dados con valores forzados
    @Override
    public void forzarDados(String valores) throws MonopolyException{
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            throw new EstadoXogoException("Non hai xogadores na partida.");
        }
        if (this.jugadores.size() < 2){
            throw new EstadoXogoException("Non se poden lanzar os dados ata que haxa polo menos 2 xogadores.");
        }

        Jugador actual = this.jugadores.get(this.turno); // Obtenemos o xogador actual
        int[] valoresDados = Dado.procesarTiradaForzada(valores); // Procesamos o formato "2+4"

        if (valoresDados == null) {
            throw new ComandoInvalidoException("Formato de tirada forzada inválido. Use 'numero+numero'.");
        }

        if (actual.isEnCarcel()) { // Verificamos se o xogador está no cárcere
            if (!this.tirado) {
                //intenta salir de carcel
                int resultado = actual.intentarSalirCarcel(this.dado1, this.dado2, this.tablero, true, valoresDados[0], valoresDados[1]);
                if (resultado == -1){
                    return; //está en bancarrota, non pode sair
                } else if (resultado == 0) {
                    //segue no carcere, non se move
                    this.tirado = true;
                    return;
                }
                else {
                    // resultado == 1: Sae do carcere e movese cos dados
                    this.tirado = true;
                    gestionarTirada(actual, valoresDados[0], valoresDados[1]);
                }
            } else {
                throw new EstadoXogoException("Xa se tiraron os dados, remata o turno.");
            }
        } else {
            if (!tirado) {
                //forzamos valores dos dados
                this.dado1.lanzarForzado(valoresDados[0]);
                this.dado2.lanzarForzado(valoresDados[1]);

                this.tirado = true;
                gestionarTirada(actual, valoresDados[0], valoresDados[1]);
            } else {
                throw new EstadoXogoException("Xa se tiraron os dados, remata o turno.");
            }
        }
    }

    // Metodo para mostrar o xogador actual
    @Override
    public void mostrarJugadorActual() throws MonopolyException {
        if (jugadores.isEmpty()) {
            throw new EstadoXogoException("Non hai xogadores na partida.");
        }

        Jugador actual = jugadores.get(turno);
        consola.imprimir("É o turno de: " + actual.getNombre() + ".");
        consola.imprimir("Estado actual: " + actual.toString());
    }

    @Override
    public void crearJugador(String nome, String tipoAvatar) throws MonopolyException {
        // Validacións do xogador antes de engadilo
        if (jugadores.size() >= 4) {
            throw new EstadoXogoException("Xa hai 4 xogadores, non se poden engadir máis.");
        }

        if (dadosLanzados) {
            throw new EstadoXogoException("Non se poden crear xogadores unha vez comezada a partida.");
        }

        for (Jugador j : jugadores) {
            if (j.getNombre().equalsIgnoreCase(nome)) {
                throw new EstadoXogoException("Xa existe un xogador con ese nome: " + nome);
            }
        }

        // Validar tipo de avatar
        String[] tiposValidos = {"Coche", "Esfinge", "Sombrero", "Pelota"};
        boolean tipoValido = false;
        for (String tipo : tiposValidos) {
            if (tipo.equalsIgnoreCase(tipoAvatar)) { //se o tipo coincide con algún dos válidos
                tipoValido = true;
                break;
            }
        }

        if (!tipoValido) {
            throw new ComandoInvalidoException("Tipo de avatar non válido. Usa: Coche, Esfinge, Sombrero ou Pelota.");
        }

        //Comprobamos que o tipo de avatar non estea xa collido
        for (Avatar av : avatares) {
            if (av.getTipo().equalsIgnoreCase(tipoAvatar)) {
                throw new EstadoXogoException("O tipo de avatar '" + tipoAvatar + "' xa está en uso.");
            }
        }

        //Buscar casilla de salida
        Casilla salida = tablero.encontrar_casilla("Salida");
        if (salida == null) {
            throw new NonExisteCasillaException("Salida");
        }

        //Crear novo xogador se non se produciron erros
        Jugador novoJugador = new Jugador(nome, tipoAvatar, salida, avatares);
        jugadores.add(novoJugador); // Engadimos o xogador á lista
        avatares.add(novoJugador.getAvatar()); // Engadimos o avatar á lista

        consola.imprimir("{\n" +
                "nome: " + novoJugador.getNombre() + ",\n" +
                "avatar: " + novoJugador.getAvatar().getId() + "\n" +
                "}");

        consola.imprimir(this.tablero.toString());
    }

    // Metodo auxiliar para ver o taboleiro
    private void verTablero() {
        consola.imprimir(this.tablero.toString());
    }

    private void xestionarBancarrota(Jugador jugadorEnBancarrota) {
        this.jugadores.remove(jugadorEnBancarrota); //Remove xa verifica que este na lista

        if (this.jugadores.isEmpty()) {
            consola.imprimir("\nTodos os xogadores en bancarrota! Xogo rematado.");
            System.exit(0);
        }
        // Axustar o turno se é necesario
        if (this.turno >= this.jugadores.size()) {
            this.turno = 0;
        }

        // Se só queda un xogador, declaramos o gañador e rematamos
        if (this.jugadores.size() == 1) {
            Jugador ganador = this.jugadores.get(0); //O único xogador restante é o gañador
            consola.imprimir("\nO xogo rematou!");
            consola.imprimir("O gañador é " + ganador.getNombre() + " cunha fortuna de " + (int)ganador.getFortuna() + "€.");
            consola.imprimir("\nEstatísticas finais:");
            consola.imprimir(ganador.mostrarEstadisticas());
            System.exit(0);
        } else {
            consola.imprimir("Quedan " + this.jugadores.size() + " xogadores en xogo.\n");

            Jugador siguiente = this.jugadores.get(this.turno); // Obtenemos o novo xogador actual
            consola.imprimir("É o turno de: " + siguiente.getNombre() + "."); // Mostramos quen é o novo xogador
            consola.imprimir("Estado actual: " + siguiente); //toString creado en jugador
        }
    }

    @Override
    public void estadisticasJugador(String nombreJugador) throws MonopolyException{
        Jugador jugador = null;
        for (Jugador j : jugadores) {
            if (j.getNombre().equalsIgnoreCase(nombreJugador)) {
                jugador = j;
                break;
            }
        }
        if (jugador != null) {
            consola.imprimir(jugador.mostrarEstadisticas());
        } else {
            throw new NonExisteXogadorException(nombreJugador);
        }
    }

    @Override
    public void estadisticasJuego() {
        consola.imprimir("{\n" +
                "casillaMasRentable: " + obtenerCasillaMasRentable() + ",\n" +
                "grupoMasRentable: " + obtenerGrupoMasRentable() + ",\n" +
                "casillaMasFrecuentada: " + obtenerCasillaMasFrecuentada() + ",\n" +
                "jugadorMasVueltas: " + obtenerJugadorMasVueltas() + ",\n" +
                "jugadorEnCabeza: " + obtenerJugadorEnCabeza() + "\n" +
                "}");
    }

    // Métodos auxiliares para estadísticas (implementación básica)
    private String obtenerCasillaMasRentable() {
       float maxRentabilidad = 0;
       String casillaMasRentable = "-";

       //Percorrer todas as casillas do taboleiro
        for (ArrayList<Casilla> lado : tablero.getPosiciones()) {
            for (Casilla casilla : lado) {
                if (casilla != null && casilla instanceof Propiedad) {
                    Propiedad propiedad = (Propiedad) casilla;
                    float rentabilidad = propiedad.getTotalAlquileresCobrados();
                    if (rentabilidad > maxRentabilidad) {
                        maxRentabilidad = rentabilidad;
                        casillaMasRentable = casilla.getNombre();
                    }
                }
            }
        }
        return casillaMasRentable;
    }

    private String obtenerGrupoMasRentable() {
        //Map para almacenar a rentabilidade de cada grupo
        Map<String, Float> rentabilidadesGrupos = new HashMap<>();

        // Percorrer todas as casillas do taboleiro
        for (ArrayList<Casilla> lado : tablero.getPosiciones()) {
            for (Casilla casilla : lado) {
                if (casilla != null && casilla instanceof Solar) {
                    Solar solar = (Solar) casilla;
                    Grupo grupo = solar.getGrupo();
                    if (grupo != null) {
                        String colorGrupo = grupo.getColorGrupo();
                        float alquileresCobrados = solar.getTotalAlquileresCobrados();
                        rentabilidadesGrupos.put(colorGrupo, rentabilidadesGrupos.getOrDefault(colorGrupo, 0f) + alquileresCobrados);
                    }
                }
            }
        }

        String grupoMasRentable = "-";
        float maxRentabilidad = 0;
        for (Map.Entry<String, Float> entrada : rentabilidadesGrupos.entrySet()) {
            if (entrada.getValue() > maxRentabilidad) {
                maxRentabilidad = entrada.getValue();
                grupoMasRentable = entrada.getKey();
            }
        }
        return grupoMasRentable;
    }

    private String obtenerCasillaMasFrecuentada() {
        int maxVeces = 0;
        String casillaMasFrecuentada = "-";

        // Percorrer todas as casillas do taboleiro
        for (ArrayList<Casilla> lado : tablero.getPosiciones()) {
            for (Casilla casilla : lado) {
                if (casilla != null && casilla.getVecesCaida() > maxVeces) {
                    maxVeces = casilla.getVecesCaida();
                    casillaMasFrecuentada = casilla.getNombre();
                }
            }
        }
        return casillaMasFrecuentada;
    }

    private String obtenerJugadorMasVueltas() {
        int maxVueltas = 0;
        String jugadorMasVueltas = "-";

        for (Jugador j : jugadores) {
            if (j.getVueltas() > maxVueltas) { // Comprobamos se é o de maior número de voltas
                maxVueltas = j.getVueltas();
                jugadorMasVueltas = j.getNombre();
            }
        }
        return jugadorMasVueltas;
    }

    private String obtenerJugadorEnCabeza() {
        float maxFortuna = 0;
        String jugadorEnCabeza = "-";

        for (Jugador j : jugadores) {
            // Calcular fortuna total = diñeiro + valor propiedades + valor edificios
            float fortunaTotal = j.getFortuna();

            //sumar valor propiedades + edificios
            for (Casilla propiedad : j.getPropiedades()) {
                if (propiedad instanceof Propiedad) {
                    fortunaTotal += ((Propiedad)propiedad).getValor();
                }
            }

            if (fortunaTotal > maxFortuna) {
                maxFortuna = fortunaTotal;
                jugadorEnCabeza = j.getNombre();
            }
        }
        return jugadorEnCabeza;
    }

    public Tablero getTablero() {
        return this.tablero;
    }


    //metodos para os tratos

    private int generarIdTrato() {
        return contadorTratos++; // devolve e incrementa o contador
    }


    @Override
    public void proponerTrato(String comando) throws MonopolyException {
        String sinTrato = comando.substring(5).trim(); // Elimina "trato "
        String[] partes = sinTrato.split(":");

        if (partes.length < 2) {
            throw new ComandoInvalidoException("Formato incorrecto. Use: trato <xogador>: cambiar (elemento1, elemento2)");
        }

        String receptorNombre = partes[0].trim();
        String ofertaStr = partes[1].trim();
        Jugador propone = jugadores.get(turno);
        Jugador receptor = buscarJugadorPorNome(receptorNombre);

        if (receptor == null) {
            throw new NonExisteXogadorException(receptorNombre);
        }

        if (propone.equals(receptor)) {
            throw new TratoInvalidoException("Non podes propoñer un trato a ti mesmo.");
        }

        // Parsear elementos do trato (simplificado)
        StringBuilder tratoStr = new StringBuilder();
        for (int i = 2; i < partes.length; i++) {
            tratoStr.append(partes[i]).append(" ");
        }

        // Crear trato (simplificado - necesitarías implementar parseo completo)
        String id = "trato" + contadorTratos++;
        Trato trato = new Trato(id, propone, receptor, null, null, 0, 0);

        // Engadir trato ás listas
        tratosPendentes.add(trato);
        receptor.recibirTrato(trato);
        propone.proponerTrato(trato);

        consola.imprimir(trato.toString());
        consola.imprimir("Trato " + id + " proposto a " + receptor.getNombre() + ".");
    }

    @Override
    public void aceptarTrato(String idTrato) throws MonopolyException {

        Trato trato = buscarTratoPorId(idTrato);
        if (trato == null) {
            throw new NonExisteTratoException(idTrato);
        }

        Jugador aceptante = jugadores.get(turno);
        if (!trato.getReceptor().equals(aceptante)) {
            throw new TratoInvalidoException(aceptante.getNombre(), trato.getPropone().getNombre(),
                    "aceptar trato", "O trato non está dirixido a este xogador.");
        }

        // Validar trato
        validarTrato(trato);

        // Executar trato (simplificado)
        ejecutarTrato(trato);

        // Eliminar trato
        tratosPendentes.remove(trato);
        trato.getPropone().eliminarTratoPropuesto(trato);
        trato.getReceptor().eliminarTratoPendiente(trato);

        consola.imprimir("Trato " + idTrato + " aceptado e executado.");
    }

    @Override
    public void listarTratos() throws MonopolyException {
        Jugador actual = jugadores.get(turno);

        ArrayList<Trato> tratosJugador = actual.getTratosPendientes();

        if (tratosJugador.isEmpty()) {
            consola.imprimir("Non hai tratos pendentes para " + actual.getNombre() + ".");
            return;
        }

        consola.imprimir("Tratos pendentes para " + actual.getNombre() + ":");
        for (Trato t : tratosJugador) {
            consola.imprimir(t.toString());
        }
    }

    public void eliminarTrato(String idTrato) throws MonopolyException {
        Trato trato = buscarTratoPorId(idTrato);
        if (trato == null) {
            throw new NonExisteTratoException(idTrato);
        }

        Jugador solicitante = jugadores.get(turno);
        if (!trato.getPropone().equals(solicitante)) {
            throw new TratoInvalidoException(solicitante.getNombre(), trato.getPropone().getNombre(), "eliminar trato", "Só o propoñente pode eliminar o trato.");
        }

        // Eliminar trato
        tratosPendentes.remove(trato);
        trato.getReceptor().eliminarTratoPendiente(trato);
        trato.getPropone().eliminarTratoPropuesto(trato);

        consola.imprimir("Trato " + idTrato + " eliminado.");
    }

    private Jugador buscarJugadorPorNome(String nome) {
        for (Jugador j : jugadores)
            if (j.getNombre().equalsIgnoreCase(nome))
                return j;
        return null;
    }

    private void mostrarTratosPendentes(Jugador jugador) {
        ArrayList<Trato> tratos = jugador.getTratosPendientes();
        if (!tratos.isEmpty()) {
            consola.imprimir("\n" + jugador.getNombre() + ", tes " + tratos.size() + " trato(s) pendente(s):");
            for (Trato t : tratos) {
                consola.imprimir("  " + t.toString());
            }
        }
    }

    private Trato buscarTratoPorId(String id) {
        for (Trato t : tratosPendentes) {
            if (t.getId().equals(id)) {
                return t;
            }
        }
        return null;
    }

    private void validarTrato(Trato trato) throws MonopolyException {
        // Validar propiedades ofrecidas
        if (trato.getPropiedadOfrecida() != null && !trato.getPropiedadOfrecida().getDuenho().equals(trato.getPropone())) {
            throw new TratoInvalidoException(trato.getPropone().getNombre(), trato.getReceptor().getNombre(),
                    "validar trato", trato.getPropiedadOfrecida().getNombre() +
                    " non pertence a " + trato.getPropone().getNombre());
        }

        // Validar propiedades pedidas
        if (trato.getPropiedadPedida() != null && !trato.getPropiedadPedida().getDuenho().equals(trato.getReceptor())) {
            throw new TratoInvalidoException(trato.getPropone().getNombre(), trato.getReceptor().getNombre(),
                    "validar trato", trato.getPropiedadPedida().getNombre() +
                    " non pertence a " + trato.getReceptor().getNombre());
        }

        // Validar diñeiro ofrecido
        if (trato.getDineroOfrecido() > 0 && !trato.getPropone().puedePagar(trato.getDineroOfrecido())) {
            throw new DiñeiroInsuficienteException(trato.getPropone().getNombre(),
                    trato.getDineroOfrecido(),
                    trato.getPropone().getFortuna());
        }

        // Validar diñeiro pedido
        if (trato.getDineroPedido() > 0 && !trato.getReceptor().puedePagar(trato.getDineroPedido())) {
            throw new DiñeiroInsuficienteException(trato.getReceptor().getNombre(),
                    trato.getDineroPedido(),
                    trato.getReceptor().getFortuna());
        }
    }

    private void ejecutarTrato(Trato trato) {
        // Transferir propiedades ofrecidas
        if (trato.getPropiedadOfrecida() != null) {
            Propiedad propiedad = trato.getPropiedadOfrecida();
            trato.getPropone().eliminarPropiedad(propiedad);
            trato.getReceptor().anhadirPropiedad(propiedad);
            propiedad.setDuenho(trato.getReceptor());
        }

        // Transferir propiedades pedidas
        if (trato.getPropiedadPedida() != null) {
            Propiedad propiedad = trato.getPropiedadPedida();
            trato.getReceptor().eliminarPropiedad(propiedad);
            trato.getPropone().anhadirPropiedad(propiedad);
            propiedad.setDuenho(trato.getPropone());
        }

        // Transferir diñeiro ofrecido
        if (trato.getDineroOfrecido() > 0) {
            trato.getPropone().pagarJugador(trato.getReceptor(), trato.getDineroOfrecido(), tablero);
        }

        // Transferir diñeiro pedido
        if (trato.getDineroPedido() > 0) {
            trato.getReceptor().pagarJugador(trato.getPropone(), trato.getDineroPedido(), tablero);
        }
    }

    //Metodos estaticos para acceso a consola dende outras clases
    public static Consola getConsola() {
        return consola;
    }

    private void mostrarAyuda() {
        consola.imprimir("\nComandos dispoñibles:");
        consola.imprimir("- crear jugador <nome> <avatar>");
        consola.imprimir("- jugador");
        consola.imprimir("- listar jugadores");
        consola.imprimir("- lanzar dados [suma]");
        consola.imprimir("- acabar turno");
        consola.imprimir("- salir carcel");
        consola.imprimir("- describir <NomeCasilla>");
        consola.imprimir("- describir jugador <Nome>");
        consola.imprimir("- comprar <NomePropiedade>");
        consola.imprimir("- listar enventa");
        consola.imprimir("- ver tablero");
        consola.imprimir("- edificar <tipoEdificacion> (casa, hotel, piscina, pista)");
        consola.imprimir("- listar edificios");
        consola.imprimir("- listar edificios <colorGrupo>");
        consola.imprimir("- hipotecar <NomeCasilla>");
        consola.imprimir("- deshipotecar <NomeCasilla>");
        consola.imprimir("- vender <tipo> <NomeCasilla> <cantidade>");
        consola.imprimir("- estadisticas [nomeXogador]");
        consola.imprimir("- comandos <NomeFicheiro>");
        consola.imprimir("- trato <xogador>: cambiar (elemento1, elemento2)");
        consola.imprimir("- aceptar trato <idTrato>");
        consola.imprimir("- tratos");
        consola.imprimir("- eliminar trato <idTrato>");
        consola.imprimir("- salir");
    }
}
