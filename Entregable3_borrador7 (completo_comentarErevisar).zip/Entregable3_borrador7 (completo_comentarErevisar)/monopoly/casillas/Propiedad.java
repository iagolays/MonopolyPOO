package monopoly.casillas;
import monopoly.*;
import partida.*;

//Clase abstracta porque implementa métodos abstractos
public abstract class Propiedad extends Casilla{

    //Atributos comúns a todas as propiedades
    protected float valor; //Valor de esa casilla (en la mayoría será valor de compra, en la casilla parking se usará como el bote).
    protected Jugador duenho; //Dueño de la casilla (por defecto sería la banca).
    protected float totalAlquileresCobrados; //Total de alquileres cobrados en esta Casilla

    //Constructor
    public Propiedad(String nombre, int posicion, Jugador duenho, float valor) {
        super(nombre, posicion); //Chamada ao constructor da clase Casilla, con super para inicializar os atributos herdados
        this.valor = valor;
        this.duenho = duenho;
        this.totalAlquileresCobrados = 0;
    }


    //Metodo para saber se unha propiedade pertence a un xogador
    public boolean perteneceAJugador(Jugador jugador){
        return this.duenho!= null && this.duenho.equals(jugador);
    }

    //Metodo que devolve o valor da propiedade
    public abstract float valor();

    //Metodo para saber se unha propiedade cobra aluguer
    public abstract float alquiler(int tirada, boolean desdeCarta);

    //Metodo para a compra dunha propiedade
    public void comprar(Jugador jugador){
        if (jugador == null){
            return;
        }
        if(this.duenho == null || "Banca".equals(this.duenho.getNombre())){ //Se a propiedade non ten dono ou o dono é a banca
            if (jugador.puedePagar(this.valor)){
                jugador.sumarFortuna(-this.valor); //O xogador paga o valor da propiedade
                jugador.sumarInversion(this.valor);
                this.duenho = jugador; //O xogador pasa a ser o dono da propiedade
                jugador.anhadirPropiedad(this);
                Juego.getConsola().imprimir(jugador.getNombre() + " comprou " + this.getNombre() + " por " + (int)this.valor + "€.");
            } else {
                Juego.getConsola().imprimir(jugador.getNombre() + " non ten diñeiro suficiente.");
            }
        } else {
            Juego.getConsola().imprimir("A propiedade xa ten dono.");
        }
    }

    public void sumarAlquilerCobrado(float cantidad) {
        if (cantidad > 0) {
            totalAlquileresCobrados += cantidad;
        }
    }

    //Metodo para saber se está en venda
    public String casEnVenta() {
        if (duenho == null || "Banca".equalsIgnoreCase(duenho.getNombre())) {
            return "{\n" + "nome: " + this.nombre + ",\n" + "tipo: " + this.getTipo() +
                    ",\nvalor: " + (int)this.valor + "\n" +"}";
        }
        return "";
    }

    public Jugador getDuenho() {
        return duenho;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public void setDuenho(Jugador duenho) {
        this.duenho = duenho;
    }

    public float getTotalAlquileresCobrados() {
        return totalAlquileresCobrados;
    }

    //Sobrescritura do metodo toString
    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder(super.infoCasilla());
        sb.insert(sb.length() - 1, ",\n  dono: \"" + (duenho != null ? duenho.getNombre() : "Banca") + "\"");
        sb.insert(sb.length() - 1, ",\n  valor: " + (int)valor);
        return sb.toString();
    }
}
