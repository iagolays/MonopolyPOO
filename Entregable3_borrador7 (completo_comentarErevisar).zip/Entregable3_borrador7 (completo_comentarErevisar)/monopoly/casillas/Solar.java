package monopoly.casillas;

import monopoly.*;
import monopoly.cartas.Carta;
import monopoly.edificios.*;
import monopoly.exceptions.MonopolyException;
import partida.*;
import java.util.ArrayList;

public class Solar extends Propiedad {

    // Atributos específicos de Solar
    private boolean hipotecada;  //false se no nestá hipotecada ou non se pode,true si está hipotecada
    private float hipoteca; //Valor otorgado por hipotecar una CasillaAntigua
    private Grupo grupo; //Grupo al que pertenece la CasillaAntigua (si es solar).

    private ArrayList<Edificio> edificios; //Datos dos edificios construídos nesta CasillaAntigua (se é solar)
    private ArrayList<String> idsEdificios; //IDs dos edificios construídos nesta CasillaAntigua (se é solar)

    // Contadores para verificación rápida
    private int numCasas;
    private int numHoteles;
    private int numPiscinas;
    private int numPistas;

    // Constructor
    public Solar(String nombre, int posicion, Jugador duenho) {
        super(nombre, posicion, duenho, Valor.obtenerPrecioSolar(nombre));
        this.grupo = null; //inicialmente non ten grupo asignado
        this.hipotecada = false;
        this.hipoteca = getValor() / 2; //Valor da hipoteca é a metade do valor da propiedade
        this.edificios = new ArrayList<>();
        this.idsEdificios = new ArrayList<>();
        this.numCasas = 0;
        this.numHoteles = 0;
        this.numPiscinas = 0;
        this.numPistas = 0;
    }

    // Constructor que acepta grupo directamente
    public Solar(String nombre, int posicion, Jugador duenho, Grupo grupo) {
        super(nombre, posicion, duenho, Valor.obtenerPrecioSolar(nombre)); // reutiliza o construtor base
        this.setGrupo(grupo); // asigna o grupo ao solar
    }


    //metodo para establecer o grupo ao que pertence o solar
    public void setGrupo(Grupo grupo) {
        this.grupo = grupo;
        if (grupo != null && !grupo.getMiembros().contains(this)) {
            grupo.anhadirCasilla(this);
        }
    }

    //metodo para hipotecar un solar
    public void hipotecar(Jugador jugador) throws MonopolyException {
        if (!perteneceAJugador(jugador)){
            Juego.getConsola().imprimir(jugador.getNombre() + " non é o dono de " + getNombre() + " e non pode hipotecalo.");
            return;
        }
        if (hipotecada) { //se está hipotecada non se pode volver a hipotecar
            Juego.getConsola().imprimir(getNombre() + " xa está hipotecado.");
            return;
        }

        if (!edificios.isEmpty()) {
            Juego.getConsola().imprimir("Non se pode hipotecar " + getNombre() + " porque ten edificios. Debe vendelos antes de hipotecar.");
            return;
        }

        //Hipotecar, dase o diñeiro ao xogador
        this.hipotecada = true;
        float valorHipoteca = this.hipoteca;

        // actualizar listas do xogador
        jugador.anhadirHipoteca(this);
        jugador.sumarFortuna(valorHipoteca); // Engadimos o diñeiro da hipoteca á fortuna do xogador
        jugador.sumarInversion(valorHipoteca); // Engadimos o diñeiro da hipoteca ás inversións do xogador

        Juego.getConsola().imprimir(jugador.getNombre() + " recibe " + (int)valorHipoteca + "€ pola hipoteca de " + this.nombre +
                ". Non pode recibir alugueres, nin edificar no grupo " + (this.grupo != null ? this.grupo.getColorGrupo() : "") + ".");
        return;
    }

    //Metodo para deshipotecar o solar
    public void deshipotecar(Jugador jugador) throws MonopolyException {
        if (!perteneceAJugador(jugador)){
            Juego.getConsola().imprimir(jugador.getNombre() + " non é o dono de " + getNombre() + " e non pode deshipotecalo.");
            return;
        }
        if (!hipotecada) {
            Juego.getConsola().imprimir(getNombre() + " non está hipotecado.");
            return;
        }

        //Deshipotecar, restase o diñeiro ao xogador, compróbase que ten diñeiro suficiente
        float valorDeshipoteca = this.hipoteca;
        if (!jugador.puedePagar(valorDeshipoteca)){
            Juego.getConsola().imprimir(jugador.getNombre() + " non pode deshipotecar " + this.nombre + ". Non ten diñeiro suficiente.");
            return;
        }
        this.hipotecada = false;
        jugador.sumarFortuna(-valorDeshipoteca);
        jugador.eliminarHipoteca(this);
        Juego.getConsola().imprimir(jugador.getNombre() + " paga " + (int)valorDeshipoteca + "€ por deshipotecar " + this.nombre +
                "." + (this.grupo != null && this.grupo.esDuenhoGrupo(jugador)? " Agora pode recibir alugueres e edificar no grupo " + this.grupo.getColorGrupo() : " Agora pode recibir alugueres") + ".");
        return;
    }


    @Override
    public float valor() {
        // Valor del solar según su nombre
        return this.valor;
    }

    public boolean estaHipotecada() {
        return hipotecada;
    }

    //Metodo para edificar un edificio no solar
    public void anhadirEdificio(Edificio edificio) {
        if (!edificios.contains(edificio)) {
            edificios.add(edificio);
            idsEdificios.add(edificio.getId());

            String tipo = edificio.obterTipoEdificio().toLowerCase();

            // Actualizar contadores
            switch (tipo) {
                case "casa":
                    numCasas++;
                    break;
                case "hotel":
                    numHoteles++;
                    break;
                case "piscina":
                    numPiscinas++;
                    break;
                case "pista":
                    numPistas++;
                    break;
            }
        }
    }

    public void eliminarEdificio (Edificio edificio) {
        if (edificios.contains(edificio)) {
            edificios.remove(edificio);
            idsEdificios.remove(edificio.getId());

            String tipo = edificio.obterTipoEdificio().toLowerCase();

            // Actualizar contadores
            switch (tipo) {
                case "casa":
                    numCasas--;
                    break;
                case "hotel":
                    numHoteles--;
                    break;
                case "piscina":
                    numPiscinas--;
                    break;
                case "pista":
                    numPistas--;
                    break;
            }
        }
    }

    public Edificio buscarEdificio(String id) {
        for (Edificio e : edificios) {
            if (e.getId().equals(id)) {
                return e;
            }
        }
        return null;
    }

    public boolean tieneEdificios() {
        return !edificios.isEmpty();
    }

    public void anhadirIdEdificio(String id) {
        if (!idsEdificios.contains(id)) {
            idsEdificios.add(id);
        }
    }

    public void eliminarIdEdificio(String id) {
        idsEdificios.remove(id);
        Edificio e = buscarEdificio(id);
        if (e != null) {
            eliminarEdificio(e);
        }
    }

    //Metodo reescrito para calcular o alquiler dun solar
    @Override
    public float alquiler(int tirada, boolean desdeCarta) {
        if (hipotecada) return 0;

        float alquiler = Valor.obtenerAlquilerSolar(nombre);

        for (Edificio e : edificios) {
            alquiler += e.obterAluguer();
        }

        //Se ten o grupo enteiro e con ningún edificio, o alquiler duplicase
        if (grupo != null && grupo.esDuenhoGrupo(duenho) && edificios.isEmpty()) {
            alquiler *= 2;
        }
        return alquiler;
    }

    //Metodo para calcular o alquiler sen tirada nin carta
    public float calcularAlquiler() {
        return alquiler(0, false);
    }

    //Metodo para construír un edificio no solar
    public boolean construirEdificio(String tipo, Jugador jugador) throws MonopolyException {
        if (!perteneceAJugador(jugador)) { //debe pertencer ao xogador
            Juego.getConsola().imprimir(jugador.getNombre() + " non é dono de " + nombre);
            return false;
        }

        if (hipotecada) {
            Juego.getConsola().imprimir(nombre + " está hipotecada");
            return false;
        }

        // Verificar que o xogador é dono do grupo completo
        if (grupo == null || !grupo.esDuenhoGrupo(jugador)) {
            Juego.getConsola().imprimir("Necesitas ter todo o grupo para construír");
            return false;
        }

        switch (tipo.toLowerCase()) {
            case "casa":
                if (numCasas >= 4) { //Para construir unha casa non pode haber 4 casas xa
                    Juego.getConsola().imprimir("Xa hai 4 casas en " + nombre);
                    return false;
                }
                if (numHoteles > 0) { //se hai hotel non se poden construír casas
                    Juego.getConsola().imprimir("Non se poden construír casas se hai hotel");
                    return false;
                }
                break;

            case "hotel": //para poder construir un hotel deben haber 4 casas e ninngún hotel
                if (numCasas < 4) {
                    Juego.getConsola().imprimir("Necesitas 4 casas para construír un hotel");
                    return false;
                }
                if (numHoteles >= 1) {
                    Juego.getConsola().imprimir("Xa hai un hotel en " + nombre);
                    return false;
                }
                break;

            case "piscina": //para poder construír unha piscina debe haber un hotel e ningunha piscina
                if (numHoteles < 1) {
                    Juego.getConsola().imprimir("Necesitas un hotel para construír unha piscina");
                    return false;
                }
                if (numPiscinas >= 1) {
                    Juego.getConsola().imprimir("Xa hai unha piscina en " + nombre);
                    return false;
                }
                break;

            case "pista": //para poder construír unha pista debe haber un hotel, unha piscina e ningunha pista
                if (numHoteles < 1) {
                    Juego.getConsola().imprimir("Necesitas un hotel para construír unha pista");
                    return false;
                }
                if (numPiscinas < 1) {
                    Juego.getConsola().imprimir("Necesitas unha piscina para construír unha pista");
                    return false;
                }
                if (numPistas >= 1) {
                    Juego.getConsola().imprimir("Xa hai unha pista en " + nombre);
                    return false;
                }
                break;

            default:
                Juego.getConsola().imprimir("Tipo de edificio descoñecido: " + tipo);
                return false;
        }

        Edificio nuevoEdificio = null;
        switch (tipo.toLowerCase()) {
            case "casa":
                nuevoEdificio = new Casa(this, jugador);
                break;
            case "hotel":
                nuevoEdificio = new Hotel(this, jugador);
                eliminarCasasParaHotel(); //Eliminanse as catro casas que eran necesarias para construir o hotel
                break;
            case "piscina":
                nuevoEdificio = new Piscina(this, jugador);
                break;
            case "pista":
                nuevoEdificio = new PistaDeDeporte(this, jugador);
                break;
        }

        if (nuevoEdificio == null) { //se non se creou o edificio, retorna false
            return false;
        }

        // Verificar que o xogador ten diñeiro suficiente para pagar a construción
        float precio = nuevoEdificio.getPrecio();
        if (!jugador.puedePagar(precio)) {
            Juego.getConsola().imprimir(jugador.getNombre() + " non ten diñeiro para construír " + tipo);
            return false;
        }

        jugador.sumarFortuna(-precio);
        jugador.sumarInversion(precio);
        anhadirEdificio(nuevoEdificio);
        jugador.anhadirEdificio(nuevoEdificio);

        Juego.getConsola().imprimir(jugador.getNombre() + " constrúe un " + tipo +
                " en " + nombre + " por " + (int)precio + "€");
        return true;
    }

    //Metodo para eliminar as catro casas necesarias para construír un hotel
    private void eliminarCasasParaHotel() {
        ArrayList<Edificio> casasAEliminar = new ArrayList<>();
        for (Edificio e : edificios) {
            if (e instanceof Casa) { //se é unha casa
                casasAEliminar.add(e);
                if (casasAEliminar.size() == 4){
                    break;
                }
            }
        }

        for (Edificio casa : casasAEliminar) {
            eliminarEdificio(casa);
            //non se recibe o diñeiro da venda das casas para construír o hotel
        }
    }

    //Metodo reescrito para avaliar a casilla solar
    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta, ArrayList<Carta> mazoSuerte, ArrayList<Carta> mazoComunidad, int[] indices) throws MonopolyException{
        vecesCaida++; // Incrementar contador de veces que cae na casilla

        if (duenho == null || duenho == banca) {
            Juego.getConsola().imprimir(nombre + " está en venda por " + (int)valor + "€");
            return true;
        }

        if (duenho.equals(actual)) {
            Juego.getConsola().imprimir(actual.getNombre() + " é o dono de " + nombre);
            return true;
        }

        if (!hipotecada) {
            float alquilerAPagar = alquiler(tirada, desdeCarta);
            Juego.getConsola().imprimir(actual.getNombre() + " paga " + (int)alquilerAPagar +
                    "€ a " + duenho.getNombre());

            boolean pagoExitoso = actual.pagarJugador(duenho, alquilerAPagar, tablero);
            if (pagoExitoso) {
                sumarAlquilerCobrado(alquilerAPagar);
                duenho.registrarCobroAlquiler(alquilerAPagar);
                actual.registrarPagoAlquiler(alquilerAPagar);
                return true;
            } else {
                actual.setUltimoCobraAlquiler(duenho); //en caso de que non se poida pagar, gardase o dono ao que lle debe
                return false;
            }
        }

        Juego.getConsola().imprimir(nombre + " está hipotecada, non se paga aluguer");
        return true;
    }

    @Override
    public String getTipo() {
        return "solar";
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("\ttipo: solar,\n");
        sb.append("\tnome: \"").append(nombre).append("\",\n");
        sb.append("\tposicion: ").append(posicion).append(",\n");
        sb.append("\tgrupo: \"").append(grupo != null ? grupo.getColorGrupo() : "-").append("\",\n");
        sb.append("\tpropietario: \"").append(duenho != null ? duenho.getNombre() : "Banca").append("\",\n");
        sb.append("\tvalor: ").append((int)valor).append(",\n");
        sb.append("\talquiler: ").append((int)alquiler(0, false)).append(",\n");
        sb.append("\thipotecada: ").append(hipotecada).append(",\n");
        sb.append("\tvalorHipoteca: ").append((int)hipoteca).append(",\n");
        sb.append("\tedificios: {\n");
        sb.append("\t\tcasas: ").append(numCasas).append(",\n");
        sb.append("\t\thoteis: ").append(numHoteles).append(",\n");
        sb.append("\t\tpiscinas: ").append(numPiscinas).append(",\n");
        sb.append("\t\tpistas: ").append(numPistas).append("\n");
        sb.append("\t},\n");

        sb.append("\talquileresCobrados: ").append((int)totalAlquileresCobrados).append("\n");
        sb.append("}");
        return sb.toString();
    }

    public ArrayList<String> getIdsEdificios() {
        return idsEdificios;
    }

    public int getNumCasas() {
        return numCasas;
    }

    public int getNumHoteles() {
        return numHoteles;
    }

    public int getNumPiscinas() {
        return numPiscinas;
    }

    public int getNumPistas() {
        return numPistas;
    }

    public ArrayList<Edificio> getEdificios() {
        return edificios;
    }

    public Grupo getGrupo() {
        return grupo;
    }

    public float getHipoteca() {
        return hipoteca;
    }


}