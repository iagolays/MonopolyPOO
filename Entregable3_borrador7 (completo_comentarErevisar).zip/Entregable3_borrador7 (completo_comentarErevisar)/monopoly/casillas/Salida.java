package monopoly.casillas;
import monopoly.*;
import monopoly.cartas.Carta;
import partida.*;

import java.util.ArrayList;
import monopoly.exceptions.MonopolyException;

public class Salida extends Especial{

    public Salida (String nombre, int posicion) {
        super(nombre, posicion);
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta, ArrayList<Carta> mazoSuerte, ArrayList<Carta> mazoComunidad, int[] indices) throws MonopolyException{
        vecesCaida++;
        //Non se suma o saldo porque xa se sumou ao mover o avatar
        return true;
    }

    public void realizarAccion(Jugador jugador) {
        jugador.sumarFortuna(Valor.SUMA_VUELTA);
        jugador.registrarPasoSalida(Valor.SUMA_VUELTA);
        Juego.getConsola().imprimir(jugador.getNombre() + " cobra " +
                (int)Valor.SUMA_VUELTA + "€ por pasar pola Salida");
    }

    @Override
    public String getTipo() {
        return "salida";
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("\ttipo: salida,\n");
        sb.append("\tnome: \"").append(nombre).append("\",\n");
        sb.append("\tposicion: ").append(posicion).append("\n");
        sb.append("\tpago por paso: ").append((int)Valor.SUMA_VUELTA).append("\n");
        sb.append("}");
        return sb.toString();
    }

}
