package monopoly;

import partida.Jugador;
import monopoly.casillas.Propiedad;

public class Trato {

    private String id; //id do tipo trato2
    private Jugador propone;
    private Jugador receptor;
    private Propiedad propiedadOfrecida;
    private Propiedad propiedadPedida;
    private float dineroOfrecido;
    private float dineroPedido;

    public Trato(String id, Jugador propone, Jugador receptor,
                 Propiedad propiedadOfrecida, Propiedad propiedadPedida,
                 float dineroOfrecido, float dineroPedido) {
        this.id = id;
        this.propone = propone;
        this.receptor = receptor;
        this.propiedadOfrecida = propiedadOfrecida;
        this.propiedadPedida = propiedadPedida;
        this.dineroOfrecido = dineroOfrecido;
        this.dineroPedido = dineroPedido;
    }

    public String getId() { return id; }
    public Jugador getPropone() { return propone; }
    public Jugador getReceptor() { return receptor; }
    public Propiedad getPropiedadOfrecida() { return propiedadOfrecida; }
    public Propiedad getPropiedadPedida() { return propiedadPedida; }
    public float getDineroOfrecido() { return dineroOfrecido; }
    public float getDineroPedido() { return dineroPedido; }

    @Override
    public String toString() {
        return "{\n" +
                "id: " + id + ",\n" +
                "jugadorPropone: " + propone.getNombre() + ",\n" +
                "trato: cambiar (" +
                (propiedadOfrecida != null ? propiedadOfrecida.getNombre() : (int)dineroOfrecido + "€")
                + " , " +
                (propiedadPedida != null ? propiedadPedida.getNombre() : (int)dineroPedido + "€") +
                ")\n" +
                "}";
    }

}
