package monopoly.exceptions;

//excepción para cando un xogador está na cárcere

public class XogadorCarcelException extends EstadoXogoException{
    public XogadorCarcelException(String nomeXogador) {
        super("O xogador " + nomeXogador + " está no cárcere.");
    }

    //constructor para cando un xogador intenta realizar unha acción non permitida dende o cárcere
    public XogadorCarcelException(String nomeXogador, String accion) {
        super("O xogador " + nomeXogador + " está no cárcere e non pode " + accion + ".");
    }
}
