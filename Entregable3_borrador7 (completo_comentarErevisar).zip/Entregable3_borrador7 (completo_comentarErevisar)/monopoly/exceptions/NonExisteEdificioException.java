package monopoly.exceptions;

//excepción para edificios que non existen no xogo

public class NonExisteEdificioException extends NonExisteExcepcion{

    //costructor para edificios que non existen
    public NonExisteEdificioException(String nomeEdificio) {
        super("edificio", nomeEdificio);
        //chama ao constructor da clase pai NonExisteExcepcion, con super ("Non existe edificio co nome " + nomeEdificio);
    }

    //constructor para tipos de edificios que non se poden construír
    public NonExisteEdificioException(String tipoEdificio, String nomeSolar) {
        super("Non se pode construír un " + tipoEdificio + " no " + nomeSolar);
    }
}
