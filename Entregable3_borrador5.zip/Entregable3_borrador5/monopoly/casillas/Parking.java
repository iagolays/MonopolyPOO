package monopoly.casillas;
import monopoly.*;
import partida.*;

public class Parking extends Accion{

    private float bote; //bote de esa casilla (en la mayoría será bote de compra, en la casilla parking se usará como el bote).

    //Constructor
    public Parking(String nombre, int posicion) {
        super(nombre, posicion);
        this.bote = 0; //Inicialmente o bote do parking é 0
    }

    public void sumarValor(float cantidad) {
        bote += cantidad;
    }

    @Override
    public void realizarAccion(Jugador jugador, Tablero tablero) {
        if (bote > 0) {
            Juego.getConsola().imprimir(jugador.getNombre() + " cobra o bote do Parking: " + (int)bote + "€");
            jugador.sumarFortuna(bote);
            jugador.registrarPremio(bote);
            bote = 0; // Resetea o bote
        } else {
            Juego.getConsola().imprimir("O Parking está baleiro");
        }
    }

    @Override
    public String getTipo() {
        return "parking";
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("\ttipo: parking,\n");
        sb.append("\tnome: \"").append(nombre).append("\",\n");
        sb.append("\tposicion: ").append(posicion).append(",\n");
        sb.append("\tbote: ").append((int)bote).append("\n");
        sb.append("}");
        return sb.toString();
    }

    public float getBote() {
        return bote;
    }
}
