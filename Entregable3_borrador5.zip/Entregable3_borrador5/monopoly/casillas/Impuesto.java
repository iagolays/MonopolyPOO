package monopoly.casillas;
import monopoly.*;
import partida.*;

public class Impuesto extends Casilla{

    private float impuesto; //Cantidad a pagar por caer en la casilla: el alquiler en solares/servicios/transportes o cantidads.
    
    //Constructor
    public Impuesto(String nombre, int posicion, float impuesto) {
        super(nombre, posicion);
        this.impuesto = impuesto;
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta) {
        vecesCaida++;

        if (actual.puedePagar(impuesto)) {
            // Paga o imposto
            actual.sumarFortuna(-impuesto);
            actual.registrarTasa(impuesto);

            // O diñeiro vai ao Parking
            Casilla parking = tablero.encontrar_casilla("Parking");
            if (parking != null && parking instanceof Parking) {
                Parking p = (Parking) parking;
                p.sumarValor(impuesto);
                Juego.getConsola().imprimir("Imposto engadido ao Parking: " + (int)impuesto + "€");
            }
            return true;
        } else {
            // Non pode pagar
            actual.sumarFortuna(-impuesto); // Fica en números negativos
            actual.setUltimoCobraAlquiler(tablero.getBanca());
            Juego.getConsola().imprimir(actual.getNombre() + " non pode pagar o imposto");
            return false;
        }
    }

    @Override
    public String getTipo() {
        return "impuesto";
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("\ttipo: impuesto,\n");
        sb.append("\tnome: \"").append(nombre).append("\",\n");
        sb.append("\tposicion: ").append(posicion).append(",\n");
        sb.append("\timporte: ").append((int)impuesto).append("\n");
        sb.append("}");
        return sb.toString();
    }

    public float getImpuesto() {
        return impuesto;
    }
}
