package monopoly.casillas;
import monopoly.*;
import partida.*;

public abstract class Accion extends Casilla {

    public Accion(String nombre, int posicion) {
        super(nombre, posicion);
    }

    // Acción xenérica a executar (nas subclases)
    public abstract void realizarAccion(Jugador jugador, Tablero tablero);

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta) {
        vecesCaida++;
        realizarAccion(actual, tablero);
        return true; //As accións non quebran ao xogador
    }

}
