package monopoly.exceptions;

// Excepción para propiedades con edificios
public class PropiedadeEdificiosException extends TransaccionException {
    public PropiedadeEdificiosException(String nomePropiedade) {
        super("A propiedade " + nomePropiedade + " ten edificios. Véndaos primeiro.");
    }
}