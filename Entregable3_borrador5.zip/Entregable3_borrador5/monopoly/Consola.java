package monopoly;

//a interfaz representa unha abstracción que non depende de system.out nin de scanner

public interface Consola {

    void imprimir(String mensaxe); //imprime unha mensaxe ao usuario

    String ler(String descripcion); //pide un dato ao usuario e devolve o que escriba
}