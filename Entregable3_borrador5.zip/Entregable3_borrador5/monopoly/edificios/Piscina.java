package monopoly.edificios;

import monopoly.*;
import monopoly.casillas.Solar;
import partida.*;

//Clase que representa unha Piscina construída nun solar.
public class Piscina extends Edificio {

    // Contador estático para xerar IDs únicos para as piscinas
    private static int contador = 1;

    //Constructor da clase Piscina.
    public Piscina(Solar solar, Jugador propietario) {
        super(solar, propietario);
    }

    //Metodo que devolve o tipo de edificio.
    @Override
    public String obterTipoEdificio() {
        return "piscina";
    }

    //Metodo que obtén o seguinte número do contador de piscinas.
    @Override
    public int obterContador() {
        return contador++;
    }

    //Metodo que calcula o prezo da piscina segundo o solar.
    @Override
    public float calcularPrezo() {
        return obterPrecioValor(solar.getNombre().toLowerCase(), "piscina");
    }

    //Metodo que obtén o aluguer que aporta esta piscina.
    @Override
    public float obterAluguer() {
        return obterAlquilerValor(solar.getNombre().toLowerCase(), "piscina");
    }
}