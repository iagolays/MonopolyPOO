package monopoly.casillas;
import monopoly.*;
import partida.*;
import monopoly.cartas.*;
import java.util.ArrayList;

public class CajaComunidad extends Accion {

    public CajaComunidad(String nombre, int posicion) {
        super(nombre, posicion);
    }

    @Override
    public void realizarAccion(Jugador jugador, Tablero tablero, ArrayList<Carta> mazoSuerte, ArrayList<Carta> mazoComunidad, int[] indices) {

        if (mazoComunidad != null && !mazoComunidad.isEmpty()) {
            indices[1] = (indices[1] + 1) % mazoComunidad.size();
            Carta carta = mazoComunidad.get(indices[1]);
            Juego.getConsola().imprimir(jugador.getNombre() + ", saca unha carta de Caixa de Comunidade: " + carta.getDescripcion());
            carta.accion(jugador, tablero);
        }
    }

    @Override
    public String getTipo() {
        return "comunidad";
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("\ttipo: cajaComunidad,\n");
        sb.append("\tnome: \"").append(nombre).append("\",\n");
        sb.append("\tposicion: ").append(posicion).append("\n");
        sb.append("}");
        return sb.toString();
    }
}
