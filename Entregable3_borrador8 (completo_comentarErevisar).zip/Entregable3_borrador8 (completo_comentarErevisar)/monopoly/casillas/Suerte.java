package monopoly.casillas;
import monopoly.*;
import partida.*;
import monopoly.cartas.*;
import java.util.ArrayList;

public class Suerte extends Accion {

    public Suerte(String nombre, int posicion) {
        super(nombre, posicion);
    }

    @Override
    public void realizarAccion(Jugador jugador, Tablero tablero, ArrayList<Carta> mazoSuerte, ArrayList<Carta> mazoComunidad, int[] indices){
        if (mazoSuerte != null && !mazoSuerte.isEmpty()) {
            indices[0] = (indices[0] + 1) % mazoSuerte.size();
            Carta carta = mazoSuerte.get(indices[0]);
            Juego.getConsola().imprimir(jugador.getNombre() + ", saca unha carta de Sorte: " + carta.getDescripcion());
            carta.accion(jugador, tablero);
        }
    }

    @Override
    public String getTipo() {
        return "suerte";
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("\ttipo: suerte,\n");
        sb.append("\tnome: \"").append(nombre).append("\",\n");
        sb.append("\tposicion: ").append(posicion).append("\n");
        sb.append("}");
        return sb.toString();
    }
}
