package monopoly.exceptions;

//non é unha clase abstracta, para así poder instanciala directamente en caso de que non exista unha excepcion más específica

public class MonopolyException extends Exception {

    public MonopolyException(String mensaxe) {
        super(mensaxe); //mensaxe descritivo do erro
    }
}