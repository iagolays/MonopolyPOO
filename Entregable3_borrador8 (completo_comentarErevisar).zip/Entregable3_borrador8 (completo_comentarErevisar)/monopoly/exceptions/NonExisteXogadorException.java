package monopoly.exceptions;

//excepción para xogadores que non existen na partida

public class NonExisteXogadorException extends NonExisteExcepcion{
    public NonExisteXogadorException(String nomeXogador) {
        super("xogador", nomeXogador);
        //chama ao constructor da clase pai NonExisteExcepcion, con super ("Non existe xogador co nome " + nomeXogador);
    }
}
