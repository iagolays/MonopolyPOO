package partida;

import monopoly.*;
import monopoly.casillas.Casilla;

import java.util.ArrayList;
import java.util.Random;


public class Avatar {

    //Atributos
    private String id; //Identificador: una letra generada aleatoriamente.
    private String tipo; //Sombrero, Esfinge, Pelota, Coche
    private Jugador jugador; //Un jugador al que pertenece ese avatar, cada avatar pertenece a un único jugador.
    private Casilla lugar; //Los avatares se sitúan en casillas del tablero.

    //Constructor vacío
    public Avatar() {

    }

    /*Constructor principal. Requiere éstos parámetros:
    * Tipo del avatar, jugador al que pertenece, lugar en el que estará ubicado, y un arraylist con los
    * avatares creados (usado para crear un ID distinto del de los demás avatares).
    */

    public Avatar(String tipo, Jugador jugador, Casilla lugar, ArrayList<Avatar> avCreados) {
        //Asignamos os parámetros recividos os atributos do obxecto
        this.tipo = tipo;
        this.jugador = jugador;
        this.lugar = lugar;
        this.generarId(avCreados); //xenera un ID único (A-Z y 0-9) que non estéa repetido en avCreados
        avCreados.add(this); //engadimos o avatar a unha lista de avatares creados

        // Engadimos o avatar á casilla inicial (se o metodo existe)
        if (this.lugar != null) {
            this.lugar.anhadirAvatar(this);
        }
        System.out.println("Avatar creado: " + this.id + " (Tipo: " + this.tipo + ") para " + jugador.getNombre());
    }

    //A continuación, tenemos otros métodos útiles para el desarrollo del juego.
    /*Metodo que permite mover a un avatar a una casilla concreta. Parámetros:
    * - Un array con las casillas del tablero. Se trata de un arrayList de arrayList de casillas (uno por lado).
    * - Un entero que indica el numero de casillas a moverse (será el valor sacado en la tirada de los dados).
    * EN ESTA VERSIÓN SUPONEMOS QUE valorTirada siemrpe es positivo.
     */

    private void mover(ArrayList<ArrayList<Casilla>> casillas, int valorTirada, Tablero tablero, boolean avanzar) {
        //Creamos unha lista que conteña en orden todas as casillas do taboleiro para que sea mais comodo traballar
        ArrayList<Casilla> todasCasillas = tablero.CasillasLineales();

        //Atopamos a posición actual do avatar
        int posicionActual = -1;
        for (int i = 0; i < todasCasillas.size(); i++) {
            if (todasCasillas.get(i) == this.lugar) {
                posicionActual = i; //gardamos a posición na que se atopa o avatar
                break;
            }
        }
        if (posicionActual == -1) {
            System.out.println("Non se puido atopar a posición do avatar " + this.id);
            return; //Se non se atopa, saímos
        }

        // Calculamos a nova posición aplicando módulo (permite que o avatar de voltas completas ao taboleiro)
        int novaPos = (posicionActual + valorTirada) % todasCasillas.size();

        if (avanzar) {

            boolean pasoPorSalida = (novaPos <= posicionActual && valorTirada > 0);
            // Se a nova posición é menor que a actual, significa que deu unha volta completa

            // Se pasou pola Salida, sumar diñeiro
            if (pasoPorSalida) {
                this.jugador.sumarFortuna(Valor.SUMA_VUELTA);
                this.jugador.registrarPasoSalida(Valor.SUMA_VUELTA);
            }
        }
        //en caso de que sexa false, retrocedemos, e non se comproba se pasa por salida ou cobra diñeiro

        Casilla casillaDestino = todasCasillas.get(novaPos);

        // Se a casilla destino é "IrCarcel", mover directamente á Cárcere
        if ("IrCarcel".equalsIgnoreCase(casillaDestino.getNombre())) {

            // Buscar a casilla Cárcere
            Casilla carcel = tablero.encontrar_casilla("Carcel");

            if (carcel != null) {
                // Mover o avatar ao Cárcere
                this.lugar.eliminarAvatar(this);
                this.lugar = carcel;
                carcel.anhadirAvatar(this);

                // Encarcelar ao xogador
                this.jugador.encarcelar(casillas, tablero);
                return; // Saímos do metodo aquí
            }
        }

        // Movemento normal (se non cae en IrCarcel)
        this.lugar.eliminarAvatar(this);
        this.lugar = casillaDestino;
        this.lugar.anhadirAvatar(this);

    }

    public void moverAvatar(ArrayList<ArrayList<Casilla>> casillas, int valorTirada, Tablero tablero, boolean avanzar) {
        String casillaAnteriorNombre = lugar.getNombre();
        mover(casillas, valorTirada, tablero, avanzar);

        // Mensaxe base
        String mensaje = "O avatar " + this.id + " avanza " + valorTirada + " posiciones, dende " + casillaAnteriorNombre + " ata " + lugar.getNombre() + ".";

        System.out.println(mensaje);
    }

    //funcion para mover o avatar a unha casilla en especifico
    public void moverAvatarHasta(String nombreCasilla, ArrayList<ArrayList<Casilla>> casillas, Tablero tablero, boolean avanzar) {
        // Creamos unha lista lineal coas casillas do taboleiro
        ArrayList<Casilla> todasCasillas = tablero.CasillasLineales();

        // Buscamos posición actual e destino
        int posActual = todasCasillas.indexOf(this.lugar);
        int posDestino = -1;
        for (int i = 0; i < todasCasillas.size(); i++) {
            if (todasCasillas.get(i).getNombre().equalsIgnoreCase(nombreCasilla)) {
                posDestino = i;
                break;
            }
        }

        if (posActual == -1 || posDestino == -1) {
            System.out.println("Erro: non se puido atopar a casilla destino (" + nombreCasilla + ")");
            return;
        }

        // Calculamos cantas casillas hai ata o destino (sentido horario)
        int pasos = (posDestino - posActual + todasCasillas.size()) % todasCasillas.size();

        // Chamamos ao metodo principal que xa tes
        this.mover(casillas, pasos, tablero, avanzar);
    }

    /*Metodo que permite generar un ID para un avatar. Sólo lo usamos en esta clase (por ello es privado).
    * El ID generado será una letra mayúscula. Parámetros:
    * - Un arraylist de los avatares ya creados, con el objetivo de evitar que se generen dos ID iguales.
     */
    private void generarId(ArrayList<Avatar> avCreados) {
        Random rand = new Random(); //xenera números aleatorios
        String novoId;
        boolean idValido; //indica que o ID non está repetido

        //buscamos mentras o ID non sexa válido
        do {
            //xeramos números aleatorios entre 0-35, letras maiusculas + numeros
            int r = rand.nextInt(36);

            if (r < 26){ //usamos unha letra da A-Z
                novoId = String.valueOf((char) ('A' + r)); // Convertimos o número a letra (0--A, 1--B)
            }
            else{ //usamos os números de 0-9
                novoId = String.valueOf((char) ('0' + (r -26))); // Convertimos o número a díxito (26--0, 27--1)
            }

            //comprobamos que o ID non estea en uso
            idValido = true; //asumimos que é válido inicialmente
            for (Avatar av : avCreados){
                if (av.getId().equalsIgnoreCase(novoId)){
                    idValido = false; //está repetido e temos que buscar outro
                    break; //non fai falta seguir buscando
                }
            }
        } while (!idValido);

        //Asignamos o ID ao avatar
        this.id = novoId;
    }

    //----------Metodos auxiliares

    public String getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public Jugador getJugador() {
        return jugador;
    }

    public Casilla getLugar() {
        return lugar;
    }

    public void setLugar(Casilla lugar) {
        this.lugar = lugar;
    }

    @Override
    public String toString() {
        // Útil para comandos tipo "listar jugadores"
        return "{avatar: " + this.id + ", tipo: " + this.tipo + "}";
    }
}
