package partida;

import monopoly.casillas.Casilla;

public class Trato {
    private String id;
    private Jugador proponente;
    private Jugador receptor;
    private Casilla propiedadOfrecida;
    private float dineroOfrecido;
    private Casilla propiedadSolicitada;
    private float dineroSolicitado;
    private boolean aceptado;
    private boolean eliminado;

    public Trato(String id, Jugador proponente, Jugador receptor,
                 Casilla propiedadOfrecida, Casilla propiedadSolicitada,
                 float dineroOfrecido, float dineroSolicitado) {
        this.id = id;
        this.proponente = proponente;
        this.receptor = receptor;
        this.propiedadOfrecida = propiedadOfrecida;
        this.propiedadSolicitada = propiedadSolicitada;
        this.dineroOfrecido = dineroOfrecido;
        this.dineroSolicitado = dineroSolicitado;
        this.aceptado = false;
        this.eliminado = false;
    }

    public boolean puedeSerEjecutado() {
        // Validar que el proponente aún tiene lo que ofrece
        if (propiedadOfrecida != null && !propiedadOfrecida.getDuenho().equals(proponente)) {
            return false;
        }
        if (dineroOfrecido > 0 && proponente.getFortuna() < dineroOfrecido) {
            return false;
        }

        // Validar que el receptor aún tiene lo que se solicita
        if (propiedadSolicitada != null && !propiedadSolicitada.getDuenho().equals(receptor)) {
            return false;
        }
        if (dineroSolicitado > 0 && receptor.getFortuna() < dineroSolicitado) {
            return false;
        }

        return true;
    }

    public void ejecutar() {
        // Transferir propiedades
        if (propiedadOfrecida != null) {
            propiedadOfrecida.setDuenho(receptor);
            proponente.eliminarPropiedad(propiedadOfrecida);
            receptor.anhadirPropiedad(propiedadOfrecida);
        }

        if (propiedadSolicitada != null) {
            propiedadSolicitada.setDuenho(proponente);
            receptor.eliminarPropiedad(propiedadSolicitada);
            proponente.anhadirPropiedad(propiedadSolicitada);
        }

        // Transferir dinero
        if (dineroOfrecido > 0) {
            proponente.sumarFortuna(-dineroOfrecido);
            receptor.sumarFortuna(dineroOfrecido);
        }

        if (dineroSolicitado > 0) {
            receptor.sumarFortuna(-dineroSolicitado);
            proponente.sumarFortuna(dineroSolicitado);
        }

        this.aceptado = true;
    }

    public String getDescripcionOfertada() {
        StringBuilder sb = new StringBuilder();
        if (propiedadOfrecida != null) {
            sb.append(propiedadOfrecida.getNombre());
        }
        if (dineroOfrecido > 0) {
            if (propiedadOfrecida != null) sb.append(" y ");
            sb.append((int)dineroOfrecido).append("€");
        }
        return sb.toString();
    }

    public String getDescripcionSolicitada() {
        StringBuilder sb = new StringBuilder();
        if (propiedadSolicitada != null) {
            sb.append(propiedadSolicitada.getNombre());
        }
        if (dineroSolicitado > 0) {
            if (propiedadSolicitada != null) sb.append(" y ");
            sb.append((int)dineroSolicitado).append("€");
        }
        return sb.toString();
    }

    public String getDescripcionCompleta() {
        return "cambiar (" + getDescripcionOfertada() + ") por (" + getDescripcionSolicitada() + ")";
    }

    @Override
    public String toString() {
        return "{\n" +
                "id: " + id + ",\n" +
                "jugadorPropone: " + proponente.getNombre() + ",\n" +
                "trato: " + getDescripcionCompleta() + "\n" +
                "}";
    }

    // Getters y Setters
    public String getId() { return id; }
    public Jugador getProponente() { return proponente; }
    public Jugador getReceptor() { return receptor; }
    public Casilla getPropiedadOfrecida() { return propiedadOfrecida; }
    public float getDineroOfrecido() { return dineroOfrecido; }
    public Casilla getPropiedadSolicitada() { return propiedadSolicitada; }
    public float getDineroSolicitado() { return dineroSolicitado; }
    public boolean isAceptado() { return aceptado; }
    public boolean isEliminado() { return eliminado; }
    public void setEliminado(boolean eliminado) { this.eliminado = eliminado; }
}