package monopoly.edificios;

import monopoly.*;
import monopoly.casillas.Solar;
import partida.*;

//Clase que representa unha Piscina construída nun solar.
public class Piscina extends Edificio {

    // Contador estático para xerar IDs únicos para as piscinas
    private static int contador = 1;

    //Constructor da clase Piscina.
    public Piscina(Solar solar, Jugador propietario) {
        super(solar, propietario);
    }

    //Metodo que devolve o tipo de edificio.
    @Override
    protected String obterTipoEdificio() {
        return "piscina";
    }

    //Metodo que obtén o seguinte número do contador de piscinas.
    @Override
    protected int obterContador() {
        return contador++;
    }

    //Metodo que calcula o prezo da piscina segundo o solar.
    @Override
    protected float calcularPrezo() {
        String nomeSolar = solar.getNombre().toLowerCase();

        switch(nomeSolar) {
            case "solar1": return Valor.SOLAR1_PRECIO_PISCINA;
            case "solar2": return Valor.SOLAR2_PRECIO_PISCINA;
            case "solar3": return Valor.SOLAR3_PRECIO_PISCINA;
            case "solar4": return Valor.SOLAR4_PRECIO_PISCINA;
            case "solar5": return Valor.SOLAR5_PRECIO_PISCINA;
            case "solar6": return Valor.SOLAR6_PRECIO_PISCINA;
            case "solar7": return Valor.SOLAR7_PRECIO_PISCINA;
            case "solar8": return Valor.SOLAR8_PRECIO_PISCINA;
            case "solar9": return Valor.SOLAR9_PRECIO_PISCINA;
            case "solar10": return Valor.SOLAR10_PRECIO_PISCINA;
            case "solar11": return Valor.SOLAR11_PRECIO_PISCINA;
            case "solar12": return Valor.SOLAR12_PRECIO_PISCINA;
            case "solar13": return Valor.SOLAR13_PRECIO_PISCINA;
            case "solar14": return Valor.SOLAR14_PRECIO_PISCINA;
            case "solar15": return Valor.SOLAR15_PRECIO_PISCINA;
            case "solar16": return Valor.SOLAR16_PRECIO_PISCINA;
            case "solar17": return Valor.SOLAR17_PRECIO_PISCINA;
            case "solar18": return Valor.SOLAR18_PRECIO_PISCINA;
            case "solar19": return Valor.SOLAR19_PRECIO_PISCINA;
            case "solar20": return Valor.SOLAR20_PRECIO_PISCINA;
            case "solar21": return Valor.SOLAR21_PRECIO_PISCINA;
            case "solar22": return Valor.SOLAR22_PRECIO_PISCINA;
            default: return 100000f; // Prezo por defecto
        }
    }

    //Metodo que obtén o aluguer que aporta esta piscina.
    @Override
    public float obterAluguer() {
        String nomeSolar = solar.getNombre().toLowerCase();

        switch(nomeSolar) {
            case "solar1": return Valor.SOLAR1_ALQUILER_PISCINA;
            case "solar2": return Valor.SOLAR2_ALQUILER_PISCINA;
            case "solar3": return Valor.SOLAR3_ALQUILER_PISCINA;
            case "solar4": return Valor.SOLAR4_ALQUILER_PISCINA;
            case "solar5": return Valor.SOLAR5_ALQUILER_PISCINA;
            case "solar6": return Valor.SOLAR6_ALQUILER_PISCINA;
            case "solar7": return Valor.SOLAR7_ALQUILER_PISCINA;
            case "solar8": return Valor.SOLAR8_ALQUILER_PISCINA;
            case "solar9": return Valor.SOLAR9_ALQUILER_PISCINA;
            case "solar10": return Valor.SOLAR10_ALQUILER_PISCINA;
            case "solar11": return Valor.SOLAR11_ALQUILER_PISCINA;
            case "solar12": return Valor.SOLAR12_ALQUILER_PISCINA;
            case "solar13": return Valor.SOLAR13_ALQUILER_PISCINA;
            case "solar14": return Valor.SOLAR14_ALQUILER_PISCINA;
            case "solar15": return Valor.SOLAR15_ALQUILER_PISCINA;
            case "solar16": return Valor.SOLAR16_ALQUILER_PISCINA;
            case "solar17": return Valor.SOLAR17_ALQUILER_PISCINA;
            case "solar18": return Valor.SOLAR18_ALQUILER_PISCINA;
            case "solar19": return Valor.SOLAR19_ALQUILER_PISCINA;
            case "solar20": return Valor.SOLAR20_ALQUILER_PISCINA;
            case "solar21": return Valor.SOLAR21_ALQUILER_PISCINA;
            case "solar22": return Valor.SOLAR22_ALQUILER_PISCINA;
            default: return 500000f; // Aluguer por defecto
        }
    }
}