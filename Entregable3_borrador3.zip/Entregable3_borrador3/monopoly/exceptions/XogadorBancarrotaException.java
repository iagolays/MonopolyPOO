package monopoly.exceptions;

//excepción para cando un xogador queda en bancarrota

public class XogadorBancarrotaException extends EstadoXogoException{
    public XogadorBancarrotaException(String nomeXogador) {
        super("O xogador " + nomeXogador + " declárase en bancarrota e abandona o xogo.");
    }

    //constructor para cando un xogador queda en bancarrota indicando a razon
    public XogadorBancarrotaException(String nomeXogador, String razon) {
        super("O xogador " + nomeXogador + " declárase en bancarrota por: " + razon + " e abandona o xogo.");
    }
}
