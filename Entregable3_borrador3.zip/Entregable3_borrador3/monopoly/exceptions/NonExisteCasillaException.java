package monopoly.exceptions;

//excepción para casillas que non existen no taboleiro

public class NonExisteCasillaException extends NonExisteExcepcion{
    public NonExisteCasillaException(String nomeCasilla) {
        super("casilla", nomeCasilla);
        //chama ao constructor da clase pai NonExisteExcepcion, con super ("Non existe casilla co nome " + nomeCasilla);
    }
}
