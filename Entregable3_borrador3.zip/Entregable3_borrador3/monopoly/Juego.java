package monopoly;

import partida.*; //impórtanse todas as clases do paquete partida
import monopoly.casillas.*; //impórtanse todas as clases do paquete casillas
import monopoly.exceptions.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner; //Para ler a entrada do usuario
import java.io.File; // Para xestionar ficheiros
import java.io.FileNotFoundException; //obligatorio para que funcione new Scanner ao ler o arquivo

public class Juego implements Comando {

    //Atributos
    private static ConsolaNormal consola; //Consola para interacción co usuario

    private ArrayList<Jugador> jugadores; //Jugadores de la partida.
    private ArrayList<Avatar> avatares; //Avatares en la partida.
    private int turno = 0; //Índice correspondiente a la posición en el arrayList del jugador (y el avatar) que tienen el turno
    private int lanzamientos; //Variable para contar el número de lanzamientos de un jugador en un turno.
    private Tablero tablero; //Tablero en el que se juega.
    private Dado dado1; //Dos dados para lanzar y avanzar casillas.
    private Dado dado2;
    private Jugador banca; //El jugador banca.
    private boolean tirado; //Booleano para comprobar si el jugador que tiene el turno ha tirado o no.
    private boolean solvente; //Booleano para comprobar si el jugador que tiene el turno es solvente, es decir, si ha pagado sus deudas.
    private boolean dadosLanzados; //Comprobar que os dados foron lanzados e xa comezou a partida

    private Suerte casillaSuerte; // Referencia a la casilla de Suerte (que contiene las cartas)
    private CajaComunidad casillaComunidad; // Referencia a la casilla de Caja Comunidad (que contiene las cartas)

    // NUEVO: Atributos para tratos
    private ArrayList<Trato> tratos;
    private int contadorTratos;

    public Juego(boolean modoInteractivo) { //constructor do menú se non se recibe un arquivo

        consola = new ConsolaNormal(); // Inicializamos a consola estática para a interacción

        // Inicializamos as listas de xogadores e avatares
        this.jugadores = new ArrayList<>();
        this.avatares = new ArrayList<>();
        this.banca = new Jugador(); // Creamos a banca do xogo
        this.tablero = new Tablero(banca); // Creamos o taboleiro asociado á banca

        // Creamos os dous dados para o xogo
        this.dado1 = new Dado();
        this.dado2 = new Dado();

        // Obtener referencias a las casillas de cartas desde el tablero
        this.casillaSuerte = (Suerte) this.tablero.encontrar_casilla("Suerte");
        this.casillaComunidad = (CajaComunidad) this.tablero.encontrar_casilla("CajaComunidad");

        // NUEVO: Inicializar lista de tratos
        this.tratos = new ArrayList<>();
        this.contadorTratos = 1;

        this.turno = 0; // Comeza o primeiro xogador
        this.lanzamientos = 0; // Aínda non houbo lanzamentos
        this.tirado = false; // Aínda non se lanzaron dados
        this.solvente = true; // Asumimos que é solvente inicialmente
        this.dadosLanzados = false; // Inicialmente non se lanzaron dados

        if (modoInteractivo) {
            this.iniciarPartida(); // Iniciamos a partida en modo interactivo
        }
    }

    private void iniciarPartida() {
        consola.imprimir("Benvido ao Monopoly ETSE!");

        //Sustitúense todos os System.out por consola.imprimir
        consola.imprimir("\n- crear jugador <nome> <avatar>");
        consola.imprimir("- jugador");
        consola.imprimir("- listar jugadores");
        consola.imprimir("- lanzar dados [suma]");
        consola.imprimir("- acabar turno");
        consola.imprimir("- salir carcel");
        consola.imprimir("- describir <NomeCasilla>");
        consola.imprimir("- describir jugador <Nome>");
        consola.imprimir("- comprar <NomePropiedade>");
        consola.imprimir("- listar enventa");
        consola.imprimir("- ver tablero");
        consola.imprimir("- edificar <tipoEdificacion> (casa, hotel, piscina, pista)");
        consola.imprimir("- listar edificios");
        consola.imprimir("- listar edificios <colorGrupo>");
        consola.imprimir("- hipotecar <NomeCasilla>");
        consola.imprimir("- deshipotecar <NomeCasilla>");
        consola.imprimir("- vender <tipo> <NomeCasilla> <cantidade>");
        consola.imprimir("- estadisticas [nomeXogador]");
        consola.imprimir("- comandos <NomeFicheiro>");
        consola.imprimir("- salir");
        consola.imprimir(""); // Liña en branco para separar*/

        while (true) { // Bucle infinito
            String comando = consola.ler("\n$> ").trim();

            if (comando.equalsIgnoreCase("salir")) { //Se o comando é "salir", saímos do xogo
                consola.imprimir("\nSaíndo do xogo...");
                consola.imprimir("Ata pronto!");
                break; // Saímos do bucle

            } else if (comando.startsWith("comandos ")) { //Se o comando empeza por "comandos ", lense os comandos dende un ficheiro
                String nomeFicheiro = comando.substring(9);
                try {
                    this.lerFicheiroComandos(nomeFicheiro); // AÑADIR try-catch AQUÍ
                } catch (MonopolyException e) {
                    consola.imprimir("Erro: " + e.getMessage());
                }

            } else { // Calquera outro comando envíase ao metodo que interpreta comandos
                try {
                    this.procesarComando(comando);
                } catch (MonopolyException e) {
                    consola.imprimir("Erro: " + e.getMessage());
                }
            }
        }
    }

    /* Metodo que interpreta o comando introducido e toma a acción correspondente
     * Parámetro: cadea de caracteres (o comando)
     */
    @Override
    public void procesarComando(String linea) throws MonopolyException {
        String comando = linea.trim();
        // Separa a cadea por espazos entre palabras
        String[] partes = comando.split("\\s+");

        if (partes.length == 0){
            return; // Se está baleiro, non facemos nada
        }

        if (!this.jugadores.isEmpty()) {
            Jugador actual = this.jugadores.get(this.turno);
            if (actual.getFortuna() < 0 && !actual.isEnBancarrota()) { //se o xogador ten débedas pendentes
                consola.imprimir(actual.getNombre() + " aínda ten débedas pendentes (" + (int)Math.abs(actual.getFortuna()) + "€).");
                consola.imprimir("Use 'hipotecar <casilla>' ou 'acabar turno' para resolver.");
            }
        }

        switch (partes[0].toLowerCase()) { //Analiza o primeiro termo do comando en minúsculas

            case "crear": // Comando: crear jugador <nombre> <tipoAvatar>
                if (partes.length >= 4 && partes[1].equalsIgnoreCase("jugador")) {
                    if (dadosLanzados){
                        throw new EstadoXogoException("Non se poden crear xogadores unha vez comezada a partida.");
                    } else {
                        this.crearXogador(partes[2], partes[3]); // Creamos o novo xogador
                    }
                } else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: crear jugador <nome> <avatar>");
                }
                break;
            case "jugador": // Comando: jugador - mostra o xogador actual
                this.mostrarXogadorActual();
                break;
            case "listar":
                comandoListar(partes);
                break;
            case "lanzar": // Comando: lanzar dados [valor]
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("dados")) {
                    if (partes.length >= 3) {
                        this.lanzarDadosForzados(partes[2]); // Lanzamento forzado
                        this.dadosLanzados = true;
                    } else {
                        this.lanzarDados(); // Lanzamento aleatorio
                        this.dadosLanzados = true;
                    }
                }else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: lanzar dados [valor]");
                }
                break;
            case "describir": // Comando: describir jugador <nome> ou describir <casilla>
                if (partes.length >= 3 && partes[1].equalsIgnoreCase("jugador")) {
                    this.describirJugador(partes[2]); //Describir Jugador
                } else if (partes.length >= 2) {
                    this.describirCasilla(partes[1]); // Describir casilla
                } else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: describir jugador <nome> OU describir <casilla>");
                }
                break;
            case "comprar": // Comando: comprar <propiedade>
                if (partes.length >= 2) {
                    this.comprarCasilla(partes[1]);
                } else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: comprar <nomeCasilla>");
                }
                break;
            case "salir": // Comando: salir carcel
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("carcel")) {
                    this.salirCarcel();
                } else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: salir carcel");
                }
                break;
            case "acabar": // Comando: acabar turno
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("turno")) {
                    this.acabarTurno();
                } else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: acabar turno");
                }
                break;
            case "ver": // Comando: ver tablero
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("tablero")) {
                    this.verTablero();
                } else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: ver tablero");
                }
                break;
            case "edificar":
                comandoEdificar(partes);
                break;
            case "hipotecar":
                this.hipotecar(partes);
                break;
            case "deshipotecar":
                this.deshipotecar(partes);
                break;
            case "vender":
                this.comandoVender(partes);
                break;
            case "estadisticas":
                if (partes.length >= 2) {
                    this.mostrarEstadisticasJugador(partes[1]);
                } else {
                    this.mostrarEstadisticasXogo();
                }
                break;
            case "trato": // NUEVO: Comando para proponer tratos
                this.proponerTrato(partes);
                break;
            case "aceptar": // NUEVO: Comando para aceptar tratos
                if (partes.length >= 3 && partes[1].equalsIgnoreCase("trato")) {
                    this.aceptarTrato(partes[2]);
                } else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: aceptar trato <idTrato>");
                }
                break;
            case "tratos": // NUEVO: Comando para listar tratos
                this.listarTratos();
                break;
            case "eliminar": // NUEVO: Comando para eliminar tratos
                if (partes.length >= 3 && partes[1].equalsIgnoreCase("trato")) {
                    this.eliminarTrato(partes[2]);
                } else {
                    throw new ComandoInvalidoException("Formato incorrecto. Use: eliminar trato <idTrato>");
                }
                break;
            default:
                throw new NonExisteComandoException(comando);
        }
    }

    // ========== IMPLEMENTACIÓN DE LA INTERFAZ COMANDO ==========

    @Override
    public void crearXogador(String nome, String tipoAvatar) throws MonopolyException {
        //Verificamos se xa existen demasiados xogadores
        if (this.jugadores.size() >= 4) {
            throw new EstadoXogoException("Xa hai 4 xogadores, non poden engadrse mais.");
        }

        for (Jugador j : this.jugadores) { // Verificamos se xa existe un xogador con ese nome
            if (j.getNombre().equalsIgnoreCase(nome)) {
                throw new EstadoXogoException("Xa existe un xogador con ese nome");
            }
        }

        //Validamos que o tipo de avatar sexa correcto
        String[] tiposValidos = {"Coche", "Esfinge", "Sombrero", "Pelota"};
        boolean tipoValido = false; //poñemos unha bandeira
        for (String tipo : tiposValidos) {
            if (tipo.equalsIgnoreCase(tipoAvatar)) {
                tipoValido = true;
                break;
            }
        }
        if (!tipoValido) {
            throw new ComandoInvalidoException("Tipo de avatar non válido. Usa: Coche, Esfinge, Sombrero ou Pelota.");
        }

        //Comprobamos que o tipo de avatar non estea xa collido
        for (Avatar av : this.avatares) {
            if (av.getTipo().equalsIgnoreCase(tipoAvatar)) {
                throw new EstadoXogoException("O tipo de avatar '" + tipoAvatar + "' xa está en uso por outro xogador.");
            }
        }

        Casilla salida = this.tablero.encontrar_casilla("Salida"); // Buscamos a casilla de salida
        if (salida == null) {
            throw new EstadoXogoException("Non se atopou a casilla Salida");
        }

        // Creamos o novo xogador
        Jugador novoJugador = new Jugador(nome, tipoAvatar, salida, this.avatares);
        this.jugadores.add(novoJugador); // Engadimos o xogador á lista
        this.avatares.add(novoJugador.getAvatar()); // Engadimos o avatar á lista

        consola.imprimir("{"); // Mostramos a confirmación da creación
        consola.imprimir("nome: " + novoJugador.getNombre() + ",");
        consola.imprimir("avatar: " + novoJugador.getAvatar().getId());
        consola.imprimir("}");

        consola.imprimir(this.tablero.toString()); // Mostramos o taboleiro actualizado
    }

    @Override
    public void mostrarXogadorActual() throws MonopolyException {
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            throw new EstadoXogoException("Non hai xogadores na partida");
        }

        Jugador actual = this.jugadores.get(this.turno); // Obtenemos o xogador actual
        consola.imprimir("É o turno de: " + actual.getNombre() + "."); // Mostramos quen é o novo xogador
        consola.imprimir("Estado actual: " + actual); //toString creado en jugador
    }

    @Override
    public void describirJugador(String nome) throws MonopolyException {
        Jugador jugador = buscarJugador(nome);
        if (jugador == null) {
            throw new NonExisteXogadorException(nome);
        }
        consola.imprimir(jugador.infoJugador()); // Mostramos a información do xogador
    }

    @Override
    public void describirCasilla(String nome) throws MonopolyException {
        Casilla c = this.tablero.encontrar_casilla(nome); // Buscamos a casilla no taboleiro
        if (c == null) { // Se non se atopa a casilla, mostramos erro
            throw new NonExisteCasillaException(nome);
        }
        consola.imprimir(c.infoCasilla()); // Mostramos a información da casilla
    }

    @Override
    public void comandoListar(String[] partes) throws MonopolyException {
        if (partes.length < 2){
            throw new ComandoInvalidoException("Formato incorrecto. Use: listar jugadores|edificios|enventa|tratos");
        }

        switch (partes[1].toLowerCase()) {
            case "jugadores":
                listarJugadores();
                break;
            case "edificios":
                if (partes.length == 2) {
                    listarTodosEdificios();
                } else {
                    // Reconstruimos o nombre completo do grupo
                    StringBuilder colorGrupoBuilder = new StringBuilder();
                    for (int i = 2; i < partes.length; i++) {
                        if (i > 2){
                            colorGrupoBuilder.append(" "); // añadimos espacio entre palabras
                        }
                        colorGrupoBuilder.append(partes[i]);
                    }
                    listarEdificiosGrupo(colorGrupoBuilder.toString());
                }
                break;
            case "enventa":
                listarVenta();
                break;
            case "tratos": // NUEVO: Listar tratos
                listarTratos();
                break;
            default:
                throw new ComandoInvalidoException("Subcomando listar non recoñecido: " + partes[1]);
        }
    }

    @Override
    public void lanzarDados() throws MonopolyException {
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            throw new EstadoXogoException("Non hai xogadores na partida, non se poden lanzar os dados.");
        } else if (this.jugadores.size() < 2){
            throw new EstadoXogoException("Non se poden lanzar os dados ata que haxa polo menos 2 xogadores.");
        }

        Jugador actual = this.jugadores.get(this.turno); // Obtenemos o xogador actual

        if (actual.isEnCarcel()) { // Verificamos se o xogador está no cárcere
            if (!this.tirado){
                //intenta salir de carcel
                int resultado = actual.intentarSalirCarcel(this.dado1, this.dado2, this.tablero, false, 0, 0);
                if (resultado == -1){
                    return; //está en bancarrota, non pode sair
                } else if (resultado == 0) {
                    //segue no carcere, non se move
                    this.tirado = true;
                    return;
                }
                else {
                    // resultado == 1: Sae do carcere e movese cos dados
                    int valor1 = this.dado1.getValor(); // Usamos o valor xa tirado
                    int valor2 = this.dado2.getValor();
                    this.tirado = true;
                    gestionarTirada(actual, valor1, valor2, this.tablero);
                }
            }else {
                throw new XogadorCarcelException(actual.getNombre(), "tirar dados xa que xa tirou");
            }
        } else {
            if (!this.tirado){ //só se non se tirou con anterioridade
                // Facemos a tirada aleatoria dos dados
                int valor1 = this.dado1.hacerTirada();
                int valor2 = this.dado2.hacerTirada();

                gestionarTirada(actual, valor1, valor2, this.tablero);
            } else {
                throw new EstadoXogoException("Xa se tiraron os dados, remata o turno.");
            }
        }
    }

    @Override
    public void lanzarDadosForzados(String tirada) throws MonopolyException {
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            throw new EstadoXogoException("Non hai xogadores na partida");
        } else if (this.jugadores.size() < 2){
            throw new EstadoXogoException("Non se poden lanzar os dados ata que haxa polo menos 2 xogadores.");
        }

        Jugador actual = this.jugadores.get(this.turno); // Obtenemos o xogador actual
        int[] valoresDados = Dado.procesarTiradaForzada(tirada); // Procesamos o formato "2+4"

        if (valoresDados == null) {
            throw new ComandoInvalidoException("Formato de tirada forzada inválido. Use 'numero + numero'");
        }

        if (actual.isEnCarcel()) { // Verificamos se o xogador está no cárcere
            if (!this.tirado) {
                //intenta salir de carcel
                int resultado = actual.intentarSalirCarcel(this.dado1, this.dado2, this.tablero, true, valoresDados[0], valoresDados[1]);
                if (resultado == -1){
                    return; //está en bancarrota, non pode sair
                } else if (resultado == 0) {
                    //segue no carcere, non se move
                    this.tirado = true;
                    return;
                }
                else {
                    // resultado == 1: Sae do carcere e movese cos dados
                    this.tirado = true;
                    gestionarTirada(actual, valoresDados[0], valoresDados[1], this.tablero);
                }
            } else {
                throw new XogadorCarcelException(actual.getNombre(), "tirar dados xa que xa tirou");
            }
        } else {
            if (!tirado) {
                //forzamos valores dos dados
                this.dado1.lanzarForzado(valoresDados[0]);
                this.dado2.lanzarForzado(valoresDados[1]);

                this.tirado = true;
                gestionarTirada(actual, valoresDados[0], valoresDados[1], tablero);
            } else {
                throw new EstadoXogoException("Os dados xa foron tirados, remate o turno.");
            }
        }
    }

    @Override
    public void comprarCasilla(String nome) throws MonopolyException {
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            throw new EstadoXogoException("Non hai xogadores na partida, non se poden comprar casillas.");
        }

        Jugador jugadorActual = this.jugadores.get(this.turno); // Xogador que ten o turno
        Casilla casilla = this.tablero.encontrar_casilla(nome); // Buscamos a casilla no taboleiro

        if (casilla == null) { // Verificamos que a casilla exista
            throw new NonExisteCasillaException(nome);
        }

        // Verificamos que o xogador está na casilla que quere comprar
        if (!jugadorActual.getAvatar().getLugar().equals(casilla)) {
            throw new ComandoInvalidoException("Só podes comprar a casilla na que estás actualmente: " + jugadorActual.getAvatar().getLugar().getNombre());
        }

        // Verificamos que a casilla sexa comprable
        if (!casilla.getTipo().equalsIgnoreCase("solar") && !casilla.getTipo().equalsIgnoreCase("transporte") &&
                !casilla.getTipo().equalsIgnoreCase("servicio")) {
            throw new ComandoInvalidoException("Non se pode comprar a casilla " + nome + ".");
        }

        // Verificamos que a casilla non teña dono ou sexa da banca
        if (casilla.getDuenho() != null && !"Banca".equalsIgnoreCase(casilla.getDuenho().getNombre())) {
            throw new PropiedadeNonPertenceException(nome,casilla.getDuenho().getNombre());
        }

        if (!jugadorActual.puedePagar(casilla.getValor())) {
            throw new DiñeiroInsuficienteException(jugadorActual.getNombre(), casilla.getValor(), jugadorActual.getFortuna());
        }

        casilla.comprarCasilla(jugadorActual, this.banca); // Chamamos ao metodo de compra da casilla
    }

    @Override
    public void comandoEdificar(String[] partes) throws MonopolyException {
        if (this.jugadores.isEmpty()) {
            throw new EstadoXogoException("Non hai xogadores na partida.");
        }

        if (partes.length < 2) {
            throw new ComandoInvalidoException("Formato incorrecto. Use: edificar <tipo>");
        }

        Jugador jugadorActual = this.jugadores.get(this.turno);
        String tipoEdificio = partes[1].toLowerCase();

        // Validar tipo de edificio
        if (!tipoEdificio.equals("casa") && !tipoEdificio.equals("hotel") && !tipoEdificio.equals("piscina") && !tipoEdificio.equals("pista")) {
            throw new ComandoInvalidoException("Tipo de edificio non válido. Use: casa, hotel, piscina ou pista.");
        }

        // Verificar que o xogador está nun solar
        Casilla casillaActual = jugadorActual.getAvatar().getLugar();
        if (casillaActual == null || !"solar".equalsIgnoreCase(casillaActual.getTipo())) {
            throw new ComandoInvalidoException("Só podes edificar nun solar e debes estar na casilla onde queres edificar.");
        }

        // Verificar que o xogador é dono da casilla
        if (!casillaActual.getDuenho().equals(jugadorActual)) {
            throw new PropiedadeNonPertenceException(jugadorActual.getNombre(), casillaActual.getNombre());
        }

        // Chamar al método de construcción (de la segunda clase)
        boolean exito = construirEdificioInterno(casillaActual, jugadorActual, tipoEdificio);

        if (exito) {
            // Actualizar el tablero para mostrar los cambios
            consola.imprimir(this.tablero.toString());
        }
    }

    // Método auxiliar para construcción de edificios (tomado de la segunda clase)
    private boolean construirEdificioInterno(Casilla casillaActual, Jugador jugadorActual, String tipoEdificio) {
        // Verificar que el jugador es dueño de la casilla (ya validado arriba)

        // Llamar al método de Solares para construir
        boolean exito = Solar.construirEdificio(casillaActual, jugadorActual, tipoEdificio);

        if (exito) {
            consola.imprimir("Se ha edificado unha " + tipoEdificio + " en " + casillaActual.getNombre() + ".");
        }

        return exito;
    }

    @Override
    public void comandoVender(String[] partes) throws MonopolyException {
        if (partes.length < 4){
            throw new ComandoInvalidoException("Formato incorrecto. Use: vender <tipo> <nomeCasilla> <cantidade>");
        }

        String tipo = partes[1];
        String nombreCasilla = partes[2];
        int cantidad = Integer.parseInt(partes[3]); //convertimos a enteiro o numero pasado por comandos
        Casilla c = this.tablero.encontrar_casilla(nombreCasilla);
        if (c == null) {
            throw new NonExisteCasillaException(nombreCasilla);
        }

        Jugador jugadorActual = this.jugadores.get(this.turno);
        if (!c.getDuenho().equals(jugadorActual)) {
            throw new PropiedadeNonPertenceException(jugadorActual.getNombre(), c.getNombre());
        }

        Solar.venderEdificio(c, jugadorActual, tipo, cantidad);
    }

    @Override
    public void hipotecar(String[] partes) throws MonopolyException {
        if (partes.length < 2) {
            throw new ComandoInvalidoException("Formato incorrecto. Use: hipotecar <nomeCasilla>");
        }

        String nombreCasilla = partes[1];
        Casilla c = this.tablero.encontrar_casilla(nombreCasilla);
        if (c == null) {
            throw new NonExisteCasillaException(nombreCasilla);
        }

        Jugador jugadorActual = this.jugadores.get(this.turno);
        if (!c.getDuenho().equals(jugadorActual)) {
            throw new PropiedadeNonPertenceException(jugadorActual.getNombre(), c.getNombre());
        }

        if (c.isHipotecada()) {
            throw new EstadoXogoException("A casilla xa está hipotecada.");
        }

        c.hipotecar(jugadorActual);
    }

    @Override
    public void deshipotecar(String[] partes) throws MonopolyException {
        if (partes.length < 2) {
            throw new ComandoInvalidoException("Formato incorrecto. Use: deshipotecar <nomeCasilla>");
        }

        String nombreCasilla = partes[1];
        Casilla c = this.tablero.encontrar_casilla(nombreCasilla);
        if (c == null) {
            throw new NonExisteCasillaException(nombreCasilla);
        }

        Jugador jugadorActual = this.jugadores.get(this.turno);
        if (!c.getDuenho().equals(jugadorActual)) {
            throw new PropiedadeNonPertenceException(jugadorActual.getNombre(), c.getNombre());
        }

        if (!c.isHipotecada()) {
            throw new EstadoXogoException("A casilla non está hipotecada.");
        }

        c.deshipotecar(jugadorActual);
    }

    @Override
    public void salirCarcel() throws MonopolyException {
        if (this.jugadores.isEmpty()){
            throw new EstadoXogoException("Non hai xogadores na partida");
        }

        Jugador jugador = this.jugadores.get(this.turno); // Xogador que ten o turno

        if (!jugador.isEnCarcel()) { // Verificamos que o xogador estea no cárcere
            throw new EstadoXogoException(jugador.getNombre() + " non está no cárcere.");
        }

        if (!jugador.puedePagar(Valor.CARCEL_SALIDA)) {
            throw new DiñeiroInsuficienteException(jugador.getNombre(), Valor.CARCEL_SALIDA, jugador.getFortuna());
        }

        jugador.salirCarcel(tablero);
    }

    @Override
    public void acabarTurno() throws MonopolyException {
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            throw new EstadoXogoException("Non hai xogadores");
        }
        Jugador actual = this.jugadores.get(this.turno);
        //verificamos que o xogador actual teña tirado e sexa solvente
        if (!this.tirado) {
            throw new EstadoXogoException("Non podes acabar o turno sen lanzar os dados.");
        }
        boolean tenDebedas = (actual.getFortuna() < 0 && !actual.isEnBancarrota());

        if (tenDebedas) {
            Jugador pagarA = detectarPagar (actual); //detecta a quen lle debe o xogador actual
            actual.declararBancarrota(this.tablero, pagarA);
            xestionarBancarrota(actual);
        } else {
            // NUEVO: Mostrar tratos pendentes al cambiar de turno
            mostrarTratosPendentes();

            this.turno = (this.turno + 1) % this.jugadores.size(); // Avanzamos ao seguinte xogador
            this.tirado = false; // Marcamos que non se lanzaron dados no novo turno
            this.solvente = true; // Asumimos que o novo xogador é solvent

            Jugador siguiente = this.jugadores.get(this.turno); // Obtenemos o novo xogador actual
            consola.imprimir("É o turno de: " + siguiente.getNombre() + "."); // Mostramos quen é o nuevo xogador
            consola.imprimir("Estado actual: " + siguiente); //toString creado en jugador
        }
    }

    @Override
    public void mostrarEstadisticasXogo() throws MonopolyException {
        estadisticasJuego();
    }

    @Override
    public void mostrarEstadisticasJugador(String nome) throws MonopolyException {
        Jugador jugador = buscarJugador(nome);
        if (jugador != null) {
            consola.imprimir(jugador.mostrarEstadisticas());
        } else {
            throw new NonExisteXogadorException(nome);
        }
    }

    @Override
    public void lerComandosFicheiro(String nome) throws MonopolyException {
        lerFicheiroComandos(nome);
    }

    // ========== NUEVOS MÉTODOS PARA TRATOS ==========

    private void proponerTrato(String[] partes) throws MonopolyException {
        if (partes.length < 3) {
            throw new ComandoInvalidoException("Formato: trato <jugador>: cambiar (propiedad1, propiedad2)");
        }

        Jugador actual = jugadores.get(turno);
        String nombreReceptor = partes[1].replace(":", "");
        Jugador receptor = buscarJugador(nombreReceptor);

        if (receptor == null) {
            throw new NonExisteXogadorException(nombreReceptor);
        }

        if (receptor.equals(actual)) {
            throw new ComandoInvalidoException("Non podes propoñer un trato a ti mesmo");
        }

        // Unir las partes restantes para parsear la oferta
        StringBuilder ofertaBuilder = new StringBuilder();
        for (int i = 2; i < partes.length; i++) {
            ofertaBuilder.append(partes[i]);
            if (i < partes.length - 1) {
                ofertaBuilder.append(" ");
            }
        }
        String oferta = ofertaBuilder.toString();

        // Parsear la oferta (implementación simplificada)
        Trato trato = parsearTrato(actual, receptor, oferta);
        if (trato == null) {
            throw new ComandoInvalidoException("Formato de trato inválido");
        }

        // Validar que el trato es posible
        validarTrato(trato);

        // Añadir trato a la lista
        tratos.add(trato);
        consola.imprimir(actual.getNombre() + " propón: " + receptor.getNombre() + ", ¿doche " +
                trato.getDescripcionOfertada() + " e dásme " + trato.getDescripcionSolicitada() + "?");
    }

    private void aceptarTrato(String idTrato) throws MonopolyException {
        Jugador actual = jugadores.get(turno);
        Trato trato = buscarTrato(idTrato, actual);

        if (trato == null) {
            throw new NonExisteTratoException(idTrato);
        }

        if (!trato.getReceptor().equals(actual)) {
            throw new TratoInvalidoException("Só o receptor pode aceptar o trato");
        }

        if (trato.isAceptado()) {
            throw new EstadoXogoException("O trato xa foi aceptado");
        }

        if (trato.isEliminado()) {
            throw new EstadoXogoException("O trato foi eliminado");
        }

        // Validar que el trato aún es posible
        if (!trato.puedeSerEjecutado()) {
            throw new TratoInvalidoException("O trato xa non pode ser executado (propiedades ou diñeiro insuficiente)");
        }

        // Ejecutar el trato
        trato.ejecutar();
        consola.imprimir("Aceptado o trato " + idTrato + " con " + trato.getProponente().getNombre());
    }

    private void listarTratos() throws MonopolyException {
        Jugador actual = jugadores.get(turno);
        boolean hayTratos = false;

        consola.imprimir("{");
        for (Trato trato : tratos) {
            if (trato.getReceptor().equals(actual) && !trato.isAceptado() && !trato.isEliminado()) {
                consola.imprimir(trato.toString() + ",");
                hayTratos = true;
            }
        }
        consola.imprimir("}");

        if (!hayTratos) {
            consola.imprimir("Non hai tratos pendentes");
        }
    }

    private void eliminarTrato(String idTrato) throws MonopolyException {
        Jugador actual = jugadores.get(turno);
        Trato trato = buscarTrato(idTrato, actual);

        if (trato == null) {
            throw new NonExisteTratoException(idTrato);
        }

        if (!trato.getProponente().equals(actual)) {
            throw new TratoInvalidoException("Só o proponente pode eliminar o trato");
        }

        if (trato.isAceptado()) {
            throw new EstadoXogoException("Non se pode eliminar un trato aceptado");
        }

        trato.setEliminado(true);
        consola.imprimir("Eliminado o trato " + idTrato);
    }

    private void mostrarTratosPendentes() {
        Jugador siguiente = jugadores.get((turno + 1) % jugadores.size());
        boolean hayTratos = false;

        for (Trato trato : tratos) {
            if (trato.getReceptor().equals(siguiente) && !trato.isAceptado() && !trato.isEliminado()) {
                if (!hayTratos) {
                    consola.imprimir("\nTratos pendentes para " + siguiente.getNombre() + ":");
                    hayTratos = true;
                }
                consola.imprimir("  " + trato.getId() + ": " + trato.getProponente().getNombre() +
                        " propón: " + trato.getDescripcionCompleta());
            }
        }
    }

    // ========== MÉTODOS AUXILIARES ==========

    private Jugador buscarJugador(String nombre) {
        for (Jugador j : jugadores) {
            if (j.getNombre().equalsIgnoreCase(nombre)) {
                return j;
            }
        }
        return null;
    }

    private Trato buscarTrato(String id, Jugador jugador) {
        for (Trato trato : tratos) {
            if (trato.getId().equals(id) &&
                    (trato.getProponente().equals(jugador) || trato.getReceptor().equals(jugador))) {
                return trato;
            }
        }
        return null;
    }

    private Trato parsearTrato(Jugador proponente, Jugador receptor, String oferta) {
        // Implementación simplificada - en una versión real debería ser más compleja
        try {
            // Formato: cambiar (Solar14, Solar10)
            // Formato: cambiar (Solar1, 2500000)
            // Formato: cambiar (Solar1, Solar14 y 300000)

            if (!oferta.startsWith("cambiar (")) {
                return null;
            }

            String contenido = oferta.substring(9, oferta.length() - 1); // Quitar "cambiar (" y ")"
            String[] partes = contenido.split(",");

            if (partes.length < 2) {
                return null;
            }

            // Simplificación: asumimos primer formato: cambiar (prop1, prop2)
            String ofrecidaStr = partes[0].trim();
            String solicitadaStr = partes[1].trim();

            Casilla propiedadOfrecida = tablero.encontrar_casilla(ofrecidaStr);
            Casilla propiedadSolicitada = tablero.encontrar_casilla(solicitadaStr);

            if (propiedadOfrecida == null || propiedadSolicitada == null) {
                return null;
            }

            return new Trato("trato" + contadorTratos++, proponente, receptor,
                    propiedadOfrecida, propiedadSolicitada, 0, 0);

        } catch (Exception e) {
            return null;
        }
    }

    private void validarTrato(Trato trato) throws MonopolyException {
        // Validar que el proponente tiene lo que ofrece
        if (trato.getPropiedadOfrecida() != null) {
            if (!trato.getPropiedadOfrecida().getDuenho().equals(trato.getProponente())) {
                throw new PropiedadeNonPertenceException(trato.getProponente().getNombre(),
                        trato.getPropiedadOfrecida().getNombre());
            }
        }

        if (trato.getDineroOfrecido() > 0) {
            if (trato.getProponente().getFortuna() < trato.getDineroOfrecido()) {
                throw new DiñeiroInsuficienteException(trato.getProponente().getNombre(),
                        trato.getDineroOfrecido(),
                        trato.getProponente().getFortuna());
            }
        }

        // Validar que el receptor tiene lo que se solicita
        if (trato.getPropiedadSolicitada() != null) {
            if (!trato.getPropiedadSolicitada().getDuenho().equals(trato.getReceptor())) {
                throw new PropiedadeNonPertenceException(trato.getReceptor().getNombre(),
                        trato.getPropiedadSolicitada().getNombre());
            }
        }

        if (trato.getDineroSolicitado() > 0) {
            if (trato.getReceptor().getFortuna() < trato.getDineroSolicitado()) {
                throw new DiñeiroInsuficienteException(trato.getReceptor().getNombre(),
                        trato.getDineroSolicitado(),
                        trato.getReceptor().getFortuna());
            }
        }
    }

    // ========== MÉTODOS TOMADOS DE LA SEGUNDA CLASE ==========

    private void listarJugadores() {
        if (jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            consola.imprimir("Non hai xogadores na partida.");
            return;
        }

        // Percorremos todos os xogadores e mostramos a súa información
        for (Jugador j : this.jugadores) {
            consola.imprimir(j.infoJugador()); // Mostramos a información dos xogadores
        }
    }

    private void listarVenta() {
        boolean hayPropiedades = false; // Inicializamos unha bandeira para saber se hai propiedades en venda

        // Percorremos todos os lados do taboleiro
        for (int lado = 0; lado < 4; lado++) {
            ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
            for (Casilla casilla : casillasLado) { // Percorremos cada casilla do lado actual
                String infoVenta = casilla.casEnVenta(); // Obtenemos la información de venda de la casilla
                if (!infoVenta.isEmpty()) { // Se a casilla está en venda, mostramos a información
                    consola.imprimir(infoVenta);
                    hayPropiedades = true;
                }
            }
        }

        if (!hayPropiedades) { // Se non hai propiedades en venda, mostramos mensaxe
            consola.imprimir("Non hai propiedades en venda");
        }
    }

    private void listarTodosEdificios() {
        boolean hayEdificios = false;

        for (Jugador j : jugadores) {
            // Listar directamente os edificios do xogador (teñen IDs únicos)
            for (String idEdificio : j.getEdificios()) {
                // Extraer información del ID
                String[] partes = idEdificio.split("-"); // Formato: tipo-numero
                if (partes.length >= 2) {
                    String tipo = partes[0]; // Tipo de edificio (casa, hotel, piscina, pista)

                    // Buscar casilla correspondiente a este edificio
                    Casilla casillaEdificio = null;
                    for (Casilla propiedad : j.getPropiedades()) { // Buscamos entre as propiedades do xogador
                        if ("solar".equalsIgnoreCase(propiedad.getTipo())) {
                            // Verificar si esta propiedad tiene edificios
                            Solar.DatosEdificios edificios = propiedad.getDatosedificios();
                            if (edificios != null) {
                                boolean tieneEsteTipo = false;
                                switch (tipo.toLowerCase()) {
                                    case "casa":
                                        tieneEsteTipo = edificios.getNumCasas() > 0;
                                        break;
                                    case "hotel":
                                        tieneEsteTipo = edificios.getNumHoteles() > 0;
                                        break;
                                    case "piscina":
                                        tieneEsteTipo = edificios.getNumPiscinas() > 0;
                                        break;
                                    case "pista":
                                        tieneEsteTipo = edificios.getNumPistas() > 0;
                                        break;
                                }
                                if (tieneEsteTipo) {
                                    casillaEdificio = propiedad;
                                    break;
                                }
                            }
                        }
                    }

                    if (casillaEdificio != null) {
                        // Calcular coste dependendo do tipo
                        float coste = 0;
                        switch (tipo.toLowerCase()) {
                            case "casa":
                                coste = Solar.obtenerPrecioCasa(casillaEdificio.getNombre());
                                break;
                            case "hotel":
                                coste = Solar.obtenerPrecioHotel(casillaEdificio.getNombre());
                                break;
                            case "piscina":
                                coste = Solar.obtenerPrecioPiscina(casillaEdificio.getNombre());
                                break;
                            case "pista":
                                coste = Solar.obtenerPrecioPista(casillaEdificio.getNombre());
                                break;
                        }

                        consola.imprimir(Solar.generarInfoEdificio(idEdificio, j, casillaEdificio, coste));
                        hayEdificios = true;
                    }
                }
            }
        }

        if (!hayEdificios) {
            consola.imprimir("Non hai edificios construidos.");
        }
    }

    private void listarEdificiosGrupo(String colorGrupo) {
        boolean hayEdificios = false; // bandera para saber si hay edificios
        colorGrupo = colorGrupo.trim().toLowerCase(); // normalizamos a color do grupo

        // Buscamos o grupo correspondente (para poder obter a info final de construción)
        ArrayList<Grupo> gruposEncontrados = new ArrayList<>(); // lista para almacenar grupos encontrados, e non repetilos
        for (Jugador jugador : jugadores) {
            for (Casilla propiedad : jugador.getPropiedades()) {
                Grupo grupo = propiedad.getGrupo(); // Obtemos o grupo da propiedade
                if (grupo != null && grupo.getColorGrupo().equalsIgnoreCase(colorGrupo) && !gruposEncontrados.contains(grupo)) { // Comprobamos que o grupo non estea xa na lista
                    gruposEncontrados.add(grupo);
                }
            }
        }
        if (gruposEncontrados.isEmpty()) {
            consola.imprimir("Non se atopou ningún edificio no grupo ca color " + colorGrupo + ".");
            return;
        }
        // Mostrar información de cada grupo
        for (Grupo grupo : gruposEncontrados) {
            String info = grupo.obtenerInfoEdificios();
            if (!info.contains("propiedad:") || info.contains("casa-") || info.contains("hotel-") || info.contains("piscina-") || info.contains("pista-")) {
                hayEdificios = true;
            }
            consola.imprimir(info);
        }
        if (!hayEdificios) {
            consola.imprimir("Non hai casillas con edificios construidos no grupo " + colorGrupo + ".");
        }
    }

    private void verTablero() {
        consola.imprimir(this.tablero.toString());
    }

    // Metodo auxiliar para procesar el movimiento después de lanzar dados
    private void procesarMovimento(Jugador actual, int total) {
        Avatar avatar = actual.getAvatar(); // Obtenemos o avatar do xogador actual

        // Movemos o avatar polo taboleiro
        ArrayList<ArrayList<Casilla>> todasCasillas = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            todasCasillas.add(this.tablero.getLado(i));
        }
        //moverAvatar xa verifica se pasa por "Salida"
        avatar.moverAvatar(todasCasillas, total, tablero, true);

        Casilla casillaActual = avatar.getLugar(); // Obtenemos a nova casilla

        // Si cae en Suerte o Comunidad, ejecutamos la acción de la casilla
        String tipo = casillaActual.getTipo().toLowerCase();

        if ("suerte".equals(tipo)) {
            // Ejecutar la acción de la casilla Suerte
            this.solvente = casillaActual.evaluarCasilla(actual, this.banca, total, this.tablero, false);
            this.solvente = !actual.isEnBancarrota();
            if (actual.getFortuna() < 0 && solvente){
                consola.imprimir(actual.getNombre() + " ten débedas pendentes tras a carta de Suerte.");
            }
        } else if ("comunidad".equals(tipo)) {
            // Ejecutar la acción de la casilla CajaComunidad
            this.solvente = casillaActual.evaluarCasilla(actual, this.banca, total, this.tablero, false);
            this.solvente = !actual.isEnBancarrota();
            if (actual.getFortuna() < 0 && solvente){
                consola.imprimir(actual.getNombre() + " ten débedas pendentes tras a carta de Comunidad.");
            }
        } else {
            this.solvente = casillaActual.evaluarCasilla(actual, this.banca, total, this.tablero, false);
        }

        // Mostrar mensaje de déudas solo si hay
        if (actual.getFortuna() < 0 && this.solvente){
            consola.imprimir(actual.getNombre() + " ten débedas pendentes.");
        }

        consola.imprimir(this.tablero.toString()); // Mostramos o taboleiro actualizado
        this.tirado = true; // Marcamos que xa se lanzaron dados neste turno
    }

    //metodo para dobles
    public void gestionarTirada(Jugador actual, int valor1, int valor2, Tablero tablero) {
        int total = valor1 + valor2; // Calculamos o total da tirada

        if (valor1 == valor2) { // Comprobar dobres
            actual.incrementarDobles(); // Incrementamos dobles consecutivos

            if (actual.getDoblesConsecutivos() == 3) { // Tres dobles consecutivos implica que debe ir ao cárcere
                consola.imprimir(actual.getNombre() + " sacou dobles 3 veces seguidas, vai directamente ao cárcere.");
                actual.encarcelar(tablero.getPosiciones(), tablero);
                actual.resetearDobles();
                this.tirado = true;
                try {
                    acabarTurno(); // AÑADIR try-catch AQUÍ
                } catch (MonopolyException e) {
                    consola.imprimir("Erro ao acabar turno: " + e.getMessage());
                }
                return;
            } else {
                this.procesarMovimento(actual, total);
                consola.imprimir("¡Dobles! " + actual.getNombre() + " tira outra vez.");
                this.lanzamientos++;

                //permitir novo lanzamiento se é solvente
                this.tirado = false;
                if (actual.isEnBancarrota() || actual.getFortuna() < 0) {
                    this.tirado = true; // Non pode tirar de novo se está en bancarrota
                    xestionarBancarrota(actual);
                }
                return;
            }
        } else { // No son dobles
            actual.resetearDobles();
            this.procesarMovimento(actual, total);
            this.lanzamientos++;
            this.tirado = true; // Turno terminado
        }
        //comprobamos que non esté en bancarrota
        if (actual.getFortuna() <= 0) {
            consola.imprimir(actual.getNombre() + " ten débedas pendentes.");
            // Non declarar bancarrota automática - esperar a que o xogador decida
        }
    }

    // Metodo para leer el fichero con los comandos introducidos
    public void lerFicheiroComandos(String nomeFicheiro) throws MonopolyException {
        File ficheiro = new File(nomeFicheiro); // Creamos un obxecto File co nome do ficheiro

        if (!ficheiro.exists()) { // Comprobamos si o ficheiro existe
            throw new ComandoInvalidoException("O ficheiro non existe: " + nomeFicheiro);
        }

        Scanner scanner = null; //declara o scanner pero non o inicializa
        try {
            scanner = new Scanner(ficheiro); // Ábrese o ficheiro en modo lectura
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine().trim(); //lemos a seguinte liña y eliminamos espazos en branco ao inicio/fin
                if (!linea.isEmpty() && !linea.startsWith("#")) { // Ignoramos liñas baleiras y comentarios
                    consola.imprimir("$> " + linea); // Mostramos o comando que se vai executar
                    this.procesarComando(linea); // Procesamos el comando
                }
            }
        } catch (FileNotFoundException e) { // Mostramos erro se non se pode abrir o ficheiro
            throw new ComandoInvalidoException("Non se pode abrir o ficheiro: " + e.getMessage());
        } finally {
            if (scanner != null) {
                scanner.close(); // Aseguramos que pechamos o scanner
            }
        }
    }

    //Metodo para detectar a quen debe pagar el jugador en bancarrota y pasar las propiedades
    private Jugador detectarPagar(Jugador deudor) {
        if (deudor.getUltimoCobraAlquiler() != null) {
            return deudor.getUltimoCobraAlquiler();
        } else {
            return this.banca;
        }
    }

    private void xestionarBancarrota(Jugador jugadorEnBancarrota) {
        this.jugadores.remove(jugadorEnBancarrota); //Remove xa verifica que este na lista

        if (this.jugadores.isEmpty()) {
            consola.imprimir("\nTodos os xogadores en bancarrota! Xogo rematado.");
            System.exit(0);
        }
        // Axustar o turno se é necesario
        if (this.turno >= this.jugadores.size()) {
            this.turno = 0;
        }

        // Se sólo queda un xogador, declaramos el ganador y terminamos
        if (this.jugadores.size() == 1) {
            Jugador ganador = this.jugadores.get(0); //O único xogador restante é o gañador
            consola.imprimir("\nO xogo rematou!");
            consola.imprimir("O gañador é " + ganador.getNombre() + " cunha fortuna de " + (int)ganador.getFortuna() + "€.");
            consola.imprimir("\nEstatísticas finais:");
            consola.imprimir(ganador.mostrarEstadisticas());
            System.exit(0);
        } else {
            consola.imprimir("Quedan " + this.jugadores.size() + " xogadores en xogo.\n");

            Jugador siguiente = this.jugadores.get(this.turno); // Obtenemos el nuevo jugador actual
            consola.imprimir("É o turno de: " + siguiente.getNombre() + "."); // Mostramos quién es el nuevo jugador
            consola.imprimir("Estado actual: " + siguiente); //toString creado en jugador
        }
    }

    private void estadisticasJuego() {
        consola.imprimir("{\n" +
                "casillaMasRentable: " + obtenerCasillaMasRentable() + ",\n" +
                "grupoMasRentable: " + obtenerGrupoMasRentable() + ",\n" +
                "casillaMasFrecuentada: " + obtenerCasillaMasFrecuentada() + ",\n" +
                "jugadorMasVueltas: " + obtenerJugadorMasVueltas() + ",\n" +
                "jugadorEnCabeza: " + obtenerJugadorEnCabeza() + "\n" +
                "}");
    }

    // Métodos auxiliares para estadísticas (implementación básica)
    private String obtenerCasillaMasRentable() {
        float maxRentabilidad = 0;
        String casillaMasRentable = "-";

        //Percorrer todas as casillas do taboleiro
        for (int lado = 0; lado < 4; lado++) {
            ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
            for (Casilla casilla : casillasLado) {
                if (casilla != null){
                    // A rentabilidade mídese polo total de alugueis cobrados
                    float rentabilidad = casilla.getTotalAlquileresCobrados();
                    if (rentabilidad > maxRentabilidad) {
                        maxRentabilidad = rentabilidad;
                        casillaMasRentable = casilla.getNombre();
                    }
                }
            }
        }
        return casillaMasRentable;
    }

    private String obtenerGrupoMasRentable() {
        //Map para almacenar a rentabilidade de cada grupo
        Map<String, Float> rentabilidadesGrupos = new HashMap<>();
        Map<String, String> nombresGrupos = new HashMap<>();

        // Percorrer todas as casillas do taboleiro
        for (int lado = 0; lado < 4; lado++) {
            ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
            for (Casilla casilla : casillasLado) {
                if (casilla != null && casilla.getGrupo() != null) {
                    String colorGrupo = casilla.getGrupo().getColorGrupo(); // Obtemos a color do grupo
                    float alquileresCobrados = casilla.getTotalAlquileresCobrados(); // Obtemos o total de alugueis cobrados na casilla

                    // Acumulamos a rentabilidade do grupo
                    rentabilidadesGrupos.put(colorGrupo, rentabilidadesGrupos.getOrDefault(colorGrupo, 0f) + alquileresCobrados); // Sumamos alugueis
                    nombresGrupos.put(colorGrupo, colorGrupo); // Gardamos o nome do grupo
                }
            }
        }
        //Encontrar o grupo con maior rentabilidade
        String grupoMasRentable = "-";
        float maxRentabilidad = 0;
        for (Map.Entry<String, Float> entrada : rentabilidadesGrupos.entrySet()) { // Percorremos as entradas do mapa
            if (entrada.getValue() > maxRentabilidad) { // Comprobamos si é a de mayor rentabilidade
                maxRentabilidad = entrada.getValue();
                grupoMasRentable = nombresGrupos.get(entrada.getKey());
            }
        }
        return grupoMasRentable;
    }

    private String obtenerCasillaMasFrecuentada() {
        int maxVeces = 0;
        String casillaMasFrecuentada = "-";

        // Percorrer todas as casillas do taboleiro
        for (int lado = 0; lado < 4; lado++) {
            ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
            for (Casilla casilla : casillasLado) {
                if (casilla != null && casilla.getVecesCaida() > maxVeces) { // Comprobamos si é a de mayor número de veces caídas
                    maxVeces = casilla.getVecesCaida();
                    casillaMasFrecuentada = casilla.getNombre();
                }
            }
        }
        return casillaMasFrecuentada;
    }

    private String obtenerJugadorMasVueltas() {
        int maxVueltas = 0;
        String jugadorMasVueltas = "-";

        for (Jugador j : jugadores) {
            if (j.getVueltas() > maxVueltas) { // Comprobamos si es el de mayor número de vueltas
                maxVueltas = j.getVueltas();
                jugadorMasVueltas = j.getNombre();
            }
        }
        return jugadorMasVueltas;
    }

    private String obtenerJugadorEnCabeza() {
        float maxFortuna = 0;
        String jugadorEnCabeza = "-";

        for (Jugador j : jugadores) {
            // Calcular fortuna total = diñeiro + valor propiedades + valor edificios
            float fortunaTotal = j.getFortuna();

            //sumar valor propiedades + edificios
            for (Casilla propiedad : j.getPropiedades()) {
                fortunaTotal += propiedad.getValor();
                Solar.DatosEdificios edificios = propiedad.getDatosedificios();
                if (edificios != null) {
                    Solar.DatosSolar datos = Solar.obtenerDatos(propiedad.getNombre());
                    if (datos != null) { // Sumamos o valor dos edificios
                        fortunaTotal += edificios.getNumCasas() * datos.getValorCasa();
                        fortunaTotal += edificios.getNumHoteles() * datos.getValorHotel();
                        fortunaTotal += edificios.getNumPiscinas() * datos.getValorPiscina();
                        fortunaTotal += edificios.getNumPistas() * datos.getValorPista();
                    }
                }
            }
            if (fortunaTotal > maxFortuna) { // Comprobamos si es el de mayor fortuna total
                maxFortuna = fortunaTotal;
                jugadorEnCabeza = j.getNombre();
            }
        }
        return jugadorEnCabeza;
    }

    public Tablero getTablero() {
        return this.tablero;
    }

    //Metodo estático para acceder á consola dende outras clases
    public static ConsolaNormal getConsola() {
        return consola;
    }
}