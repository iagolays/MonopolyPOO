package monopoly.cartas;

import partida.*;
import monopoly.*;
import monopoly.casillas.*;
import java.util.ArrayList;

public class Suerte extends Carta {

    private TipoAccion tipoAccion;

    public Suerte(String descripcion, int id, TipoAccion tipoAccion) {
        super(descripcion, id);
        this.tipoAccion = tipoAccion;
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero, ArrayList<Jugador> jugadores) {
        switch(tipoAccion) {
            case AVANZAR_SOLAR19:
                avanzarASolar19(jugador, tablero);
                break;
            case IR_CARCEL:
                irCarcel(jugador, tablero);
                break;
            case LOTERIA:
                ganarLoteria(jugador);
                break;
            case PAGAR_TODOS:
                pagarATodos(jugador, tablero, jugadores);
                break;
            case RETROCEDER3:
                retroceder3(jugador, tablero);
                break;
            case MULTA_MOVIL:
                multaMovil(jugador, tablero);
                break;
            case AVANZAR_TRANSPORTE:
                avanzarTransporte(jugador, tablero);
                break;
        }
    }

    private void avanzarASolar19(Jugador jugador, Tablero tablero) {
        jugador.getAvatar().moverAvatarHasta("Solar19", tablero.getCasillas(), tablero, true);
        monopoly.casillas.Casilla destino = tablero.encontrar_casilla("Solar19");
        if (destino != null) {
            try {
                destino.evaluarCasilla(jugador, tablero.getBanca(), 0, tablero, false);
            } catch (Exception e) {
                // Manejar excepción si es necesario
            }
        }
    }

    private void irCarcel(Jugador jugador, Tablero tablero) {
        monopoly.casillas.Casilla carcel = tablero.encontrar_casilla("Carcel");
        if (carcel != null) {
            jugador.encarcelar(tablero.getPosiciones(), tablero);
        }
    }

    private void ganarLoteria(Jugador jugador) {
        jugador.sumarFortuna(1000000);
        jugador.registrarPremio(1000000);
    }

    private void pagarATodos(Jugador pagador, Tablero tablero, ArrayList<Jugador> jugadores) {
        int numJugadoresAPagar = 0;
        for (Jugador j : jugadores) {
            if (j != pagador && !j.isEnBancarrota()) {
                numJugadoresAPagar++;
            }
        }

        float total = numJugadoresAPagar * 250000f;

        if (pagador.puedePagar(total)) {
            for (Jugador j : jugadores) {
                if (j != pagador && !j.isEnBancarrota()) {
                    pagador.pagarJugador(j, 250000f, tablero);
                }
            }
        } else {
            pagador.sumarFortuna(-total);
            // Notificar sobre deudas
            monopoly.Juego.getConsola().imprimir("\n" + pagador.getNombre() + " non pode pagar o imposto de " + (int)total + "€.");
            monopoly.Juego.getConsola().imprimir("Opcións dispoñibles:");
            monopoly.Juego.getConsola().imprimir("   - 'hipotecar <casilla>' para obter diñeiro");
            monopoly.Juego.getConsola().imprimir("   - 'acabar turno' para declararse en bancarrota");
            pagador.setUltimoCobraAlquiler(tablero.getBanca());
        }
    }

    private void retroceder3(Jugador jugador, Tablero tablero) {
        jugador.getAvatar().moverAvatar(tablero.getPosiciones(), -3, tablero, false);
    }

    private void multaMovil(Jugador jugador, Tablero tablero) {
        float multa = 150000f;
        if (jugador.puedePagar(multa)) {
            jugador.sumarFortuna(-multa);
            jugador.registrarTasa(multa);

            monopoly.casillas.Casilla parking = tablero.encontrar_casilla("Parking");
            if (parking != null) {
                parking.sumarValor(multa);
            }
        } else {
            jugador.sumarFortuna(-multa);
            // Notificar sobre deudas
            monopoly.Juego.getConsola().imprimir("\n" + jugador.getNombre() + " non pode pagar o imposto de " + (int)multa + "€.");
            monopoly.Juego.getConsola().imprimir("Opcións dispoñibles:");
            monopoly.Juego.getConsola().imprimir("   - 'hipotecar <casilla>' para obter diñeiro");
            monopoly.Juego.getConsola().imprimir("   - 'acabar turno' para declararse en bancarrota");
            jugador.setUltimoCobraAlquiler(tablero.getBanca());
        }
    }

    private void avanzarTransporte(Jugador jugador, Tablero tablero) {
        ArrayList<monopoly.casillas.Casilla> todasCasillas = tablero.CasillasLineales();
        monopoly.casillas.Casilla actual = jugador.getAvatar().getLugar();

        int posActual = todasCasillas.indexOf(actual);
        monopoly.casillas.Casilla destino = null;

        do {
            posActual = (posActual + 1) % todasCasillas.size();
            monopoly.casillas.Casilla casillaActual = todasCasillas.get(posActual);
            if (casillaActual instanceof Transporte) {
                destino = casillaActual;
                break;
            }
        } while (posActual != todasCasillas.indexOf(actual));

        if (destino != null) {
            jugador.getAvatar().moverAvatarHasta(destino.getNombre(), tablero.getCasillas(), tablero, false);
            try {
                destino.evaluarCasilla(jugador, tablero.getBanca(), 0, tablero, true);
            } catch (Exception e) {
                // Manejar excepción si es necesario
            }
        }
    }

    public enum TipoAccion {
        AVANZAR_SOLAR19,
        IR_CARCEL,
        LOTERIA,
        PAGAR_TODOS,
        RETROCEDER3,
        MULTA_MOVIL,
        AVANZAR_TRANSPORTE
    }

    public TipoAccion getTipoAccion() {
        return tipoAccion;
    }
}