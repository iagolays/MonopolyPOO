package monopoly.cartas;

import partida.*;
import monopoly.*;

public class CajaComunidad extends Carta {

    private TipoAccion tipoAccion;

    public CajaComunidad(String descripcion, int id, TipoAccion tipoAccion) {
        super(descripcion, id);
        this.tipoAccion = tipoAccion;
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero, java.util.ArrayList<Jugador> jugadores) {
        switch(tipoAccion) {
            case PAGAR_BALNEARIO:
                pagarBalneario(jugador, tablero);
                break;
            case IR_CARCEL_FRAUDE:
                irCarcelFraude(jugador, tablero);
                break;
            case IR_SALIDA:
                irSalida(jugador, tablero);
                break;
            case DEVOLUCION_FACENDA:
                devolucionFacenda(jugador);
                break;
            case RETROCEDER_SOLAR1:
                retrocederSolar1(jugador, tablero);
                break;
            case IR_SOLAR20:
                irSolar20(jugador, tablero);
                break;
        }
    }

    private void pagarBalneario(Jugador jugador, Tablero tablero) {
        float cantidad = 500000f;
        if (jugador.puedePagar(cantidad)) {
            jugador.sumarFortuna(-cantidad);
            jugador.registrarTasa(cantidad);

            monopoly.casillas.Casilla parking = tablero.encontrar_casilla("Parking");
            if (parking != null) {
                parking.sumarValor(cantidad);
            }
        } else {
            jugador.sumarFortuna(-cantidad);
            // Notificar sobre deudas
            monopoly.Juego.getConsola().imprimir("\n" + jugador.getNombre() + " non pode pagar o imposto de " + (int)cantidad + "€.");
            monopoly.Juego.getConsola().imprimir("Opcións dispoñibles:");
            monopoly.Juego.getConsola().imprimir("   - 'hipotecar <casilla>' para obter diñeiro");
            monopoly.Juego.getConsola().imprimir("   - 'acabar turno' para declararse en bancarrota");
            jugador.setUltimoCobraAlquiler(tablero.getBanca());
        }
    }

    private void irCarcelFraude(Jugador jugador, Tablero tablero) {
        monopoly.casillas.Casilla carcel = tablero.encontrar_casilla("Carcel");
        if (carcel != null) {
            jugador.encarcelar(tablero.getPosiciones(), tablero);
        }
    }

    private void irSalida(Jugador jugador, Tablero tablero) {
        monopoly.casillas.Casilla salida = tablero.encontrar_casilla("Salida");
        if (salida != null) {
            jugador.getAvatar().moverAvatarHasta("Salida", tablero.getCasillas(), tablero, true);
        }
    }

    private void devolucionFacenda(Jugador jugador) {
        float cantidad = 500000f;
        jugador.sumarFortuna(cantidad);
        jugador.registrarPremio(cantidad);
    }

    private void retrocederSolar1(Jugador jugador, Tablero tablero) {
        jugador.getAvatar().moverAvatarHasta("Solar1", tablero.getCasillas(), tablero, false);
    }

    private void irSolar20(Jugador jugador, Tablero tablero) {
        jugador.getAvatar().moverAvatarHasta("Solar20", tablero.getCasillas(), tablero, true);
    }

    public enum TipoAccion {
        PAGAR_BALNEARIO,
        IR_CARCEL_FRAUDE,
        IR_SALIDA,
        DEVOLUCION_FACENDA,
        RETROCEDER_SOLAR1,
        IR_SOLAR20
    }

    public TipoAccion getTipoAccion() {
        return tipoAccion;
    }
}