package monopoly.cartas;

import partida.Jugador;
import monopoly.Tablero;
import java.util.ArrayList;

public abstract class Carta {

    protected String descripcion; // Descrición da carta
    protected int id;             // Identificador único da carta

    //Constructor da carta.
    public Carta(String descripcion, int id) {
        this.descripcion = descripcion;
        this.id = id;
    }

    //Metodo abstracto que executa a acción da carta.
    public abstract void accion(Jugador jugador, Tablero tablero, ArrayList<Jugador> jugadores);

    public String getDescripcion() {
        return descripcion;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Carta #" + id + ": " + descripcion;
    }
}