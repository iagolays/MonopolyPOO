package monopoly.casillas;
import monopoly.*;
import partida.*;

import java.util.ArrayList;

public abstract class Propiedad extends Casilla {

    // Atributos comúns a todas as propiedades
    private float valor;
    private Jugador duenho;
    private boolean hipotecada;
    private float alquiler;

    // Constructor
    public Propiedad(String nombre, int posicion, Jugador duenho) {
        super(nombre, posicion);
        this.valor = calcularValor();
        this.duenho = duenho;
        this.hipotecada = false;
        this.alquiler = calcularAlquiler();
    }

    // Métodos abstractos específicos de propiedades
    public abstract float calcularAlquiler();
    public abstract float calcularValor();
    public abstract boolean estaHipotecada();
    public abstract boolean alquiler();
    protected abstract float calcularAlquilerConcreto(int tirada, Tablero tablero);

    // Métodos comunes para todas las propiedades
    public boolean perteneceAJugador(Jugador jugador) {
        return this.duenho != null && this.duenho.equals(jugador);
    }

    public void comprar(Jugador jugador) {
        if (jugador == null) return;

        if (this.duenho == null || "Banca".equals(this.duenho.getNombre())) {
            if (jugador.puedePagar(this.valor)) {
                jugador.sumarFortuna(-this.valor);
                jugador.sumarInversion(this.valor);
                this.duenho = jugador;
                jugador.anhadirPropiedad(this);
                Juego.getConsola().imprimir(jugador.getNombre() + " compra " + this.getNombre() + " por " + (int)this.valor + "€.");
            } else {
                Juego.getConsola().imprimir(jugador.getNombre() + " non ten diñeiro suficiente.");
            }
        } else {
            Juego.getConsola().imprimir("A propiedade xa ten dono.");
        }
    }

    public void hipotecar() {
        Juego.getConsola().imprimir(this.getNombre() + " non se puede hipotecar.");
    }

    public void deshipotecar() {
        Juego.getConsola().imprimir(this.getNombre() + " non se pode deshipotecar.");
    }

    // Getters y setters
    public Jugador getDuenho() {
        return duenho;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public void setDuenho(Jugador duenho) {
        this.duenho = duenho;
    }

    // Implementación de evaluarCasilla
    @Override
    public boolean evaluarCasilla(Jugador jugador, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta) {
        this.vecesCaida++;

        if (!alquiler() || duenho == null || jugador == null || jugador.equals(duenho)) {
            return true;
        }

        float cantidad = calcularAlquilerConcreto(tirada, tablero);
        if (cantidad <= 0) {
            return true;
        }

        boolean resultado = jugador.pagarJugador(duenho, cantidad, tablero);

        if (resultado) {
            sumarAlquilerCobrado(cantidad);
        }

        return resultado;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("nome: ").append(nombre).append(",\n");
        sb.append("posicion: ").append(posicion).append(",\n");
        sb.append("dono: ").append(duenho != null ? duenho.getNombre() : "Banca").append(",\n");
        sb.append("hipotecada: ").append(hipotecada).append(",\n");
        sb.append("valor: ").append((int) valor).append("\n");
        sb.append("}");
        return sb.toString();
    }

    // ========== IMPLEMENTACIÓN DE MÉTODOS ABSTRACTOS DE CASILLA ==========

    // Los siguientes métodos se implementarán en las subclases
    @Override
    public abstract String getTipo();

    @Override
    public abstract monopoly.casillas.Solar.DatosEdificios getDatosedificios();

    @Override
    public abstract Grupo getGrupo();

    @Override
    public abstract String infoCasilla();

    @Override
    public abstract ArrayList<String> getIdsEdificiosCasilla();

    @Override
    public abstract void anhadirIdEdificio(String idEdificio);

    @Override
    public abstract void eliminarIdEdificio(String idEdificio);
}