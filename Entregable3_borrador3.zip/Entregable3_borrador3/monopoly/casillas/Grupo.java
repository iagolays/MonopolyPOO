// Grupo.java - COMPLETA (sin cambios)
package monopoly.casillas;

import partida.Jugador;
import java.util.ArrayList;

public class Grupo {

    //Atributos
    private ArrayList<Solar> miembros; //Sólo los solares pueden ser miembros del grupo
    private String colorGrupo; //Color del grupo
    private int numCasillas; //Número de casillas del grupo.

    //Constructor vacío, crea un grupo sin casillas y sin color definida.
    public Grupo() {
        this.miembros = new ArrayList<>();
        this.colorGrupo = "";
        this.numCasillas = 0;
    }

    /*Constructor para cuando el grupo está formado por DOS SOLARES:
     * Requiere como parámetros los dos solares miembro y el color del grupo.
     */
    public Grupo(Solar sol1, Solar sol2, String colorGrupo) {
        this.miembros = new ArrayList<>();
        this.miembros.add(sol1);
        this.miembros.add(sol2);
        this.colorGrupo = colorGrupo;
        this.numCasillas = this.miembros.size();

        //Vinculamos cada solar con este grupo:
        sol1.setGrupo(this);
        sol2.setGrupo(this);
    }

    /*Constructor para cuando el grupo está formado por TRES SOLARES:
     * Requiere como parámetros los tres solares miembro y el color del grupo.
     */
    public Grupo(Solar sol1, Solar sol2, Solar sol3, String colorGrupo) {
        this.miembros = new ArrayList<>();
        this.miembros.add(sol1);
        this.miembros.add(sol2);
        this.miembros.add(sol3);
        this.colorGrupo = colorGrupo;
        this.numCasillas = this.miembros.size();

        //Vinculamos cada solar con este grupo:
        sol1.setGrupo(this);
        sol2.setGrupo(this);
        sol3.setGrupo(this);
    }

    /* Método que añade un solar al array de solares miembro de un grupo.
     * Parámetro: solar que se quiere añadir.
     */
    public void anhadirSolar(Solar solar) {
        if (solar != null && !miembros.contains(solar)) {
            this.miembros.add(solar);
            solar.setGrupo(this);
            this.numCasillas = miembros.size();
        }
    }

    /* Método que comprueba si el jugador pasado tiene en su haber todas las casillas del grupo:
     * Parámetro: jugador que se quiere evaluar.
     * Valor devuelto: true si es dueño de todas las casillas del grupo, false en otro caso.
     */
    public boolean esDuenhoGrupo(Jugador jugador) {
        if (jugador == null || this.miembros.isEmpty()) {
            return false;
        }

        for (Solar solar : this.miembros) {
            if (solar.getDuenho() != jugador) {
                return false;
            }
        }
        return true;
    }

    // ---------- Métodos auxiliares ----------

    // Método estático para calcular el color de un solar según su posición
    public static String calcularColor(Solar s) {
        int pos = s.getPosicion();
        final String RESET = "\u001B[0m";

        // Definición de colores ANSI para cada grupo
        final String MARRON = "\u001B[38;5;130m";
        final String AZUL_CL = "\u001B[36m";
        final String ROSA = "\u001B[35m";
        final String NARANJA = "\u001B[33m";
        final String ROJO = "\u001B[31m";
        final String AMARILLO = "\u001B[93m";
        final String VERDE = "\u001B[32m";
        final String AZUL_OSC = "\u001B[34m";

        // Asigna colores según la posición
        if (pos == 1 || pos == 3)
            return MARRON + s.getNombre() + RESET;
        if (pos == 6 || pos == 8 || pos == 9)
            return AZUL_CL + s.getNombre() + RESET;
        if (pos == 11 || pos == 13 || pos == 14)
            return ROSA + s.getNombre() + RESET;
        if (pos == 16 || pos == 18 || pos == 19)
            return NARANJA + s.getNombre() + RESET;
        if (pos == 21 || pos == 23 || pos == 24)
            return ROJO + s.getNombre() + RESET;
        if (pos == 26 || pos == 27 || pos == 29)
            return AMARILLO + s.getNombre() + RESET;
        if (pos == 31 || pos == 32 || pos == 34)
            return VERDE + s.getNombre() + RESET;
        if (pos == 37 || pos == 39)
            return AZUL_OSC + s.getNombre() + RESET;

        return s.getNombre(); // Si no es un solar o no pertenece a un grupo de color
    }

    // Obtén el código de color ANSI para este grupo
    public String obtenerColor() {
        switch (this.colorGrupo.toLowerCase()) {
            case "marrón":
            case "marron":
            case "brown":
                return "\u001B[38;5;130m";
            case "azul_claro":
            case "azul claro":
            case "light_blue":
                return "\u001B[36m";
            case "rosa":
            case "pink":
                return "\u001B[35m";
            case "naranja":
            case "orange":
                return "\u001B[33m";
            case "rojo":
            case "red":
                return "\u001B[31m";
            case "amarillo":
            case "yellow":
                return "\u001B[93m";
            case "verde":
            case "green":
                return "\u001B[32m";
            case "azul_oscuro":
            case "azul oscuro":
            case "dark blue":
                return "\u001B[34m";
            default:
                return "\u001B[97m";
        }
    }

    // Obtén información detallada del grupo para mostrar al usuario
    public String obtenerInfoEdificios() {
        StringBuilder info = new StringBuilder();
        boolean primerElemento = true;
        boolean hayPropiedades = false;

        for (Solar solar : miembros) {
            if (!primerElemento) {
                info.append(",\n");
            }
            primerElemento = false;
            hayPropiedades = true;
            Jugador duenho = solar.getDuenho();

            info.append("{\n");
            info.append("propiedad: ").append(solar.getNombre()).append(",\n");

            if (duenho != null) {
                // Hoteles
                info.append("hoteles: ");
                ArrayList<String> hotelesList = obtenerEdificiosTipo(solar, "hotel");
                info.append(hotelesList.isEmpty() ? "-" : hotelesList.toString()).append(",\n");

                // Casas
                info.append("casas: ");
                ArrayList<String> casasList = obtenerEdificiosTipo(solar, "casa");
                info.append(casasList.isEmpty() ? "-" : casasList.toString()).append(",\n");

                // Piscinas
                info.append("piscinas: ");
                ArrayList<String> piscinasList = obtenerEdificiosTipo(solar, "piscina");
                info.append(piscinasList.isEmpty() ? "-" : piscinasList.toString()).append(",\n");

                // Pistas de deporte
                info.append("pistasDeDeporte: ");
                ArrayList<String> pistasList = obtenerEdificiosTipo(solar, "pista");
                info.append(pistasList.isEmpty() ? "-" : pistasList.toString()).append(",\n");
            } else {
                info.append("hoteles: -,\n");
                info.append("casas: -,\n");
                info.append("piscinas: -,\n");
                info.append("pistasDeDeporte: -,\n");
            }
            float alquiler = Solar.calcularAlquiler(solar);
            info.append("alquiler: ").append((int) alquiler).append("\n");
            info.append("}");
        }

        if (!hayPropiedades) {
            return "Non hai solares neste grupo.";
        }

        info.append("\n").append(obtenerInfoConstruccionPosible());
        return info.toString();
    }

    // Método para obtener una lista de edificios de un tipo específico en una propiedad
    private ArrayList<String> obtenerEdificiosTipo(Solar solar, String tipo) {
        ArrayList<String> resultado = new ArrayList<>();
        for (String idEdificio : solar.getIdsEdificiosCasilla()) {
            if (idEdificio.startsWith(tipo + "-")) {
                resultado.add(idEdificio);
            }
        }
        return resultado;
    }

    // Obtén información sobre la construcción posible en este grupo
    public String obtenerInfoConstruccionPosible() {
        int casasDisponibles = 0;
        boolean puedeHotel = false;
        boolean puedePiscina = false;
        boolean puedePista = false;

        for (Solar solar : miembros) {
            Jugador duenho = solar.getDuenho();
            if (duenho != null) {
                monopoly.casillas.Solar.DatosEdificios edificios = solar.getDatosedificios();
                if (edificios != null) {
                    // Máx. 4 casas por solar
                    int restantes = 4 - edificios.getNumCasas();
                    if (restantes > 0 && Solar.PuedeConstruirSilencio(solar, duenho, 1, "casa")) {
                        casasDisponibles = Math.max(casasDisponibles, restantes);
                    }

                    if (!puedeHotel && Solar.PuedeConstruirSilencio(solar, duenho, 1, "hotel")) {
                        puedeHotel = true;
                    }
                    if (!puedePiscina && Solar.PuedeConstruirSilencio(solar, duenho, 1, "piscina")) {
                        puedePiscina = true;
                    }
                    if (!puedePista && Solar.PuedeConstruirSilencio(solar, duenho, 1, "pista")) {
                        puedePista = true;
                    }
                }
            }
        }

        // Crear el texto descriptivo final
        StringBuilder info = new StringBuilder();
        ArrayList<String> disponibles = new ArrayList<>();

        if (casasDisponibles > 0) {
            disponibles.add("ata " + casasDisponibles + " casas");
        }
        if (puedeHotel) {
            disponibles.add("un hotel");
        }
        if (puedePiscina) {
            disponibles.add("unha piscina");
        }
        if (puedePista) {
            disponibles.add("unha pista de deporte");
        }

        if (disponibles.isEmpty()) {
            info.append("Xa non se poden construír máis edificios neste grupo.");
        } else {
            info.append("Aínda se poden edificar ");
            for (int i = 0; i < disponibles.size(); i++) {
                info.append(disponibles.get(i));
                if (i < disponibles.size() - 2) {
                    info.append(", ");
                } else if (i == disponibles.size() - 2) {
                    info.append(" e ");
                }
            }
            info.append(".");
        }

        // Si no es posible construir porque no es dueño de todo el grupo
        if (!puedeHotel && !puedePiscina && !puedePista && casasDisponibles == 0) {
            info = new StringBuilder("Non é posible construír máis edificios neste grupo (non é dono de todas as propiedades do grupo ou xa están todas construídas).");
        }
        return info.toString();
    }

    // ---------- Getters ----------
    public String getColorGrupo() {
        return colorGrupo;
    }

    public ArrayList<Solar> getMiembros() {
        return miembros;
    }

    public int getNumCasillas() {
        return numCasillas;
    }

    // Representación en texto del grupo
    @Override
    public String toString() {
        return "Grupo{color='" + colorGrupo + "', casillas=" + numCasillas + "}";
    }
}