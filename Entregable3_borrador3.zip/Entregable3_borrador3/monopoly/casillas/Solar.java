
package monopoly.casillas;

import partida.*;
import monopoly.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

public class Solar extends Propiedad {

    private Grupo grupo;
    private Solar.DatosEdificios datosEdificios;
    private ArrayList<String> idsEdificiosCasilla;
    private boolean hipotecada;
    private float valorHipoteca;
    private float impuesto;
    private float valor; // Añadir este campo

    // Atributos estáticos para gestión de datos
    private static final Map<String, DatosSolar> DATOS_SOLARES = new HashMap<>();
    private static final ArrayList<String> idsEdificiosGlobal = new ArrayList<>();
    private static int contadorIdsCasas = 1;
    private static int contadorIdsHoteles = 1;
    private static int contadorIdsPiscinas = 1;
    private static int contadorIdsPistas = 1;

    // Clase interna para datos de solar
    public static class DatosSolar {
        private float precio;
        private float alquiler;
        private float valorCasa;
        private float valorHotel;
        private float valorPiscina;
        private float valorPista;
        private float alquilerCasa;
        private float alquilerHotel;
        private float alquilerPiscina;
        private float alquilerPista;

        public DatosSolar(float precio, float alquiler, float valorCasa, float valorHotel, float valorPiscina, float valorPista,
                          float alquilerCasa, float alquilerHotel, float alquilerPiscina, float alquilerPista) {
            this.precio = precio;
            this.alquiler = alquiler;
            this.valorCasa = valorCasa;
            this.valorHotel = valorHotel;
            this.valorPiscina = valorPiscina;
            this.valorPista = valorPista;
            this.alquilerCasa = alquilerCasa;
            this.alquilerHotel = alquilerHotel;
            this.alquilerPiscina = alquilerPiscina;
            this.alquilerPista = alquilerPista;
        }

        // Getters
        public float getPrecio() { return precio; }
        public float getAlquiler() { return alquiler; }
        public float getValorCasa() { return valorCasa; }
        public float getValorHotel() { return valorHotel; }
        public float getValorPiscina() { return valorPiscina; }
        public float getValorPista() { return valorPista; }
        public float getAlquilerCasa() { return alquilerCasa; }
        public float getAlquilerHotel() { return alquilerHotel; }
        public float getAlquilerPiscina() { return alquilerPiscina; }
        public float getAlquilerPista() { return alquilerPista; }
    }

    // Clase interna para datos de edificios
    public static class DatosEdificios {
        private int numCasas;
        private int numHoteles;
        private int numPiscinas;
        private int numPistas;
        private boolean tieneEdificios;

        public DatosEdificios() {
            this.numCasas = 0;
            this.numHoteles = 0;
            this.numPiscinas = 0;
            this.numPistas = 0;
            this.tieneEdificios = false;
        }

        // Getters
        public int getNumCasas() { return numCasas; }
        public int getNumHoteles() { return numHoteles; }
        public int getNumPiscinas() { return numPiscinas; }
        public int getNumPistas() { return numPistas; }
        public boolean isTieneEdificios() { return tieneEdificios; }

        public void actualizarEstadoEdificios() {
            this.tieneEdificios = (numCasas > 0 || numHoteles > 0 || numPiscinas > 0 || numPistas > 0);
        }

        // Setters
        public void setNumCasas(int numCasas) { this.numCasas = numCasas; }
        public void setNumHoteles(int numHoteles) { this.numHoteles = numHoteles; }
        public void setNumPiscinas(int numPiscinas) { this.numPiscinas = numPiscinas; }
        public void setNumPistas(int numPistas) { this.numPistas = numPistas; }
    }

    // Bloque estático para inicializar datos de todos los solares
    static {
        // Solar 1
        DATOS_SOLARES.put("solar1", new DatosSolar(Valor.SOLAR1_PRECIO, Valor.SOLAR1_ALQUILER, Valor.SOLAR1_PRECIO_CASA, Valor.SOLAR1_PRECIO_HOTEL,
                Valor.SOLAR1_PRECIO_PISCINA, Valor.SOLAR1_PRECIO_PISTA, Valor.SOLAR1_ALQUILER_CASA, Valor.SOLAR1_ALQUILER_HOTEL,
                Valor.SOLAR1_ALQUILER_PISCINA, Valor.SOLAR1_ALQUILER_PISTA));

        // Solar 2
        DATOS_SOLARES.put("solar2", new DatosSolar(Valor.SOLAR2_PRECIO, Valor.SOLAR2_ALQUILER, Valor.SOLAR2_PRECIO_CASA, Valor.SOLAR2_PRECIO_HOTEL,
                Valor.SOLAR2_PRECIO_PISCINA, Valor.SOLAR2_PRECIO_PISTA, Valor.SOLAR2_ALQUILER_CASA, Valor.SOLAR2_ALQUILER_HOTEL,
                Valor.SOLAR2_ALQUILER_PISCINA, Valor.SOLAR2_ALQUILER_PISTA));

        // Solar 3
        DATOS_SOLARES.put("solar3", new DatosSolar(Valor.SOLAR3_PRECIO, Valor.SOLAR3_ALQUILER, Valor.SOLAR3_PRECIO_CASA, Valor.SOLAR3_PRECIO_HOTEL,
                Valor.SOLAR3_PRECIO_PISCINA, Valor.SOLAR3_PRECIO_PISTA, Valor.SOLAR3_ALQUILER_CASA, Valor.SOLAR3_ALQUILER_HOTEL,
                Valor.SOLAR3_ALQUILER_PISCINA, Valor.SOLAR3_ALQUILER_PISTA));

        // Solar 4
        DATOS_SOLARES.put("solar4", new DatosSolar(Valor.SOLAR4_PRECIO, Valor.SOLAR4_ALQUILER, Valor.SOLAR4_PRECIO_CASA, Valor.SOLAR4_PRECIO_HOTEL,
                Valor.SOLAR4_PRECIO_PISCINA, Valor.SOLAR4_PRECIO_PISTA, Valor.SOLAR4_ALQUILER_CASA, Valor.SOLAR4_ALQUILER_HOTEL,
                Valor.SOLAR4_ALQUILER_PISCINA, Valor.SOLAR4_ALQUILER_PISTA));

        // Solar 5
        DATOS_SOLARES.put("solar5", new DatosSolar(Valor.SOLAR5_PRECIO, Valor.SOLAR5_ALQUILER, Valor.SOLAR5_PRECIO_CASA, Valor.SOLAR5_PRECIO_HOTEL,
                Valor.SOLAR5_PRECIO_PISCINA, Valor.SOLAR5_PRECIO_PISTA, Valor.SOLAR5_ALQUILER_CASA, Valor.SOLAR5_ALQUILER_HOTEL,
                Valor.SOLAR5_ALQUILER_PISCINA, Valor.SOLAR5_ALQUILER_PISTA));

        // Solar 6
        DATOS_SOLARES.put("solar6", new DatosSolar(Valor.SOLAR6_PRECIO, Valor.SOLAR6_ALQUILER, Valor.SOLAR6_PRECIO_CASA, Valor.SOLAR6_PRECIO_HOTEL,
                Valor.SOLAR6_PRECIO_PISCINA, Valor.SOLAR6_PRECIO_PISTA, Valor.SOLAR6_ALQUILER_CASA, Valor.SOLAR6_ALQUILER_HOTEL,
                Valor.SOLAR6_ALQUILER_PISCINA, Valor.SOLAR6_ALQUILER_PISTA));

        // Solar 7
        DATOS_SOLARES.put("solar7", new DatosSolar(Valor.SOLAR7_PRECIO, Valor.SOLAR7_ALQUILER, Valor.SOLAR7_PRECIO_CASA, Valor.SOLAR7_PRECIO_HOTEL,
                Valor.SOLAR7_PRECIO_PISCINA, Valor.SOLAR7_PRECIO_PISTA, Valor.SOLAR7_ALQUILER_CASA, Valor.SOLAR7_ALQUILER_HOTEL,
                Valor.SOLAR7_ALQUILER_PISCINA, Valor.SOLAR7_ALQUILER_PISTA));

        // Solar 8
        DATOS_SOLARES.put("solar8", new DatosSolar(Valor.SOLAR8_PRECIO, Valor.SOLAR8_ALQUILER, Valor.SOLAR8_PRECIO_CASA, Valor.SOLAR8_PRECIO_HOTEL,
                Valor.SOLAR8_PRECIO_PISCINA, Valor.SOLAR8_PRECIO_PISTA, Valor.SOLAR8_ALQUILER_CASA, Valor.SOLAR8_ALQUILER_HOTEL,
                Valor.SOLAR8_ALQUILER_PISCINA, Valor.SOLAR8_ALQUILER_PISTA));

        // Solar 9
        DATOS_SOLARES.put("solar9", new DatosSolar(Valor.SOLAR9_PRECIO, Valor.SOLAR9_ALQUILER, Valor.SOLAR9_PRECIO_CASA, Valor.SOLAR9_PRECIO_HOTEL,
                Valor.SOLAR9_PRECIO_PISCINA, Valor.SOLAR9_PRECIO_PISTA, Valor.SOLAR9_ALQUILER_CASA, Valor.SOLAR9_ALQUILER_HOTEL,
                Valor.SOLAR9_ALQUILER_PISCINA, Valor.SOLAR9_ALQUILER_PISTA));

        // Solar 10
        DATOS_SOLARES.put("solar10", new DatosSolar(Valor.SOLAR10_PRECIO, Valor.SOLAR10_ALQUILER, Valor.SOLAR10_PRECIO_CASA, Valor.SOLAR10_PRECIO_HOTEL,
                Valor.SOLAR10_PRECIO_PISCINA, Valor.SOLAR10_PRECIO_PISTA, Valor.SOLAR10_ALQUILER_CASA, Valor.SOLAR10_ALQUILER_HOTEL,
                Valor.SOLAR10_ALQUILER_PISCINA, Valor.SOLAR10_ALQUILER_PISTA));

        // Solar 11
        DATOS_SOLARES.put("solar11", new DatosSolar(Valor.SOLAR11_PRECIO, Valor.SOLAR11_ALQUILER, Valor.SOLAR11_PRECIO_CASA, Valor.SOLAR11_PRECIO_HOTEL,
                Valor.SOLAR11_PRECIO_PISCINA, Valor.SOLAR11_PRECIO_PISTA, Valor.SOLAR11_ALQUILER_CASA, Valor.SOLAR11_ALQUILER_HOTEL,
                Valor.SOLAR11_ALQUILER_PISCINA, Valor.SOLAR11_ALQUILER_PISTA));

        // Solar 12
        DATOS_SOLARES.put("solar12", new DatosSolar(Valor.SOLAR12_PRECIO, Valor.SOLAR12_ALQUILER, Valor.SOLAR12_PRECIO_CASA, Valor.SOLAR12_PRECIO_HOTEL,
                Valor.SOLAR12_PRECIO_PISCINA, Valor.SOLAR12_PRECIO_PISTA, Valor.SOLAR12_ALQUILER_CASA, Valor.SOLAR12_ALQUILER_HOTEL,
                Valor.SOLAR12_ALQUILER_PISCINA, Valor.SOLAR12_ALQUILER_PISTA));

        // Solar 13
        DATOS_SOLARES.put("solar13", new DatosSolar(Valor.SOLAR13_PRECIO, Valor.SOLAR13_ALQUILER, Valor.SOLAR13_PRECIO_CASA, Valor.SOLAR13_PRECIO_HOTEL,
                Valor.SOLAR13_PRECIO_PISCINA, Valor.SOLAR13_PRECIO_PISTA, Valor.SOLAR13_ALQUILER_CASA, Valor.SOLAR13_ALQUILER_HOTEL,
                Valor.SOLAR13_ALQUILER_PISCINA, Valor.SOLAR13_ALQUILER_PISTA));

        // Solar 14
        DATOS_SOLARES.put("solar14", new DatosSolar(Valor.SOLAR14_PRECIO, Valor.SOLAR14_ALQUILER, Valor.SOLAR14_PRECIO_CASA, Valor.SOLAR14_PRECIO_HOTEL,
                Valor.SOLAR14_PRECIO_PISCINA, Valor.SOLAR14_PRECIO_PISTA, Valor.SOLAR14_ALQUILER_CASA, Valor.SOLAR14_ALQUILER_HOTEL,
                Valor.SOLAR14_ALQUILER_PISCINA, Valor.SOLAR14_ALQUILER_PISTA));

        // Solar 15
        DATOS_SOLARES.put("solar15", new DatosSolar(Valor.SOLAR15_PRECIO, Valor.SOLAR15_ALQUILER, Valor.SOLAR15_PRECIO_CASA, Valor.SOLAR15_PRECIO_HOTEL,
                Valor.SOLAR15_PRECIO_PISCINA, Valor.SOLAR15_PRECIO_PISTA, Valor.SOLAR15_ALQUILER_CASA, Valor.SOLAR15_ALQUILER_HOTEL,
                Valor.SOLAR15_ALQUILER_PISCINA, Valor.SOLAR15_ALQUILER_PISTA));

        // Solar 16
        DATOS_SOLARES.put("solar16", new DatosSolar(Valor.SOLAR16_PRECIO, Valor.SOLAR16_ALQUILER, Valor.SOLAR16_PRECIO_CASA, Valor.SOLAR16_PRECIO_HOTEL,
                Valor.SOLAR16_PRECIO_PISCINA, Valor.SOLAR16_PRECIO_PISTA, Valor.SOLAR16_ALQUILER_CASA, Valor.SOLAR16_ALQUILER_HOTEL,
                Valor.SOLAR16_ALQUILER_PISCINA, Valor.SOLAR16_ALQUILER_PISTA));

        // Solar 17
        DATOS_SOLARES.put("solar17", new DatosSolar(Valor.SOLAR17_PRECIO, Valor.SOLAR17_ALQUILER, Valor.SOLAR17_PRECIO_CASA, Valor.SOLAR17_PRECIO_HOTEL,
                Valor.SOLAR17_PRECIO_PISCINA, Valor.SOLAR17_PRECIO_PISTA, Valor.SOLAR17_ALQUILER_CASA, Valor.SOLAR17_ALQUILER_HOTEL,
                Valor.SOLAR17_ALQUILER_PISCINA, Valor.SOLAR17_ALQUILER_PISTA));

        // Solar 18
        DATOS_SOLARES.put("solar18", new DatosSolar(Valor.SOLAR18_PRECIO, Valor.SOLAR18_ALQUILER, Valor.SOLAR18_PRECIO_CASA, Valor.SOLAR18_PRECIO_HOTEL,
                Valor.SOLAR18_PRECIO_PISCINA, Valor.SOLAR18_PRECIO_PISTA, Valor.SOLAR18_ALQUILER_CASA, Valor.SOLAR18_ALQUILER_HOTEL,
                Valor.SOLAR18_ALQUILER_PISCINA, Valor.SOLAR18_ALQUILER_PISTA));

        // Solar 19
        DATOS_SOLARES.put("solar19", new DatosSolar(Valor.SOLAR19_PRECIO, Valor.SOLAR19_ALQUILER, Valor.SOLAR19_PRECIO_CASA, Valor.SOLAR19_PRECIO_HOTEL,
                Valor.SOLAR19_PRECIO_PISCINA, Valor.SOLAR19_PRECIO_PISTA, Valor.SOLAR19_ALQUILER_CASA, Valor.SOLAR19_ALQUILER_HOTEL,
                Valor.SOLAR19_ALQUILER_PISCINA, Valor.SOLAR19_ALQUILER_PISTA));

        // Solar 20
        DATOS_SOLARES.put("solar20", new DatosSolar(Valor.SOLAR20_PRECIO, Valor.SOLAR20_ALQUILER, Valor.SOLAR20_PRECIO_CASA, Valor.SOLAR20_PRECIO_HOTEL,
                Valor.SOLAR20_PRECIO_PISCINA, Valor.SOLAR20_PRECIO_PISTA, Valor.SOLAR20_ALQUILER_CASA, Valor.SOLAR20_ALQUILER_HOTEL,
                Valor.SOLAR20_ALQUILER_PISCINA, Valor.SOLAR20_ALQUILER_PISTA));

        // Solar 21
        DATOS_SOLARES.put("solar21", new DatosSolar(Valor.SOLAR21_PRECIO, Valor.SOLAR21_ALQUILER, Valor.SOLAR21_PRECIO_CASA, Valor.SOLAR21_PRECIO_HOTEL,
                Valor.SOLAR21_PRECIO_PISCINA, Valor.SOLAR21_PRECIO_PISTA, Valor.SOLAR21_ALQUILER_CASA, Valor.SOLAR21_ALQUILER_HOTEL,
                Valor.SOLAR21_ALQUILER_PISCINA, Valor.SOLAR21_ALQUILER_PISTA));

        // Solar 22
        DATOS_SOLARES.put("solar22", new DatosSolar(Valor.SOLAR22_PRECIO, Valor.SOLAR22_ALQUILER, Valor.SOLAR22_PRECIO_CASA, Valor.SOLAR22_PRECIO_HOTEL,
                Valor.SOLAR22_PRECIO_PISCINA, Valor.SOLAR22_PRECIO_PISTA, Valor.SOLAR22_ALQUILER_CASA, Valor.SOLAR22_ALQUILER_HOTEL,
                Valor.SOLAR22_ALQUILER_PISCINA, Valor.SOLAR22_ALQUILER_PISTA));
    }

    //Constructor
    public Solar(String nombre, int posicion, float valor, Jugador duenho) {
        super(nombre, posicion, duenho);
        this.valor = valor;
        this.grupo = null;
        this.datosEdificios = new DatosEdificios();
        this.idsEdificiosCasilla = new ArrayList<>();
        this.hipotecada = false;
        this.valorHipoteca = valor / 2;
        this.impuesto = obtenerAlquiler(nombre);
    }

    // ========== MÉTODOS ESTÁTICOS (antes en Solares) ==========

    public static DatosSolar obtenerDatos(String nombreSolar) {
        return DATOS_SOLARES.get(nombreSolar.toLowerCase());
    }

    public static float obtenerPrecio(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.getPrecio() : 0;
    }

    public static float obtenerAlquiler(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.getAlquiler() : 0;
    }

    public static float obtenerPrecioCasa(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.getValorCasa() : 0;
    }

    public static float obtenerPrecioHotel(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.getValorHotel() : 0;
    }

    public static float obtenerPrecioPiscina(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.getValorPiscina() : 0;
    }

    public static float obtenerPrecioPista(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.getValorPista() : 0;
    }

    public static float calcularAlquiler(Casilla casilla) {
        DatosSolar datos = obtenerDatos(casilla.getNombre());
        if (datos == null) {
            return 0;
        }

        Solar.DatosEdificios edificios = casilla.getDatosedificios();
        float alquilerTotal = datos.getAlquiler();

        if (edificios != null) {
            alquilerTotal += edificios.getNumCasas() * datos.getAlquilerCasa();
            alquilerTotal += edificios.getNumHoteles() * datos.getAlquilerHotel();
            alquilerTotal += edificios.getNumPiscinas() * datos.getAlquilerPiscina();
            alquilerTotal += edificios.getNumPistas() * datos.getAlquilerPista();
        }
        return alquilerTotal;
    }

    public static boolean PuedeConstruir(Casilla casilla, Jugador jugador, String tipo) {
        // Comprobar si la casilla o alguna del grupo está hipotecada
        if (casilla.isHipotecada()) {
            Juego.getConsola().imprimir("Non se pode construír en " + casilla.getNombre() + " porque está hipotecada.");
            return false;
        }

        Grupo grupo = casilla.getGrupo();
        if (grupo != null) {
            for (Casilla c : grupo.getMiembros()) {
                if (c.isHipotecada()) {
                    Juego.getConsola().imprimir("Non se pode construír en " + casilla.getNombre() + " porque algunha casilla do grupo está hipotecada.");
                    return false;
                }
            }
        }

        if (casilla.getDuenho() == null || !casilla.getDuenho().equals(jugador)) {
            Juego.getConsola().imprimir("Non se pode construír en " + casilla.getNombre() + " porque " + jugador.getNombre() + " non é o propietario da casilla.");
            return false;
        }

        if (jugador.getAvatar() != null && jugador.getAvatar().getLugar() != casilla) {
            Juego.getConsola().imprimir("Non se pode construír en " + casilla.getNombre() + " porque " + jugador.getNombre() + " non está nesa casilla.");
            return false;
        }

        if (casilla.getGrupo() == null || !casilla.getGrupo().esDuenhoGrupo(jugador)) {
            Juego.getConsola().imprimir("Non se pode construír en " + casilla.getNombre() + " porque " + jugador.getNombre() + " non posúe todo o grupo.");
            return false;
        }

        Solar.DatosEdificios edificios = casilla.getDatosedificios();
        if (edificios == null) {
            return false;
        }

        switch (tipo.toLowerCase()) {
            case "casa":
                if (edificios.getNumCasas() + 1 > 4) {
                    Juego.getConsola().imprimir("Non se poden construír máis de 4 casas en " + casilla.getNombre() + ".");
                    return false;
                }
                if (edificios.getNumHoteles() >= 1) {
                    Juego.getConsola().imprimir("Non se poden construír casas en " + casilla.getNombre() + " porque xa hai un hotel construído.");
                    return false;
                }
                break;
            case "hotel":
                if (edificios.getNumCasas() < 4) {
                    Juego.getConsola().imprimir("Non se pode construír un hotel en " + casilla.getNombre() + " porque non hai 4 casas construídas.");
                    return false;
                }
                if (edificios.getNumHoteles() >= 1) {
                    Juego.getConsola().imprimir("Non se poden construír máis de 1 hotel en " + casilla.getNombre() + ".");
                    return false;
                }
                break;
            case "piscina":
                if (edificios.getNumHoteles() < 1) {
                    Juego.getConsola().imprimir("Non se pode construír unha piscina en " + casilla.getNombre() + " porque non hai ningún hotel construído.");
                    return false;
                }
                if (edificios.getNumPiscinas() >= 1) {
                    Juego.getConsola().imprimir("Non se poden construír máis de 1 piscina en " + casilla.getNombre() + ".");
                    return false;
                }
                break;
            case "pista":
                if (edificios.getNumHoteles() < 1) {
                    Juego.getConsola().imprimir("Non se pode construír unha pista de deporte en " + casilla.getNombre() + " porque non hai ningún hotel construído.");
                    return false;
                }
                if (edificios.getNumPiscinas() < 1) {
                    Juego.getConsola().imprimir("Non se pode construír unha pista de deporte en " + casilla.getNombre() + " porque non hai ningunha piscina construída.");
                    return false;
                }
                if (edificios.getNumPistas() >= 1) {
                    Juego.getConsola().imprimir("Non se poden construír máis de unha pista de deporte en " + casilla.getNombre() + ".");
                    return false;
                }
                break;
            default:
                Juego.getConsola().imprimir("Tipo de edificio descoñecido: " + tipo);
                return false;
        }
        return true;
    }

    public static boolean PuedeConstruirSilencio(Casilla casilla, Jugador jugador, int cantidad, String tipo) {
        // Comprobar si la casilla o alguna del grupo está hipotecada
        if (casilla.isHipotecada()) {
            return false;
        }

        Grupo grupo = casilla.getGrupo();
        if (grupo != null) {
            for (Casilla c : grupo.getMiembros()) {
                if (c.isHipotecada()) {
                    return false;
                }
            }
        }

        if (casilla.getDuenho() == null || !casilla.getDuenho().equals(jugador) ||
                casilla.getGrupo() == null || !casilla.getGrupo().esDuenhoGrupo(jugador)) {
            return false;
        }

        if (jugador.getAvatar() != null && jugador.getAvatar().getLugar() != casilla) {
            return false;
        }

        Solar.DatosEdificios edificios = casilla.getDatosedificios();
        if (edificios == null) {
            return false;
        }

        switch (tipo.toLowerCase()) {
            case "casa":
                if (edificios.getNumCasas() + cantidad > 4 || edificios.getNumHoteles() >= 1) {
                    return false;
                }
                break;
            case "hotel":
                if (edificios.getNumCasas() < 4 || edificios.getNumHoteles() >= 1) {
                    return false;
                }
                break;
            case "piscina":
                if (edificios.getNumHoteles() < 1 || edificios.getNumPiscinas() >= 1) {
                    return false;
                }
                break;
            case "pista":
                if (edificios.getNumHoteles() < 1 || edificios.getNumPiscinas() < 1 || edificios.getNumPistas() >= 1) {
                    return false;
                }
                break;
            default:
                return false;
        }
        return true;
    }

    public static boolean construirEdificio(Casilla casilla, Jugador jugador, String tipo) {
        if (!PuedeConstruir(casilla, jugador, tipo)) {
            return false;
        }

        DatosSolar datos = obtenerDatos(casilla.getNombre());
        Solar.DatosEdificios edificios = casilla.getDatosedificios();
        float costeTotal;

        switch (tipo.toLowerCase()) {
            case "casa":
                costeTotal = datos.getValorCasa();
                if (!jugador.puedePagar(costeTotal)) {
                    Juego.getConsola().imprimir("A fortuna de " + jugador.getNombre() + " non é suficiente para construír unha casa en " + casilla.getNombre() + ".");
                    return false;
                }
                String idCasa = generarIdEdificio("casa", jugador.getEdificios());
                jugador.anhadirEdificio(idCasa);
                casilla.anhadirIdEdificio(idCasa);
                edificios.setNumCasas(edificios.getNumCasas() + 1);
                break;
            case "hotel":
                costeTotal = datos.getValorHotel();
                if (!jugador.puedePagar(costeTotal)) {
                    Juego.getConsola().imprimir("A fortuna de " + jugador.getNombre() + " non é suficiente para construír un hotel en " + casilla.getNombre() + ".");
                    return false;
                }
                String idHotel = generarIdEdificio("hotel", jugador.getEdificios());
                jugador.anhadirEdificio(idHotel);
                casilla.anhadirIdEdificio(idHotel);
                edificios.setNumHoteles(edificios.getNumHoteles() + 1);

                // Eliminar las casas una vez construido el hotel
                int casasEliminadas = 0;
                ArrayList<String> edificiosAEliminar = new ArrayList<>();
                for (String id : casilla.getIdsEdificiosCasilla()) {
                    if (id.startsWith("casa-") && casasEliminadas < 4) {
                        edificiosAEliminar.add(id);
                        casasEliminadas++;
                    }
                }
                for (String id : edificiosAEliminar) {
                    jugador.eliminarEdificio(id);
                    casilla.eliminarIdEdificio(id);
                }
                edificios.setNumCasas(0);
                break;
            case "piscina":
                costeTotal = datos.getValorPiscina();
                if (!jugador.puedePagar(costeTotal)) {
                    Juego.getConsola().imprimir("A fortuna de " + jugador.getNombre() + " non é suficiente para construír unha piscina en " + casilla.getNombre() + ".");
                    return false;
                }
                String idPiscina = generarIdEdificio("piscina", jugador.getEdificios());
                jugador.anhadirEdificio(idPiscina);
                casilla.anhadirIdEdificio(idPiscina);
                edificios.setNumPiscinas(edificios.getNumPiscinas() + 1);
                break;
            case "pista":
                costeTotal = datos.getValorPista();
                if (!jugador.puedePagar(costeTotal)) {
                    Juego.getConsola().imprimir("A fortuna de " + jugador.getNombre() + " non é suficiente para construír unha pista de deporte en " + casilla.getNombre() + ".");
                    return false;
                }
                String idPista = generarIdEdificio("pista", jugador.getEdificios());
                jugador.anhadirEdificio(idPista);
                casilla.anhadirIdEdificio(idPista);
                edificios.setNumPistas(edificios.getNumPistas() + 1);
                break;
            default:
                Juego.getConsola().imprimir("Tipo de edificio descoñecido: " + tipo + ".");
                return false;
        }

        jugador.sumarFortuna(-costeTotal);
        jugador.sumarInversion(costeTotal);
        edificios.actualizarEstadoEdificios();

        Juego.getConsola().imprimir("Constrúese un " + tipo + " en " + casilla.getNombre() + ". A fortuna de " + jugador.getNombre() + " é " + (int) jugador.getFortuna() + "€.");
        return true;
    }

    public static boolean venderEdificio(Casilla casilla, Jugador jugador, String tipo, int cantidad) {
        if (!casilla.getDuenho().equals(jugador)) {
            Juego.getConsola().imprimir("Non se pode vender " + casilla.getNombre() + " porque " + jugador.getNombre() + " non é o propietario da casilla.");
            return false;
        }

        DatosSolar datos = obtenerDatos(casilla.getNombre());
        Solar.DatosEdificios edificios = casilla.getDatosedificios();
        ArrayList<String> idsCasilla = casilla.getIdsEdificiosCasilla();
        float ingresoTotal;
        int cantidadVendida;

        switch (tipo.toLowerCase()) {
            case "casa":
                if (edificios.getNumCasas() < cantidad) {
                    Juego.getConsola().imprimir("Non se poden vender " + cantidad + " casas en " + casilla.getNombre() + " porque só hai " + edificios.getNumCasas() + " casas construídas.");
                    return false;
                }
                ingresoTotal = datos.getValorCasa() * cantidad;
                edificios.setNumCasas(edificios.getNumCasas() - cantidad);
                cantidadVendida = cantidad;

                Iterator<String> iteratorCasas = idsCasilla.iterator();
                int casasEliminadas = 0;
                while (iteratorCasas.hasNext() && casasEliminadas < cantidad) {
                    String id = iteratorCasas.next();
                    if (id.startsWith("casa-")) {
                        jugador.eliminarEdificio(id);
                        iteratorCasas.remove();
                        casasEliminadas++;
                    }
                }
                break;

            case "hotel":
                if (edificios.getNumHoteles() < 1) {
                    Juego.getConsola().imprimir("Non se pode vender un hotel en " + casilla.getNombre() + " porque non hai ningún hotel construído.");
                    return false;
                }
                ingresoTotal = datos.getValorHotel();
                edificios.setNumHoteles(edificios.getNumHoteles() - 1);
                cantidadVendida = 1;

                Iterator<String> iteratorHotel = idsCasilla.iterator();
                while (iteratorHotel.hasNext()) {
                    String id = iteratorHotel.next();
                    if (id.startsWith("hotel-")) {
                        jugador.eliminarEdificio(id);
                        iteratorHotel.remove();
                        break;
                    }
                }
                break;

            case "piscina":
                if (edificios.getNumPiscinas() < 1) {
                    Juego.getConsola().imprimir("Non se pode vender unha piscina en " + casilla.getNombre() + " porque non hai ningunha piscina construída.");
                    return false;
                }
                ingresoTotal = datos.getValorPiscina();
                edificios.setNumPiscinas(edificios.getNumPiscinas() - 1);
                cantidadVendida = 1;

                Iterator<String> iteratorPiscina = idsCasilla.iterator();
                while (iteratorPiscina.hasNext()) {
                    String id = iteratorPiscina.next();
                    if (id.startsWith("piscina-")) {
                        jugador.eliminarEdificio(id);
                        iteratorPiscina.remove();
                        break;
                    }
                }
                break;

            case "pista":
                if (edificios.getNumPistas() < 1) {
                    Juego.getConsola().imprimir("Non se pode vender unha pista de deporte en " + casilla.getNombre() + " porque non hai ningunha pista construída.");
                    return false;
                }
                ingresoTotal = datos.getValorPista();
                edificios.setNumPistas(edificios.getNumPistas() - 1);
                cantidadVendida = 1;

                Iterator<String> iteratorPista = idsCasilla.iterator();
                while (iteratorPista.hasNext()) {
                    String id = iteratorPista.next();
                    if (id.startsWith("pista-")) {
                        jugador.eliminarEdificio(id);
                        iteratorPista.remove();
                        break;
                    }
                }
                break;

            default:
                Juego.getConsola().imprimir("Tipo de edificio descoñecido: " + tipo + ".");
                return false;
        }

        jugador.sumarFortuna(ingresoTotal);
        jugador.sumarInversion(ingresoTotal);
        edificios.actualizarEstadoEdificios();

        String mensaje = jugador.getNombre() + " vendéronse " + cantidadVendida + " " + tipo;
        if (cantidadVendida > 1) {
            mensaje += "s";
        }
        mensaje += " en " + casilla.getNombre() + ", recibindo " + (int) ingresoTotal + "€.";

        if ("casa".equalsIgnoreCase(tipo) && edificios.getNumCasas() > 0) {
            mensaje += " Na propiedade queda " + edificios.getNumCasas() + " casa(s).";
        }

        Juego.getConsola().imprimir(mensaje);
        return true;
    }

    public static String generarIdEdificio(String tipo, ArrayList<String> idsExistentes) {
        String nuevoId;

        do {
            switch (tipo.toLowerCase()) {
                case "casa":
                    nuevoId = tipo.toLowerCase() + "-" + contadorIdsCasas;
                    contadorIdsCasas++;
                    break;
                case "hotel":
                    nuevoId = tipo.toLowerCase() + "-" + contadorIdsHoteles;
                    contadorIdsHoteles++;
                    break;
                case "piscina":
                    nuevoId = tipo.toLowerCase() + "-" + contadorIdsPiscinas;
                    contadorIdsPiscinas++;
                    break;
                case "pista":
                    nuevoId = tipo.toLowerCase() + "-" + contadorIdsPistas;
                    contadorIdsPistas++;
                    break;
                default:
                    Juego.getConsola().imprimir("Tipo de edificio descoñecido para xerar ID: " + tipo);
                    return null;
            }
        } while (idsExistentes.contains(nuevoId) || idsEdificiosGlobal.contains(nuevoId));

        idsExistentes.add(nuevoId);
        idsEdificiosGlobal.add(nuevoId);

        return nuevoId;
    }

    public static String generarInfoEdificio(String id, Jugador propietario, Casilla casilla, float coste) {
        return "{\n" +
                "id: " + id + ",\n" +
                "propietario: " + propietario.getNombre() + ",\n" +
                "casilla: " + casilla.getNombre() + ",\n" +
                "grupo: " + (casilla.getGrupo() != null ? casilla.getGrupo().getColorGrupo() : "-") + ",\n" +
                "coste: " + (int)coste + "\n" +
                "}";
    }

    // ========== MÉTODOS DE INSTANCIA ==========

    @Override
    public String getTipo() {
        return "solar";
    }

    @Override
    public void comprarCasilla(Jugador solicitante, Jugador banca) {
        Jugador duenhoActual = getDuenho();  // Usar getter en lugar de this.duenho
        float valorPropiedad = getValor();   // Usar getter en lugar de this.valor

        if (duenhoActual == null || duenhoActual == banca) {
            if (solicitante.puedePagar(valorPropiedad)) {
                solicitante.sumarFortuna(-valorPropiedad);
                solicitante.sumarInversion(valorPropiedad);
                setDuenho(solicitante);  // Usar setter
                solicitante.anhadirPropiedad(this);

                Juego.getConsola().imprimir("O xogador " + solicitante.getNombre() + " compra a Casilla " + this.getNombre() + " por " + (int)valorPropiedad + "€. A súa fortuna actual é " + (int)solicitante.getFortuna() + "€.");
            } else {
                Juego.getConsola().imprimir(solicitante.getNombre() + " non ten diñeiro suficiente para comprar " + this.getNombre() + ".");
            }
        } else {
            Juego.getConsola().imprimir("A Casilla " + this.getNombre() + " xa ten dono: " + duenhoActual.getNombre());
        }
    }

    @Override
    public String casEnVenta() {
        Jugador duenhoActual = getDuenho();
        if ((duenhoActual == null || "Banca".equalsIgnoreCase(duenhoActual.getNombre())) && "solar".equalsIgnoreCase(getTipo())) {
            return "{\n" + "nome: " + this.getNombre() + ",\n" + "tipo: " + this.getTipo() +
                    (grupo != null ? ",\ngrupo: " + grupo.getColorGrupo() : "") +
                    ",\nvalor: " + (int)getValor() + "\n" +"}";
        }
        return "";
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta) {
        Jugador duenhoActual = getDuenho();

        // 1) Se non ten dono ou pertence á banca
        if (duenhoActual == null || duenhoActual == banca) {
            float precioCompra = obtenerPrecio(getNombre());
            Juego.getConsola().imprimir("O solar está dispoñible para comprar por " + (int)precioCompra + "€");
            return true;
        }

        // Se o dono é o propio xogador
        if (duenhoActual == actual) {
            Juego.getConsola().imprimir("É o dono desta propiedade");
            return true;
        }

        // 2) Se ten dono e non está hipotecado, págase aluguer
        else if (!hipotecada) {
            float alquilerAPagar = calcularAlquiler(this);

            // Verificamos se o dono ten o grupo para aplicar o incremento
            if (this.grupo != null && this.grupo.esDuenhoGrupo(duenhoActual) && this.datosEdificios != null && !this.datosEdificios.isTieneEdificios()) {
                alquilerAPagar *= 2;
                Juego.getConsola().imprimir("O dono ten todo o grupo " + this.grupo.getColorGrupo() + ", o aluguer dóbrase.");
            }

            Juego.getConsola().imprimir(actual.getNombre() + " debe pagar " + (int)alquilerAPagar + "€ de aluguer a " + duenhoActual.getNombre());
            boolean pagoExitoso = evaluar(actual, banca, tablero, alquilerAPagar, duenhoActual);
            if (!pagoExitoso && duenhoActual != banca){
                actual.setUltimoCobraAlquiler(duenhoActual);
            }
            return pagoExitoso;
        }

        // 3) Se está hipotecado, non se paga aluguer
        else {
            Juego.getConsola().imprimir("O solar está hipotecado, non se paga aluguer.");
            return true;
        }
    }

    // Método auxiliar evaluar modificado para recibir duenho como parámetro
    private boolean evaluar(Jugador actual, Jugador banca, Tablero tablero, float alquilerTransporte, Jugador duenho) {
        boolean resultado = actual.pagarJugador(duenho, alquilerTransporte, tablero);
        if (!resultado){
            if (duenho != banca || duenho != null){
                actual.setUltimoCobraAlquiler(duenho);
            }
            return false;
        }
        else {
            sumarAlquilerCobrado(alquilerTransporte);
            if (duenho != null) {
                duenho.registrarCobroAlquiler(alquilerTransporte);
            }
            actual.registrarPagoAlquiler(alquilerTransporte);
        }
        return true;
    }

    @Override
    public boolean isHipotecada() {
        return hipotecada;
    }

    @Override
    public void hipotecar(Jugador jugador) {
        Jugador duenhoActual = getDuenho();
        if (duenhoActual == null || !duenhoActual.equals(jugador)){
            Juego.getConsola().imprimir(jugador.getNombre() + " non pode hipotecar " + this.getNombre() + " porque non é o seu dono.");
            return;
        }

        if (this.hipotecada){
            Juego.getConsola().imprimir(this.getNombre() + " xa está hipotecada.");
            return;
        }

        if (!"solar".equalsIgnoreCase(this.getTipo())){
            Juego.getConsola().imprimir(jugador.getNombre() + " non pode hipotecar " + this.getNombre() + ". Non é unha propiedade hipotecable.");
            return;
        }

        if (this.datosEdificios != null && this.datosEdificios.isTieneEdificios()) {
            Juego.getConsola().imprimir(jugador.getNombre() + " non pode hipotecar " + this.getNombre() + ". Ten edificios que deben venderse primeiro.");
            return;
        }

        this.hipotecada = true;
        jugador.anhadirHipoteca(this);
        jugador.sumarFortuna(valorHipoteca);
        jugador.sumarInversion(valorHipoteca);

        Juego.getConsola().imprimir(jugador.getNombre() + " recibe " + (int)valorHipoteca + "€ pola hipoteca de " + this.getNombre() +
                ". Non pode recibir alugueres, nin edificar no grupo " + (this.grupo != null ? this.grupo.getColorGrupo() : "") + ".");
    }

    @Override
    public void deshipotecar(Jugador jugador) {
        Jugador duenhoActual = getDuenho();
        if (duenhoActual == null || !duenhoActual.equals(jugador)){
            Juego.getConsola().imprimir(jugador.getNombre() + " non pode deshipotecar " + this.getNombre() + " porque non é o seu dono.");
            return;
        }

        if (!"solar".equalsIgnoreCase(this.getTipo())){
            Juego.getConsola().imprimir(jugador.getNombre() + " non pode deshipotecar " + this.getNombre() + ". Non é unha propiedade hipotecable.");
            return;
        }

        if (!this.hipotecada){
            Juego.getConsola().imprimir(this.getNombre() + " non está hipotecada.");
            return;
        }

        if (!jugador.puedePagar(valorHipoteca)){
            Juego.getConsola().imprimir(jugador.getNombre() + " non pode deshipotecar " + this.getNombre() + ". Non ten diñeiro suficiente.");
            return;
        }

        this.hipotecada = false;
        jugador.sumarFortuna(-valorHipoteca);
        jugador.eliminarHipoteca(this);

        Juego.getConsola().imprimir(jugador.getNombre() + " paga " + (int)valorHipoteca + "€ por deshipotecar " + this.getNombre() +
                "." + (this.grupo != null && this.grupo.esDuenhoGrupo(jugador)? " Agora pode recibir alugueres e edificar no grupo " + this.grupo.getColorGrupo() : " Agora pode recibir alugueres") + ".");
    }

    @Override
    public Solar.DatosEdificios getDatosedificios() {
        return datosEdificios;
    }

    @Override
    public Grupo getGrupo() {
        return grupo;
    }

    public void setGrupo(Grupo grupo) {
        this.grupo = grupo;
    }

    public ArrayList<String> getIdsEdificiosCasilla() {
        return idsEdificiosCasilla;
    }

    public void anhadirIdEdificio(String idEdificio) {
        if (!this.idsEdificiosCasilla.contains(idEdificio)) {
            idsEdificiosCasilla.add(idEdificio);
        }
    }

    public void eliminarIdEdificio(String idEdificio) {
        idsEdificiosCasilla.remove(idEdificio);
    }

    @Override
    public String infoCasilla() {
        StringBuilder info = new StringBuilder();
        info.append("{\n");

        info.append("tipo: solar,\n");
        info.append("grupo: ").append(grupo != null ? grupo.getColorGrupo() : "-").append(",\n");
        info.append("propietario: ").append(getDuenho() != null ? getDuenho().getNombre() : "Banca").append(",\n");
        info.append("valor: ").append((int)getValor()).append(",\n");
        info.append("alquiler: ").append((int)calcularAlquiler(this)).append(",\n");
        info.append("valor hotel: ").append((int)obtenerPrecioHotel(getNombre())).append(",\n");
        info.append("valor casa: ").append((int)obtenerPrecioCasa(getNombre())).append(",\n");
        info.append("valor piscina: ").append((int)obtenerPrecioPiscina(getNombre())).append(",\n");
        info.append("valor pista de deporte: ").append((int)obtenerPrecioPista(getNombre())).append(",\n");
        info.append("alquiler casa: ").append((int)obtenerDatos(getNombre()).getAlquilerCasa()).append(",\n");
        info.append("alquiler hotel: ").append((int)obtenerDatos(getNombre()).getAlquilerHotel()).append(",\n");
        info.append("alquiler piscina: ").append((int)obtenerDatos(getNombre()).getAlquilerPiscina()).append(",\n");
        info.append("alquiler pista de deporte: ").append((int)obtenerDatos(getNombre()).getAlquilerPista()).append("\n");

        info.append("}");
        return info.toString();
    }

// ========== IMPLEMENTACIÓN DE MÉTODOS ABSTRACTOS DE PROPIEDAD ==========

    @Override
    public float calcularAlquiler() {
        return calcularAlquiler(this);
    }

    @Override
    public float calcularValor() {
        return getValor();  // Usar getter en lugar de this.valor
    }

    @Override
    public boolean estaHipotecada() {
        return this.hipotecada;
    }

    @Override
    protected float calcularAlquilerConcreto(int tirada, Tablero tablero) {
        return calcularAlquiler();
    }

    @Override
    public void hipotecar() {
        Juego.getConsola().imprimir("Use o comando 'hipotecar " + getNombre() + "' para hipotecar este solar.");
    }

    @Override
    public void deshipotecar() {
        Juego.getConsola().imprimir("Use o comando 'deshipotecar " + getNombre() + "' para deshipotecar este solar.");
    }

    @Override
    public boolean alquiler() {
        return true;
    }

// Métodos específicos de Solar requeridos por la especificación

    public void edificar(String tipoEdificio) {
        construirEdificio(this, getDuenho(), tipoEdificio);  // Usar getDuenho()
    }

    public boolean estaHipotecadaSolar() {
        return this.hipotecada;
    }
}