
package monopoly.casillas;
import monopoly.*;
import partida.*;

import java.util.ArrayList;

public class Transporte extends Propiedad{

    private float precioCompra;

    //Constructor
    public Transporte(String nombre, int posicion, float precioCompra, Jugador duenho) {
        super(nombre, posicion, duenho);
        this.precioCompra = precioCompra;
    }

    @Override
    public boolean alquiler() {
        // Los transportes cobran alquiler si tienen dueño y no es el jugador actual
        return true;
    }

    @Override
    public float getValor() {
        return calcularValor(); //O valor do transporte é o seu prezo de compra
    }

    @Override
    public boolean estaHipotecada() {
        // Los transportes no se pueden hipotecar (en la primera entrega)
        // En la segunda entrega, según la documentación: "La funcionalidad de hipotecas se implementará en futuras entregas"
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Transporte {\n");
        sb.append("nome: '" ).append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append("',\n");
        sb.append("precio: ").append(getValor()).append("',\n");
        sb.append("propietario: ").append(getDuenho() != null ? getDuenho().getNombre() : "Banca");
        sb.append("\n}");
        return sb.toString();
    }

    // Método para calcular el alquiler base (250.000€ según la documentación)
    public float alquilerTransporte() {
        return Valor.TRANSPORTE_ALQUILER;
    }

    // Cálculo del alquiler según si proviene de cartas o no
    public float calculoAlquilerTransporte(boolean desdeCarta) {
        float alquilerTransporte = this.alquilerTransporte();
        if (desdeCarta) {
            alquilerTransporte *= 2; //Dúas veces o aluguer se provén de cartas
        }
        return alquilerTransporte;
    }

    @Override
    public void hipotecar() {
        // Los transportes no se pueden hipotecar (según la documentación de la segunda entrega)
        Juego.getConsola().imprimir(this.getNombre() + " non se puede hipotecar.");
    }

    @Override
    public void deshipotecar() {
        // Los transportes no se pueden deshipotecar
        Juego.getConsola().imprimir(this.getNombre() + " non se pode deshipotecar.");
    }

    @Override
    public String getTipo() {
        return "transporte";
    }

    // Métodos abstractos de Propiedad que deben implementarse

    @Override
    public float calcularValor() {
        return this.precioCompra;
    }

    @Override
    public float calcularAlquiler() {

        Jugador duenho = getDuenho();
        if (duenho == null) {
            return 0;
        }

        // Contar cuántos transportes tiene el jugador
        int numTransportes = 0;
        for (Casilla propiedad : duenho.getPropiedades()) {
            if (propiedad instanceof Transporte) {
                numTransportes++;
            }
        }

        // El alquiler es la suma del alquiler de TODOS los transportes del jugador
        // Cada transporte: 250.000€
        return numTransportes * Valor.TRANSPORTE_ALQUILER;
    }

    @Override
    protected float calcularAlquilerConcreto(int tirada, Tablero tablero) {
        // Para transportes, el alquiler no depende de la tirada
        // En la segunda entrega se usa la lógica completa: suma de todos los transportes
        return calcularAlquiler();
    }

    // Métodos abstractos de Casilla que deben implementarse

    @Override
    public Jugador getDuenho() {
        return super.getDuenho();
    }

    @Override
    public void setDuenho(Jugador duenho) {
        super.setDuenho(duenho);
    }

    @Override
    public void comprarCasilla(Jugador solicitante, Jugador banca) {
        this.comprar(solicitante);
    }

    @Override
    public String casEnVenta() {
        if (getDuenho() == null || "Banca".equalsIgnoreCase(getDuenho().getNombre())) {
            return "{\n" +
                    "nome: " + getNombre() + ",\n" +
                    "tipo: " + getTipo() + ",\n" +
                    "valor: " + (int)getValor() + "\n" +
                    "}";
        }
        return "";
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta) {
        // Cada vez que se cae en la casilla, actualizamos la estadística
        this.vecesCaida++;

        // Si no puede cobrar alquiler, salimos
        if (!alquiler() || getDuenho() == null || actual == null || actual.equals(getDuenho())) {
            return true;
        }

        // Calcular el alquiler según la lógica de la segunda entrega
        float cantidad;
        if (desdeCarta) {
            // Si viene de carta, se paga el doble
            cantidad = calcularAlquiler() * 2;
        } else {
            cantidad = calcularAlquiler();
        }

        if (cantidad <= 0) {
            return true;
        }

        // Cobrar alquiler al jugador que ha caído
        boolean resultado = actual.pagarJugador(getDuenho(), cantidad, tablero);

        if (resultado) {
            // Actualizar estadística de alquileres cobrados en la casilla
            sumarAlquilerCobrado(cantidad);
        }

        return resultado;
    }

    @Override
    public boolean isHipotecada() {
        return false; // Los transportes no se pueden hipotecar en la segunda entrega
    }

    @Override
    public void hipotecar(Jugador jugador) {
        Juego.getConsola().imprimir(getNombre() + " non se pode hipotecar.");
    }

    @Override
    public void deshipotecar(Jugador jugador) {
        Juego.getConsola().imprimir(getNombre() + " non se pode deshipotecar.");
    }

    @Override
    public monopoly.casillas.Solar.DatosEdificios getDatosedificios() {
        return null; // Los transportes no tienen edificios
    }

    @Override
    public Grupo getGrupo() {
        // Los transportes no pertenecen a grupos como los solares
        return null;
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("tipo: transporte,\n");
        sb.append("nome: '").append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append(",\n");
        sb.append("vecesCaida: ").append(getVecesCaida()).append(",\n");
        sb.append("propietario: ").append(getDuenho() != null ? getDuenho().getNombre() : "Banca").append(",\n");
        sb.append("valor: ").append((int)getValor()).append(",\n");

        // Mostrar información del alquiler actual
        Jugador duenho = getDuenho();
        if (duenho != null) {
            int numTransportes = 0;
            for (Casilla propiedad : duenho.getPropiedades()) {
                if (propiedad instanceof Transporte) {
                    numTransportes++;
                }
            }
            sb.append("transportesDelPropietario: ").append(numTransportes).append(",\n");
            sb.append("alquilerTotal: ").append((int)calcularAlquiler()).append(",\n");
        } else {
            sb.append("alquilerBase: ").append((int)Valor.TRANSPORTE_ALQUILER).append(",\n");
        }

        sb.append("avatares: ").append(getAvataresString()).append("\n");
        sb.append("}");
        return sb.toString();
    }

    @Override
    public ArrayList<String> getIdsEdificiosCasilla() {
        return null;
    }

    @Override
    public void anhadirIdEdificio(String idEdificio) {

    }

    @Override
    public void eliminarIdEdificio(String idEdificio) {

    }

    public void setPrecioCompra(float precioCompra) {
        this.precioCompra = precioCompra;
    }
}