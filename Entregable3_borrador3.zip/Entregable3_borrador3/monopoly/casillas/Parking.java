
package monopoly.casillas;
import monopoly.*;
import partida.*;

import java.util.ArrayList;

public class Parking extends Accion {

    private float bote; //bote de esa casilla (en la mayoría será bote de compra, en la casilla parking se usará como el bote).

    //Constructor
    public Parking(String nombre, int posicion) {
        super(nombre, posicion);
        this.bote = 0; //Inicialmente o bote do parking é 0
    }

    @Override
    public boolean ejecutarAccion(Jugador jugador, Tablero tablero) {
        //O xogador cae en parking e cobra o bote acumulado
        Juego.getConsola().imprimir(jugador.getNombre() + " cae en Parking.");
        if(this.bote > 0){
            Juego.getConsola().imprimir(" Cobra " + (int)this.bote + "€ do Parking.");
            jugador.sumarFortuna(this.bote);
            jugador.registrarPremio(this.bote);
            this.bote = 0; //O bote do parking volve a 0
        } else {
            Juego.getConsola().imprimir(" O Parking está baleiro.");
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Parking {\n");
        sb.append("nome: '").append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append(",\n");
        sb.append("bote: ").append((int)bote).append("\n");
        sb.append("}");
        return sb.toString();
    }

    //Metodo para engadir bote ao parking
    public void anhadirAlBote(float cantidad) {
        this.bote += cantidad;
        Juego.getConsola().imprimir("Engádense " + (int)cantidad + "€ ao bote do Parking. Total: " + (int)bote + "€");
    }

    public float getBote() {
        return bote;
    }

    @Override
    public String getTipo() {
        return "parking";
    }

    // ========== IMPLEMENTACIÓN DE MÉTODOS ABSTRACTOS DE CASILLA ==========

    @Override
    public float getValor() {
        return this.bote; // El valor es el bote acumulado
    }

    @Override
    public Jugador getDuenho() {
        return null; // El parking no tiene dueño
    }

    @Override
    public void setDuenho(Jugador duenho) {
        // El parking no puede tener dueño, no hacer nada
    }

    @Override
    public void comprarCasilla(Jugador solicitante, Jugador banca) {
        Juego.getConsola().imprimir("Non se pode comprar o Parking.");
    }

    @Override
    public String casEnVenta() {
        return ""; // El parking no está en venta
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta) {
        // Incrementar contador de caídas
        this.vecesCaida++;

        // Ejecutar la acción del parking
        return ejecutarAccion(actual, tablero);
    }

    @Override
    public boolean isHipotecada() {
        return false; // El parking no se puede hipotecar
    }

    @Override
    public void hipotecar(Jugador jugador) {
        Juego.getConsola().imprimir("Non se pode hipotecar o Parking.");
    }

    @Override
    public void deshipotecar(Jugador jugador) {
        Juego.getConsola().imprimir("Non se puede deshipotecar o Parking.");
    }

    @Override
    public monopoly.casillas.Solar.DatosEdificios getDatosedificios() {
        return null; // El parking no tiene edificios
    }

    @Override
    public Grupo getGrupo() {
        return null; // El parking no pertenece a ningún grupo
    }

    // ========== SOBRESCRITURA DE MÉTODOS DE CASILLA ==========

    @Override
    public void sumarValor(float cantidad) {
        // Sobrescribimos para añadir al bote
        anhadirAlBote(cantidad);
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("nome: ").append(getNombre()).append(",\n");
        sb.append("tipo: ").append(getTipo()).append(",\n");
        sb.append("posicion: ").append(getPosicion()).append(",\n");
        sb.append("bote: ").append((int)this.bote).append(",\n");
        sb.append("vecesCaida: ").append(getVecesCaida()).append("\n");
        sb.append("}");
        return sb.toString();
    }

    @Override
    public ArrayList<String> getIdsEdificiosCasilla() {
        return null;
    }

    @Override
    public void anhadirIdEdificio(String idEdificio) {

    }

    @Override
    public void eliminarIdEdificio(String idEdificio) {

    }

    @Override
    public void sumarAlquilerCobrado(float cantidad) {
        // El parking no cobra alquileres, pero sí acumula bote
        // Podríamos redirigir esto al bote si queremos
        // sumarValor(cantidad);
        Juego.getConsola().imprimir("O Parking non cobra alugueres.");
    }
}