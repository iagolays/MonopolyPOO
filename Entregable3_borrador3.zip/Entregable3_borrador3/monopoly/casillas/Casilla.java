package monopoly.casillas;

import partida.*;
import monopoly.*;
import java.util.ArrayList;

public abstract class Casilla {

    // Atributos comúns a todas as casillas
    protected String nombre;
    protected int posicion;
    protected ArrayList<Avatar> avatares;
    protected int vecesCaida;
    protected float totalAlquileresCobrados;

    // Constructor
    public Casilla(String nombre, int posicion) {
        this.nombre = nombre;
        this.posicion = posicion;
        this.avatares = new ArrayList<>();
        this.vecesCaida = 0;
        this.totalAlquileresCobrados = 0;
    }

    // Métodos comunes (no abstractos)
    public boolean estaAvatar(Avatar avatar) {
        return avatar.getLugar().equals(this);
    }

    public int frecuenciaVisita() {
        return vecesCaida;
    }

    @Override
    public String toString() {
        return infoCasilla();
    }

    public void anhadirAvatar(Avatar av) {
        if (av != null && !this.avatares.contains(av)) {
            this.avatares.add(av);
            this.vecesCaida++;
        } else {
            Juego.getConsola().imprimir("O avatar xa estaba nesta Casilla");
        }
    }

    public void eliminarAvatar(Avatar av) {
        if (av != null && this.avatares.contains(av)) {
            this.avatares.remove(av);
        } else {
            Juego.getConsola().imprimir("Non se pode eliminar o avatar");
        }
    }

    public String getAvataresString() {
        if (avatares == null || avatares.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for(Avatar av : avatares) {
            sb.append(av.getId());
            if (av.getJugador().isEnCarcel()) {
                sb.append(" (c)");
            }
            sb.append(" ");
        }
        return sb.toString().trim();
    }

    public void sumarValor(float cantidad) {
        // Implementación por defecto, as subclases sobrescriben
    }

    public void sumarAlquilerCobrado(float cantidad) {
        if (cantidad > 0) {
            totalAlquileresCobrados += cantidad;
        }
    }

    public String getNombre() {
        return nombre;
    }

    public int getPosicion() {
        return posicion;
    }

    public ArrayList<Avatar> getAvatares() {
        return avatares;
    }

    public float getTotalAlquileresCobrados() {
        return totalAlquileresCobrados;
    }

    public int getVecesCaida() {
        return vecesCaida;
    }

    // ========== MÉTODOS ABSTRACTOS ==========
    public abstract String getTipo();
    public abstract float getValor();
    public abstract Jugador getDuenho();
    public abstract void setDuenho(Jugador duenho);
    public abstract void comprarCasilla(Jugador solicitante, Jugador banca);
    public abstract String casEnVenta();
    public abstract boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta);
    public abstract boolean isHipotecada();
    public abstract void hipotecar(Jugador jugador);
    public abstract void deshipotecar(Jugador jugador);
    public abstract monopoly.casillas.Solar.DatosEdificios getDatosedificios();
    public abstract Grupo getGrupo();
    public abstract String infoCasilla();

    // NUEVOS MÉTODOS ABSTRACTOS PARA GESTIÓN DE EDIFICIOS
    public abstract ArrayList<String> getIdsEdificiosCasilla();
    public abstract void anhadirIdEdificio(String idEdificio);
    public abstract void eliminarIdEdificio(String idEdificio);
}