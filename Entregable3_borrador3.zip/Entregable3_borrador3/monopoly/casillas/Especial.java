
package monopoly.casillas;

import partida.Jugador;
import monopoly.*;
import partida.*;

import java.util.ArrayList;

//Clase concreta que representa unha casilla especial no taboleiro (Carcel, Saida, IsACarcel)
public class Especial extends Casilla {

    private String tipoEspecial; //Tipo de casilla especial (Carcel, Saida, IsACarcel)

    //Constructor
    public Especial(String nombre, int posicion, String tipoEspecial) {
        super(nombre, posicion);
        this.tipoEspecial = tipoEspecial.toLowerCase();
    }

    //Metodo toString
    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("Especial {\n");
        sb.append("nome: '").append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append(",\n");
        sb.append("tipoEspecial: '").append(tipoEspecial).append("'\n");
        sb.append("}");
        return sb.toString();
    }

    //Metodo que executa a accion da casilla especial (non fai nada, so representa unha casilla especial)
    public boolean ejecutar(Jugador jugador, Tablero tablero) {
        switch (tipoEspecial) {
            case "salida":
                return ejecutarSalida(jugador);

            case "carcel":
                return ejecutarCarcel(jugador);

            case "ircarcel":
                return ejecutarIrCarcel(jugador, tablero);

            default:
                Juego.getConsola().imprimir("Tipo especial descoñecido: " + tipoEspecial);
                return true;
        }
    }

    // Acción para a casilla Salida.
    private boolean ejecutarSalida(Jugador jugador) {
        Juego.getConsola().imprimir(jugador.getNombre() + " está na Salida."); // Non fai nada especial ao caer só cando pasa dela
        return true;
    }

    //Acción para a casilla Carcel.
    private boolean ejecutarCarcel(Jugador jugador) {
        Juego.getConsola().imprimir(jugador.getNombre() + " está visitando o Cárcere.");
        return true;
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta) {
        // Implementar la lógica según el tipo de casilla especial
        switch (tipoEspecial) {
            case "salida":
                actual.sumarFortuna(Valor.SUMA_VUELTA);
                return true;
            case "carcel":
                // Visita a la cárcel
                return true;
            case "ircarcel":
                // Ir a la cárcel
                actual.encarcelar(tablero.getPosiciones(), tablero);
                return true;
            default:
                return true;
        }
    }

    //Acción para a casilla Ir a Carcel.
    private boolean ejecutarIrCarcel(Jugador jugador, Tablero tablero) {
        Juego.getConsola().imprimir(jugador.getNombre() + " vai ao Cárcere!");

        // Encarcelar ao xogador
        jugador.setEnCarcel(true);
        jugador.registrarVecesEnCarcel();

        // Buscar a casilla cárcere e mover o avatar
        Casilla carcel = encontrarCarcel(tablero);
        if (carcel != null && jugador.getAvatar() != null) {
            // Eliminar de la casilla actual
            Casilla lugarActual = jugador.getAvatar().getLugar();
            if (lugarActual != null) {
                lugarActual.eliminarAvatar(jugador.getAvatar());
            }

            // Mover a la cárcel
            jugador.getAvatar().setLugar(carcel);
            carcel.anhadirAvatar(jugador.getAvatar());
        }
        return true;
    }

    //busca a casilla de carcel no tablero
    private Especial encontrarCarcel(Tablero tablero) {
        // Esto lo implementaremos después cuando actualicemos Tablero
        return null;
    }

    @Override
    public void comprarCasilla(Jugador solicitante, Jugador banca) {
        Juego.getConsola().imprimir("Non se puede comprar a casilla especial: " + getNombre());
    }

    @Override
    public String casEnVenta() {
        return ""; // Las casillas especiales no están en venta
    }

    public String getTipoEspecial() {
        return tipoEspecial;
    }

    @Override
    public float getValor() {
        if ("carcel".equals(tipoEspecial)) {
            return Valor.CARCEL_SALIDA; // Coste para salir de la cárcel
        } else if ("salida".equals(tipoEspecial)) {
            return Valor.SUMA_VUELTA; // Dinero que se recibe al pasar
        } else {
            return 0; // Para "ircarcel" y otros
        }
    }

    //metodo para verificar se a casilla é de un tipo especial
    public boolean esTipoEspecial(String tipo) {
        return this.tipoEspecial.equalsIgnoreCase(tipo);
    }

    @Override
    public String getTipo() {
        return getTipoEspecial();
    }

    @Override
    public void setDuenho(Jugador duenho) {
        // Las casillas especiales no tienen dueño, no hacer nada
    }

    @Override
    public Jugador getDuenho() {
        return null; // Las casillas especiales no tienen dueño
    }

    @Override
    public boolean isHipotecada() {
        return false; // Las casillas especiales no se pueden hipotecar
    }

    @Override
    public void hipotecar(Jugador jugador) {
        Juego.getConsola().imprimir("Non se puede hipotecar a casilla especial: " + getNombre());
    }

    @Override
    public void deshipotecar(Jugador jugador) {
        Juego.getConsola().imprimir("Non se puede deshipotecar a casilla especial: " + getNombre());
    }

    @Override
    public monopoly.casillas.Solar.DatosEdificios getDatosedificios() {
        return null; // Las casillas especiales no tienen edificios
    }

    @Override
    public Grupo getGrupo() {
        return null; // Las casillas especiales no pertenecen a grupos
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("nome: ").append(getNombre()).append(",\n");
        sb.append("tipo: ").append(getTipo()).append(",\n");
        sb.append("posicion: ").append(getPosicion()).append(",\n");
        sb.append("vecesCaida: ").append(getVecesCaida()).append("\n");
        sb.append("}");
        return sb.toString();
    }

    @Override
    public ArrayList<String> getIdsEdificiosCasilla() {
        return null;
    }

    @Override
    public void anhadirIdEdificio(String idEdificio) {

    }

    @Override
    public void eliminarIdEdificio(String idEdificio) {

    }
}