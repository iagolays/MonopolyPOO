
package monopoly.casillas;
import monopoly.*;
import partida.*;

import java.util.ArrayList;

public class Impuesto extends Casilla {

    private float cantidad; //Cantidad a pagar por caer en la casilla

    //Constructor
    public Impuesto(String nombre, int posicion, float cantidad) {
        super(nombre, posicion);
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Impuesto {\n");
        sb.append("nome: '").append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append(",\n");
        sb.append("cantidad: ").append(cantidad).append("\n");
        sb.append("}");
        return sb.toString();
    }

    //Metodo para pagar o imposto
    public boolean pagarCantidad(Jugador jugador, Tablero tablero) {
        Juego.getConsola().imprimir(jugador.getNombre() + " debe pagar un imposto de " + (int) cantidad + "€.");

        if (jugador.puedePagar(cantidad)) {
            jugador.sumarFortuna(-cantidad); // Restamos o imposto da fortuna do xogador
            jugador.registrarTasa(cantidad); // Rexistramos o gasto en impostos
            //Engádese ao parking
            Casilla parking = tablero.encontrar_casilla("Parking");
            if (parking != null) {
                parking.sumarValor(cantidad);
            }
            Juego.getConsola().imprimir("Imposto pagado. Jugador " + jugador.getNombre() + " agora ten " + (int) jugador.getFortuna() + "€.");
            return true;
        } else {
            //Non bancarrota automática
            jugador.sumarFortuna(-cantidad);
            Juego.getConsola().imprimir("\n" + jugador.getNombre() + " non puede pagar o imposto de " + (int) cantidad + "€.");
            Juego.getConsola().imprimir("Opcións dispoñibles:");
            Juego.getConsola().imprimir("   - 'hipotecar <casilla>' para obter diñeiro");
            Juego.getConsola().imprimir("   - 'acabar turno' para declararse en bancarrota");
            jugador.setUltimoCobraAlquiler(tablero.getBanca());
            return false;
        }
    }

    public float getCantidad() {
        return cantidad;
    }

    @Override
    public String getTipo() {
        return "impuesto";
    }

    // ========== IMPLEMENTACIÓN DE MÉTODOS ABSTRACTOS DE CASILLA ==========

    @Override
    public float getValor() {
        return cantidad; // El valor es la cantidad del impuesto
    }

    @Override
    public Jugador getDuenho() {
        return null; // Las casillas de impuesto no tienen dueño
    }

    @Override
    public void setDuenho(Jugador duenho) {
        // Las casillas de impuesto no tienen dueño, no hacer nada
    }

    @Override
    public void comprarCasilla(Jugador solicitante, Jugador banca) {
        Juego.getConsola().imprimir("Non se puede comprar a casilla de imposto: " + getNombre());
    }

    @Override
    public String casEnVenta() {
        return ""; // Las casillas de impuesto no están en venta
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta) {
        // Incrementar contador de caídas
        this.vecesCaida++;

        // Pagar el impuesto
        return pagarCantidad(actual, tablero);
    }

    @Override
    public boolean isHipotecada() {
        return false; // Las casillas de impuesto no se pueden hipotecar
    }

    @Override
    public void hipotecar(Jugador jugador) {
        Juego.getConsola().imprimir("Non se puede hipotecar a casilla de imposto: " + getNombre());
    }

    @Override
    public void deshipotecar(Jugador jugador) {
        Juego.getConsola().imprimir("Non se puede deshipotecar a casilla de imposto: " + getNombre());
    }

    @Override
    public monopoly.casillas.Solar.DatosEdificios getDatosedificios() {
        return null; // Las casillas de impuesto no tienen edificios
    }

    @Override
    public Grupo getGrupo() {
        return null; // Las casillas de impuesto no pertenecen a grupos
    }

    // ========== MÉTODOS ESPECÍFICOS DE IMPUESTO ==========

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("nome: ").append(getNombre()).append(",\n");
        sb.append("tipo: ").append(getTipo()).append(",\n");
        sb.append("posicion: ").append(getPosicion()).append(",\n");
        sb.append("cantidad: ").append((int)cantidad).append(",\n");
        sb.append("vecesCaida: ").append(getVecesCaida()).append("\n");
        sb.append("}");
        return sb.toString();
    }

    @Override
    public ArrayList<String> getIdsEdificiosCasilla() {
        return null;
    }

    @Override
    public void anhadirIdEdificio(String idEdificio) {

    }

    @Override
    public void eliminarIdEdificio(String idEdificio) {

    }

    @Override
    public void sumarValor(float cantidad) {
        // Las casillas de impuesto no acumulan valor
        Juego.getConsola().imprimir("As casillas de imposto non acumulan valor.");
    }

    // Método auxiliar para encontrar parking (ya no es necesario si usas tablero.encontrar_casilla)
    private Parking encontrarParking(Tablero tablero) {
        Casilla parkingCasilla = tablero.encontrar_casilla("Parking");
        if (parkingCasilla instanceof Parking) {
            return (Parking) parkingCasilla;
        }
        return null;
    }
}