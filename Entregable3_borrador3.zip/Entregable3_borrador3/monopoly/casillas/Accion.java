
package monopoly.casillas;
import monopoly.*;
import partida.*;

public abstract class Accion extends Casilla {
    //Constructor
    public Accion(String nombre, int posicion) {
        super(nombre, posicion);
    }

    //Metodo abstracto que se implementará nas clases fillas
    public abstract boolean ejecutarAccion(Jugador jugador, Tablero tablero);

    //Metodo toString
    @Override
    public abstract String toString();

    // ========== IMPLEMENTACIÓN DE MÉTODOS ABSTRACTOS DE CASILLA ==========
    // Estos métodos deben estar aquí ya que Accion es abstracta

    @Override
    public abstract String getTipo();

    @Override
    public abstract float getValor();

    @Override
    public abstract Jugador getDuenho();

    @Override
    public abstract void setDuenho(Jugador duenho);

    @Override
    public abstract void comprarCasilla(Jugador solicitante, Jugador banca);

    @Override
    public abstract String casEnVenta();

    @Override
    public abstract boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta);

    @Override
    public abstract boolean isHipotecada();

    @Override
    public abstract void hipotecar(Jugador jugador);

    @Override
    public abstract void deshipotecar(Jugador jugador);

    @Override
    public abstract monopoly.casillas.Solar.DatosEdificios getDatosedificios();

    @Override
    public abstract Grupo getGrupo();

    @Override
    public abstract String infoCasilla();
}