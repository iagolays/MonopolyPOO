
package monopoly.casillas;
import monopoly.*;
import partida.*;

import java.util.ArrayList;

public class Servicio extends Propiedad{
    //Constructor
    private float precioCompra;

    //Constructor modificado
    public Servicio(String nombre, int posicion, float precioCompra, Jugador duenho) {
        super(nombre, posicion, duenho);
        this.precioCompra = precioCompra;
    }

    // Implementación de calcularValor() - Devuelve el precio de compra
    @Override
    public float calcularValor() {
        return this.precioCompra; // o Valor.SERVICIO_PRECIO si usas constante
    }

    @Override
    // Implementación de calcularAlquiler() - Devuelve el alquiler base
    public float calcularAlquiler() {
        return Valor.FACTOR_SERVICIO * 4; // Alquiler base sin tirada de dados
    }

    // Método para calcular el alquiler según la tirada de dados
    public float calcularAlquilertirada(int valorTirada) {
        return valorTirada * Valor.FACTOR_SERVICIO * 4;
    }

    // Implementación de alquiler() - Indica si cobra alquiler
    @Override
    public boolean alquiler() {
        return true; // Los servicios sí cobran alquiler
    }

    // Implementación de estaHipotecada()
    @Override
    public boolean estaHipotecada() {
        return false; // Los servicios no se pueden hipotecar
    }

    // Implementación de calcularAlquilerConcreto() requerido por Propiedad
    @Override
    protected float calcularAlquilerConcreto(int tirada, Tablero tablero) {
        return calcularAlquilertirada(tirada);
    }

    // Implementación de getValor() para Casilla
    @Override
    public float getValor() {
        return calcularValor();
    }

    // Implementación de getTipo()
    @Override
    public String getTipo() {
        return "servicio";
    }

    // Implementación de getDuenho() para Casilla
    @Override
    public Jugador getDuenho() {
        return super.getDuenho(); // Usa el getter de Propiedad
    }

    // Implementación de setDuenho() para Casilla
    @Override
    public void setDuenho(Jugador duenho) {
        super.setDuenho(duenho); // Usa el setter de Propiedad
    }

    // Implementación de comprarCasilla() para Casilla
    @Override
    public void comprarCasilla(Jugador solicitante, Jugador banca) {
        // Llama al método comprar() de Propiedad
        this.comprar(solicitante);
    }

    // Implementación de casEnVenta() para Casilla
    @Override
    public String casEnVenta() {
        if (getDuenho() == null || "Banca".equalsIgnoreCase(getDuenho().getNombre())) {
            return "{\n" +
                    "nome: " + getNombre() + ",\n" +
                    "tipo: " + getTipo() + ",\n" +
                    "valor: " + (int)getValor() + "\n" +
                    "}";
        }
        return "";
    }

    // Implementación de evaluarCasilla() para Casilla
    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta) {
        // Usa el método de Propiedad
        return super.evaluarCasilla(actual, banca, tirada, tablero, desdeCarta);
    }

    // Implementación de isHipotecada() para Casilla
    @Override
    public boolean isHipotecada() {
        return false; // Los servicios no se pueden hipotecar
    }

    // Implementación de hipotecar() para Casilla
    @Override
    public void hipotecar(Jugador jugador) {
        Juego.getConsola().imprimir(getNombre() + " non se pode hipotecar.");
    }

    // Implementación de deshipotecar() para Casilla
    @Override
    public void deshipotecar(Jugador jugador) {
        Juego.getConsola().imprimir(getNombre() + " non se pode deshipotecar.");
    }

    // Implementación de getDatosedificios() para Casilla
    @Override
    public monopoly.casillas.Solar.DatosEdificios getDatosedificios() {
        return null; // Los servicios no tienen edificios
    }

    // Implementación de getGrupo() para Casilla
    @Override
    public Grupo getGrupo() {
        return null; // Los servicios no pertenecen a grupos
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Servicio {\n");
        sb.append("nome: '" ).append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append("',\n");
        sb.append("precio: ").append(getValor()).append("',\n");
        sb.append("propietario: ").append(getDuenho() != null ? getDuenho().getNombre() : "Banca");
        sb.append("\n}");
        return sb.toString();
    }

    @Override
    public void hipotecar() {
        // Os servizos non se poden hipotecar
        Juego.getConsola().imprimir(this.getNombre() + " non se puede hipotecar.");
    }

    @Override
    public void deshipotecar() {
        // Os servizos non se poden deshipotecar
        Juego.getConsola().imprimir(this.getNombre() + " non se pode deshipotecar.");
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("tipo: servicio,\n");
        sb.append("nome: '").append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append(",\n");
        sb.append("valor: ").append((int)getValor()).append(",\n");
        sb.append("propietario: ").append(getDuenho() != null ? getDuenho().getNombre() : "Banca").append(",\n");
        sb.append("hipotecada: ").append(isHipotecada()).append(",\n");
        sb.append("vecesCaida: ").append(getVecesCaida()).append("\n");
        sb.append("}");
        return sb.toString();
    }

    @Override
    public ArrayList<String> getIdsEdificiosCasilla() {
        return null;
    }

    @Override
    public void anhadirIdEdificio(String idEdificio) {

    }

    @Override
    public void eliminarIdEdificio(String idEdificio) {

    }
}