
package monopoly.casillas;
import monopoly.*;
import partida.*;
import java.util.ArrayList;

public class Suerte extends Accion {

    private ArrayList<monopoly.cartas.Suerte> cartasSuerte;
    private int indiceSuerte;

    //Constructor
    public Suerte(String nombre, int posicion) {
        super(nombre, posicion);
        this.cartasSuerte = new ArrayList<>();
        this.indiceSuerte = 0;
        inicializarCartasSuerte();
    }

    private void inicializarCartasSuerte() {
        // Inicializar cartas de Suerte
        cartasSuerte.add(new monopoly.cartas.Suerte("Decides facer unha viaxe de pracer. Avanza ata Solar19. Se pasas pola Saída, cobra 2.000.000€.",
                1, monopoly.cartas.Suerte.TipoAccion.AVANZAR_SOLAR19));
        cartasSuerte.add(new monopoly.cartas.Suerte("Os acredores persíguenche por impago. Vai direcamente ao cárcere, sen pasar pola saída e sen cobrar os 2.000.000€.",
                2, monopoly.cartas.Suerte.TipoAccion.IR_CARCEL));
        cartasSuerte.add(new monopoly.cartas.Suerte("Ganas o bote da lotería. Recibe 1.000.000€.",
                3, monopoly.cartas.Suerte.TipoAccion.LOTERIA));
        cartasSuerte.add(new monopoly.cartas.Suerte("Foches elixido presidente da xunta directiva. Paga a cada xogador 250.000€.",
                4, monopoly.cartas.Suerte.TipoAccion.PAGAR_TODOS));
        cartasSuerte.add(new monopoly.cartas.Suerte("Hora punta de tráfico! Retrocede 3 casillas.",
                5, monopoly.cartas.Suerte.TipoAccion.RETROCEDER3));
        cartasSuerte.add(new monopoly.cartas.Suerte("Multante por usar o móbil mentres conduces. Paga 150.000€.",
                6, monopoly.cartas.Suerte.TipoAccion.MULTA_MOVIL));
        cartasSuerte.add(new monopoly.cartas.Suerte("Avanza ata a casilla de transporte máis cercana. Se non ten dono, podes comprala. Se ten dono, paga ao dono o dobre da operación indicada.",
                7, monopoly.cartas.Suerte.TipoAccion.AVANZAR_TRANSPORTE));
    }

    @Override
    public boolean ejecutarAccion(Jugador jugador, Tablero tablero) {
        //O xogador saca unha carta de sorte e aplícase o efecto
        Juego.getConsola().imprimir(jugador.getNombre() + " cae en Suerte. Saca unha carta de Suerte:");

        //Precisamos a lista de xogadores para algunhas cartas
        ArrayList<Jugador> jugadores = tablero.getJugadores();

        //Sacar e ejecutar a carta
        monopoly.cartas.Suerte carta = cartasSuerte.get(indiceSuerte);
        indiceSuerte = (indiceSuerte + 1) % cartasSuerte.size();

        Juego.getConsola().imprimir(jugador.getNombre() + ", saca unha carta de Sorte: " + carta.getId() + ".");
        Juego.getConsola().imprimir("Acción: " + carta.getDescripcion());

        carta.accion(jugador, tablero, jugadores);
        return !jugador.isEnBancarrota();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Suerte {\n");
        sb.append("nome: '").append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append("\n");
        sb.append("}");
        return sb.toString();
    }

    @Override
    public String getTipo() {
        return "suerte";
    }

    // Métodos abstractos heredados de Casilla que deben implementarse

    @Override
    public float getValor() {
        return 0;
    }

    @Override
    public Jugador getDuenho() {
        return null;
    }

    @Override
    public void setDuenho(Jugador duenho) {
        // No hacer nada
    }

    @Override
    public void comprarCasilla(Jugador solicitante, Jugador banca) {
        Juego.getConsola().imprimir("As casillas de Suerte non se poden comprar.");
    }

    @Override
    public String casEnVenta() {
        return "As casillas de Suerte non se poden comprar.";
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta) {
        return ejecutarAccion(actual, tablero);
    }

    @Override
    public boolean isHipotecada() {
        return false;
    }

    @Override
    public void hipotecar(Jugador jugador) {
        Juego.getConsola().imprimir("As casillas de Suerte non se poden hipotecar.");
    }

    @Override
    public void deshipotecar(Jugador jugador) {
        Juego.getConsola().imprimir("As casillas de Suerte non se poden hipotecar.");
    }

    @Override
    public monopoly.casillas.Solar.DatosEdificios getDatosedificios() {
        return null;
    }

    @Override
    public Grupo getGrupo() {
        return null;
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("tipo: suerte,\n");
        sb.append("nome: '").append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append(",\n");
        sb.append("vecesCaida: ").append(getVecesCaida()).append(",\n");
        sb.append("avatares: ").append(getAvataresString()).append("\n");
        sb.append("}");
        return sb.toString();
    }

    @Override
    public ArrayList<String> getIdsEdificiosCasilla() {
        return null;
    }

    @Override
    public void anhadirIdEdificio(String idEdificio) {

    }

    @Override
    public void eliminarIdEdificio(String idEdificio) {

    }

    // Métodos auxiliares (de la clase CartasSuerte original)
    public void pagarMultaParking(Jugador jugador, Tablero tablero, float cantidad) {
        if (jugador.puedePagar(cantidad)) {
            jugador.sumarFortuna(-cantidad);
            jugador.registrarTasa(cantidad);
            Casilla parking = tablero.encontrar_casilla("Parking");
            if (parking != null){
                parking.sumarValor(cantidad);
            }
        } else {
            jugador.sumarFortuna(-cantidad);
        }
    }

    public void pagarAosDemais(Jugador pagador, ArrayList<Jugador> jugadores, float cantidad, Tablero tablero) {
        int numJugadoresAPagar = 0;
        for (Jugador j : jugadores) {
            if (j != pagador && !j.isEnBancarrota()) {
                numJugadoresAPagar++;
            }
        }

        float total = numJugadoresAPagar * cantidad;

        if (pagador.puedePagar(total)) {
            for (Jugador j : jugadores) {
                if (j != pagador && !j.isEnBancarrota()) {
                    pagador.pagarJugador(j, cantidad, tablero);
                }
            }
        } else {
            pagador.sumarFortuna(-total);
        }
    }
}