
package monopoly.casillas;
import monopoly.*;
import partida.*;
import java.util.ArrayList;

public class CajaComunidad extends Accion {

    private ArrayList<monopoly.cartas.CajaComunidad> cartasComunidad;
    private int indiceComunidad;

    //Constructor
    public CajaComunidad(String nombre, int posicion) {
        super(nombre, posicion);
        this.cartasComunidad = new ArrayList<>();
        this.indiceComunidad = 0;
        inicializarCartasComunidad();
    }

    private void inicializarCartasComunidad() {
        // Inicializar cartas de Caja Comunidad
        cartasComunidad.add(new monopoly.cartas.CajaComunidad("Paga 500.000€ por un fin de semana nun balneario de 5 estrelas.",
                1, monopoly.cartas.CajaComunidad.TipoAccion.PAGAR_BALNEARIO));
        cartasComunidad.add(new monopoly.cartas.CajaComunidad("Investígante por fraude de identidade. Vai ao cárcere. Vai directamente sen pasar pola Saída e sen cobrar os 2.000.000€.",
                2, monopoly.cartas.CajaComunidad.TipoAccion.IR_CARCEL_FRAUDE));
        cartasComunidad.add(new monopoly.cartas.CajaComunidad("Colócate na casilla de Saída. Cobra 2.000.000€.",
                3, monopoly.cartas.CajaComunidad.TipoAccion.IR_SALIDA));
        cartasComunidad.add(new monopoly.cartas.CajaComunidad("Devolución de Facenda. Cobra 500.000€.",
                4, monopoly.cartas.CajaComunidad.TipoAccion.DEVOLUCION_FACENDA));
        cartasComunidad.add(new monopoly.cartas.CajaComunidad("Retrocede ata Solar1 para comprar antigüidades exóticas.",
                5, monopoly.cartas.CajaComunidad.TipoAccion.RETROCEDER_SOLAR1));
        cartasComunidad.add(new monopoly.cartas.CajaComunidad("Vai a Solar20 para gozar do San Fermín. Se pasas pola Saída, cobra 2.000.000€.",
                6, monopoly.cartas.CajaComunidad.TipoAccion.IR_SOLAR20));
    }

    @Override
    public boolean ejecutarAccion(Jugador jugador, Tablero tablero) {
        //O xogador saca unha carta de caixa de comunidade e aplícase o efecto
        Juego.getConsola().imprimir(jugador.getNombre() + " cae en Caixa de Comunidade. Saca unha carta de Caixa de Comunidade:");

        //Sacar e ejecutar a carta
        monopoly.cartas.CajaComunidad carta = cartasComunidad.get(indiceComunidad);
        indiceComunidad = (indiceComunidad + 1) % cartasComunidad.size();

        Juego.getConsola().imprimir(jugador.getNombre() + ", saca unha carta de Caixa de Comunidade: " + carta.getId() + ".");
        Juego.getConsola().imprimir("Acción: " + carta.getDescripcion());

        carta.accion(jugador, tablero, new ArrayList<Jugador>());
        return !jugador.isEnBancarrota();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("CajaComunidad {\n");
        sb.append("nome: '").append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append("\n");
        sb.append("}");
        return sb.toString();
    }

    @Override
    public String getTipo() {
        return "comunidad";
    }

    // ========== IMPLEMENTACIÓN DE MÉTODOS ABSTRACTOS DE CASILLA ==========

    @Override
    public float getValor() {
        return 0;
    }

    @Override
    public Jugador getDuenho() {
        return null;
    }

    @Override
    public void setDuenho(Jugador duenho) {
        // No hacer nada
    }

    @Override
    public void comprarCasilla(Jugador solicitante, Jugador banca) {
        Juego.getConsola().imprimir("Non se pode comprar a casilla de comunidade: " + getNombre());
    }

    @Override
    public String casEnVenta() {
        return "";
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta) {
        this.vecesCaida++;
        return ejecutarAccion(actual, tablero);
    }

    @Override
    public boolean isHipotecada() {
        return false;
    }

    @Override
    public void hipotecar(Jugador jugador) {
        Juego.getConsola().imprimir("Non se pode hipotecar a casilla de comunidade: " + getNombre());
    }

    @Override
    public void deshipotecar(Jugador jugador) {
        Juego.getConsola().imprimir("Non se pode deshipotecar a casilla de comunidade: " + getNombre());
    }

    @Override
    public monopoly.casillas.Solar.DatosEdificios getDatosedificios() {
        return null;
    }

    @Override
    public Grupo getGrupo() {
        return null;
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("nome: ").append(getNombre()).append(",\n");
        sb.append("tipo: ").append(getTipo()).append(",\n");
        sb.append("posicion: ").append(getPosicion()).append(",\n");
        sb.append("vecesCaida: ").append(getVecesCaida()).append("\n");
        sb.append("}");
        return sb.toString();
    }

    @Override
    public ArrayList<String> getIdsEdificiosCasilla() {
        return null;
    }

    @Override
    public void anhadirIdEdificio(String idEdificio) {

    }

    @Override
    public void eliminarIdEdificio(String idEdificio) {

    }

    @Override
    public void sumarValor(float cantidad) {
        Juego.getConsola().imprimir("As casillas de comunidade non acumulan valor.");
    }

    // Métodos auxiliares (de la clase CartasSuerte original)
    public void pagarMultaParking(Jugador jugador, Tablero tablero, float cantidad) {
        if (jugador.puedePagar(cantidad)) {
            jugador.sumarFortuna(-cantidad);
            jugador.registrarTasa(cantidad);
            Casilla parking = tablero.encontrar_casilla("Parking");
            if (parking != null){
                parking.sumarValor(cantidad);
            }
        } else {
            jugador.sumarFortuna(-cantidad);
        }
    }
}