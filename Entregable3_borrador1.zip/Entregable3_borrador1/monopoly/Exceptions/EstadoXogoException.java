package monopoly.Exceptions;

//excepción para estados inválidos do xogo

public class EstadoXogoException extends MonopolyException{
    public EstadoXogoException(String mensaxe) {
        super(mensaxe);
    }
}
