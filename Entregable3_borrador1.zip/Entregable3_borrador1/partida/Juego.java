package partida;

import java.util.ArrayList;
import monopoly.*;

public class Juego {

    private ArrayList<Jugador> jugadores;     // Lista de xogadores na partida
    private Tablero tablero;     // Taboleiro da partida

    //inicializa a lista de xogadores e o taboleiro
    public Juego() {
        this.jugadores = new ArrayList<>();
        this.tablero = new Tablero(); // Creamos o taboleiro coa súa lista de casillas
    }

    //Metodo para engadir un xogador á partida
    public void anhadirJugador(Jugador jugador) {
        if (!jugadores.contains(jugador)) {
            jugadores.add(jugador);
        } else {
            System.out.println("O xogador " + jugador.getNombre() + " xa está na partida.");
        }
    }

    //Buscar un xogador polo seu nome
    public Jugador buscarJugador(String nombre) {
        for (Jugador xogador : jugadores) {
            if (xogador.getNombre().equalsIgnoreCase(nombre)){
                return xogador;
            }
        }
        return null;
    }

    //Metodo que devolve a lista de xogadores
    public ArrayList<Jugador> getJugadores() {
        return jugadores;
    }

    public Tablero getTablero() {
        return tablero;
    }

    //Metodo para mostrar o estado actual de todos os xogadores
    public void mostrarEstadoJugadores() {
        for (Jugador j : jugadores) {
            System.out.println(j.infoJugador());
        }
    }
}
