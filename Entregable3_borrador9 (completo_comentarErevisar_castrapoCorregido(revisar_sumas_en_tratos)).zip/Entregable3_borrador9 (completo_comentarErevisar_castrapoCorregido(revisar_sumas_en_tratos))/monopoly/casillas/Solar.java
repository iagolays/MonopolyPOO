package monopoly.casillas;

import monopoly.*;
import monopoly.cartas.Carta;
import monopoly.edificios.*;
import monopoly.exceptions.MonopolyException;
import partida.*;
import java.util.ArrayList;

public class Solar extends Propiedad {

    // Atributos específicos de Solar
    private boolean hipotecada;
    private float hipoteca;
    private Grupo grupo;
    private ArrayList<Edificio> edificios;
    private ArrayList<String> idsEdificios;

    // Contadores para verificación rápida
    private int numCasas;
    private int numHoteles;
    private int numPiscinas;
    private int numPistas;

    // Constructor
    public Solar(String nombre, int posicion, Jugador duenho) {
        super(nombre, posicion, duenho, Valor.obtenerPrecioSolar(nombre));
        this.grupo = null;
        this.hipotecada = false;
        this.hipoteca = getValor() / 2;
        this.edificios = new ArrayList<>();
        this.idsEdificios = new ArrayList<>();
        this.numCasas = 0;
        this.numHoteles = 0;
        this.numPiscinas = 0;
        this.numPistas = 0;
    }

    // Constructor que acepta grupo directamente
    public Solar(String nombre, int posicion, Jugador duenho, Grupo grupo) {
        super(nombre, posicion, duenho, Valor.obtenerPrecioSolar(nombre));
        this.edificios = new ArrayList<>();
        this.idsEdificios = new ArrayList<>();
        this.setGrupo(grupo);
        this.hipotecada = false;
        this.hipoteca = getValor() / 2;
        this.numCasas = 0;
        this.numHoteles = 0;
        this.numPiscinas = 0;
        this.numPistas = 0;
    }

    // Método para establecer el grupo
    public void setGrupo(Grupo grupo) {
        this.grupo = grupo;
        if (grupo != null && !grupo.getMiembros().contains(this)) {
            grupo.anhadirCasilla(this);
        }
    }

    // Método para hipotecar un solar
    public void hipotecar(Jugador jugador) throws MonopolyException {
        if (!perteneceAJugador(jugador)) {
            Juego.getConsola().imprimir(jugador.getNombre() + " non é o dono de " + getNombre() + " e non pode hipotecalo.");
            return;
        }
        if (hipotecada) {
            Juego.getConsola().imprimir(getNombre() + " xa está hipotecado.");
            return;
        }

        if (edificios != null && !edificios.isEmpty()) {
            Juego.getConsola().imprimir("Non se pode hipotecar " + getNombre() + " porque ten edificios. Debe vendelos antes de hipotecar.");
            return;
        }

        this.hipotecada = true;
        float valorHipoteca = this.hipoteca;

        jugador.anhadirHipoteca(this);
        jugador.sumarFortuna(valorHipoteca);
        jugador.sumarInversion(valorHipoteca);

        Juego.getConsola().imprimir(jugador.getNombre() + " recibe " + (int)valorHipoteca + "€ pola hipoteca de " + this.nombre +
                ". Non pode recibir alugueres, nin edificar no grupo " + (this.grupo != null ? this.grupo.getColorGrupo() : "") + ".");
    }

    // Método para deshipotecar el solar
    public void deshipotecar(Jugador jugador) throws MonopolyException {
        if (!perteneceAJugador(jugador)) {
            Juego.getConsola().imprimir(jugador.getNombre() + " non é o dono de " + getNombre() + " e non pode deshipotecalo.");
            return;
        }
        if (!hipotecada) {
            Juego.getConsola().imprimir(getNombre() + " non está hipotecado.");
            return;
        }

        float valorDeshipoteca = this.hipoteca;
        if (!jugador.puedePagar(valorDeshipoteca)) {
            Juego.getConsola().imprimir(jugador.getNombre() + " non pode deshipotecar " + this.nombre + ". Non ten diñeiro suficiente.");
            return;
        }

        this.hipotecada = false;
        jugador.sumarFortuna(-valorDeshipoteca);
        jugador.eliminarHipoteca(this);

        StringBuilder mensaje = new StringBuilder();
        mensaje.append(jugador.getNombre()).append(" paga ").append((int)valorDeshipoteca)
                .append("€ por deshipotecar ").append(this.nombre).append(".");

        if (this.grupo != null && this.grupo.esDuenhoGrupo(jugador)) {
            if (this.grupo.todosDeshipotecados(jugador)) {
                mensaje.append(" Agora pode recibir alugueres e edificar no grupo ").append(this.grupo.getColorGrupo()).append(".");
            } else {
                mensaje.append(" Aínda non pode recibir alugueres nin edificar no grupo ").append(this.grupo.getColorGrupo())
                        .append(" porque hai outros solares do grupo aínda hipotecados.");
            }
        } else {
            mensaje.append(" Agora pode recibir alugueres neste solar.");
        }

        Juego.getConsola().imprimir(mensaje.toString());
    }

    @Override
    public float valor() {
        return this.valor;
    }

    public boolean estaHipotecada() {
        return hipotecada;
    }

    // Método para añadir edificio
    public void anhadirEdificio(Edificio edificio) {
        if (edificios == null) {
            edificios = new ArrayList<>();
        }
        if (idsEdificios == null) {
            idsEdificios = new ArrayList<>();
        }

        if (!edificios.contains(edificio)) {
            edificios.add(edificio);
            idsEdificios.add(edificio.getId());

            String tipo = edificio.obterTipoEdificio().toLowerCase();

            // Actualizar contadores
            switch (tipo) {
                case "casa":
                    numCasas++;
                    break;
                case "hotel":
                    numHoteles++;
                    break;
                case "piscina":
                    numPiscinas++;
                    break;
                case "pista":
                    numPistas++;
                    break;
            }
        }
    }

    public void eliminarEdificio(Edificio edificio) {
        if (edificios == null || edificio == null) return;

        if (edificios.contains(edificio)) {
            edificios.remove(edificio);

            // También eliminar del array de IDs
            if (idsEdificios != null) {
                idsEdificios.remove(edificio.getId());
            }

            String tipo = edificio.obterTipoEdificio().toLowerCase();

            // Actualizar contadores
            switch (tipo) {
                case "casa":
                    if (numCasas > 0) numCasas--;
                    break;
                case "hotel":
                    if (numHoteles > 0) numHoteles--;
                    break;
                case "piscina":
                    if (numPiscinas > 0) numPiscinas--;
                    break;
                case "pista":
                    if (numPistas > 0) numPistas--;
                    break;
            }
        }
    }

    public Edificio buscarEdificio(String id) {
        if (edificios == null) return null;

        for (Edificio e : edificios) {
            if (e.getId().equals(id)) {
                return e;
            }
        }
        return null;
    }

    public boolean tieneEdificios() {
        return edificios != null && !edificios.isEmpty();
    }

    public void anhadirIdEdificio(String id) {
        if (idsEdificios == null) {
            idsEdificios = new ArrayList<>();
        }
        if (!idsEdificios.contains(id)) {
            idsEdificios.add(id);
        }
    }

    public void eliminarIdEdificio(String id) {
        if (idsEdificios != null) {
            idsEdificios.remove(id);
        }
        Edificio e = buscarEdificio(id);
        if (e != null) {
            eliminarEdificio(e);
        }
    }

    // Método para eliminar todas las casas (al construir hotel)
    private void eliminarTodasLasCasas() {
        if (edificios == null) return;

        // Crear lista temporal para evitar ConcurrentModificationException
        ArrayList<Edificio> casasAEliminar = new ArrayList<>();
        for (Edificio e : edificios) {
            if (e instanceof Casa) {
                casasAEliminar.add(e);
            }
        }

        // Eliminar todas las casas
        for (Edificio casa : casasAEliminar) {
            eliminarEdificio(casa);
            // También eliminar del jugador
            if (casa.getPropietario() != null) {
                casa.getPropietario().eliminarEdificio(casa.getId());
            }
        }

        // Resetear contador de casas
        numCasas = 0;
    }

    // Método para calcular el alquiler
    @Override
    public float alquiler(int tirada, boolean desdeCarta) {
        // Si este solar está hipotecado, no se cobra
        if (hipotecada) return 0;

        // Verificar si el jugador tiene todo el grupo
        if (grupo != null && grupo.esDuenhoGrupo(duenho)) {
            // Si tiene todo el grupo, verificar si algún solar del grupo está hipotecado
            for (Propiedad propiedad : grupo.getMiembros()) {
                if (propiedad instanceof Solar) {
                    Solar solar = (Solar) propiedad;
                    if (solar.estaHipotecada()) {
                        return 0;
                    }
                }
            }
        }

        float alquiler = Valor.obtenerAlquilerSolar(nombre);

        if (edificios != null) {
            for (Edificio e : edificios) {
                alquiler += e.obterAluguer();
            }
        }

        // Duplicar alquiler si tiene todo el grupo, sin edificios
        if (grupo != null && grupo.esDuenhoGrupo(duenho) &&
                (edificios == null || edificios.isEmpty())) {
            alquiler *= 2;
        }

        return alquiler;
    }

    // Método para calcular el alquiler sin tirada ni carta
    public float calcularAlquiler() {
        return alquiler(0, false);
    }

    // Método para construir un edificio en el solar
    public boolean construirEdificio(String tipo, Jugador jugador) throws MonopolyException {
        if (!perteneceAJugador(jugador)) {
            Juego.getConsola().imprimir(jugador.getNombre() + " non é dono de " + nombre);
            return false;
        }

        if (hipotecada) {
            Juego.getConsola().imprimir(nombre + " está hipotecada");
            return false;
        }

        // Verificar que el jugador es dueño del grupo completo
        if (grupo == null || !grupo.esDuenhoGrupo(jugador)) {
            Juego.getConsola().imprimir("Necesitas ter todo o grupo para construír");
            return false;
        }

        // Verificar que todos los solares del grupo no estén hipotecados
        if (grupo != null) {
            for (Propiedad propiedad : grupo.getMiembros()) {
                if (propiedad instanceof Solar) {
                    Solar solarDelGrupo = (Solar) propiedad;
                    if (solarDelGrupo.estaHipotecada()) {
                        Juego.getConsola().imprimir("Non se pode edificar no grupo " + grupo.getColorGrupo() +
                                " porque " + solarDelGrupo.getNombre() + " está hipotecado.");
                        return false;
                    }
                }
            }
        }

        switch (tipo.toLowerCase()) {
            case "casa":
                if (numCasas >= 4) {
                    Juego.getConsola().imprimir("Xa hai 4 casas en " + nombre);
                    return false;
                }
                if (numHoteles > 0) {
                    Juego.getConsola().imprimir("Non se poden construír casas se hai hotel");
                    return false;
                }
                break;

            case "hotel":
                if (numCasas < 4) {
                    Juego.getConsola().imprimir("Necesitas 4 casas para construír un hotel");
                    return false;
                }
                if (numHoteles >= 1) {
                    Juego.getConsola().imprimir("Xa hai un hotel en " + nombre);
                    return false;
                }
                // Eliminar las 4 casas antes de construir hotel
                eliminarTodasLasCasas();
                break;

            case "piscina":
                if (numHoteles < 1) {
                    Juego.getConsola().imprimir("Necesitas un hotel para construír unha piscina");
                    return false;
                }
                if (numPiscinas >= 1) {
                    Juego.getConsola().imprimir("Xa hai unha piscina en " + nombre);
                    return false;
                }
                break;

            case "pista":
                if (numHoteles < 1) {
                    Juego.getConsola().imprimir("Necesitas un hotel para construír unha pista");
                    return false;
                }
                if (numPiscinas < 1) {
                    Juego.getConsola().imprimir("Necesitas unha piscina para construír unha pista");
                    return false;
                }
                if (numPistas >= 1) {
                    Juego.getConsola().imprimir("Xa hai unha pista en " + nombre);
                    return false;
                }
                break;

            default:
                Juego.getConsola().imprimir("Tipo de edificio descoñecido: " + tipo);
                return false;
        }

        Edificio nuevoEdificio = null;
        switch (tipo.toLowerCase()) {
            case "casa":
                nuevoEdificio = new Casa(this, jugador);
                break;
            case "hotel":
                nuevoEdificio = new Hotel(this, jugador);
                break;
            case "piscina":
                nuevoEdificio = new Piscina(this, jugador);
                break;
            case "pista":
                nuevoEdificio = new PistaDeDeporte(this, jugador);
                break;
        }

        if (nuevoEdificio == null) {
            return false;
        }

        // Verificar que el jugador tiene dinero suficiente
        float precio = nuevoEdificio.getPrecio();
        if (!jugador.puedePagar(precio)) {
            Juego.getConsola().imprimir(jugador.getNombre() + " non ten diñeiro para construír " + tipo);
            return false;
        }

        // Realizar el pago y añadir el edificio
        jugador.sumarFortuna(-precio);
        jugador.sumarInversion(precio);
        anhadirEdificio(nuevoEdificio);
        jugador.anhadirEdificio(nuevoEdificio);

        Juego.getConsola().imprimir("Constrúese un " + tipo + " en " + nombre + ".");
        return true;
    }

    // Método para evaluar la casilla solar
    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta, ArrayList<Carta> mazoSuerte, ArrayList<Carta> mazoComunidad, int[] indices) throws MonopolyException {
        vecesCaida++;

        if (duenho == null || duenho == banca) {
            Juego.getConsola().imprimir(nombre + " está en venda por " + (int)valor + "€");
            return true;
        }

        if (duenho.equals(actual)) {
            Juego.getConsola().imprimir(actual.getNombre() + " é o dono de " + nombre);
            return true;
        }

        // Verificar si se puede cobrar alquiler
        boolean sePuedeCobrar = !hipotecada;

        if (sePuedeCobrar && grupo != null && grupo.esDuenhoGrupo(duenho)) {
            // Si el dueño tiene todo el grupo, verificar que ningún solar esté hipotecado
            for (Propiedad propiedad : grupo.getMiembros()) {
                if (propiedad instanceof Solar) {
                    Solar solar = (Solar) propiedad;
                    if (solar.estaHipotecada()) {
                        sePuedeCobrar = false;
                        break;
                    }
                }
            }
        }

        if (sePuedeCobrar) {
            float alquilerAPagar = alquiler(tirada, desdeCarta);
            Juego.getConsola().imprimir(actual.getNombre() + " paga " + (int)alquilerAPagar + "€ a " + duenho.getNombre());

            boolean pagoExitoso = actual.pagarJugador(duenho, alquilerAPagar, tablero);
            if (pagoExitoso) {
                sumarAlquilerCobrado(alquilerAPagar);
                duenho.registrarCobroAlquiler(alquilerAPagar);
                actual.registrarPagoAlquiler(alquilerAPagar);
                return true;
            } else {
                actual.setUltimoCobraAlquiler(duenho);
                return false;
            }
        } else {
            Juego.getConsola().imprimir(nombre + " non cobra aluguer (está hipotecada ou hai solares hipotecados no grupo)");
            return true;
        }
    }

    @Override
    public String getTipo() {
        return "solar";
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("\ttipo: solar,\n");
        sb.append("\tgrupo: ").append(grupo != null ? grupo.getColorGrupo() : "-").append(",\n");
        sb.append("\tpropietario: ").append(duenho != null ? duenho.getNombre() : "Banca").append(",\n");
        sb.append("\tvalor: ").append((int)valor).append(",\n");
        sb.append("\talquiler: ").append((int)calcularAlquiler()).append(",\n");

        // Precios de edificios según el solar
        sb.append("\tvalor hotel: ").append((int)Valor.obtenerPrecioHotel(nombre.toLowerCase())).append(",\n");
        sb.append("\tvalor casa: ").append((int)Valor.obtenerPrecioCasa(nombre.toLowerCase())).append(",\n");
        sb.append("\tvalor piscina: ").append((int)Valor.obtenerPrecioPiscina(nombre.toLowerCase())).append(",\n");
        sb.append("\tvalor pista de deporte: ").append((int)Valor.obtenerPrecioPista(nombre.toLowerCase())).append(",\n");

        // Alquileres de edificios
        sb.append("\talquiler casa: ").append((int)Valor.obtenerAlquilerCasa(nombre.toLowerCase())).append(",\n");
        sb.append("\talquiler hotel: ").append((int)Valor.obtenerAlquilerHotel(nombre.toLowerCase())).append(",\n");
        sb.append("\talquiler piscina: ").append((int)Valor.obtenerAlquilerPiscina(nombre.toLowerCase())).append(",\n");
        sb.append("\talquiler pista de deporte: ").append((int)Valor.obtenerAlquilerPista(nombre.toLowerCase())).append(",\n");

        //Edificios construidos
        sb.append("\tedificios construidos: {\n");

        // Casas
        sb.append("\t\tcasas: [");
        ArrayList<String> casas = obtenerIdsEdificiosTipo("casa");
        if (casas.isEmpty()) {
            sb.append("-");
        } else {
            for (int i = 0; i < casas.size(); i++) {
                sb.append(casas.get(i));
                if (i < casas.size() - 1) sb.append(", ");
            }
        }
        sb.append("],\n");

        // Hoteles
        sb.append("\t\thoteles: [");
        ArrayList<String> hoteles = obtenerIdsEdificiosTipo("hotel");
        if (hoteles.isEmpty()) {
            sb.append("-");
        } else {
            for (int i = 0; i < hoteles.size(); i++) {
                sb.append(hoteles.get(i));
                if (i < hoteles.size() - 1) sb.append(", ");
            }
        }
        sb.append("],\n");

        // Piscinas
        sb.append("\t\tpiscinas: [");
        ArrayList<String> piscinas = obtenerIdsEdificiosTipo("piscina");
        if (piscinas.isEmpty()) {
            sb.append("-");
        } else {
            for (int i = 0; i < piscinas.size(); i++) {
                sb.append(piscinas.get(i));
                if (i < piscinas.size() - 1) sb.append(", ");
            }
        }
        sb.append("],\n");

        // Pistas de deporte
        sb.append("\t\tpistas de deporte: [");
        ArrayList<String> pistas = obtenerIdsEdificiosTipo("pista");
        if (pistas.isEmpty()) {
            sb.append("-");
        } else {
            for (int i = 0; i < pistas.size(); i++) {
                sb.append(pistas.get(i));
                if (i < pistas.size() - 1) sb.append(", ");
            }
        }
        sb.append("]\n");

        sb.append("\t}\n");
        sb.append("}");
        return sb.toString();
    }

    // Método auxiliar para obtener IDs de edificios por tipo
    private ArrayList<String> obtenerIdsEdificiosTipo(String tipo) {
        ArrayList<String> ids = new ArrayList<>();
        if (edificios == null) return ids;

        for (Edificio edificio : edificios) {
            if (edificio.obterTipoEdificio().equalsIgnoreCase(tipo)) {
                ids.add(edificio.getId());
            }
        }
        return ids;
    }

    // Getters
    public ArrayList<String> getIdsEdificios() {
        if (idsEdificios == null) {
            idsEdificios = new ArrayList<>();
        }
        return idsEdificios;
    }

    public int getNumCasas() {
        return numCasas;
    }

    public int getNumHoteles() {
        return numHoteles;
    }

    public int getNumPiscinas() {
        return numPiscinas;
    }

    public int getNumPistas() {
        return numPistas;
    }

    public ArrayList<Edificio> getEdificios() {
        if (edificios == null) {
            edificios = new ArrayList<>();
        }
        return edificios;
    }

    public Grupo getGrupo() {
        return grupo;
    }

    public float getHipoteca() {
        return hipoteca;
    }
}