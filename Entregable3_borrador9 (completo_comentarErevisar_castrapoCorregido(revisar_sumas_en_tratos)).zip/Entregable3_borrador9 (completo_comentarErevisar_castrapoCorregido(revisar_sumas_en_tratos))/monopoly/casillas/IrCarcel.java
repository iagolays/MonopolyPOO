package monopoly.casillas;
import monopoly.*;
import monopoly.cartas.Carta;
import partida.*;

import java.util.ArrayList;
import monopoly.exceptions.MonopolyException;

public class IrCarcel extends Especial{

    public IrCarcel(String nombre, int posicion) {
        super(nombre, posicion);
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta, ArrayList<Carta> mazoSuerte, ArrayList<Carta> mazoComunidad, int[] indices) throws MonopolyException{
        vecesCaida++;

        // Pon ao xogador no cárcere
        actual.setEnCarcel(true);
        actual.registrarVecesEnCarcel();

        // Move o avatar ao cárcere
        Casilla carcel = tablero.encontrar_casilla("Carcel");
        if (carcel != null) {
            // Elimina da casilla actual
            this.eliminarAvatar(actual.getAvatar());
            //Move ao carcere
            actual.getAvatar().setLugar(carcel);
            carcel.anhadirAvatar(actual.getAvatar());
        }

        Juego.getConsola().imprimir(actual.getNombre() + " vai á cárcere!");
        return true;
    }

    @Override
    public String getTipo() {
        return "irCarcel";
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("\ttipo: irCarcel,\n");
        sb.append("\tnome: \"").append(nombre).append("\",\n");
        sb.append("\tposicion: ").append(posicion).append("\n");
        sb.append("}");
        return sb.toString();
    }
}
