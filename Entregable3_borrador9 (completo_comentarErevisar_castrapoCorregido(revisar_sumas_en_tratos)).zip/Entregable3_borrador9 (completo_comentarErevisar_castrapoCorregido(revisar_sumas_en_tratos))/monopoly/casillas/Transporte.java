package monopoly.casillas;
import monopoly.*;
import monopoly.cartas.Carta;
import monopoly.exceptions.MonopolyException;
import partida.*;

import java.util.ArrayList;

public class Transporte extends Propiedad {

    // Constructor
    public Transporte(String nombre, int posicion, Jugador duenho) {
        super(nombre, posicion, duenho, Valor.TRANSPORTE_PRECIO);
    }

    @Override
    public float valor() {
        return this.valor; // Prezo fixo para todos os transportes
    }

    @Override
    public float alquiler(int tirada, boolean desdeCarta) {
        float alquiler = Valor.TRANSPORTE_ALQUILER;
        if (desdeCarta) {
            alquiler *= 2; // Se ven de carta, dóbrase
        }
        return alquiler;
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta, ArrayList<Carta> mazoSuerte, ArrayList<Carta> mazoComunidad, int[] indices) throws MonopolyException{
        vecesCaida++; // Contador de visitas

        //Se está en venda
        if (duenho == null || duenho == banca) {
            Juego.getConsola().imprimir(nombre + " (Transporte) está en venda por " +
                    (int)valor() + "€");
            return true;
        }

        //Se é o dono
        if (duenho.equals(actual)) {
            Juego.getConsola().imprimir(actual.getNombre() + " é dono deste transporte");
            return true;
        }

        //Paga aluguer
        float alquilerAPagar = alquiler(tirada, desdeCarta);
        Juego.getConsola().imprimir(actual.getNombre() + " paga " + (int)alquilerAPagar + "€ de aluguer a " + duenho.getNombre());

        boolean pagoExitoso = actual.pagarJugador(duenho, alquilerAPagar, tablero);
        if (pagoExitoso) {
            sumarAlquilerCobrado(alquilerAPagar);
            duenho.registrarCobroAlquiler(alquilerAPagar);
            actual.registrarPagoAlquiler(alquilerAPagar);
            return true;
        } else {
            actual.setUltimoCobraAlquiler(duenho);
            return false;
        }
    }

    @Override
    public String getTipo() {
        return "transporte";
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("\ttipo: transporte,\n");
        sb.append("\tnome: \"").append(nombre).append("\",\n");
        sb.append("\tposicion: ").append(posicion).append(",\n");
        sb.append("\tpropietario: \"").append(duenho != null ? duenho.getNombre() : "Banca").append("\",\n");
        sb.append("\tvalor: ").append((int)valor()).append(",\n");
        sb.append("\talquiler: ").append((int)Valor.TRANSPORTE_ALQUILER).append(",\n");
        sb.append("\talquileresCobrados: ").append((int)totalAlquileresCobrados).append("\n");
        sb.append("}");
        return sb.toString();
    }
}