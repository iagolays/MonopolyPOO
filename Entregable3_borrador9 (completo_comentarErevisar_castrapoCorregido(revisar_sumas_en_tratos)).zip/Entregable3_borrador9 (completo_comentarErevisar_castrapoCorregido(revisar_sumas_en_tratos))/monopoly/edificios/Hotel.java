package monopoly.edificios;

import monopoly.*;
import monopoly.casillas.Solar;
import partida.*;

//Clase que representa un Hotel construído nun solar.
public class Hotel extends Edificio {

    // Contador estático para xerar IDs únicos para os hoteis
    private static int contador = 1;

    //Constructor da clase Hotel.
    public Hotel(Solar solar, Jugador propietario) {
        super(solar, propietario);
    }

    //Metodo que devolve o tipo de edificio.
    @Override
    public String obterTipoEdificio() {
        return "hotel";
    }

    //metodo que obtén o seguinte número do contador de hoteis (para o Id).
    @Override
    public int obterContador() {
        return contador++;
    }

    //Metodo que calcula o prezo do hotel segundo o solar.
    @Override
    public float calcularPrezo() {
        return obterPrecioValor(solar.getNombre().toLowerCase(), "hotel");
    }

    //Metodo que obtén o aluguer que aporta este hotel.
    @Override
    public float obterAluguer() {
        return obterAlquilerValor(solar.getNombre().toLowerCase(), "hotel");
    }
}