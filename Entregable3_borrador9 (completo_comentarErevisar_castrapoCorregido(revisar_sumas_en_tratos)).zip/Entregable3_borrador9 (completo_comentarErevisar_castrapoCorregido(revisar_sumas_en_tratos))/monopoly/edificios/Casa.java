package monopoly.edificios;

import monopoly.*;
import monopoly.casillas.Solar;
import partida.*;

//Clase que representa unha Casa construída nun solar.
public class Casa extends Edificio {

    //Contador estático para xerar IDs únicos para as casas (inicialízase a 1 e incrementa cada vez que se crea unha nova casa)
    private static int contador = 1;

    //Constructor da clase Casa.
    public Casa(Solar solar, Jugador propietario) {
        super(solar, propietario);
    }

    //Metodo que devolve o tipo de edificio (reescritura do metodo).
    @Override
    public String obterTipoEdificio() {
        return "casa";
    }

    //Metodo que obtén o seguinte número do contador de casas.
    @Override
    public int obterContador() {
        return contador++; //incrementa o contador cada vez que se chama
    }

    //Calcula o prezo da casa segundo o solar no que se constrúe.
    @Override
    public float calcularPrezo() {
        return obterPrecioValor(solar.getNombre().toLowerCase(), "casa");
    }

    //Metodo que obtén o aluguer que aporta a casa.
    @Override
    public float obterAluguer() {
        return obterAlquilerValor(solar.getNombre().toLowerCase(), "casa");
    }
}