package monopoly;

import monopoly.exceptions.*;

public interface Comando {

    //empregase MonopolyException porque non se debe a un erro especifico se non a un erro qeu pode ser producido polo monopoly en xeral.

    void crearJugador(String nome, String tipoAvatar) throws MonopolyException;

    void mostrarJugadorActual() throws MonopolyException;
    void descJugador(String nomeBuscar) throws MonopolyException;
    void descCasilla(String nombre) throws MonopolyException;

    void comandoListar(String[] partes) throws MonopolyException;

    void lanzarDados() throws MonopolyException;
    void forzarDados(String valores) throws MonopolyException;

    void comprar(String nome) throws MonopolyException;
    void comandoEdificar(String[] partes) throws MonopolyException;
    void comandoVender(String[] partes) throws MonopolyException;

    void hipotecar(String[] partes) throws MonopolyException;
    void deshipotecar(String[] partes) throws MonopolyException;

    void salirCarcere() throws MonopolyException;

    void acabarTurno() throws MonopolyException;

    void estadisticasJuego();
    void estadisticasJugador(String nombreJugador) throws MonopolyException;

    void lerFicheiroComandos(String nomeFicheiro) throws MonopolyException;

    void analizarComando(String linea) throws MonopolyException;

    void proponerTrato(String comando) throws MonopolyException;
    void aceptarTrato(String id) throws MonopolyException;
    void eliminarTrato(String id) throws MonopolyException;
    void listarTratos() throws MonopolyException;

}
