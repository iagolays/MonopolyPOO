package monopoly.cartas;

import partida.*;
import monopoly.*;
import monopoly.casillas.*;
import java.util.ArrayList;

public class CartaSuerte extends Carta {

    private TipoAccion tipoAccion;

    public CartaSuerte(String descripcion, int id, TipoAccion tipoAccion) {
        super(descripcion, id);
        this.tipoAccion = tipoAccion;
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero) {
        switch(tipoAccion) {
            case AVANZAR_SOLAR19:
                avanzarASolar19(jugador, tablero);
                break;
            case IR_CARCEL:
                irCarcel(jugador, tablero);
                break;
            case LOTERIA:
                ganarLoteria(jugador);
                break;
            case PAGAR_TODOS:
                pagarATodos(jugador, tablero);
                break;
            case RETROCEDER3:
                retroceder3(jugador, tablero);
                break;
            case MULTA_MOVIL:
                multaMovil(jugador, tablero);
                break;
            case AVANZAR_TRANSPORTE:
                avanzarTransporte(jugador, tablero);
                break;
        }
    }

    private void avanzarASolar19(Jugador jugador, Tablero tablero) {
        jugador.getAvatar().moverAvatarHasta("Solar19", tablero.getPosiciones(), tablero, true);
        Casilla destino = tablero.encontrar_casilla("Solar19");
        if (destino != null) {
            try {
                if (destino instanceof Propiedad) {
                    Propiedad prop = (Propiedad) destino;
                    // Evaluación simplificada para carta
                    if (prop.getDuenho() != null && !prop.getDuenho().equals(jugador)) {
                        float alquiler = prop.alquiler(0, true); // desdeCarta=true
                        jugador.pagarJugador(prop.getDuenho(), alquiler, tablero);
                    }
                }
            } catch (Exception e) {
                // Manejar excepción
            }
        }
    }

    private void irCarcel(Jugador jugador, Tablero tablero) {
        Casilla carcel = tablero.encontrar_casilla("Carcel");
        if (carcel != null) {
            jugador.encarcelar(tablero.getPosiciones(), tablero);
        }
    }

    private void ganarLoteria(Jugador jugador) {
        jugador.sumarFortuna(1000000);
        jugador.registrarPremio(1000000);
    }

    private void pagarATodos(Jugador pagador, Tablero tablero) {
        ArrayList<Jugador> todosJugadores = tablero.getJugadores();
        int numJugadoresAPagar = 0;

        for (Jugador j : todosJugadores) {
            if (j != pagador && !j.isEnBancarrota()) {
                numJugadoresAPagar++;
            }
        }

        float total = numJugadoresAPagar * 250000f;

        if (pagador.puedePagar(total)) {
            for (Jugador j : todosJugadores) {
                if (j != pagador && !j.isEnBancarrota()) {
                    pagador.pagarJugador(j, 250000f, tablero);
                }
            }
        } else {
            pagador.sumarFortuna(-total);
            // Notificar sobre deudas
            monopoly.Juego.getConsola().imprimir("\n" + pagador.getNombre() + " non pode pagar o imposto de " + (int)total + "€.");
            monopoly.Juego.getConsola().imprimir("Opcións dispoñibles:");
            monopoly.Juego.getConsola().imprimir("   - 'hipotecar <casilla>' para obter diñeiro");
            monopoly.Juego.getConsola().imprimir("   - 'acabar turno' para declararse en bancarrota");
            pagador.setUltimoCobraAlquiler(tablero.getBanca());
        }
    }

    private void retroceder3(Jugador jugador, Tablero tablero) {
        jugador.getAvatar().moverAvatar(tablero.getPosiciones(), -3, tablero, false);
    }

    private void multaMovil(Jugador jugador, Tablero tablero) {
        float multa = 150000f;
        if (jugador.puedePagar(multa)) {
            jugador.sumarFortuna(-multa);
            jugador.registrarTasa(multa);

            Parking parking = (Parking) tablero.encontrar_casilla("Parking");
            if (parking != null) {
                parking.sumarValor(multa);
            }
        } else {
            jugador.sumarFortuna(-multa);
            // Notificar sobre deudas
            monopoly.Juego.getConsola().imprimir("\n" + jugador.getNombre() + " non pode pagar o imposto de " + (int)multa + "€.");
            monopoly.Juego.getConsola().imprimir("Opcións dispoñibles:");
            monopoly.Juego.getConsola().imprimir("   - 'hipotecar <casilla>' para obter diñeiro");
            monopoly.Juego.getConsola().imprimir("   - 'acabar turno' para declararse en bancarrota");
            jugador.setUltimoCobraAlquiler(tablero.getBanca());
        }
    }

    private void avanzarTransporte(Jugador jugador, Tablero tablero) {
        ArrayList<Casilla> todasCasillas = tablero.CasillasLineales();
        Casilla actual = jugador.getAvatar().getLugar();

        int posActual = todasCasillas.indexOf(actual);
        Casilla destino = null;

        do {
            posActual = (posActual + 1) % todasCasillas.size();
            Casilla casillaActual = todasCasillas.get(posActual);
            if (casillaActual instanceof Transporte) {
                destino = casillaActual;
                break;
            }
        } while (posActual != todasCasillas.indexOf(actual));

        if (destino != null) {
            jugador.getAvatar().moverAvatarHasta(destino.getNombre(), tablero.getPosiciones(), tablero, false);

            if (destino instanceof Transporte) {
                Transporte transporte = (Transporte) destino;
                // Evaluación simplificada para carta
                if (transporte.getDuenho() != null && !transporte.getDuenho().equals(jugador)) {
                    float alquiler = transporte.alquiler(0, true) * 2; // desdeCarta=true y doble
                    jugador.pagarJugador(transporte.getDuenho(), alquiler, tablero);
                }
            }
        }
    }

    public enum TipoAccion {
        AVANZAR_SOLAR19,
        IR_CARCEL,
        LOTERIA,
        PAGAR_TODOS,
        RETROCEDER3,
        MULTA_MOVIL,
        AVANZAR_TRANSPORTE
    }

    public TipoAccion getTipoAccion() {
        return tipoAccion;
    }
}