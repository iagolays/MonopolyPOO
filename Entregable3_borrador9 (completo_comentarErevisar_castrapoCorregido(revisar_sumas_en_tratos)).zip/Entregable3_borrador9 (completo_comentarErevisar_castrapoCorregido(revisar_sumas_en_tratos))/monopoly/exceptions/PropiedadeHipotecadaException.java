package monopoly.exceptions;

// Excepción para propiedades xa hipotecadas
public class PropiedadeHipotecadaException extends TransaccionException {
    public PropiedadeHipotecadaException(String nomePropiedade) {
        super("A propiedade " + nomePropiedade + " xa está hipotecada.");
    }
}