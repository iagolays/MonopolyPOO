package monopoly;

import partida.*;
import java.util.ArrayList;

import static monopoly.Valor.FACTOR_SERVICIO;

/// ///////////////////////////////////////////
/// /////////////////////////////////////////
///
/// EN MOFIDICACIÓN (ROSA)
///
/// ////////////////////////////////////////
/// ////////////////////////////////////////

public class Casilla {

    //Atributos:
    private String nombre; //Nombre de la casilla
    private String tipo; //Tipo de casilla (Solar, Especial, Transporte, Servicios, Comunidad, Suerte y Impuesto).
    private float valor; //Valor de esa casilla (en la mayoría será valor de compra, en la casilla parking se usará como el bote).
    private int posicion; //Posición que ocupa la casilla en el tablero (entero entre 1 y 40).
    private Jugador duenho; //Dueño de la casilla (por defecto sería la banca).
    private Grupo grupo; //Grupo al que pertenece la casilla (si es solar).
    private float impuesto; //Cantidad a pagar por caer en la casilla: el alquiler en solares/servicios/transportes o impuestos.
    private float hipoteca; //Valor otorgado por hipotecar una casilla
    private ArrayList<Avatar> avatares; //Avatares que están situados en la casilla.
    private int hipotecada;  //Nueva clase, 0 si no está hipotecada, 1 si está hipotecada y 2 si no es una casilla hipotecable

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public int getPosicion() {
        return posicion;
    }

    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }

    public Jugador getDuenho() {
        return duenho;
    }

    public void setDuenho(Jugador duenho) {
        this.duenho = duenho;
    }

    public Grupo getGrupo() {
        return grupo;
    }

    public void setGrupo(Grupo grupo) {
        this.grupo = grupo;
    }

    //Constructores:
    public Casilla() {
        this.nombre = "";
        this.tipo = "";
        this.valor = 0;
        this.posicion = 0;
        this.duenho = null;
        this.grupo = null;
        this.impuesto = 0;
        this.hipoteca = 0;
        this.avatares = new ArrayList<>();
        this.hipotecada = 0;
    }

    public Casilla(String nombre, String tipo, int posicion, float valor, Jugador duenho) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.posicion = posicion;
        this.valor = valor;
        this.duenho = duenho;
        this.grupo = null;
        this.impuesto = 0;
        this.hipoteca = 0;
        this.avatares = new ArrayList<>();

        switch (this.tipo.toLowerCase()) {
            case "solar":
                this.hipotecada = 0;
                break;
            case "serv":
            case "transporte":
                this.hipotecada = 2;
                break;
            default:
                this.hipotecada = 0;
        }
    }

    public Casilla(String nombre, int posicion, float impuesto, Jugador duenho) {
        this.nombre = nombre;
        this.posicion = posicion;
        this.duenho = duenho;
        this.impuesto = impuesto;

        this.tipo = "";
        this.valor = 0;
        this.grupo = null;
        this.hipoteca = 0;
        this.avatares = new ArrayList<>();
        this.hipotecada = 2;
    }

    public Casilla(String nombre, String tipo, int posicion, Jugador duenho) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.posicion = posicion;
        this.duenho = duenho;

        this.valor = 0;
        this.grupo = null;
        this.impuesto = 0;
        this.hipoteca = 0;
        this.avatares = new ArrayList<>();
        this.hipotecada = 2;
    }

    public void anhadirAvatar(Avatar av) {
        if (!avatares.contains(av)) {
            avatares.add(av);
            System.out.println("Avatar añadido a la lista de jugadores.\n");
        } else {
            System.out.println("El avatar ya está en la lista de jugadores. No se puede añadir de nuevo.\n");
        }
    }

    public void eliminarAvatar(Avatar av) {
        if (avatares.contains(av)) {
            avatares.remove(av);
            System.out.println("Avatar eliminado de la lista de jugadores.\n");
        } else {
            System.out.println("No se puede eliminar el avatar porque no está en la lista de jugadores.\n");
        }
    }


    public static void imprimir_en_venta(ArrayList<Casilla> casillas_lados, Jugador banca) {
        for (Casilla e : casillas_lados) {
            if (e.getDuenho() == null || e.getDuenho() == banca) {
                System.out.println("Casilla: " + e.getNombre());
                System.out.println("Tipo: " + e.getTipo());
                System.out.println("Grupo: " + (e.getGrupo() != null ? e.getGrupo().getColorGrupo() : "-"));
                System.out.println("Valor: " + e.getValor() + "€\n");
            }
        }
    }

    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada) {

        switch (this.tipo.toLowerCase()) {

            case "solar":
                if (this.duenho == null || this.duenho.equals(banca)) {
                    System.out.println("Esta casilla está en venta por " + this.valor + "€.");
                    return true;
                } else if (!this.duenho.equals(actual)) {
                    if (this.hipotecada == 1) {
                        System.out.println("La propiedad está hipotecada. No hay que hacer nada");
                    } else {
                        System.out.println("Pagas alquiler de " + this.impuesto + "€ a " + duenho.getNombre());
                        boolean si_paga = actual.puedePagar(this.impuesto);
                        if (si_paga) {
                            actual.sumarFortuna(-this.impuesto);
                            duenho.sumarFortuna(this.impuesto);
                            return true;
                        } else {
                            System.out.println("No tienes suficiente dinero para pagar el alquiler.");
                            return false;
                        }
                    }
                } else {
                    System.out.println("El jugador actual es el dueño de esta casilla.");
                    /// AÑADIR PARTE DE PROPIEDADES EN CASO DE QUE EL JUGADOR SEA EL DUEÑO DE LA CASILLA
                }
                break;

            case "serv":
                if (this.duenho == null || this.duenho.equals(banca)) {
                    System.out.println("Esta casilla está en venta por " + this.valor + "€.");
                    return true;
                } else if (!this.duenho.equals(actual)) {
                    int cantidad = (int) (4 * FACTOR_SERVICIO);
                    boolean si_paga = actual.puedePagar(cantidad);
                    if (si_paga) {
                        actual.sumarFortuna(-cantidad);
                        duenho.sumarFortuna(cantidad);
                        return true;
                    } else {
                        System.out.println("No tienes suficiente dinero para pagar el alquiler.");
                        return false;
                    }
                } else {
                    System.out.println("El jugador actual es el dueño de esta casilla.");
                }
                break;

            case "transporte":
                if (this.duenho == null || this.duenho.equals(banca)) {
                    System.out.println("Esta casilla está en venta por " + this.valor + "€.");
                    return true;
                } else if (!this.duenho.equals(actual)) {
                    System.out.println("Pagas alquiler de " + this.impuesto + "€ a " + duenho.getNombre());
                    boolean si_paga = actual.puedePagar(this.impuesto);
                    if (si_paga) {
                        actual.sumarFortuna(-this.impuesto);
                        duenho.sumarFortuna(this.impuesto);
                        return true;
                    } else {
                        System.out.println("No tienes suficiente dinero para pagar el alquiler.");
                        return false;
                    }
                } else {
                    System.out.println("El jugador actual es el dueño de esta casilla.");
                }
                break;

            default:
                System.out.println("Tipo de casilla no reconocido.");
                return true;
        }

        return true;
    }
    //
    public String getAvataresString(){
        if (avatares == null || avatares.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for(Avatar av : avatares){
            sb.append(av.getId()).append(" ");
        }
        return sb.toString();
    }
}
