package monopoly;

import partida.*;

public class TestTableroColores {

    public static void main(String[] args) {

        // Crear la banca (usando tu clase Jugador)
        Jugador banca = new Jugador(); // tu constructor vacío ya define nombre = "Banca"

        // Crear el tablero
        Tablero tablero = new Tablero(banca);

        // Imprimir el tablero con colores
        System.out.println(tablero.toString());
    }
}
