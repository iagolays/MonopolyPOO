// TODO revisar: más llaves cerradas (13) que abiertas (12)
package monopoly;

import partida.*;
import java.util.ArrayList;


class Grupo {

    //Atributos
    private ArrayList<Casilla> miembros; //Casillas miembros del grupo.
    private String colorGrupo; //Color del grupo
    private int numCasillas; //Número de casillas del grupo.


    //Constructor vacío.
    public Grupo() {

        this.miembros = new ArrayList<>();  //Inicializa la lista de casillas
        this.colorGrupo = "";               //Color vacío por defecto
        this.numCasillas = 0;               //No hay casillas aún

    }

    /*Constructor para cuando el grupo está formado por DOS CASILLAS:
     * Requiere como parámetros las dos casillas miembro y el color del grupo.
     */
    public Grupo(Casilla cas1, Casilla cas2, String colorGrupo) {

        this.miembros = new ArrayList<>();   //Inicializamos la lista de miembros
        this.miembros.add(cas1);               //Añadimos la primera casilla
        this.miembros.add(cas2);               //Añadimos la segunda casilla
        this.colorGrupo = colorGrupo;        //Asignamos el color del grupo
        this.numCasillas = miembros.size();  //Guardamos el número de casillas (2 en este caso)

        //Vinculamos cada casilla con este grupo:
        cas1.setGrupo(this);
        cas2.setGrupo(this);
    }

    /*Constructor para cuando el grupo está formado por TRES CASILLAS:
     * Requiere como parámetros las tres casillas miembro y el color del grupo.
     */
    public Grupo(Casilla cas1, Casilla cas2, Casilla cas3, String colorGrupo) {

        this.miembros = new ArrayList<>();   //Inicializamos la lista de miembros
        this.miembros.add(cas1);               //Añadimos la primera casilla
        this.miembros.add(cas2);               //Añadimos la segunda casilla
        this.miembros.add(cas3);
        this.colorGrupo = colorGrupo;        //Asignamos el color del grupo
        this.numCasillas = miembros.size();  //Guardamos el número de casillas (2 en este caso)

        //Vinculamos cada casilla con este grupo:
        cas1.setGrupo(this);
        cas2.setGrupo(this);
        cas3.setGrupo(this);

    }

    /* Metodo que añade una casilla al array de casillas miembro de un grupo.
     * Parámetro: casilla que se quiere añadir.
     */
    public void anhadirCasilla(Casilla miembro) {
        this.miembros.add(miembro);
        this.numCasillas = miembros.size();
        miembro.setGrupo(this);
    }

    public String getColorGrupo() {
        return colorGrupo;
    }

    public void setColorGrupo(String colorGrupo) {
        this.colorGrupo = colorGrupo;
    }

    public int getNumCasillas() {
        return numCasillas;
    }

    public ArrayList<Casilla> getMiembros() {
        return miembros;
    }


    /*Metodo que comprueba si el jugador pasado tiene en su haber todas las casillas del grupo:
     * Parámetro: jugador que se quiere evaluar.
     * Valor devuelto: true si es dueño de todas las casillas del grupo, false en otro caso.
     */
/*    public static boolean esDuenhoGrupo(Jugador jugador) {

    }

    public int num_casillas_grupo(Jugador jugador){

    }
}
*/
    public static String calcularColor(Casilla c) {
        int pos = c.getPosicion();
        final String RESET = "\u001B[0m";

        final String MARRON = "\u001B[38;5;130m";
        final String AZUL_CL = "\u001B[36m";
        final String ROSA = "\u001B[35m";
        final String NARANJA = "\u001B[33m";
        final String ROJO = "\u001B[31m";
        final String AMARILLO = "\u001B[93m";
        final String VERDE = "\u001B[32m";
        final String AZUL_OSC = "\u001B[34m";

        if (pos == 2 || pos == 4)
            return MARRON + c.getNombre() + RESET;
        if (pos == 7 || pos == 9 || pos == 10)
            return AZUL_CL + c.getNombre() + RESET;
        if (pos == 12 || pos == 14 || pos == 15)
            return ROSA + c.getNombre() + RESET;
        if (pos == 17 || pos == 19 || pos == 20)
            return NARANJA + c.getNombre() + RESET;
        if (pos == 22 || pos == 24 || pos == 25)
            return ROJO + c.getNombre() + RESET;
        if (pos == 27 || pos == 28 || pos == 30)
            return AMARILLO + c.getNombre() + RESET;
        if (pos == 32 || pos == 33 || pos == 35)
            return VERDE + c.getNombre() + RESET;
        if (pos == 38 || pos == 40)
            return AZUL_OSC + c.getNombre() + RESET;

        return c.getNombre(); // Si no pertenece a un grupo de color
    }
}