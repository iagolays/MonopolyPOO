package monopoly;

public class TestColores {
    public static void main(String[] args) {

        // Mostramos los colores de cada grupo según las posiciones del tablero
        System.out.println("\n🟤 GRUPO MARRÓN:");
        for (int pos : new int[]{2, 4})
            imprimirColor(pos);

        System.out.println("\n🔵 GRUPO AZUL CLARO:");
        for (int pos : new int[]{7, 9, 10})
            imprimirColor(pos);

        System.out.println("\n🌸 GRUPO ROSA:");
        for (int pos : new int[]{12, 14, 15})
            imprimirColor(pos);

        System.out.println("\n🟧 GRUPO NARANJA:");
        for (int pos : new int[]{17, 19, 20})
            imprimirColor(pos);

        System.out.println("\n🔴 GRUPO ROJO:");
        for (int pos : new int[]{22, 24, 25})
            imprimirColor(pos);

        System.out.println("\n🟡 GRUPO AMARILLO:");
        for (int pos : new int[]{27, 28, 30})
            imprimirColor(pos);

        System.out.println("\n🟢 GRUPO VERDE:");
        for (int pos : new int[]{32, 33, 35})
            imprimirColor(pos);

        System.out.println("\n🔷 GRUPO AZUL OSCURO:");
        for (int pos : new int[]{38, 40})
            imprimirColor(pos);
    }

    // Método auxiliar para crear una "casilla ficticia" y aplicar colorGrupo()
    private static void imprimirColor(int posicion) {
        // Creamos una casilla ficticia para probar (solo con nombre y posición)
        Casilla c = new Casilla("Solar" + posicion, "Solar", posicion, 0, null);

        // Usamos el método de Grupo para aplicar color
        String textoColoreado = Grupo.calcularColor(c);

        System.out.println("  Posición " + posicion + " → " + textoColoreado);
    }
}

