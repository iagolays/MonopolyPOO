package monopoly;

import partida.*;
import java.util.*;

public class TestMovimiento {

    public static void main(String[] args) throws InterruptedException {

        Jugador banca = new Jugador();
        Tablero tablero = new Tablero(banca);

        ArrayList<Avatar> avatares = new ArrayList<>();
        ArrayList<Casilla> sur = tablero.getLado(0);

        Avatar a1 = new Avatar("coche", banca, sur.get(0), avatares);
        Avatar a2 = new Avatar("sombrero", banca, sur.get(0), avatares);

        System.out.println("🟩 TABLERO INICIAL 🟩");
        System.out.println(tablero);

        Random rnd = new Random();

        for (int turno = 1; turno <= 6; turno++) {
            System.out.println("\n=== TURNO " + turno + " ===");

            int pasosA = rnd.nextInt(3) + 1;
            int pasosB = rnd.nextInt(3) + 1;

            a1.moverAvatar(tablero.getPosiciones(), pasosA);
            a2.moverAvatar(tablero.getPosiciones(), pasosB);

            System.out.println(tablero);
            Thread.sleep(1000);
        }
    }
}
