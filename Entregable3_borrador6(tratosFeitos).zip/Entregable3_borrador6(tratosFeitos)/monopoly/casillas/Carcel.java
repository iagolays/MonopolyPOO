package monopoly.casillas;
import monopoly.*;
import partida.*;

public class Carcel extends Especial{

    public Carcel(String nombre, int posicion) {
        super(nombre, posicion);
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta) {
        vecesCaida++;
        // Caer no cárcere non significa estar preso, só visita
        return true;
    }

    @Override
    public String getTipo() {
        return "carcel";
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("\ttipo: carcel,\n");
        sb.append("\tnome: \"").append(nombre).append("\",\n");
        sb.append("\tposicion: ").append(posicion).append("\n");
        sb.append("\tfianza para sair: ").append((int)Valor.CARCEL_SALIDA).append("\n");
        sb.append("}");
        return sb.toString();
    }

}
