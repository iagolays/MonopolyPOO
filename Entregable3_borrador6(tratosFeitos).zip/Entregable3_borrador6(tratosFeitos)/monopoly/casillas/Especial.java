package monopoly.casillas;
import monopoly.*;
import partida.*;

//Clase concreta que representa unha casilla especial no taboleiro (Carcel, Saida, IsACarcel)
public abstract class Especial extends Casilla {

    //Constructor
    public Especial(String nombre, int posicion) {
        super(nombre, posicion);
    }
}
