package monopoly.casillas;
import monopoly.*;
import partida.*;

public class Salida extends Especial{

    public Salida (String nombre, int posicion) {
        super(nombre, posicion);
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta) {
        vecesCaida++;
        //Non se suma o saldo porque xa se sumou ao mover o avatar
        return true;
    }

    public void realizarAccion(Jugador jugador) {
        jugador.sumarFortuna(Valor.SUMA_VUELTA);
        jugador.registrarPasoSalida(Valor.SUMA_VUELTA);
        Juego.getConsola().imprimir(jugador.getNombre() + " cobra " +
                (int)Valor.SUMA_VUELTA + "€ por pasar pola Salida");
    }

    @Override
    public String getTipo() {
        return "salida";
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("\ttipo: salida,\n");
        sb.append("\tnome: \"").append(nombre).append("\",\n");
        sb.append("\tposicion: ").append(posicion).append("\n");
        sb.append("\tpago por paso: ").append((int)Valor.SUMA_VUELTA).append("\n");
        sb.append("}");
        return sb.toString();
    }

}
