package monopoly.casillas;
import monopoly.*;
import partida.*;

public class CajaComunidad extends Accion {

    public CajaComunidad(String nombre, int posicion) {
        super(nombre, posicion);
    }

    @Override
    public void realizarAccion(Jugador jugador, Tablero tablero) {
        CartasSuerte cartas = new CartasSuerte();
        cartas.sacarCartaComunidad(jugador, tablero);
    }

    @Override
    public String getTipo() {
        return "comunidad";
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("\ttipo: cajaComunidad,\n");
        sb.append("\tnome: \"").append(nombre).append("\",\n");
        sb.append("\tposicion: ").append(posicion).append("\n");
        sb.append("}");
        return sb.toString();
    }
}
