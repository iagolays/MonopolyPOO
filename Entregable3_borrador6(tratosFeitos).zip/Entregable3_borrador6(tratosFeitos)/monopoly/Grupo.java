package monopoly;

import monopoly.casillas.*;
import partida.*;
import java.util.ArrayList;

public class Grupo {

    //Atributos
    private ArrayList<Propiedad> miembros; //Casillas membros do grupo
    private String colorGrupo;             //Cor identificativa do grupo
    private int numCasillas;               //Número total de casillas do grupo
    private float alquilerTotal;           //Estatística opcional

    // ============================================================
    // 🔹 NOVO CONSTRUCTOR → permite crear o grupo só coa cor
    //    (NECESARIO para Tablero)
    // ============================================================
    public Grupo(String colorGrupo) {
        this.miembros = new ArrayList<>();
        this.colorGrupo = colorGrupo;
        this.numCasillas = 0;
        this.alquilerTotal = 0;
    }

    public Grupo() {
        this.miembros = new ArrayList<>();
        this.colorGrupo = "";
        this.numCasillas = 0;
        this.alquilerTotal = 0;
    }

    public Grupo(Solar cas1, Solar cas2, String colorGrupo) {
        this(colorGrupo);
        anhadirCasilla(cas1);
        anhadirCasilla(cas2);
    }

    public Grupo(Solar cas1, Solar cas2, Solar cas3, String colorGrupo) {
        this(colorGrupo);
        anhadirCasilla(cas1);
        anhadirCasilla(cas2);
        anhadirCasilla(cas3);
    }

    public void anhadirCasilla(Solar miembro) {
        if (miembro != null && !miembros.contains(miembro)) {
            miembros.add(miembro);
            miembro.setGrupo(this);     // Vincúlase pola outra banda
            numCasillas = miembros.size();
        }
    }

    public boolean esDuenhoGrupo(Jugador jugador) {
        if (jugador == null || miembros.isEmpty()) return false;

        for (Propiedad p : miembros) {
            if (p.getDuenho() == null || !p.getDuenho().equals(jugador)) {
                return false;
            }
        }
        return true;
    }

    public static String calcularColor(Casilla c) {
        int pos = c.getPosicion();
        final String RESET = "\u001B[0m";

        final String MARRON   = "\u001B[38;5;130m";
        final String AZUL_CL  = "\u001B[36m";
        final String ROSA     = "\u001B[35m";
        final String NARANJA  = "\u001B[33m";
        final String ROJO     = "\u001B[31m";
        final String AMARILLO = "\u001B[93m";
        final String VERDE    = "\u001B[32m";
        final String AZUL_OSC = "\u001B[34m";

        if (pos == 1 || pos == 3) return MARRON + c.getNombre() + RESET;
        if (pos == 6 || pos == 8 || pos == 9) return AZUL_CL + c.getNombre() + RESET;
        if (pos == 11 || pos == 13 || pos == 14) return ROSA + c.getNombre() + RESET;
        if (pos == 16 || pos == 18 || pos == 19) return NARANJA + c.getNombre() + RESET;
        if (pos == 21 || pos == 23 || pos == 24) return ROJO + c.getNombre() + RESET;
        if (pos == 26 || pos == 27 || pos == 29) return AMARILLO + c.getNombre() + RESET;
        if (pos == 31 || pos == 32 || pos == 34) return VERDE + c.getNombre() + RESET;
        if (pos == 37 || pos == 39) return AZUL_OSC + c.getNombre() + RESET;

        return c.getNombre();
    }

    public String obtenerInfoEdificios() {
        StringBuilder info = new StringBuilder();
        boolean primerElemento = true;
        boolean hayPropiedades = false;

        for (Propiedad propiedad : miembros) {
            if (propiedad instanceof Solar) {
                Solar solar = (Solar) propiedad;
                if (!primerElemento) {
                    info.append(",\n");
                }
                primerElemento = false;
                hayPropiedades = true;
                Jugador duenho = propiedad.getDuenho();

                info.append("{\n");
                info.append("propiedad: ").append(propiedad.getNombre()).append(",\n");

                if (duenho != null) {
                    // Hoteles
                    info.append("hoteles: ");
                    ArrayList<String> hotelesList = obtenerEdificiosTipo(solar, "hotel");
                    info.append(hotelesList.isEmpty() ? "-" : hotelesList.toString()).append(",\n");

                    // Casas
                    info.append("casas: ");
                    ArrayList<String> casasList = obtenerEdificiosTipo(solar, "casa");
                    info.append(casasList.isEmpty() ? "-" : casasList.toString()).append(",\n");

                    // Piscinas
                    info.append("piscinas: ");
                    ArrayList<String> piscinasList = obtenerEdificiosTipo(solar, "piscina");
                    info.append(piscinasList.isEmpty() ? "-" : piscinasList.toString()).append(",\n");

                    // Pistas de deporte
                    info.append("pistasDeDeporte: ");
                    ArrayList<String> pistasList = obtenerEdificiosTipo(solar, "pista");
                    info.append(pistasList.isEmpty() ? "-" : pistasList.toString()).append(",\n");
                } else {
                    info.append("hoteles: -,\n");
                    info.append("casas: -,\n");
                    info.append("piscinas: -,\n");
                    info.append("pistasDeDeporte: -,\n");
                }

                // Calcular alquiler del solar
                float alquiler = solar.calcularAlquiler();
                info.append("alquiler: ").append((int) alquiler).append("\n");
                info.append("}");
            }
        }

        if (!hayPropiedades) {
            return "Non hai solares neste grupo.";
        }

        info.append("\n").append(obtenerInfoConstruccionPosible());
        return info.toString();
    }

    private ArrayList<String> obtenerEdificiosTipo(Solar solar, String tipo) {
        ArrayList<String> resultado = new ArrayList<>();

        // Asumimos que Solar tiene un método getIdsEdificios()
        for (String idEdificio : solar.getIdsEdificios()) {
            if (idEdificio.startsWith(tipo + "-")) {
                resultado.add(idEdificio);
            }
        }

        return resultado;
    }

    public String obtenerInfoConstruccionPosible() {
        int casasDisponibles = 0;
        boolean puedeHotel = false;
        boolean puedePiscina = false;
        boolean puedePista = false;

        for (Propiedad propiedad : miembros) {
            if (propiedad instanceof Solar) {
                Solar solar = (Solar) propiedad;
                Jugador duenho = propiedad.getDuenho();

                if (duenho != null && solar.getGrupo() != null && solar.getGrupo().esDuenhoGrupo(duenho)) {
                    // Verificar edificios existentes
                    int numCasas = contarEdificiosTipo(solar, "casa");
                    int numHoteles = contarEdificiosTipo(solar, "hotel");
                    int numPiscinas = contarEdificiosTipo(solar, "piscina");
                    int numPistas = contarEdificiosTipo(solar, "pista");

                    // Casas disponibles (máximo 4 por solar)
                    if (numCasas < 4) {
                        casasDisponibles = Math.max(casasDisponibles, 4 - numCasas);
                    }

                    // Hotel - necesita 4 casas y no tener hotel
                    if (numCasas == 4 && numHoteles == 0) {
                        puedeHotel = true;
                    }

                    // Piscina - necesita hotel
                    if (numHoteles > 0 && numPiscinas == 0) {
                        puedePiscina = true;
                    }

                    // Pista - necesita hotel y piscina
                    if (numHoteles > 0 && numPiscinas > 0 && numPistas == 0) {
                        puedePista = true;
                    }
                }
            }
        }

        // Crear texto descriptivo
        StringBuilder info = new StringBuilder();
        ArrayList<String> disponibles = new ArrayList<>();

        if (casasDisponibles > 0) {
            disponibles.add("ata " + casasDisponibles + " casas");
        }
        if (puedeHotel) {
            disponibles.add("un hotel");
        }
        if (puedePiscina) {
            disponibles.add("unha piscina");
        }
        if (puedePista) {
            disponibles.add("unha pista de deporte");
        }

        if (disponibles.isEmpty()) {
            info.append("Xa non se poden construír máis edificios neste grupo.");
        } else {
            info.append("Aínda se poden edificar ");
            for (int i = 0; i < disponibles.size(); i++) {
                info.append(disponibles.get(i));
                if (i < disponibles.size() - 2) {
                    info.append(", ");
                } else if (i == disponibles.size() - 2) {
                    info.append(" e ");
                }
            }
            info.append(".");
        }

        return info.toString();
    }

    private int contarEdificiosTipo(Solar solar, String tipo) {
        int contador = 0;
        for (String idEdificio : solar.getIdsEdificios()) {
            if (idEdificio.startsWith(tipo + "-")) {
                contador++;
            }
        }
        return contador;
    }

    public String obtenerColor() {
        switch (this.colorGrupo.toLowerCase()) {
            case "marrón":
            case "marron":
            case "brown":
                return "\u001B[38;5;130m";
            case "azul_claro":
            case "azul claro":
            case "light_blue":
                return "\u001B[36m";
            case "rosa":
            case "pink":
                return "\u001B[35m";
            case "naranja":
            case "orange":
                return "\u001B[33m";
            case "rojo":
            case "red":
                return "\u001B[31m";
            case "amarillo":
            case "yellow":
                return "\u001B[93m";
            case "verde":
            case "green":
                return "\u001B[32m";
            case "azul_oscuro":
            case "azul oscuro":
            case "dark blue":
                return "\u001B[34m";
            default:
                return "\u001B[97m";
        }
    }

    public String getColorGrupo() {
        return colorGrupo;
    }

    public ArrayList<Propiedad> getMiembros() {
        return miembros;
    }

    @Override
    public String toString() {
        return "Grupo{color='" + colorGrupo + "', casillas=" + numCasillas + "}";
    }

    public float sumarAlquilerGrupo(float cantidad) {
        this.alquilerTotal += cantidad;
        return alquilerTotal;
    }
}