package monopoly;

import partida.*; //impórtanse todas as clases do paquete partida
import monopoly.casillas.*;
import monopoly.edificios.*;
import monopoly.cartas.*;
import monopoly.Trato;
import monopoly.casillas.Propiedad;
import monopoly.exceptions.MonopolyException;

import monopoly.exceptions.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner; //Para ler a entrada do usuario
import java.io.File; // Para xestionar ficheiros
import java.io.FileNotFoundException; //obligatorio para que funcione new Scanner ao ler o arquivo

public class Juego implements Comando{

    //Atributos
    private static Consola consola; //Consola para interacción co usuario

    private ArrayList<Jugador> jugadores; //Jugadores de la partida.
    private ArrayList<Avatar> avatares; //Avatares en la partida.
    private int turno = 0; //Índice correspondiente a la posición en el arrayList del jugador (y el avatar) que tienen el turno
    private int lanzamientos; //Variable para contar el número de lanzamientos de un jugador en un turno.
    private Tablero tablero; //Tablero en el que se juega.
    private Dado dado1; //Dos dados para lanzar y avanzar casillas.
    private Dado dado2;
    private Jugador banca; //El jugador banca.
    private boolean tirado; //Booleano para comprobar si el jugador que tiene el turno ha tirado o no.
    private boolean solvente; //Booleano para comprobar si el jugador que tiene el turno es solvente, es decir, si ha pagado sus deudas.
    private boolean dadosLanzados; //Comprobar que os dados foron lanzados e xa comezou a partida

    //Atributos para o mazo de cartas
    private ArrayList<Carta> mazoSuerte;
    private ArrayList<Carta> mazoComunidad;
    private int indiceSuerte;
    private int indiceComunidad;

    private ArrayList<Trato> tratosPendentes; //lista de tratos pendentes
    private int contadorTratos = 0; // contador para xerar ids de trato

    public Juego(boolean modoInteractivo) { //constructor do menú se non se recibe un arquivo

        if (consola == null){
            consola = new ConsolaNormal(); // Inicializamos a consola estática para a interacción
        }

        // Inicializamos as listas de xogadores e avatares
        this.jugadores = new ArrayList<>();
        this.avatares = new ArrayList<>();
        this.tratosPendentes = new ArrayList<>();
        this.banca = new Jugador(); // Creamos a banca do xogo
        this.tablero = new Tablero(banca); // Creamos o taboleiro asociado á banca

        // Creamos os dous dados para o xogo
        this.dado1 = new Dado();
        this.dado2 = new Dado();

        //this.cartasSuerte = new CartasSuerte();
        this.mazoSuerte = new ArrayList<>();
        this.mazoComunidad = new ArrayList<>();
        this.indiceSuerte = 0;
        this.indiceComunidad = 0;
        inicializarMazosCartas();

        this.turno = 0; // Comeza o primeiro xogador
        this.lanzamientos = 0; // Aínda non houbo lanzamentos
        this.tirado = false; // Aínda non se lanzaron dados
        this.solvente = true; // Asumimos que é solvente inicialmente
        this.dadosLanzados = false; // Inicialmente non se lanzaron dados

        if (modoInteractivo) {
            this.iniciarPartida(); // Iniciamos a partida en modo interactivo
        }
    }

    // Metodo para iniciar unha partida: crea os xogadores e avatares
    private void iniciarPartida() {
        consola.imprimir("Benvido ao Monopoly ETSE!");
        mostrarAyuda();

        // Scanner permite ler entrada de texto. Neste caso, do teclado (System.in)
        //Scanner sc = new Scanner(System.in); (xa non se usa ao facer consola.ler)

        while (true) { // Bucle infinito
            try {
                String comando = consola.ler("\n$> ").trim();

                /*System.out.print("\n$> "); // Mostramos o prompt para o comando
                String comando = sc.nextLine().trim(); (xa non se usa ao facer consola.ler)*/

                /* sc.nextLine(), le unha liña completa do teclado ata premer Enter
                 * trim(), elimina espazos en branco do inicio e final da liña
                 */

                if (comando.equalsIgnoreCase("salir")) { //Se o comando é "salir", saímos do xogo
                    consola.imprimir("\nSaíndo do xogo...");
                    consola.imprimir("Ata pronto!");
                    break; // Saímos do bucle

                } else if (comando.startsWith("comandos ")) { //Se o comando empeza por "comandos ", lense os comandos dende un ficheiro
                    String nomeFicheiro = comando.substring(9);
                    /* substring(9), toma a parte da cadea que vai desde a posición 9 ata o final.
                     * Isto elimina a palabra "comandos " e deixa só o nome do ficheiro
                     */
                    this.lerFicheiroComandos(nomeFicheiro);

                } else { // Calquera outro comando envíase ao metodo que interpreta comandos
                    this.analizarComando(comando);
                }
            } catch (MonopolyException e) {
                consola.imprimir("Erro: " + e.getMessage());
            } catch (Exception e) {
                consola.imprimir("Erro inesperado: " + e.getMessage());
                e.printStackTrace(); // Mostramos a pila de chamadas para depuración
            }

        }
        //sc.close(); // Pechamos o scanner ao saír do xogo (xa non se usa ao facer consola.ler)
    }

    /* Metodo que interpreta o comando introducido e toma a acción correspondente
     * Parámetro: cadea de caracteres (o comando)
     */
    private void analizarComando(String comando) throws MonopolyException {
        // Separa a cadea por espazos entre palabras
        String[] partes = comando.trim().split("\\s+");
        //split("\\s+"), divide a cadea en partes usando un ou varios espazos como separador

        if (partes.length == 0){
            return; // Se está baleiro, non facemos nada
        }

        if (!this.jugadores.isEmpty()) {
            Jugador actual = this.jugadores.get(this.turno);
            if (actual.getFortuna() < 0 && !actual.isEnBancarrota()) { //se o xogador ten débedas pendentes
                consola.imprimir(actual.getNombre() + " aínda ten débedas pendentes (" + (int)Math.abs(actual.getFortuna()) + "€).");
                consola.imprimir("Use 'hipotecar <casilla>' ou 'acabar turno' para resolver.");
            }
        }

        switch (partes[0].toLowerCase()) { //Analiza o primeiro termo do comando en minúsculas

            case "crear": // Comando: crear jugador <nombre> <tipoAvatar>
                if (partes.length >= 4 && partes[1].equalsIgnoreCase("jugador")) {
                    if (dadosLanzados){
                        consola.imprimir("Non se poden crear xogadores unha vez comezada a partida.");
                    } else {
                        this.crearJugador(partes[2], partes[3]); // Creamos o novo xogador
                    }
                } else {
                    consola.imprimir("Formato incorrecto. Use: crear jugador <nome> <avatar>");
                }
                break;
            case "jugador": // Comando: jugador - mostra o xogador actual
                this.mostrarJugadorActual();
                break;
            case "listar":
                comandoListar(partes);
                break;
            case "lanzar": // Comando: lanzar dados [valor]
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("dados")) {
                    if (partes.length >= 3) {
                        this.forzarDados(partes[2]); // Lanzamento forzado
                        this.dadosLanzados = true;
                    } else {
                        this.lanzarDados(); // Lanzamento aleatorio
                        this.dadosLanzados = true;
                    }
                }else {
                    consola.imprimir("Formato incorrecto. Use: lanzar dados [valor]");
                }
                break;
            case "describir": // Comando: describir jugador <nome> ou describir <casilla>
                if (partes.length >= 3 && partes[1].equalsIgnoreCase("jugador")) {
                    this.descJugador(partes[2]); //Describir Jugador
                } else if (partes.length >= 2) {
                    this.descCasilla(partes[1]); // Describir casilla
                } else {
                    consola.imprimir("Formato incorrecto. Use: describir jugador <nome> OU describir <casilla>");
                }
                break;
            case "comprar": // Comando: comprar <propiedade>
                if (partes.length >= 2) {
                    this.comprar(partes[1]);
                } else {
                    consola.imprimir("Formato incorrecto. Use: comprar <nomeCasilla>");
                }
                break;
            case "salir": // Comando: salir carcel
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("carcel")) {
                    this.salirCarcere();
                } else {
                    consola.imprimir("Formato incorrecto. Use: salir carcel");
                }
                break;
            case "acabar": // Comando: acabar turno
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("turno")) {
                    this.acabarTurno();
                } else {
                    consola.imprimir("Formato incorrecto. Use: acabar turno");
                }
                break;
            case "ver": // Comando: ver tablero
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("tablero")) {
                    this.verTablero();
                } else {
                    consola.imprimir("Formato incorrecto. Use: ver tablero");
                }
                break;
            case "edificar":
                comandoEdificar(partes);
                break;
            case "hipotecar":
                if (partes.length >= 2) {
                    String nombreCasilla = partes[1];
                    Casilla c = this.tablero.encontrar_casilla(nombreCasilla);
                    if (c != null) {
                        c.hipotecar(this.jugadores.get(this.turno));
                    } else {
                        consola.imprimir("Non se atopou a casilla: " + nombreCasilla);
                    }
                } else {
                    consola.imprimir("Formato incorrecto. Use: hipotecar <nomeCasilla>");
                }
                break;
            case "deshipotecar":
                if (partes.length >= 2) {
                    String nombreCasilla = partes[1];
                    Casilla c = this.tablero.encontrar_casilla(nombreCasilla);
                    if (c != null) {
                        c.deshipotecar(this.jugadores.get(this.turno));
                    } else {
                        consola.imprimir("Non se atopou a casilla: " + nombreCasilla);
                    }
                } else {
                    consola.imprimir("Formato incorrecto. Use: deshipotecar <nomeCasilla>");
                }
                break;
            case "vender":
                if (partes.length >= 4){
                    String tipo = partes[1];
                    String nombreCasilla = partes[2];
                    int cantidad = Integer.parseInt(partes[3]); //convertimos a enteiro o numero pasado por comandos
                    Casilla c = this.tablero.encontrar_casilla(nombreCasilla);
                    if (c != null) {
                        Solares.venderEdificio(c, this.jugadores.get(this.turno), tipo, cantidad);
                    } else {
                        consola.imprimir("Non se atopou a casilla: " + nombreCasilla);
                    }
                } else {
                    consola.imprimir("Formato incorrecto. Use: vender <tipo> <nomeCasilla> <cantidade>");
                }
                break;
            case "estadisticas":
                if (partes.length >= 2) {
                    this.estadisticasJugador(partes[1]);
                } else {
                    this.estadisticasJuego();
                }
                break;
            case "trato":  // ex: trato Maria: cambiar (Solar1, Solar14 y 300000)
                proponerTrato(comando);  // pásase a liña completa
                break;

            case "aceptar":  // ex: aceptar trato20
                if (partes.length < 2) {
                    consola.imprimir("Debe especificar o ID do trato.");
                } else {
                    aceptarTrato(partes[1]);  // partes[1] = trato20
                }
                break;

            case "eliminar":  // ex: eliminar trato20
                if (partes.length < 2) {
                    consola.imprimir("Debe especificar o ID do trato.");
                } else {
                    eliminarTrato(partes[1]);
                }
                break;

            case "tratos":   // lista tratos do xogador actual
                listarTratos();
                break;
            default:
                consola.imprimir("Comando non recoñecido: " + comando);
        }
    }

    /* Metodo que realiza as accións asociadas ao comando 'describir jugador'
     * Parámetro: comando introducido
     */
    private void descJugador(String nombreBuscar) {

        Jugador jugador = null;

        for (Jugador j: jugadores) { // Buscamos o xogador na lista de xogadores
            if (j.getNombre().equalsIgnoreCase(nombreBuscar)) {
                jugador = j;
                break;
            }
        }

        if (jugador == null) { // Se non atopamos o xogador, mostramos erro
            consola.imprimir("Non existe ningún xogador con ese nome.");
            return;
        }
        consola.imprimir(jugador.infoJugador()); // Mostramos a información do xogador
    }

    /* Metodo que realiza as accións asociadas ao comando 'describir nombre_casilla'
     * Parámetros: nome da casilla a describir
     */
    public void descCasilla(String nombre) {
        Casilla c = this.tablero.encontrar_casilla(nombre); // Buscamos a casilla no taboleiro
        if (c == null) { // Se non se atopa a casilla, mostramos erro
            consola.imprimir("Non se atopou a casilla: " + nombre);
            return;
        }
        consola.imprimir(c.infoCasilla()); // Mostramos a información da casilla
    }

    private void comandoEdificar(String[] partes) {
        if (this.jugadores.isEmpty()) {
            consola.imprimir("Non hai xogadores na partida.");
            return;
        }

        if (partes.length < 2) {
            consola.imprimir("Formato incorrecto. Use: edificar <tipo>");
            consola.imprimir("Tipos válidos: casa, hotel, piscina, pista");
            return;
        }

        Jugador jugadorActual = this.jugadores.get(this.turno);
        String tipoEdificio = partes[1].toLowerCase();

        // Validar tipo de edificio
        if (!tipoEdificio.equals("casa") && !tipoEdificio.equals("hotel") && !tipoEdificio.equals("piscina") && !tipoEdificio.equals("pista")) {
            consola.imprimir("Tipo de edificio non válido. Use: casa, hotel, piscina ou pista.");
            return;
        }

        // Verificar que o xogador está nun solar
        Casilla casillaActual = jugadorActual.getAvatar().getLugar();
        if (casillaActual == null || !"solar".equalsIgnoreCase(casillaActual.getTipo())) {
            consola.imprimir("Só podes edificar nun solar e debes estar na casilla onde queres edificar.");
            return;
        }

        // Chamar ao metodo de construción en Solares
        boolean exito = Solares.construirEdificio(casillaActual, jugadorActual, tipoEdificio);

        if (exito) {
            // Actualizar o taboleiro para mostrar os cambios
            consola.imprimir(this.tablero.toString()); //engadimos .toString() para que non de erro xa que tablero é un obxecto
        }
    }

    private void comandoListar(String[] partes) {
        if (partes.length < 2){
            consola.imprimir("Formato incorrecto. Use: listar jugadores|edificios|enventa");
            return;
        }

        switch (partes[1].toLowerCase()) {
            case "jugadores":
                listarJugadores();
                break;
            case "edificios":
                if (partes.length == 2) {
                    listarTodosEdificios();
                } else {
                    // Reconstruimos o nombre completo do grupo
                    StringBuilder colorGrupoBuilder = new StringBuilder();
                    for (int i = 2; i < partes.length; i++) {
                        if (i > 2){
                            colorGrupoBuilder.append(" "); // añadimos espacio entre palabras
                        }
                        colorGrupoBuilder.append(partes[i]);
                    }
                    listarEdificiosGrupo(colorGrupoBuilder.toString());
                }
                break;
            case "enventa":
                listarVenta();
                break;
            default:
                consola.imprimir("Subcomando listar non recoñecido: " + partes[1]);
        }
    }

    private void listarTodosEdificios() {
        boolean hayEdificios = false;

        for (Jugador j : jugadores) {
            // Listar directamente os edificios do xogador (teñen IDs únicos)
            for (String idEdificio : j.getEdificios()) {
                // Extraer información do ID
                String[] partes = idEdificio.split("-"); // Formato: tipo-numero
                if (partes.length >= 2) {
                    String tipo = partes[0]; // Tipo de edificio (casa, hotel, piscina, pista)

                    // Buscar casilla correspondente a este edificio
                    Casilla casillaEdificio = null;
                    for (Casilla propiedad : j.getPropiedades()) { // Buscamos entre as propiedades do xogador
                        if ("solar".equalsIgnoreCase(propiedad.getTipo())) {
                            // Verificar se esta propiedade ten edificios
                            Solares.DatosEdificios edificios = propiedad.getDatosedificios();
                            if (edificios != null) {
                                boolean tieneEsteTipo = false;
                                switch (tipo.toLowerCase()) {
                                    case "casa":
                                        tieneEsteTipo = edificios.getNumCasas() > 0;
                                        break;
                                    case "hotel":
                                        tieneEsteTipo = edificios.getNumHoteles() > 0;
                                        break;
                                    case "piscina":
                                        tieneEsteTipo = edificios.getNumPiscinas() > 0;
                                        break;
                                    case "pista":
                                        tieneEsteTipo = edificios.getNumPistas() > 0;
                                        break;
                                }
                                if (tieneEsteTipo) {
                                    casillaEdificio = propiedad;
                                    break;
                                }
                            }
                        }
                    }

                    if (casillaEdificio != null) {
                        // Calcular coste dependendo do tipo
                        float coste = 0;
                        switch (tipo.toLowerCase()) {
                            case "casa":
                                coste = Solares.obtenerPrecioCasa(casillaEdificio.getNombre());
                                break;
                            case "hotel":
                                coste = Solares.obtenerPrecioHotel(casillaEdificio.getNombre());
                                break;
                            case "piscina":
                                coste = Solares.obtenerPrecioPiscina(casillaEdificio.getNombre());
                                break;
                            case "pista":
                                coste = Solares.obtenerPrecioPista(casillaEdificio.getNombre());
                                break;
                        }

                        consola.imprimir(Solares.generarInfoEdificio(idEdificio, j, casillaEdificio, coste));
                        hayEdificios = true;
                    }
                }
            }
        }

        if (!hayEdificios) {
            consola.imprimir("Non hai edificios construidos.");
        }
    }


    private void listarEdificiosGrupo(String colorGrupo) {
        boolean hayEdificios = false; // bandera para saber si hay edificios
        colorGrupo = colorGrupo.trim().toLowerCase(); // normalizamos a color do grupo

        // Buscamos o grupo correspondente (para poder obter a info final de construción)
        ArrayList<Grupo> gruposEncontrados = new ArrayList<>(); // lista para almacenar grupos encontrados, e non repetilos
        for (Jugador jugador : jugadores) {
            for (Casilla propiedad : jugador.getPropiedades()) {
                Grupo grupo = propiedad.getGrupo(); // Obtemos o grupo da propiedade
                if (grupo != null && grupo.getColorGrupo().equalsIgnoreCase(colorGrupo) && !gruposEncontrados.contains(grupo)) { // Comprobamos que o grupo non estea xa na lista
                    gruposEncontrados.add(grupo);
                }
            }
        }
        if (gruposEncontrados.isEmpty()) {
            consola.imprimir("Non se atopou ningún edificio no grupo ca color " + colorGrupo + ".");
            return;
        }
        // Mostrar información de cada grupo
        for (Grupo grupo : gruposEncontrados) {
            String info = grupo.obtenerInfoEdificios();
            if (!info.contains("propiedad:") || info.contains("casa-") || info.contains("hotel-") || info.contains("piscina-") || info.contains("pista-")) {
                hayEdificios = true;
            }
            consola.imprimir(info);
        }
        if (!hayEdificios) {
            consola.imprimir("Non hai casillas con edificios construidos no grupo " + colorGrupo + ".");
        }
    }

    // Metodo que executa todas as accións relacionadas co comando 'lanzar dados'
    private void lanzarDados() {
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            consola.imprimir("Non hai xogadores na partida, non se poden lanzar os dados.");
            return;
        } else if (this.jugadores.size() < 2){
            consola.imprimir("Non se poden lanzar os dados ata que haxa polo menos 2 xogadores.");
            return;
        }

        Jugador actual = this.jugadores.get(this.turno); // Obtenemos o xogador actual

        if (actual.isEnCarcel()) { // Verificamos se o xogador está no cárcere
            if (!this.tirado){
                //intenta salir de carcel
                int resultado = actual.intentarSalirCarcel(this.dado1, this.dado2, this.tablero, false, 0, 0);
                if (resultado == -1){
                    return; //está en bancarrota, non pode sair
                } else if (resultado == 0) {
                    //segue no carcere, non se move
                    this.tirado = true;
                    return;
                }
                else {
                    // resultado == 1: Sae do carcere e movese cos dados
                    int valor1 = this.dado1.getValor(); // Usamos o valor xa tirado
                    int valor2 = this.dado2.getValor();
                    this.tirado = true;
                    gestionarTirada(actual, valor1, valor2, this.tablero);
                }
            }else {
                consola.imprimir("Xa se tiraron os dados, remata o turno.");
            }
        } else {
            if (!this.tirado){ //só se non se tirou con anterioridade
                // Facemos a tirada aleatoria dos dados
                int valor1 = this.dado1.hacerTirada();
                int valor2 = this.dado2.hacerTirada();

                gestionarTirada(actual, valor1, valor2, this.tablero);
            } else {
                consola.imprimir("Xa se tiraron os dados, remata o turno.");
            }
        }
    }

    /* Metodo que executa todas as accións realizadas co comando 'comprar nombre_casilla'
     * Parámetro: cadea de caracteres co nome da casilla
     */
    private void comprar(String nombre) throws NonExisteCasillaException, DiñeiroInsuficienteException, PropiedadeNonPertenceException {
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            consola.imprimir("Non hai xogadores na partida, non se poden comprar casillas.");
            return;
        }

        Jugador jugadorActual = this.jugadores.get(this.turno); // Xogador que ten o turno
        Casilla casilla = this.tablero.encontrar_casilla(nombre); // Buscamos a casilla no taboleiro

        if (casilla == null) { // Verificamos que a casilla exista
            consola.imprimir("Propiedade non atopada: " + nombre);
            return;
        }

        // Verificamos que o xogador está na casilla que quere comprar
        if (!jugadorActual.getAvatar().getLugar().equals(casilla)) {
            //equalsIgnoreCase só funciona con String, pero casilla é un obxecto Casilla polo que se usa equals
            consola.imprimir("Só podes comprar a casilla na que estás actualmente: " + jugadorActual.getAvatar().getLugar().getNombre());
            return;
        }

        // Verificamos que a casilla sexa comprable
        if (!casilla.getTipo().equalsIgnoreCase("solar") && !casilla.getTipo().equalsIgnoreCase("transporte") &&
                !casilla.getTipo().equalsIgnoreCase("servicio")) {
            consola.imprimir("Non se pode comprar a casilla " + nombre + ".");
            return;
        }

        // Verificamos que a casilla non teña dono ou sexa da banca
        if (casilla.getDuenho() != null && !"Banca".equalsIgnoreCase(casilla.getDuenho().getNombre())) {
            consola.imprimir("A casilla " + nombre + " xa ten propietario.");
            return;
        }
        casilla.comprarCasilla(jugadorActual, this.banca); // Chamamos ao metodo de compra da casilla
    }

    // Metodo que executa todas as accións relacionadas co comando 'salir carcel'
    private void salirCarcere() {
        if (this.jugadores.isEmpty()){
            return; // Verificamos que haxa xogadores
        }

        Jugador jugador = this.jugadores.get(this.turno); // Xogador que ten o turno

        if (!jugador.isEnCarcel()) { // Verificamos que o xogador estea no cárcere
            consola.imprimir(jugador.getNombre() + " non está no cárcere.");
            return;
        }

        jugador.salirCarcel(tablero);
    }

    // Metodo que realiza as accións asociadas ao comando 'listar enventa'
    private void listarVenta() {
        boolean hayPropiedades = false; // Inicializamos unha bandeira para saber se hai propiedades en venda

        // Percorremos todos os lados do taboleiro
        for (int lado = 0; lado < 4; lado++) {
            ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
            for (Casilla casilla : casillasLado) { // Percorremos cada casilla do lado actual
                String infoVenta = casilla.casEnVenta(); // Obtenemos a información de venda da casilla
                if (!infoVenta.isEmpty()) { // Se a casilla está en venda, mostramos a información
                    consola.imprimir(infoVenta);
                    hayPropiedades = true;
                }
            }
        }

        if (!hayPropiedades) { // Se non hai propiedades en venda, mostramos mensaxe
            consola.imprimir("Non hai propiedades en venda");
        }
    }

    // Metodo que realiza as accións asociadas ao comando 'listar jugadores'
    private void listarJugadores() {
        if (jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            consola.imprimir("Non hai xogadores na partida.");
            return;
        }

        // Percorremos todos os xogadores e mostramos a súa información
        for (Jugador j : this.jugadores) {
            consola.imprimir(j.infoJugador()); // Mostramos a información dos xogadores
        }
    }

    // Metodo que realiza as accións asociadas ao comando 'acabar turno'
    private void acabarTurno() {
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            consola.imprimir("Non hai xogadores");
            return;
        }
        Jugador actual = this.jugadores.get(this.turno);
        //verificamos que o xogador actual teña tirado e sexa solvente
        if (!this.tirado) {
            consola.imprimir("Non podes acabar o turno sen lanzar os dados.");
            return;
        }
        boolean tenDebedas = (actual.getFortuna() < 0 && !actual.isEnBancarrota());

        if (tenDebedas) {
            Jugador pagarA = detectarPagar (actual); //detecta a quen lle debe o xogador actual
            actual.declararBancarrota(this.tablero, pagarA);
            xestionarBancarrota(actual);
        } else {
            this.turno = (this.turno + 1) % this.jugadores.size(); // Avanzamos ao seguinte xogador
            this.tirado = false; // Marcamos que non se lanzaron dados no novo turno
            this.solvente = true; // Asumimos que o novo xogador é solvent

            Jugador siguiente = this.jugadores.get(this.turno); // Obtenemos o novo xogador actual
            consola.imprimir("É o turno de: " + siguiente.getNombre() + "."); // Mostramos quen é o novo xogador
            consola.imprimir("Estado actual: " + siguiente); //toString creado en jugador
        }
    }

    //Metodo para detectar a quen debe pagar o xogador en bancarrota e pasar as propiedades
    private Jugador detectarPagar(Jugador deudor) {
        if (deudor.getUltimoCobraAlquiler() != null) {
            return deudor.getUltimoCobraAlquiler();
        } else {
            return this.banca;
        }
    }

    // Metodo para ler o ficheiro cos comandos introducidos
    public void lerFicheiroComandos(String nomeFicheiro) {
        File ficheiro = new File(nomeFicheiro); // Creamos un obxecto File co nome do ficheiro

        if (!ficheiro.exists()) { // Comprobamos se o ficheiro existe
            consola.imprimir("O ficheiro non existe: " + nomeFicheiro);
            return;
        }

        Scanner scanner = null; //declara o scanner pero non o inicializa
        try {
            scanner = new Scanner(ficheiro); // Ábrese o ficheiro en modo lectura
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine().trim(); //lemos a seguinte liña e eniminamos espazos en branco ao inicio/fin
                if (!linea.isEmpty() && !linea.startsWith("#")) { // Ignoramos liñas baleiras e comentarios
                    consola.imprimir("$> " + linea); // Mostramos o comando que se vai executar
                    this.analizarComando(linea); // Procesamos o comando
                }
            }
        } catch (FileNotFoundException e) { // Mostramos erro se non se pode abrir o ficheiro
            consola.imprimir("Non se pode abrir o ficheiro: " + e.getMessage());
        } finally {
            if (scanner != null) {
                scanner.close(); // Aseguramos que pechamos o scanner
            }
        }
    }

    // Metodo auxiliar para procesar o movemento despois de lanzar dados
    private void procesarMovimento(Jugador actual, int total) {
        Avatar avatar = actual.getAvatar(); // Obtenemos o avatar do xogador actual

        // Movemos o avatar polo taboleiro
        ArrayList<ArrayList<Casilla>> todasCasillas = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            todasCasillas.add(this.tablero.getLado(i));
        }
        //moverAvatar xa verifica se pasa por "Salida"
        avatar.moverAvatar(todasCasillas, total, tablero, true);

        Casilla casillaActual = avatar.getLugar(); // Obtenemos a nova casilla

        // Si cae en Suerte o Comunidad, llamamos a las cartas
        String tipo = casillaActual.getTipo().toLowerCase();

        if ("suerte".equals(tipo)) {
            cartasSuerte.sacarCartaSuerte(actual, tablero, jugadores);
            this.solvente = !actual.isEnBancarrota();
            if (actual.getFortuna() < 0 && solvente){
                consola.imprimir(actual.getNombre() + " ten débedas pendentes tras a carta de Suerte.");
            }
        } else if ("comunidad".equals(tipo)) {
            cartasSuerte.sacarCartaComunidad(actual, tablero);
            this.solvente = !actual.isEnBancarrota();
            if (actual.getFortuna() < 0 && solvente){
                consola.imprimir(actual.getNombre() + " ten débedas pendentes tras a carta de Comunidad.");
            }
        } else {
            this.solvente = casillaActual.evaluarCasilla(actual, this.banca, total, this.tablero, false);
        }

        // Mostrar mensaje de déudas solo si hay
        if (actual.getFortuna() < 0 && this.solvente){
            consola.imprimir(actual.getNombre() + " ten débedas pendentes.");
        }

        consola.imprimir(this.tablero.toString()); // Mostramos o taboleiro actualizado
        this.tirado = true; // Marcamos que xa se lanzaron dados neste turno
    }

    //metodo para dobles
    public void gestionarTirada(Jugador actual, int valor1, int valor2, Tablero tablero) {
        int total = valor1 + valor2; // Calculamos o total da tirada

        if (valor1 == valor2) { // Comprobar dobres
            actual.incrementarDobles(); // Incrementamos dobles consecutivos

            if (actual.getDoblesConsecutivos() == 3) { // Tres dobles consecutivos implica que debe ir ao cárcere
                consola.imprimir(actual.getNombre() + " sacou dobles 3 veces seguidas, vai directamente ao cárcere.");
                actual.encarcelar(tablero.getPosiciones(), tablero);
                actual.resetearDobles();
                this.tirado = true;
                acabarTurno();
                return;
            } else {
                this.procesarMovimento(actual, total);
                consola.imprimir("¡Dobles! " + actual.getNombre() + " tira outra vez.");
                this.lanzamientos++;

                //permitir novo lanzamiento se é solvente
                this.tirado = false;
                if (actual.isEnBancarrota() || actual.getFortuna() < 0) {
                    this.tirado = true; // Non pode tirar de novo se está en bancarrota
                    xestionarBancarrota(actual);
                }
                return;
            }
        } else { // No son dobles
            actual.resetearDobles();
            this.procesarMovimento(actual, total);
            this.lanzamientos++;
            this.tirado = true; // Turno terminado
        }
        //comprobamos que non esté en bancarrota
        if (actual.getFortuna() <= 0) {
            consola.imprimir(actual.getNombre() + " ten débedas pendentes.");
            // Non declarar bancarrota automática - esperar a que o xogador decida
        }
    }

    // Metodo para lanzar dados con valores forzados
    private void forzarDados(String valores) {
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            consola.imprimir("Non hai xogadores na partida");
            return;
        } else if (this.jugadores.size() < 2){
            consola.imprimir("Non se poden lanzar os dados ata que haxa polo menos 2 xogadores.");
            return;
        }

        Jugador actual = this.jugadores.get(this.turno); // Obtenemos o xogador actual
        int[] valoresDados = Dado.procesarTiradaForzada(valores); // Procesamos o formato "2+4"

        if (valoresDados == null) {
            consola.imprimir("Formato de tirada forzada inválido. Use 'numero + numero'");
            return;
        }

        if (actual.isEnCarcel()) { // Verificamos se o xogador está no cárcere
            if (!this.tirado) {
                //intenta salir de carcel
                int resultado = actual.intentarSalirCarcel(this.dado1, this.dado2, this.tablero, true, valoresDados[0], valoresDados[1]);
                if (resultado == -1){
                    return; //está en bancarrota, non pode sair
                } else if (resultado == 0) {
                    //segue no carcere, non se move
                    this.tirado = true;
                    return;
                }
                else {
                    // resultado == 1: Sae do carcere e movese cos dados
                    this.tirado = true;
                    gestionarTirada(actual, valoresDados[0], valoresDados[1], this.tablero);
                }
            } else {
                consola.imprimir("Os dados xa foron tirados, remate o turno.");
            }
        } else {
            if (!tirado) {
                //forzamos valores dos dados
                this.dado1.lanzarForzado(valoresDados[0]);
                this.dado2.lanzarForzado(valoresDados[1]);

                this.tirado = true;
                gestionarTirada(actual, valoresDados[0], valoresDados[1], tablero);
            } else {
                consola.imprimir("Os dados xa foron tirados, remate o turno.");
            }
        }
    }

    // Metodo para mostrar o xogador actual
    private void mostrarJugadorActual() {
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            consola.imprimir("Non hai xogadores na partida");
            return;
        }

        Jugador actual = this.jugadores.get(this.turno); // Obtenemos o xogador actual
        consola.imprimir("É o turno de: " + actual.getNombre() + "."); // Mostramos quen é o novo xogador
        consola.imprimir("Estado actual: " + actual); //toString creado en jugador
    }

    // Metodo para crear un xogador
    private void crearJugador(String nombre, String tipoAvatar) {
        //Verificamos se xa existen demasiados xogadores
        if (this.jugadores.size() >= 4) {
            consola.imprimir("Xa hai 4 xogadores, non poden engadrse mais.");
            return;
        }

        for (Jugador j : this.jugadores) { // Verificamos se xa existe un xogador con ese nome
            if (j.getNombre().equalsIgnoreCase(nombre)) {
                consola.imprimir("Xa existe un xogador con ese nome");
                return;
            }
        }

        //Validamos que o tipo de avatar sexa correcto
        String[] tiposValidos = {"Coche", "Esfinge", "Sombrero", "Pelota"};
        boolean tipoValido = false; //poñemos unha bandeira
        for (String tipo : tiposValidos) {
            if (tipo.equalsIgnoreCase(tipoAvatar)) {
                tipoValido = true;
                break;
            }
        }
        if (!tipoValido) {
            consola.imprimir("Tipo de avatar non válido. Usa: Coche, Esfinge, Sombrero ou Pelota.");
            return;
        }

        //Comprobamos que o tipo de avatar non estea xa collido
        for (Avatar av : this.avatares) {
            if (av.getTipo().equalsIgnoreCase(tipoAvatar)) {
                consola.imprimir("O tipo de avatar '" + tipoAvatar + "' xa está en uso por outro xogador.");
                return;
            }
        }

        Casilla salida = this.tablero.encontrar_casilla("Salida"); // Buscamos a casilla de salida
        if (salida == null) {
            consola.imprimir("Non se atopou a casilla Salida");
            return;
        }

        // Creamos o novo xogador
        Jugador novoJugador = new Jugador(nombre, tipoAvatar, salida, this.avatares);
        this.jugadores.add(novoJugador); // Engadimos o xogador á lista
        this.avatares.add(novoJugador.getAvatar()); // Engadimos o avatar á lista

        consola.imprimir("{"); // Mostramos a confirmación da creación
        consola.imprimir("nome: " + novoJugador.getNombre() + ",");
        consola.imprimir("avatar: " + novoJugador.getAvatar().getId());
        consola.imprimir("}");

        consola.imprimir(this.tablero.toString()); // Mostramos o taboleiro actualizado
    }

    // Metodo auxiliar para ver o taboleiro
    private void verTablero() {
        consola.imprimir(this.tablero.toString());
    }

    private void xestionarBancarrota(Jugador jugadorEnBancarrota) {
        this.jugadores.remove(jugadorEnBancarrota); //Remove xa verifica que este na lista

        if (this.jugadores.isEmpty()) {
            consola.imprimir("\nTodos os xogadores en bancarrota! Xogo rematado.");
            System.exit(0);
        }
        // Axustar o turno se é necesario
        if (this.turno >= this.jugadores.size()) {
            this.turno = 0;
        }

        // Se só queda un xogador, declaramos o gañador e rematamos
        if (this.jugadores.size() == 1) {
            Jugador ganador = this.jugadores.get(0); //O único xogador restante é o gañador
            consola.imprimir("\nO xogo rematou!");
            consola.imprimir("O gañador é " + ganador.getNombre() + " cunha fortuna de " + (int)ganador.getFortuna() + "€.");
            consola.imprimir("\nEstatísticas finais:");
            consola.imprimir(ganador.mostrarEstadisticas());
            System.exit(0);
        } else {
            consola.imprimir("Quedan " + this.jugadores.size() + " xogadores en xogo.\n");

            Jugador siguiente = this.jugadores.get(this.turno); // Obtenemos o novo xogador actual
            consola.imprimir("É o turno de: " + siguiente.getNombre() + "."); // Mostramos quen é o novo xogador
            consola.imprimir("Estado actual: " + siguiente); //toString creado en jugador
        }
    }


    private void estadisticasJugador(String nombreJugador) {
        Jugador jugador = null;
        for (Jugador j : jugadores) {
            if (j.getNombre().equalsIgnoreCase(nombreJugador)) {
                jugador = j;
                break;
            }
        }
        if (jugador != null) {
            consola.imprimir(jugador.mostrarEstadisticas());
        } else {
            consola.imprimir("Xogador non atopado: " + nombreJugador);
        }
    }

    private void estadisticasJuego() {
        consola.imprimir("{\n" +
                "casillaMasRentable: " + obtenerCasillaMasRentable() + ",\n" +
                "grupoMasRentable: " + obtenerGrupoMasRentable() + ",\n" +
                "casillaMasFrecuentada: " + obtenerCasillaMasFrecuentada() + ",\n" +
                "jugadorMasVueltas: " + obtenerJugadorMasVueltas() + ",\n" +
                "jugadorEnCabeza: " + obtenerJugadorEnCabeza() + "\n" +
                "}");
    }

    // Métodos auxiliares para estadísticas (implementación básica)
    private String obtenerCasillaMasRentable() {
       float maxRentabilidad = 0;
       String casillaMasRentable = "-";

       //Percorrer todas as casillas do taboleiro
        for (int lado = 0; lado < 4; lado++) {
            ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
            for (Casilla casilla : casillasLado) {
                if (casilla != null){
                    // A rentabilidade mídese polo total de alugueis cobrados
                    float rentabilidad = casilla.getTotalAlquileresCobrados();
                    if (rentabilidad > maxRentabilidad) {
                        maxRentabilidad = rentabilidad;
                        casillaMasRentable = casilla.getNombre();
                    }
                }
            }
        }
        return casillaMasRentable;
    }

    private String obtenerGrupoMasRentable() {
        //Map para almacenar a rentabilidade de cada grupo
        Map<String, Float> rentabilidadesGrupos = new HashMap<>();
        Map<String, String> nombresGrupos = new HashMap<>();

        // Percorrer todas as casillas do taboleiro
        for (int lado = 0; lado < 4; lado++) {
            ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
            for (Casilla casilla : casillasLado) {
                if (casilla != null && casilla.getGrupo() != null) {
                    String colorGrupo = casilla.getGrupo().getColorGrupo(); // Obtemos a color do grupo
                    float alquileresCobrados = casilla.getTotalAlquileresCobrados(); // Obtemos o total de alugueis cobrados na casilla

                    // Acumulamos a rentabilidade do grupo
                    rentabilidadesGrupos.put(colorGrupo, rentabilidadesGrupos.getOrDefault(colorGrupo, 0f) + alquileresCobrados); // Sumamos alugueis
                    nombresGrupos.put(colorGrupo, colorGrupo); // Gardamos o nome do grupo
                }
            }
        }
        //Encontrar o grupo con maior rentabilidade
        String grupoMasRentable = "-";
        float maxRentabilidad = 0;
        for (Map.Entry<String, Float> entrada : rentabilidadesGrupos.entrySet()) { // Percorremos as entradas do mapa
            if (entrada.getValue() > maxRentabilidad) { // Comprobamos se é a de maior rentabilidade
                maxRentabilidad = entrada.getValue();
                grupoMasRentable = nombresGrupos.get(entrada.getKey());
            }
        }
        return grupoMasRentable;
    }

    private String obtenerCasillaMasFrecuentada() {
        int maxVeces = 0;
        String casillaMasFrecuentada = "-";

        // Percorrer todas as casillas do taboleiro
        for (int lado = 0; lado < 4; lado++) {
            ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
            for (Casilla casilla : casillasLado) {
                if (casilla != null && casilla.getVecesCaida() > maxVeces) { // Comprobamos se é a de maior número de veces caídas
                    maxVeces = casilla.getVecesCaida();
                    casillaMasFrecuentada = casilla.getNombre();
                }
            }
        }
        return casillaMasFrecuentada;
    }

    private String obtenerJugadorMasVueltas() {
        int maxVueltas = 0;
        String jugadorMasVueltas = "-";

        for (Jugador j : jugadores) {
            if (j.getVueltas() > maxVueltas) { // Comprobamos se é o de maior número de voltas
                maxVueltas = j.getVueltas();
                jugadorMasVueltas = j.getNombre();
            }
        }
        return jugadorMasVueltas;
    }

    private String obtenerJugadorEnCabeza() {
        float maxFortuna = 0;
        String jugadorEnCabeza = "-";

        for (Jugador j : jugadores) {
            // Calcular fortuna total = diñeiro + valor propiedades + valor edificios
            float fortunaTotal = j.getFortuna();

            //sumar valor propiedades + edificios
            for (Casilla propiedad : j.getPropiedades()) {
                fortunaTotal += propiedad.getValor();
                Solares.DatosEdificios edificios = propiedad.getDatosedificios();
                if (edificios != null) {
                    Solares.DatosSolar datos = Solares.obtenerDatos(propiedad.getNombre());
                    if (datos != null) { // Sumamos o valor dos edificios
                        fortunaTotal += edificios.getNumCasas() * datos.getValorCasa();
                        fortunaTotal += edificios.getNumHoteles() * datos.getValorHotel();
                        fortunaTotal += edificios.getNumPiscinas() * datos.getValorPiscina();
                        fortunaTotal += edificios.getNumPistas() * datos.getValorPista();
                    }
                }
            }
            if (fortunaTotal > maxFortuna) { // Comprobamos se é o de maior fortuna total
                maxFortuna = fortunaTotal;
                jugadorEnCabeza = j.getNombre();
            }
        }
        return jugadorEnCabeza;
    }

    public Tablero getTablero() {
        return this.tablero;
    }

    //Metodo estático para aceder á consola dende outras clases
    public static ConsolaNormal getConsola() {
        return consola;
    }


    //metodos para os tratos

    private int generarIdTrato() {
        return contadorTratos++; // devolve e incrementa o contador
    }


    public void proponerTrato(Jugador propone, Jugador receptor,
                              Propiedad ofrecida, Propiedad pedida,
                              float dineroOfrecido, float dineroPedido)
            throws MonopolyException {

        // validar propiedad ofrecida
        if (ofrecida != null && ofrecida.getDuenho() != propone)
            throw new MonopolyException("Non se pode propoñer o trato: " +
                    ofrecida.getNombre() + " non pertence a " + propone.getNombre());

        // validar propiedad pedida
        if (pedida != null && pedida.getDuenho() != receptor)
            throw new MonopolyException("Non se pode propoñer o trato: " +
                    pedida.getNombre() + " no pertence a " + receptor.getNombre());

        // validar diñeiro ofrecido
        if (dineroOfrecido > 0 && !propone.puedePagar(dineroOfrecido))
            throw new MonopolyException(propone.getNombre() +
                    " non ten cartos suficientes para propoñer o trato.");

        // crear ID → trato20, trato21, etc
        String id = "trato" + generarIdTrato();

        Trato t = new Trato(id, propone, receptor,
                ofrecida, pedida, dineroOfrecido, dineroPedido);

        receptor.recibirTrato(t);
        propone.proponerTrato(t);

        consola.imprimir(propone.getNombre() +
                ", ¿douche " +
                (ofrecida != null ? ofrecida.getNombre() : (int)dineroOfrecido + "€") +
                " e ti dasme " +
                (pedida != null ? pedida.getNombre() : (int)dineroPedido + "€") +
                "?");
    }

    public void aceptarTrato(Jugador receptor, String id) throws MonopolyException {

        Trato t = receptor.buscarTratoPendientePorId(id);
        if (t == null)
            throw new MonopolyException("Non existe o trato " + id);

        Jugador propone = t.getPropone();

        // VALIDACIONES antes de ejecutar
        if (t.getPropiedadOfrecida() != null &&
                t.getPropiedadOfrecida().getDuenho() != propone)
            throw new MonopolyException("O trato non pode ser aceptado: " +
                    t.getPropiedadOfrecida().getNombre() + " non pertence a " + propone.getNombre());

        if (t.getPropiedadPedida() != null &&
                t.getPropiedadPedida().getDuenho() != receptor)
            throw new MonopolyException("O trato non pode ser aceptado: " +
                    t.getPropiedadPedida().getNombre() + " non pertence a " + receptor.getNombre());

        if (t.getDineroPedido() > 0 && !receptor.puedePagar(t.getDineroPedido()))
            throw new MonopolyException("O trato non pode ser aceptado: " +
                    receptor.getNombre() + " non dispon de " + (int)t.getDineroPedido() + "€");

        // EJECUCIÓN
        if (t.getPropiedadOfrecida() != null) {
            propone.eliminarPropiedad(t.getPropiedadOfrecida());
            receptor.anhadirPropiedad(t.getPropiedadOfrecida());
        }

        if (t.getPropiedadPedida() != null) {
            receptor.eliminarPropiedad(t.getPropiedadPedida());
            propone.anhadirPropiedad(t.getPropiedadPedida());
        }

        if (t.getDineroOfrecido() > 0)
            propone.pagarJugador(receptor, t.getDineroOfrecido(), tablero);

        if (t.getDineroPedido() > 0)
            receptor.pagarJugador(propone, t.getDineroPedido(), tablero);

        // eliminar trato das dúas listas
        receptor.eliminarTratoPendiente(t);
        propone.eliminarTratoPropuesto(t);

        consola.imprimir("Aceptouse p trato " + id + " con " +
                propone.getNombre() + ".");
    }

    public void listarTratos(Jugador j) {
        consola.imprimir("[");
        for (Trato t : j.getTratosPendientes()) {
            consola.imprimir(t.toString() + ",");
        }
        consola.imprimir("]");
    }

    public void eliminarTrato(Jugador j, String id) throws MonopolyException {

        Trato t = j.buscarTratoPropuestoPorId(id);
        if (t == null)
            throw new MonopolyException("Non podes eliminar este trato.");

        // quitar do receptor tamén
        t.getReceptor().eliminarTratoPendiente(t);
        j.eliminarTratoPropuesto(t);

        consola.imprimir("Eliminouse o " + id + ".");
    }

    private Jugador buscarJugadorPorNome(String nome) {
        for (Jugador j : jugadores)
            if (j.getNombre().equalsIgnoreCase(nome))
                return j;
        return null;
    }


    @Override
    public void proponerTrato(String linea) throws MonopolyException {

        // 1) EXTRAER RECEPTOR E CONTIDO
        // Forma esperada:
        // trato Luis: cambiar (Solar1, Solar14 y 300000)

        if (!linea.contains(":")) {
            throw new MonopolyException("Formato incorrecto. Exemplo: trato Luis: cambiar (Solar1, Solar14)");
        }

        String resto = linea.substring(6).trim(); // elimina "trato "
        String receptorNombre = resto.substring(0, resto.indexOf(":")).trim();

        Jugador propone = jugadores.get(turno); // xogador actual
        Jugador receptor = buscarJugadorPorNome(receptorNombre);

        if (receptor == null)
            throw new MonopolyException("O xogador " + receptorNombre + " non existe.");

        // Extraer contido dentro dos parénteses
        int ini = linea.indexOf("(");
        int fin = linea.lastIndexOf(")");

        if (ini < 0 || fin < 0 || fin <= ini)
            throw new MonopolyException("Formato incorrecto do trato. Use: cambiar ( ... )");

        String dentro = linea.substring(ini + 1, fin).trim();

        // 2) IDENTIFICAR ELEMENTOS DO TRATO
        // Separar por comas
        // Ex.:
        // "Solar1, Solar14"
        // "Solar1, 300000"
        // "Solar1, Solar14 y 300000"
        // "300000, Solar1"
        String[] partes = dentro.split(",");

        if (partes.length < 2 || partes.length > 2)
            throw new MonopolyException("O formato do trato non é válido.");

        String elem1 = partes[0].trim();
        String elem2 = partes[1].trim();


        String propPedidaNome = null;
        String propOfrecidaNome = null;

        float dineroOfrecido = 0;
        float dineroPedido = 0;

        // 3) PARSEAR PRIMEIRO ELEMENTO (elem1)

        if (elem1.matches("[0-9]+")) {
            // diñeiro ofrecido
            dineroOfrecido = Float.parseFloat(elem1);
        } else {
            // propiedade ofrecida
            propOfrecidaNome = elem1;
        }

        // 4) PARSEAR SEGUNDO ELEMENTO (elem2)
        // Pode ser: prop, dinero, ou "prop y dinero"

        if (elem2.contains(" y ")) {
            // caso: Solar14 y 300000
            String[] sub = elem2.split(" y ");
            if (sub.length != 2)
                throw new MonopolyException("Erro no formato do trato.");

            String e1 = sub[0].trim();
            String e2 = sub[1].trim();

            if (e1.matches("[0-9]+"))
                dineroPedido = Float.parseFloat(e1);
            else
                propPedidaNome = e1;

            if (e2.matches("[0-9]+"))
                dineroPedido += Float.parseFloat(e2);  // se hai dúas cantidades sumámolas, raro pero válido
            else if (propPedidaNome == null)
                propPedidaNome = e2;
            else
                throw new MonopolyException("O trato non pode ter dúas propiedades no lado pedido.");

        } else {

            // caso simple: propiedade OU diñeiro
            if (elem2.matches("[0-9]+")) {
                dineroPedido = Float.parseFloat(elem2);
            } else {
                propPedidaNome = elem2;
            }
        }

        // 5) CONVERTIR NOMES A OBXECTOS PROPIEDAD
        Propiedad propOfrecida = null;
        Propiedad propPedida = null;

        if (propOfrecidaNome != null)
            propOfrecida = (Propiedad) tablero.encontrar_casilla(propOfrecidaNome);

        if (propPedidaNome != null)
            propPedida = (Propiedad) tablero.encontrar_casilla(propPedidaNome);

        // 6) PASAR TODO AO MÉTODO GENERAL

        proponerTrato(propone, receptor,
                propOfrecida, propPedida,
                dineroOfrecido, dineroPedido);
    }


    public void mostrarAyuda(){
        //Sustitúense todos os System.out por consola.imprimir
        consola.imprimir("\n- crear jugador <nome> <avatar>");
        consola.imprimir("- jugador");
        consola.imprimir("- listar jugadores");
        consola.imprimir("- lanzar dados [suma]");
        consola.imprimir("- acabar turno");
        consola.imprimir("- salir carcel");
        consola.imprimir("- describir <NomeCasilla>");
        consola.imprimir("- describir jugador <Nome>");
        consola.imprimir("- comprar <NomePropiedade>");
        consola.imprimir("- listar enventa");
        consola.imprimir("- ver tablero");
        consola.imprimir("- edificar <tipoEdificacion> (casa, hotel, piscina, pista)");
        consola.imprimir("- listar edificios");
        consola.imprimir("- listar edificios <colorGrupo>");
        consola.imprimir("- hipotecar <NomeCasilla>");
        consola.imprimir("- deshipotecar <NomeCasilla>");
        consola.imprimir("- vender <tipo> <NomeCasilla> <cantidade>");
        consola.imprimir("- estadisticas [nomeXogador]");
        consola.imprimir("- comandos <NomeFicheiro>");
        consola.imprimir("- salir");
        consola.imprimir(""); // Liña en branco para separar*/
    }


}
