package monopoly.exceptions;

public class DiñeiroInsuficienteException extends TransaccionException {

    // Constructor para errores con banco
    public DiñeiroInsuficienteException(String nomeXogador, float diñeiroNecesario, float diñeiroActual) {
        super(nomeXogador, "Banco", "diñeiro insuficiente. Necesita " + (int)diñeiroNecesario + "€, pero só ten " + (int)diñeiroActual + "€");
    }

    // Constructor para transaccións entre xogadores
    public DiñeiroInsuficienteException(String xogadorDevedor, String xogadorAcreedor, float diñeiroNecesario, float diñeiroActual) {
        super(xogadorDevedor, xogadorAcreedor, "diñeiro insuficiente. Necesita " + (int)diñeiroNecesario + "€, pero só ten " + (int)diñeiroActual + "€");
    }
}