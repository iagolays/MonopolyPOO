package monopoly.casillas;
import monopoly.*;
import partida.*;

//Clase concreta que representa unha casilla especial no taboleiro (Carcel, Saida, IsACarcel)
public class Especial extends Casilla {

    private String tipoEspecial; //Tipo de casilla especial (Carcel, Saida, IsACarcel)

    //Constructor
    public Especial(String nombre, int posicion, String tipoEspecial) {
        super(nombre, posicion);
        this.tipoEspecial = tipoEspecial.toLowerCase();
    }

    //Metodo toString
    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("Especial {\n");
        sb.append("nome: '").append(getNombre()).append("',\n");
        sb.append("posicion: ").append(getPosicion()).append(",\n");
        sb.append("tipoEspecial: '").append(tipoEspecial).append("'\n");
        sb.append("}");
        return sb.toString();
    }

    //Metodo que executa a accion da casilla especial (non fai nada, so representa unha casilla especial)
    public boolean ejecutar(Jugador jugador, Tablero tablero) {
        switch (tipoEspecial) {
            case "salida":
                return ejecutarSalida(jugador);

            case "carcel":
                return ejecutarCarcel(jugador);

            case "ircarcel":
                return ejecutarIrCarcel(jugador, tablero);

            default:
                Juego.getConsola().imprimir("Tipo especial descoñecido: " + tipoEspecial);
                return true;
        }
    }

    // Acción para a casilla Salida.
    private boolean ejecutarSalida(Jugador jugador) {
        Juego.getConsola().imprimir(jugador.getNombre() + " está na Salida."); // Non fai nada especial ao caer só cando pasa dela
        return true;
    }

    //Acción para a casilla Carcel.
    private boolean ejecutarCarcel(Jugador jugador) {
        Juego.getConsola().imprimir(jugador.getNombre() + " está visitando o Cárcere.");
        return true;
    }

    //Acción para a casilla Ir a Carcel.
    private boolean ejecutarIrCarcel(Jugador jugador, Tablero tablero) {
        Juego.getConsola().imprimir(jugador.getNombre() + " vai ao Cárcere!");

        // Encarcelar ao xogador
        jugador.setEnCarcel(true);
        jugador.registrarVecesEnCarcel();

        // Buscar a casilla cárcere e mover o avatar
        Casilla carcel = encontrarCarcel(tablero);
        if (carcel != null && jugador.getAvatar() != null) {
            // Eliminar de la casilla actual
            Casilla lugarActual = jugador.getAvatar().getLugar();
            if (lugarActual != null) {
                lugarActual.eliminarAvatar(jugador.getAvatar());
            }

            // Mover a la cárcel
            jugador.getAvatar().setLugar(carcel);
            carcel.anhadirAvatar(jugador.getAvatar());
        }
        return true;
    }

    //busca a casilla de carcel no tablero
    private Especial encontrarCarcel(Tablero tablero) {
        // Esto lo implementaremos después cuando actualicemos Tablero
        return null;
    }

    public String getTipoEspecial() {
        return tipoEspecial;
    }

    //metodo para verificar se a casilla é de un tipo especial
    public boolean esTipoEspecial(String tipo) {
        return this.tipoEspecial.equalsIgnoreCase(tipo);
    }
}
