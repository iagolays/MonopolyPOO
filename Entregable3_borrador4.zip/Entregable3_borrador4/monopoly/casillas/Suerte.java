package monopoly.casillas;
import monopoly.*;
import partida.*;

public class Suerte extends Accion {

    public Suerte(String nombre, int posicion) {
        super(nombre, posicion);
    }

    @Override
    public void realizarAccion(Jugador jugador, Tablero tablero) {
        // Usar a clase CartasSuerte existente
        CartasSuerte cartas = new CartasSuerte();
        cartas.sacarCartaSuerte(jugador, tablero, tablero.getJugadores());
    }

    @Override
    public String getTipo() {
        return "suerte";
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("\ttipo: suerte,\n");
        sb.append("\tnome: \"").append(nombre).append("\",\n");
        sb.append("\tposicion: ").append(posicion).append("\n");
        sb.append("}");
        return sb.toString();
    }
}
