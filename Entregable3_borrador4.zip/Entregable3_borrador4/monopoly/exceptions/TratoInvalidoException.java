package monopoly.exceptions;

public class TratoInvalidoException extends TransaccionException{
    public TratoInvalidoException(String mensaxe) {
        super(mensaxe);
    }

    public TratoInvalidoException(String xogadorPropon, String xogadorAcepta, String tipoTrato, String problema) {
        super(xogadorPropon, xogadorAcepta, problema);
    }
}
