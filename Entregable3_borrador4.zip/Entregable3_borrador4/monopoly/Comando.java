package monopoly;

import monopoly.exceptions.*;

public interface Comando {

    //empregase MonopolyException porque non se debe a un erro especifico se non a un erro qeu pode ser producido polo monopoly en xeral.

    void crearXogador(String nome, String tipoAvatar) throws MonopolyException;


    void mostrarXogadorActual() throws MonopolyException;
    void describirJugador(String nome) throws MonopolyException;
    void describirCasilla(String nome) throws MonopolyException;

    void comandoListar(String[] partes) throws MonopolyException;

    void lanzarDados() throws MonopolyException;
    void lanzarDadosForzados(String tirada) throws MonopolyException;

    void comprarCasilla(String nome) throws MonopolyException;
    void comandoEdificar(String[] partes) throws MonopolyException;
    void comandoVender(String[] partes) throws MonopolyException;

    void hipotecar(String[] partes) throws MonopolyException;
    void deshipotecar(String[] partes) throws MonopolyException;

    void salirCarcel() throws MonopolyException;

    void acabarTurno() throws MonopolyException;

    void mostrarEstadisticasXogo() throws MonopolyException;
    void mostrarEstadisticasJugador(String nome) throws MonopolyException;

    void lerComandosFicheiro(String nome) throws MonopolyException;

    void procesarComando(String linea) throws MonopolyException;
}
