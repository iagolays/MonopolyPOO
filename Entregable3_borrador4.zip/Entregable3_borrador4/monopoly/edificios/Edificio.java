package monopoly.edificios;

import monopoly.*;
import monopoly.casillas.Solar;
import partida.*;

public abstract class Edificio {

    // Atributos protected para que as subclases poidan acceder a eles
    protected String id;           // Identificador único do edificio (ex: "casa-1", "hotel-1")
    protected float valorVenta;    // Valor de venda do edificio (metade do prezo de construción)
    protected float precio;        // Prezo de construción do edificio
    protected Solar solar;         // Solar no que está construído o edificio
    protected Jugador propietario; // Propietario do edificio (o mesmo que o do solar)

    //constructor
    public Edificio(Solar solar, Jugador propietario) {
        this.solar = solar;
        this.propietario = propietario;
        this.id = xerarId();          // Xera un ID único para este edificio
        this.precio = calcularPrezo(); // Calcula o prezo segundo o tipo de edificio
        this.valorVenta = this.precio / 2; // O valor de venda é a metade do prezo de construción
    }

    //Metodo que xera IDs únicos para cada edificio.
    private String xerarId() {
        String tipo = obterTipoEdificio(); // Obtén o tipo (casa, hotel, piscina, pista)
        int numero = obterContador();      // Obtén o seguinte número para este tipo
        return tipo.toLowerCase() + "-" + numero;
    }

    //Metodo abstracto para obter o tipo de edificio.
    public abstract String obterTipoEdificio();

    //Metodo abstracto para obter o contador correspondente.
    public abstract int obterContador();

    //Metodo abstracto para calcular o prezo do edificio.
    public abstract float calcularPrezo();

    //Metodo abstracto para obter o aluguer que aporta o edificio.
    public abstract float obterAluguer();

    //Metodo para obter prezo desde Valor
    protected float obterPrecioValor(String nombreSolar, String tipo) {
        switch(tipo) {
            case "casa": return Valor.obtenerPrecioCasa(nombreSolar);
            case "hotel": return Valor.obtenerPrecioHotel(nombreSolar);
            case "piscina": return Valor.obtenerPrecioPiscina(nombreSolar);
            case "pista": return Valor.obtenerPrecioPista(nombreSolar);
            default: return 0;
        }
    }

    //Metodo para obter alquiler desde Valor
    protected float obterAlquilerValor(String nombreSolar, String tipo) {
        switch(tipo) {
            case "casa": return Valor.obtenerAlquilerCasa(nombreSolar);
            case "hotel": return Valor.obtenerAlquilerHotel(nombreSolar);
            case "piscina": return Valor.obtenerAlquilerPiscina(nombreSolar);
            case "pista": return Valor.obtenerAlquilerPista(nombreSolar);
            default: return 0;
        }
    }


    //Vende o edificio ao banco.
    public boolean vender() {
        // Verificar que o edificio ten propietario
        if (propietario == null || "Banca".equals(propietario.getNombre())) {
            return false;
        }

        // O xogador recibe o valor de venda
        propietario.sumarFortuna(valorVenta);
        propietario.sumarInversion(valorVenta);
        propietario.eliminarEdificio(this.id);

        if (solar != null) {
            solar.eliminarIdEdificio(this.id); //Metodo creado en Solar para eliminar o edificio da lista
        }

        // Mostrar mensaxe informativo
        Juego.getConsola().imprimir("Véndese " + this.id + " por " + (int)valorVenta + "€");
        return true;
    }

    // Metodo que devolve información do edificio
    public String infoEdificio() {
        return "{\n" +
                "\tid: \"" + this.id + "\",\n" +
                "\tpropietario: \"" + (this.propietario != null ? this.propietario.getNombre() : "N/A") + "\",\n" +
                "\tcasilla: \"" + this.solar.getNombre() + "\",\n" +
                "\tgrupo: \"" + (this.solar.getGrupo() != null ? this.solar.getGrupo().getColorGrupo() : "N/A") + "\",\n" +
                "\tprezo: " + (int)this.precio + ",\n" +
                "\tvalorVenta: " + (int)this.valorVenta + "\n" +
                "}";
    }

    public String getId() {
        return id;
    }

    public float getValorVenta() {
        return valorVenta;
    }

    public float getPrecio() {
        return precio;
    }

    public Solar getSolar() {
        return solar;
    }

    public Jugador getPropietario() {
        return propietario;
    }


    @Override
    public String toString() {
        return obterTipoEdificio() + " " + id + " en " + solar.getNombre();
    }
}