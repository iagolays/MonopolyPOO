package monopoly.edificios;

import monopoly.*;
import monopoly.casillas.Solar;
import partida.*;

//Clase que representa unha Pista de Deporte construída nun solar.
public class PistaDeDeporte extends Edificio {

    // Contador estático para xerar IDs únicos para as pistas
    private static int contador = 1;

    //Constructor da clase PistaDeDeporte.
    public PistaDeDeporte(Solar solar, Jugador propietario) {
        super(solar, propietario);
    }

    //Metodo que devolve o tipo de edificio.
    @Override
    public String obterTipoEdificio() {
        return "pista";
    }

    //Metodo que obtén o seguinte número do contador de pistas.
    @Override
    public int obterContador() {
        return contador++;
    }

    //Metodo que calcula o prezo da pista segundo o solar.
    @Override
    public float calcularPrezo() {
        return obterPrecioValor(solar.getNombre().toLowerCase(), "pista");
    }

    //Metodo que obtén o aluguer que aporta esta pista de deporte.
    @Override
    public float obterAluguer() {
        return obterAlquilerValor(solar.getNombre().toLowerCase(), "pista");
    }
}