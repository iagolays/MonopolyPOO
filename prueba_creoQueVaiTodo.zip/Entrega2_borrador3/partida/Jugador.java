package partida;

import java.util.ArrayList;

import monopoly.*;


public class Jugador {

    //Atributos:
    private String nombre; //Nombre del jugador
    private Avatar avatar; //Avatar que tiene en la partida.
    private float fortuna; //Dinero que posee.
    private float gastos; //Gastos realizados a lo largo del juego.
    private boolean enCarcel; //Será true si el jugador está en la carcel
    private int tiradasCarcel; //Cuando está en la carcel, contará las tiradas sin éxito que ha hecho allí para intentar salir (se usa para limitar el numero de intentos).
    private int vueltas; //Cuenta las vueltas dadas al tablero.
    private ArrayList<Casilla> propiedades; //Propiedades que posee el jugador.
    private ArrayList<Casilla> hipotecas; //nova
    private ArrayList<String> edificios; //nova
    private boolean enBancarrota;    //novo: 0 si el jugador no está en bancarrota; 1 si está en bancarrota
    private int doblesConsecutivos; //contador de dobles consecutivos para cada xogador

    //Para mostrar estatísticas
    private float dineroInvertido; //dinero invertido na compra de propiedades e edificaciones de cada xogador
    private float pagoTasasEImpuestos; //pago de tasas e impostos
    private float pagoDeAlquileres; //pago de alquileres
    private float cobroDeAlquileres; //cobro de alquileres
    private float pasarPorCasillaSalida; //diñeiro recibido ao pasar pola casilla de salida
    private float premiosInversionesOBote; //diñeiro recibido por inversiones, premios ou polo bote ao caer na casilla parking
    private int vecesEnCarcel; //veces que caeu na casila carcel


    //Constructor vacío. Se usará para crear la banca.
    public Jugador() {
        this.nombre = "Banca";
        this.fortuna = 0f; //A banca ten diñeiro ilimitado
        this.gastos = 0f;
        this.enCarcel  = false;
        this.tiradasCarcel = 0;
        this.vueltas = 0;
        this.propiedades = new ArrayList<>();
        this.hipotecas = new ArrayList<>();
        this.edificios = new ArrayList<>();
        this.enBancarrota = false;

        inicializarEstadisticas();
        //A banca non ten avatar nin pode estar en bancarrota

    }

    /*Constructor principal. Requiere parámetros:
     * Nombre del jugador, tipo del avatar que tendrá, casilla en la que empezará y ArrayList de
     * avatares creados (usado para dos propósitos: evitar que dos jugadores tengan el mismo nombre y
     * que dos avatares tengan mismo ID). Desde este constructor también se crea el avatar.
     */
    public Jugador(String nombre, String tipoAvatar, Casilla inicio, ArrayList<Avatar> avCreados) {
        //Comprobar que non exista un xogador co mesmo nome ou avatar repetido
        this.nombre = nombre;
        this.fortuna = Valor.FORTUNA_INICIAL; //saldo inicial do xogador
        this.gastos = 0f;
        this.enCarcel  = false;
        this.tiradasCarcel = 0;
        this.vueltas = 0;
        this.propiedades = new ArrayList<>();
        this.hipotecas = new ArrayList<>();
        this.edificios = new ArrayList<>();
        this.enBancarrota = false;       //Non é posible que un xogador empece a partida estando en bancarrota

        //creamos un avatar asociado
        this.avatar = new Avatar(tipoAvatar, this, inicio, avCreados);
        this.doblesConsecutivos = 0; //inicalizamos a 0
        inicializarEstadisticas();
    }

    //Metodo para añadir una propiedad al jugador. Como parámetro, la casilla a añadir.
    public void anhadirPropiedad(Casilla casilla) {
        if (casilla != null && !propiedades.contains(casilla)) { //compóbase que un xogador non teña esa propiedade
            this.propiedades.add(casilla);
            casilla.setDuenho(this);
        }
    }

    //Metodo para eliminar una propiedad del arraylist de propiedades de jugador.
    public void eliminarPropiedad(Casilla casilla) {
        if (casilla!= null){
            this.propiedades.remove(casilla); //non se comproba se esta nas propiedades do xogador porque faino remove directamente
        }
    }

    //Metodo para añadir fortuna a un jugador
    //Como parámetro se pide el valor a añadir. Si hay que restar fortuna, se pasaría un valor negativo.
    public void sumarFortuna(float valor) {
        this.fortuna += valor;
        if (valor < 0) {
            this.sumarGastos(Math.abs(valor)); // Só sumar gastos se é negativo (pago)
            //Math.abs é o valor absoluto
        }
        if (this.fortuna < 0 && !this.enBancarrota) {
            System.out.println(this.nombre + " entrou en números vermellos: " + (int) this.fortuna + "€");
        }
    }

    //Metodo para sumar gastos a un jugador.
    //Parámetro: valor a añadir a los gastos del jugador (será el precio de un solar, impuestos pagados...).
    public void sumarGastos(float valor) {
        this.gastos += valor;
    }

    /*Metodo para establecer al jugador en la cárcel.
     * Se requiere disponer de las casillas del tablero para ello (por eso se pasan como parámetro).*/
    public void encarcelar(ArrayList<ArrayList<Casilla>> pos, Tablero tablero) {
        this.enCarcel = true;
        this.tiradasCarcel = 0;
        this.vecesEnCarcel++; //incrementamos o contador de veces que caeu na carcel

        //buscar casilla carcel
        Casilla carcel = tablero.encontrar_casilla("Carcel");

        // Movemos o avatar ao cárcere
        if (carcel != null && this.avatar != null) {
            // Quitamos o avatar da súa casilla actual
            Casilla casillaActual = this.avatar.getLugar();
            if (casillaActual != null) {
                casillaActual.eliminarAvatar(this.avatar);
            }

            // Colocamos o avatar no cárcere
            this.avatar.setLugar(carcel);
            carcel.anhadirAvatar(this.avatar);
        }
    }

    //----------Metodos auxiliares

    private void inicializarEstadisticas() {
        this.dineroInvertido = 0f;
        this.pagoTasasEImpuestos = 0f;
        this.pagoDeAlquileres = 0f;
        this.cobroDeAlquileres = 0f;
        this.pasarPorCasillaSalida = 0f;
        this.premiosInversionesOBote = 0f;
        this.vecesEnCarcel = 0;
    }

    //Metodo para saber se un xogador ten suficiente diñeiro para pagar
    public boolean puedePagar(float valor) {
        //se o diñeiro que ten é maior ca o que debe pagar entón pode pagar
        return this.fortuna >= valor;
    }

    // Pagar a outro xogador automaticamente
    public boolean pagarJugador(Jugador receptor, float cantidad, Tablero tablero) {
        if (this.puedePagar(cantidad)) {
            this.sumarFortuna(-cantidad); //restamos o que ten que pagar
            receptor.sumarFortuna(cantidad); //sumamos ao que lle debe

            this.pagoDeAlquileres += cantidad; //sumamos ao pago de alugueres
            receptor.cobroDeAlquileres += cantidad; //sumamos ao cobro de alugueres
            return true;
        } else {
            System.out.println(this.nombre + " non pode pagar " + (int)cantidad + "€ a " + receptor.getNombre());
            System.out.println("Opcións dispoñibles:");
            System.out.println("   - 'hipotecar <casilla>' para obter diñeiro");
            System.out.println("   - 'acabar turno' para declararse en bancarrota");
            return false;
        }
    }

    // Para o comando "salir cárcel"
    public void salirCarcel(Tablero tablero) {
        if (this.enCarcel && this.puedePagar(Valor.CARCEL_SALIDA)) { //se está no cárcere e pode pagar a saida
            this.sumarFortuna(-Valor.CARCEL_SALIDA); //réstaselle o que debe pagar
            this.pagoTasasEImpuestos += Valor.CARCEL_SALIDA; //sumamos ao pago de taxas e impostos
            this.enCarcel = false; //sae do cárcere
            this.tiradasCarcel = 0;
            System.out.println(this.nombre + " paga " + (int)Valor.CARCEL_SALIDA + "€ e sae do cárcere.");
        } else if (this.enCarcel && !this.puedePagar(Valor.CARCEL_SALIDA)) { //se non pode pagar a saida do cárcere
            System.out.println(this.nombre + " non ten diñeiro para sair do cárcere.");
        } else {
            System.out.println(this.nombre + " non está no cárcere.");
        }
    }

    // Metodo que se chama no turno para lanzar dados estando no cárcere
    // Retorna: 0 = sigue en cárcel, 1 = sale y puede moverse, -1 = bancarrota
    public int intentarSalirCarcel(Dado dado1, Dado dado2, Tablero tablero) {
        if (!enCarcel){
            return 1; // non está en cárcere, pode mover
        }

        tiradasCarcel++; // incremento turno en cárcere

        int v1 = dado1.hacerTirada();
        int v2 = dado2.hacerTirada();

        System.out.println(this.nombre + " saca " + v1 + " e " + v2 + " (turno " + this.tiradasCarcel + "/3)");

        if (v1 == v2) { // sacou dobles
            System.out.println(this.nombre + " saca dobles e sae do cárcere sen pagar.");
            this.enCarcel = false; //sae do carcere
            this.tiradasCarcel = 0; //se reinician
            return 1; // pode mover

        } else if (tiradasCarcel >= 3) { // 3 turnos sen sacar dobles, paga necesariamente
            if (puedePagar(Valor.CARCEL_SALIDA)) {
                salirCarcel(tablero);
                return 1; // pode mover e sae co valor dos dados
            } else {
                System.out.println(nombre + " non pode pagar para sair do cárcere.");
                this.declararBancarrota(tablero);
                return -1; // non pode mover, esta en bancarrota
            }
        }
        // Non sacou dobres e non leva 3 turnos
        return 0; // segue no cárcere
    }

    // Declara ao xogador en bancarrota
    public void declararBancarrota(Tablero tablero) {
        if (this.enBancarrota){
            return; // Se xa está en bancarrota, non facemos nada
        }
        this.enBancarrota = true; // Marcamos ao xogador en bancarrota
        this.fortuna = 0;

        // Liberamos propiedades (volven á banca)
        for (Casilla c : this.propiedades) {
            c.setDuenho(tablero.getBanca());
        }

        this.propiedades.clear(); //clear elimina todos os elementos do arrayList
        this.hipotecas.clear(); // Liberamos hipotecas
        this.edificios.clear(); // Liberamos edificios

        // Movemos avatar a null (ou deixámolo no tablero sen acción)
        if (this.avatar != null) {
            Casilla lugarActual = this.avatar.getLugar();
            if (lugarActual != null) {
                lugarActual.eliminarAvatar(this.avatar);
            }
            this.avatar = null; // O xogador xa non participa
        }
    }


    public void eliminarEdificio(String idEdificio) {
        this.edificios.remove(idEdificio);
    } //eliminar un edificio da lista do xogador

    public void sumarInversion(float valor) {
        this.dineroInvertido += valor;
    }

    public void registrarPasoSalida(float valor) {
        this.pasarPorCasillaSalida += valor;
        this.incrementarVueltas();
    }

    public void registrarPremio(float valor) {
        this.premiosInversionesOBote += valor;
    }

    public void registrarTasa(float valor) {
        this.pagoTasasEImpuestos += valor;
    }

    public void incrementarVueltas() {
        this.vueltas++;
    }

    public void registrarPagoAlquiler(float valor) {
        this.pagoDeAlquileres += valor;
    }

    public void registrarCobroAlquiler(float valor) {
        this.cobroDeAlquileres += valor;
    }

    public void registrarVecesEnCarcel() {
        this.vecesEnCarcel++;
    }

    public void anhadirHipoteca(Casilla propiedad) {
        if (propiedad != null && !hipotecas.contains(propiedad)) {
            this.hipotecas.add(propiedad);
        }
    }

    public void anhadirEdificio(String idEdificio) {
        this.edificios.add(idEdificio);
    }

    public void eliminarHipoteca(Casilla propiedad) {
        this.hipotecas.remove(propiedad);
    }

    public String infoJugador(){
        StringBuilder info = new StringBuilder();
        info.append("{\n");

        info.append("nome: ").append(this.nombre).append("\n");
        info.append("avatar: ").append(this.avatar != null ? this.avatar.getId() : "—").append("\n");
        info.append("fortuna: ").append((int)this.fortuna).append("\n");
        info.append("propiedades: [");
        int count = 0; // contador para engadir comas entre elementos
        for (Casilla p : this.propiedades){
            info.append(p.getNombre());
            if (++count < this.propiedades.size()){
                info.append(", ");
            }
        }
        info.append("]\n");
        info.append("hipotecas: [");
        count = 0; //reiniciamos
        for (Casilla h : this.hipotecas){
            info.append(h.getNombre());
            if (++count < this.hipotecas.size()){
                info.append(", ");
            }
        }
        info.append("]\n");
        info.append("edificios: [");
        count = 0; //reiniciamos
        for (String e :  this.edificios){
            info.append(e);
            if (++count < this.edificios.size()){
                info.append(", ");
            }
        }
        info.append("]\n}");
        return info.toString(); // devolvemos a información como String
    }

    public String mostrarEstadisticas() {
        StringBuilder info = new StringBuilder();
        info.append("{\n");
        info.append("dineroInvertido: ").append((int)this.dineroInvertido).append(",\n");
        info.append("pagoTasasEImpuestos: ").append((int)this.pagoTasasEImpuestos).append(",\n");
        info.append("pagoDeAlquileres: ").append((int)this.pagoDeAlquileres).append(",\n");
        info.append("cobroDeAlquileres: ").append((int)this.cobroDeAlquileres).append(",\n");
        info.append("pasarPorCasillaDeSalida: ").append((int)this.pasarPorCasillaSalida).append(",\n");
        info.append("premiosInversionesOBote: ").append((int)this.premiosInversionesOBote).append(",\n");
        info.append("vecesEnLaCarcel: ").append(this.vecesEnCarcel).append("\n");
        info.append("}");
        return info.toString();
    }


    // Incrementa o contador de dobles
    public void incrementarDobles() {
        this.doblesConsecutivos++;
    }

    // Resetea o contador de dobles
    public void resetearDobles() {
        this.doblesConsecutivos = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public Avatar getAvatar() {
        return this.avatar;
    }

    public float getFortuna() {
        return fortuna;
    }

    public boolean isEnCarcel() {
        return enCarcel;
    }

    public int getDoblesConsecutivos() {
        return doblesConsecutivos;
    }

    public void setEnCarcel(boolean enCarcel) {
        this.enCarcel = enCarcel;
    }

    public boolean isEnBancarrota() {
        return enBancarrota;
    }

    public ArrayList<Casilla> getPropiedades() {
        return propiedades;
    }

    public ArrayList<Casilla> getHipotecas() {
        return hipotecas;
    }

    public ArrayList<String> getEdificios() {
        return edificios;
    }

    public float getDineroInvertido() {
        return dineroInvertido;
    }

    public float getPasarPorCasillaSalida() {
        return pasarPorCasillaSalida;
    }

    public float getPremiosInversionesOBote() {
        return premiosInversionesOBote;
    }

    public int getVueltas() {
        return vueltas;
    }

    @Override
    public String toString() {
        return "{nombre: " + nombre + ", avatar: " + (avatar != null ? avatar.getId() : "—") +
                ", fortuna: " + (int)fortuna + ", propiedades: " + propiedades.size() +
                ", hipotecas: " + hipotecas.size() + ", edificios: " + edificios.size() + "}";
    }
}

