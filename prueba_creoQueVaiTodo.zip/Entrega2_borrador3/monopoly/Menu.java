package monopoly;

import partida.*; //impórtanse todas as clases do paquete partida

import java.net.SocketOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner; //Para ler a entrada do usuario
import java.io.File; // Para xestionar ficheiros
import java.io.FileNotFoundException; //obligatorio para que funcione new Scanner ao ler o arquivo

public class Menu {

    //Atributos
    private ArrayList<Jugador> jugadores; //Jugadores de la partida.
    private ArrayList<Avatar> avatares; //Avatares en la partida.
    private int turno = 0; //Índice correspondiente a la posición en el arrayList del jugador (y el avatar) que tienen el turno
    private int lanzamientos; //Variable para contar el número de lanzamientos de un jugador en un turno.
    private Tablero tablero; //Tablero en el que se juega.
    private Dado dado1; //Dos dados para lanzar y avanzar casillas.
    private Dado dado2;
    private Jugador banca; //El jugador banca.
    private boolean tirado; //Booleano para comprobar si el jugador que tiene el turno ha tirado o no.
    private boolean solvente; //Booleano para comprobar si el jugador que tiene el turno es solvente, es decir, si ha pagado sus deudas.
    private boolean dadosLanzados; //Comprobar que os dados foron lanzados e xa comezou a partida

    private CartasSuerte cartasSuerte;

    public Menu(boolean modoInteractivo) { //constructor do menú se non se recibe un arquivo
        // Inicializamos as listas de xogadores e avatares
        this.jugadores = new ArrayList<>();
        this.avatares = new ArrayList<>();
        this.banca = new Jugador(); // Creamos a banca do xogo
        this.tablero = new Tablero(banca); // Creamos o taboleiro asociado á banca

        // Creamos os dous dados para o xogo
        this.dado1 = new Dado();
        this.dado2 = new Dado();

        this.cartasSuerte = new CartasSuerte();

        this.turno = 0; // Comeza o primeiro xogador
        this.lanzamientos = 0; // Aínda non houbo lanzamentos
        this.tirado = false; // Aínda non se lanzaron dados
        this.solvente = true; // Asumimos que é solvente inicialmente
        this.dadosLanzados = false; // Inicialmente non se lanzaron dados

        if (modoInteractivo) {
            this.iniciarPartida(); // Iniciamos a partida en modo interactivo
        }
    }


    // Metodo para iniciar unha partida: crea os xogadores e avatares
    private void iniciarPartida() {
        System.out.println("Benvido ao Monopoly ETSE!");

        System.out.println("\n- crear jugador <nome> <avatar>");
        System.out.println("- jugador");
        System.out.println("- listar jugadores");
        System.out.println("- lanzar dados [suma]");
        System.out.println("- acabar turno");
        System.out.println("- salir carcel");
        System.out.println("- describir <NomeCasilla>");
        System.out.println("- describir jugador <Nome>");
        System.out.println("- comprar <NomePropiedade>");
        System.out.println("- listar enventa");
        System.out.println("- ver tablero");
        System.out.println("- edificar <tipoEdificacion> [cantidade] (casa, hotel, piscina, pista)");
        System.out.println("- listar edificios");
        System.out.println("- listar edificios <colorGrupo>");
        System.out.println("- hipotecar <NomeCasilla>");
        System.out.println("- deshipotecar <NomeCasilla>");
        System.out.println("- vender <tipo> <NomeCasilla> <cantidade>");
        System.out.println("- estadisticas [nomeXogador]");
        System.out.println("- comandos <NomeFicheiro>");
        System.out.println("- salir");
        System.out.println(); // Liña en branco para separar*/

        // Scanner permite ler entrada de texto. Neste caso, do teclado (System.in)
        Scanner sc = new Scanner(System.in);

        while (true) { // Bucle infinito
            System.out.print("\n$> "); // Mostramos o prompt para o comando
            String comando = sc.nextLine().trim();
            /* sc.nextLine(), le unha liña completa do teclado ata premer Enter
             * trim(), elimina espazos en branco do inicio e final da liña
             */

            if (comando.equalsIgnoreCase("salir")) { //Se o comando é "salir", saímos do xogo
                System.out.println("\nSaíndo do xogo...");
                System.out.println("Ata pronto!");
                break; // Saímos do bucle

            } else if (comando.startsWith("comandos ")) { //Se o comando empeza por "comandos ", lense os comandos dende un ficheiro
                String nomeFicheiro = comando.substring(9);
                /* substring(9), toma a parte da cadea que vai desde a posición 9 ata o final.
                 * Isto elimina a palabra "comandos " e deixa só o nome do ficheiro
                 */
                this.lerFicheiroComandos(nomeFicheiro);

            } else { // Calquera outro comando envíase ao metodo que interpreta comandos
                this.analizarComando(comando);
            }
        }
        sc.close(); // Pechamos o scanner ao saír do xogo
    }

    /* Metodo que interpreta o comando introducido e toma a acción correspondente
     * Parámetro: cadea de caracteres (o comando)
     */
    private void analizarComando(String comando) {
        // Separa a cadea por espazos entre palabras
        String[] partes = comando.trim().split("\\s+");
        //split("\\s+"), divide a cadea en partes usando un ou varios espazos como separador

        if (partes.length == 0){
            return; // Se está baleiro, non facemos nada
        }

        if (!this.jugadores.isEmpty()) {
            Jugador actual = this.jugadores.get(this.turno);
            if (actual.getFortuna() < 0 && !actual.isEnBancarrota()) {
                System.out.println(actual.getNombre() + " aínda ten débedas pendentes (" + (int)Math.abs(actual.getFortuna()) + "€).");
                System.out.println("Use 'hipotecar <casilla>' ou 'acabar turno' para resolver.");
            }
        }

        switch (partes[0].toLowerCase()) { //Analiza o primeiro termo do comando en minúsculas

            case "crear": // Comando: crear jugador <nombre> <tipoAvatar>
                if (partes.length >= 4 && partes[1].equalsIgnoreCase("jugador")) {
                    if (dadosLanzados){
                        System.out.println("Non se poden crear xogadores unha vez comezada a partida.");
                    } else {
                        this.crearJugador(partes[2], partes[3]); // Creamos o novo xogador
                    }
                } else {
                    System.out.println("Formato incorrecto. Use: crear jugador <nome> <avatar>");
                }
                break;
            case "jugador": // Comando: jugador - mostra o xogador actual
                this.mostrarJugadorActual();
                break;
            case "listar":
                comandoListar(partes);
                break;
            case "lanzar": // Comando: lanzar dados [valor]
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("dados")) {
                    if (partes.length >= 3) {
                        this.forzarDados(partes[2]); // Lanzamento forzado
                    } else {
                        this.lanzarDados(); // Lanzamento aleatorio
                    }
                }else {
                    System.out.println("Formato incorrecto. Use: lanzar dados [valor]");
                }
                break;
            case "describir": // Comando: describir jugador <nome> ou describir <casilla>
                if (partes.length >= 3 && partes[1].equalsIgnoreCase("jugador")) {
                    this.descJugador(partes[2]); //Describir Jugador
                } else if (partes.length >= 2) {
                    this.descCasilla(partes[1]); // Describir casilla
                } else {
                    System.out.println("Formato incorrecto. Use: describir jugador <nome> OU describir <casilla>");
                }
                break;
            case "comprar": // Comando: comprar <propiedade>
                if (partes.length >= 2) {
                    this.comprar(partes[1]);
                } else {
                    System.out.println("Formato incorrecto. Use: comprar <nomeCasilla>");
                }
                break;
            case "salir": // Comando: salir carcel
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("carcel")) {
                    this.salirCarcere();
                } else {
                    System.out.println("Formato incorrecto. Use: salir carcel");
                }
                break;
            case "acabar": // Comando: acabar turno
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("turno")) {
                    this.acabarTurno();
                } else {
                    System.out.println("Formato incorrecto. Use: acabar turno");
                }
                break;
            case "ver": // Comando: ver tablero
                if (partes.length >= 2 && partes[1].equalsIgnoreCase("tablero")) {
                    this.verTablero();
                } else {
                    System.out.println("Formato incorrecto. Use: ver tablero");
                }
                break;
            case "edificar":
                comandoEdificar(partes);
                break;
            case "hipotecar":
                if (partes.length >= 2) {
                    String nombreCasilla = partes[1];
                    Casilla c = this.tablero.encontrar_casilla(nombreCasilla);
                    if (c != null) {
                        c.hipotecar(this.jugadores.get(this.turno));
                    } else {
                        System.out.println("Non se atopou a casilla: " + nombreCasilla);
                    }
                } else {
                    System.out.println("Formato incorrecto. Use: hipotecar <nomeCasilla>");
                }
                break;
            case "deshipotecar":
                if (partes.length >= 2) {
                    String nombreCasilla = partes[1];
                    Casilla c = this.tablero.encontrar_casilla(nombreCasilla);
                    if (c != null) {
                        c.deshipotecar(this.jugadores.get(this.turno));
                    } else {
                        System.out.println("Non se atopou a casilla: " + nombreCasilla);
                    }
                } else {
                    System.out.println("Formato incorrecto. Use: deshipotecar <nomeCasilla>");
                }
                break;
            case "vender":
                if (partes.length >= 4){
                    String tipo = partes[1];
                    String nombreCasilla = partes[2];
                    int cantidad = Integer.parseInt(partes[3]); //convertimos a enteiro o numero pasado por comandos
                    Casilla c = this.tablero.encontrar_casilla(nombreCasilla);
                    if (c != null) {
                        Solares.venderEdificio(c, this.jugadores.get(this.turno), tipo, cantidad);
                    } else {
                        System.out.println("Non se atopou a casilla: " + nombreCasilla);
                    }
                } else {
                    System.out.println("Formato incorrecto. Use: vender <tipo> <nomeCasilla> <cantidade>");
                }
                break;
            case "estadisticas":
                if (partes.length >= 2) {
                    this.estadisticasJugador(partes[1]);
                } else {
                    this.estadisticasJuego();
                }
                break;
            default:
                System.out.println("Comando non recoñecido: " + comando);
        }
    }

    /* Metodo que realiza as accións asociadas ao comando 'describir jugador'
     * Parámetro: comando introducido
     */
    private void descJugador(String nombreBuscar) {

        Jugador jugador = null;

        for (Jugador j: jugadores) { // Buscamos o xogador na lista de xogadores
            if (j.getNombre().equalsIgnoreCase(nombreBuscar)) {
                jugador = j;
                break;
            }
        }

        if (jugador == null) { // Se non atopamos o xogador, mostramos erro
            System.out.println("Non existe ningún xogador con ese nome.");
            return;
        }
        System.out.println(jugador.infoJugador()); // Mostramos a información do xogador
    }

    /* Metodo que realiza as accións asociadas ao comando 'describir nombre_casilla'
     * Parámetros: nome da casilla a describir
     */
    public void descCasilla(String nombre) {
        Casilla c = this.tablero.encontrar_casilla(nombre); // Buscamos a casilla no taboleiro
        if (c == null) { // Se non se atopa a casilla, mostramos erro
            System.out.println("Non se atopou a casilla: " + nombre);
            return;
        }
        System.out.println(c.infoCasilla()); // Mostramos a información da casilla
    }

    private void comandoEdificar(String[] partes) {
        if (this.jugadores.isEmpty()) {
            System.out.println("Non hai xogadores na partida.");
            return;
        }

        if (partes.length < 2) {
            System.out.println("Formato incorrecto. Use: edificar <tipo> [cantidade]");
            System.out.println("Tipos válidos: casa, hotel, piscina, pista");
            return;
        }

        Jugador jugadorActual = this.jugadores.get(this.turno);
        String tipoEdificio = partes[1].toLowerCase();
        int cantidad = 1; // Por defecto, 1 edificio

        // Procesar cantidade se se proporciona
        if (partes.length >= 3) {
            try {
                cantidad = Integer.parseInt(partes[2]);
                if (cantidad <= 0) {
                    System.out.println("A cantidade debe ser maior que 0.");
                    return;
                }
                //Limitar cantidade para Casas
                if ("casa".equals(tipoEdificio) && cantidad > 4) {
                    System.out.println("Non se poden construír máis de 4 casas nun solar.");
                    cantidad = 4;
                }
            } catch (NumberFormatException e) {
                System.out.println("A cantidade debe ser un número válido.");
                return;
            }
        }

        // Validar tipo de edificio
        if (!tipoEdificio.equals("casa") && !tipoEdificio.equals("hotel") && !tipoEdificio.equals("piscina") && !tipoEdificio.equals("pista")) {
            System.out.println("Tipo de edificio non válido. Use: casa, hotel, piscina ou pista.");
            return;
        }

        // Verificar que o xogador está nun solar
        Casilla casillaActual = jugadorActual.getAvatar().getLugar();
        if (casillaActual == null || !"solar".equalsIgnoreCase(casillaActual.getTipo())) {
            System.out.println("Só podes edificar nun solar e debes estar na casilla onde queres edificar.");
            return;
        }

        // Chamar ao metodo de construción en Solares
        boolean exito = Solares.construirEdificio(casillaActual, jugadorActual, tipoEdificio, cantidad);

        if (exito) {
            // Actualizar o taboleiro para mostrar os cambios
            System.out.println(this.tablero);
        }
    }

    private void comandoListar(String[] partes) {
        if (partes.length < 2){
            System.out.println("Formato incorrecto. Use: listar jugadores|edificios|enventa");
            return;
        }

        switch (partes[1].toLowerCase()) {
            case "jugadores":
                listarJugadores();
                break;
            case "edificios":
                if (partes.length == 2) {
                    listarTodosEdificios();
                } else {
                    // Reconstruimos o nombre completo do grupo
                    StringBuilder colorGrupoBuilder = new StringBuilder();
                    for (int i = 2; i < partes.length; i++) {
                        if (i > 2){
                            colorGrupoBuilder.append(" "); // añadimos espacio entre palabras
                        }
                        colorGrupoBuilder.append(partes[i]);
                    }
                    listarEdificiosGrupo(colorGrupoBuilder.toString());
                }
                break;
            case "enventa":
                listarVenta();
                break;
            default:
                System.out.println("Subcomando listar non recoñecido: " + partes[1]);
        }
    }

    private void listarTodosEdificios() {
        boolean hayEdificios = false;

        for (Jugador j : jugadores) {
            // Listar directamente os edificios do xogador (teñen IDs únicos)
            for (String idEdificio : j.getEdificios()) {
                // Extraer información do ID
                String[] partes = idEdificio.split("-");
                if (partes.length >= 2) {
                    String tipo = partes[0];
                    String numero = partes[1];

                    // Buscar casilla correspondente a este edificio
                    Casilla casillaEdificio = null;
                    for (Casilla propiedad : j.getPropiedades()) {
                        if ("solar".equalsIgnoreCase(propiedad.getTipo())) {
                            // Verificar se esta propiedade ten edificios do tipo correcto
                            Solares.DatosEdificios edificios = propiedad.getDatosedificios();
                            if (edificios != null) {
                                boolean tieneEsteTipo = false;
                                switch (tipo.toLowerCase()) {
                                    case "casa":
                                        tieneEsteTipo = edificios.getNumCasas() > 0;
                                        break;
                                    case "hotel":
                                        tieneEsteTipo = edificios.getNumHoteles() > 0;
                                        break;
                                    case "piscina":
                                        tieneEsteTipo = edificios.getNumPiscinas() > 0;
                                        break;
                                    case "pista":
                                        tieneEsteTipo = edificios.getNumPistas() > 0;
                                        break;
                                }
                                if (tieneEsteTipo) {
                                    casillaEdificio = propiedad;
                                    break;
                                }
                            }
                        }
                    }

                    if (casillaEdificio != null) {
                        // Calcular coste dependendo do tipo
                        float coste = 0;
                        switch (tipo.toLowerCase()) {
                            case "casa":
                                coste = Solares.obtenerPrecioCasa(casillaEdificio.getNombre());
                                break;
                            case "hotel":
                                coste = Solares.obtenerPrecioHotel(casillaEdificio.getNombre());
                                break;
                            case "piscina":
                                coste = Solares.obtenerPrecioPiscina(casillaEdificio.getNombre());
                                break;
                            case "pista":
                                coste = Solares.obtenerPrecioPista(casillaEdificio.getNombre());
                                break;
                        }

                        System.out.println(Solares.generarInfoEdificio(idEdificio, j, casillaEdificio, coste));
                        hayEdificios = true;
                    }
                }
            }
        }

        if (!hayEdificios) {
            System.out.println("Non hai edificios construidos.");
        }
    }


    private void listarEdificiosGrupo(String colorGrupo) {
        boolean hayEdificios = false; // bandera para saber si hay edificios
        colorGrupo = colorGrupo.trim().toLowerCase(); // normalizamos a color do grupo

        // Buscamos o grupo correspondente (para poder obter a info final de construción)
        ArrayList<Grupo> gruposEncontrados = new ArrayList<>();
        for (Jugador jugador : jugadores) {
            for (Casilla propiedad : jugador.getPropiedades()) {
                Grupo grupo = propiedad.getGrupo();
                if (grupo != null && grupo.getColorGrupo().equalsIgnoreCase(colorGrupo) && !gruposEncontrados.contains(grupo)) {
                    gruposEncontrados.add(grupo);
                }
            }
        }
        if (gruposEncontrados.isEmpty()) {
            System.out.println("Non se atopou ningún grupo ca color: " + colorGrupo + ".");
            return;
        }
        // Mostrar información de cada grupo
        for (Grupo grupo : gruposEncontrados) {
            String info = grupo.obtenerInfoEdificios();
            if (!info.contains("propiedad:") || info.contains("casa-") || info.contains("hotel-") || info.contains("piscina-") || info.contains("pista-")) {
                hayEdificios = true;
            }
            System.out.println(info);
        }
        if (!hayEdificios) {
            System.out.println("Non hai casillas con edificios construidos no grupo " + colorGrupo + ".");
        }
    }

    // Metodo que executa todas as accións relacionadas co comando 'lanzar dados'
    private void lanzarDados() {
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            System.out.println("Non hai xogadores na partida, non se poden lanzar os dados.");
            return;
        } else if (this.jugadores.size() < 2){
            System.out.println("Non se poden lanzar os dados ata que haxa polo menos 2 xogadores.");
            return;
        }

        Jugador actual = this.jugadores.get(this.turno); // Obtenemos o xogador actual

        if (actual.isEnCarcel()) { // Verificamos se o xogador está no cárcere
            if (!this.tirado){
                //intenta salir de carcel
                int resultado = actual.intentarSalirCarcel(this.dado1, this.dado2, this.tablero);
                if (resultado == -1){
                    return; //está en bancarrota, non pode sair
                } else if (resultado == 0) {
                    //segue no carcere, non se move
                    this.tirado = true;
                    return;
                }
                else {
                    // resultado == 1: Sae do carcere e movese cos dados
                    int valor1 = this.dado1.getValor(); // Usamos o valor xa tirado
                    int valor2 = this.dado2.getValor();
                    this.tirado = true;
                    gestionarTirada(actual, valor1, valor2, this.tablero);
                }
            }else {
                System.out.println("Xa se tiraron os dados, remata o turno.");
            }
        } else {
            if (!this.tirado){ //só se non se tirou con anterioridade
                // Facemos a tirada aleatoria dos dados
                int valor1 = this.dado1.hacerTirada();
                int valor2 = this.dado2.hacerTirada();

                gestionarTirada(actual, valor1, valor2, this.tablero);
            } else {
                System.out.println("Xa se tiraron os dados, remata o turno.");
            }
        }
    }

    /* Metodo que executa todas as accións realizadas co comando 'comprar nombre_casilla'
     * Parámetro: cadea de caracteres co nome da casilla
     */
    private void comprar(String nombre) {
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            System.out.println("Non hai xogadores na partida, non se poden comprar casillas.");
            return;
        }

        Jugador jugadorActual = this.jugadores.get(this.turno); // Xogador que ten o turno
        Casilla casilla = this.tablero.encontrar_casilla(nombre); // Buscamos a casilla no taboleiro

        if (casilla == null) { // Verificamos que a casilla exista
            System.out.println("Propiedade non atopada: " + nombre);
            return;
        }

        // Verificamos que o xogador está na casilla que quere comprar
        if (!jugadorActual.getAvatar().getLugar().equals(casilla)) {
            //equalsIgnoreCase só funciona con String, pero casilla é un obxecto Casilla polo que se usa equals
            System.out.println("Só podes comprar a casilla na que estás actualmente: " + jugadorActual.getAvatar().getLugar().getNombre());
            return;
        }

        // Verificamos que a casilla sexa comprable
        if (!casilla.getTipo().equalsIgnoreCase("solar") && !casilla.getTipo().equalsIgnoreCase("transporte") &&
                !casilla.getTipo().equalsIgnoreCase("servicio")) {
            System.out.println("Non se pode comprar a casilla " + nombre + ".");
            return;
        }

        // Verificamos que a casilla non teña dono ou sexa da banca
        if (casilla.getDuenho() != null && !"Banca".equalsIgnoreCase(casilla.getDuenho().getNombre())) {
            System.out.println("A casilla " + nombre + " xa ten propietario.");
            return;
        }
        casilla.comprarCasilla(jugadorActual, this.banca); // Chamamos ao metodo de compra da casilla
    }

    // Metodo que executa todas as accións relacionadas co comando 'salir carcel'
    private void salirCarcere() {
        if (this.jugadores.isEmpty()){
            return; // Verificamos que haxa xogadores
        }

        Jugador jugador = this.jugadores.get(this.turno); // Xogador que ten o turno

        if (!jugador.isEnCarcel()) { // Verificamos que o xogador estea no cárcere
            System.out.println(jugador.getNombre() + " non está no cárcere.");
            return;
        }

        jugador.salirCarcel(tablero);
    }

    // Metodo que realiza as accións asociadas ao comando 'listar enventa'
    private void listarVenta() {
        boolean hayPropiedades = false; // Inicializamos unha bandeira para saber se hai propiedades en venda

        // Percorremos todos os lados do taboleiro
        for (int lado = 0; lado < 4; lado++) {
            ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
            for (Casilla casilla : casillasLado) { // Percorremos cada casilla do lado actual
                String infoVenta = casilla.casEnVenta(); // Obtenemos a información de venda da casilla
                if (!infoVenta.isEmpty()) { // Se a casilla está en venda, mostramos a información
                    System.out.println(infoVenta);
                    hayPropiedades = true;
                }
            }
        }

        if (!hayPropiedades) { // Se non hai propiedades en venda, mostramos mensaxe
            System.out.println("Non hai propiedades en venda");
        }
    }

    // Metodo que realiza as accións asociadas ao comando 'listar jugadores'
    private void listarJugadores() {
        if (jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            System.out.println("Non hai xogadores na partida.");
            return;
        }

        // Percorremos todos os xogadores e mostramos a súa información
        for (Jugador j : this.jugadores) {
            System.out.println(j.infoJugador()); // Mostramos a información dos xogadores
        }
    }

    // Metodo que realiza as accións asociadas ao comando 'acabar turno'
    private void acabarTurno() {
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            System.out.println("Non hai xogadores");
            return;
        }
        Jugador actual = this.jugadores.get(this.turno);
        //verificamos que o xogador actual teña tirado e sexa solvente
        if (!this.tirado) {
            System.out.println("Non podes acabar o turno sen lanzar os dados.");
            return;
        }
        boolean tenDebedas = (actual.getFortuna() < 0 && !actual.isEnBancarrota());

        if (tenDebedas) {
            System.out.println(actual.getNombre() + " ten débedas pendentes. Declarase en bancarrota.");
            actual.declararBancarrota(this.tablero);
            xestionarBancarrota(actual);
        } else {
            this.turno = (this.turno + 1) % this.jugadores.size(); // Avanzamos ao seguinte xogador
            this.tirado = false; // Marcamos que non se lanzaron dados no novo turno
            this.solvente = true; // Asumimos que o novo xogador é solvent

            Jugador siguiente = this.jugadores.get(this.turno); // Obtenemos o novo xogador actual
            System.out.println("É o turno de: " + siguiente.getNombre() + "."); // Mostramos quen é o novo xogador
            System.out.println("Estado actual: " + siguiente); //toString creado en jugador
        }
    }

    //----------Métodos auxiliares----------

    // Metodo para ler o ficheiro cos comandos introducidos
    public void lerFicheiroComandos(String nomeFicheiro) {
        File ficheiro = new File(nomeFicheiro); // Creamos un obxecto File co nome do ficheiro

        if (!ficheiro.exists()) { // Comprobamos se o ficheiro existe
            System.out.println("O ficheiro non existe: " + nomeFicheiro);
            return;
        }

        Scanner scanner = null; //declara o scanner pero non o inicializa
        try {
            scanner = new Scanner(ficheiro); // Ábrese o ficheiro en modo lectura
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine().trim(); //lemos a seguinte liña e eniminamos espazos en branco ao inicio/fin
                if (!linea.isEmpty() && !linea.startsWith("#")) { // Ignoramos liñas baleiras e comentarios
                    System.out.println("$> " + linea); // Mostramos o comando que se vai executar
                    this.analizarComando(linea); // Procesamos o comando
                }
            }
        } catch (FileNotFoundException e) { // Mostramos erro se non se pode abrir o ficheiro
            System.out.println("Non se pode abrir o ficheiro: " + e.getMessage());
        } finally {
            if (scanner != null) {
                scanner.close(); // Aseguramos que pechamos o scanner
            }
        }
    }

    // Metodo auxiliar para procesar o movemento despois de lanzar dados
    private void procesarMovimento(Jugador actual, int total) {
        Avatar avatar = actual.getAvatar(); // Obtenemos o avatar do xogador actual

        // Movemos o avatar polo taboleiro
        ArrayList<ArrayList<Casilla>> todasCasillas = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            todasCasillas.add(this.tablero.getLado(i));
        }
        //moverAvatar xa verifica se pasa por "Salida"
        avatar.moverAvatar(todasCasillas, total, tablero, true);

        Casilla casillaActual = avatar.getLugar(); // Obtenemos a nova casilla

        // Si cae en Suerte o Comunidad, llamamos a las cartas
        String tipo = casillaActual.getTipo().toLowerCase();

        if ("suerte".equals(tipo)) {
            cartasSuerte.sacarCartaSuerte(actual, tablero, jugadores);
            this.solvente = !actual.isEnBancarrota();
            if (actual.getFortuna() < 0 && solvente){
                System.out.println(actual.getNombre() + " ten débedas pendentes tras a carta de Suerte.");
            }
        } else if ("comunidad".equals(tipo)) {
            cartasSuerte.sacarCartaComunidad(actual, tablero);
            this.solvente = !actual.isEnBancarrota();
            if (actual.getFortuna() < 0 && solvente){
                System.out.println(actual.getNombre() + " ten débedas pendentes tras a carta de Comunidad.");
            }
        } else {
            // Evaluar a casilla normalmente
            this.solvente = casillaActual.evaluarCasilla(actual, this.banca, total, tablero, false);
        }

        System.out.println(this.tablero); // Mostramos o taboleiro actualizado
        this.tirado = true; // Marcamos que xa se lanzaron dados neste turno
    }

    //metodo para dobles
    public void gestionarTirada(Jugador actual, int valor1, int valor2, Tablero tablero) {
        int total = valor1 + valor2; // Calculamos o total da tirada

        if (valor1 == valor2) { // Comprobar dobres
            actual.incrementarDobles(); // Incrementamos dobles consecutivos

            if (actual.getDoblesConsecutivos() == 3) { // Tres dobles consecutivos implica que debe ir ao cárcere
                System.out.println(actual.getNombre() + " sacou dobles 3 veces seguidas, vai directamente ao cárcere.");
                actual.encarcelar(tablero.getPosiciones(), tablero);
                actual.resetearDobles();
                this.tirado = true;
                acabarTurno();
                return;
            } else {
                this.procesarMovimento(actual, total);
                System.out.println("¡Dobles! " + actual.getNombre() + " tira outra vez.");
                this.lanzamientos++;

                //permitir novo lanzamiento se é solvente
                this.tirado = false;
                if (actual.isEnBancarrota() || actual.getFortuna() < 0) {
                    this.tirado = true; // Non pode tirar de novo se está en bancarrota
                    xestionarBancarrota(actual);
                }
                return;
            }
        } else { // No son dobles
            actual.resetearDobles();
            this.procesarMovimento(actual, total);
            this.lanzamientos++;
            this.tirado = true; // Turno terminado
        }
        //comprobamos que non esté en bancarrota
        if (actual.getFortuna() <= 0) {
            System.out.println(actual.getNombre() + " ten débedas pendentes.");
            // Non declarar bancarrota automática - esperar a que o xogador decida
        }
    }

    // Metodo para lanzar dados con valores forzados
    private void forzarDados(String valores) {
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            System.out.println("Non hai xogadores na partida");
            return;
        } else if (this.jugadores.size() < 2){
            System.out.println("Non se poden lanzar os dados ata que haxa polo menos 2 xogadores.");
            return;
        }

        Jugador actual = this.jugadores.get(this.turno); // Obtenemos o xogador actual

        if (actual.isEnCarcel()) { // Verificamos se o xogador está no cárcere
            if (!this.tirado) {
                int[] valoresDados = Dado.procesarTiradaForzada(valores); // Procesamos o formato "2+4"
                if (valoresDados == null) {
                    System.out.println("Formato de tirada forzada inválido. Use 'numero + numero'");
                    return;
                }
                //forzamos valores dos dados
                this.dado1.lanzarForzado(valoresDados[0]);
                this.dado2.lanzarForzado(valoresDados[1]);

                int resultado = actual.intentarSalirCarcel(this.dado1, this.dado2, tablero);
                if (resultado == -1) {
                    return; //bancarrota
                } else if (resultado == 0) {
                    this.tirado = true;
                    return; //segue no carcere
                } else {
                    this.tirado = true;
                    gestionarTirada(actual, valoresDados[0], valoresDados[1], this.tablero);
                }
            } else {
                System.out.println("Os dados xa foron tirados, remate o turno.");
            }
        } else {
            if (!tirado) {
                int[] valoresDados = Dado.procesarTiradaForzada(valores); // Procesamos o formato "2+4"
                if (valoresDados == null) {
                    System.out.println("Formato de tirada forzada inválido. Use 'numero + numero'");
                    return;
                }
                gestionarTirada(actual, valoresDados[0], valoresDados[1], tablero);
            } else {
                System.out.println("Os dados xa foron tirados, remate o turno.");
            }
        }
    }

    // Metodo para mostrar o xogador actual
    private void mostrarJugadorActual() {
        if (this.jugadores.isEmpty()) { // Verificamos que haxa xogadores na partida
            System.out.println("Non hai xogadores na partida");
            return;
        }

        Jugador actual = this.jugadores.get(this.turno); // Obtenemos o xogador actual
        System.out.println("É o turno de: " + actual.getNombre() + "."); // Mostramos quen é o novo xogador
        System.out.println("Estado actual: " + actual); //toString creado en jugador
    }

    // Metodo para crear un xogador
    private void crearJugador(String nombre, String tipoAvatar) {
        //Verificamos se xa existen demasiados xogadores
        if (this.jugadores.size() >= 4) {
            System.out.println("Xa hai 4 xogadores, non poden engadrse mais.");
            return;
        }

        for (Jugador j : this.jugadores) { // Verificamos se xa existe un xogador con ese nome
            if (j.getNombre().equalsIgnoreCase(nombre)) {
                System.out.println("Xa existe un xogador con ese nome");
                return;
            }
        }

        //Validamos que o tipo de avatar sexa correcto
        String[] tiposValidos = {"Coche", "Esfinge", "Sombrero", "Pelota"};
        boolean tipoValido = false; //poñemos unha bandeira
        for (String tipo : tiposValidos) {
            if (tipo.equalsIgnoreCase(tipoAvatar)) {
                tipoValido = true;
                break;
            }
        }
        if (!tipoValido) {
            System.out.println("Tipo de avatar non válido. Usa: Coche, Esfinge, Sombrero ou Pelota.");
            return;
        }

        //Comprobamos que o tipo de avatar non estea xa collido
        for (Avatar av : this.avatares) {
            if (av.getTipo().equalsIgnoreCase(tipoAvatar)) {
                System.out.println("O tipo de avatar '" + tipoAvatar + "' xa está en uso por outro xogador.");
                return;
            }
        }

        Casilla salida = this.tablero.encontrar_casilla("Salida"); // Buscamos a casilla de salida
        if (salida == null) {
            System.out.println("Non se atopou a casilla Salida");
            return;
        }

        // Creamos o novo xogador
        Jugador novoJugador = new Jugador(nombre, tipoAvatar, salida, this.avatares);
        this.jugadores.add(novoJugador); // Engadimos o xogador á lista
        this.avatares.add(novoJugador.getAvatar()); // Engadimos o avatar á lista

        System.out.println("{"); // Mostramos a confirmación da creación
        System.out.println("nome: " + novoJugador.getNombre() + ",");
        System.out.println("avatar: " + novoJugador.getAvatar().getId());
        System.out.println("}");

        System.out.println(this.tablero); // Mostramos o taboleiro actualizado
    }

    // Metodo auxiliar para ver o taboleiro
    private void verTablero() {
        System.out.println(this.tablero);
    }

    private void xestionarBancarrota(Jugador jugadorEnBancarrota) {
        if (this.jugadores.contains(jugadorEnBancarrota)) {
            this.jugadores.remove(jugadorEnBancarrota);
        }

        if (this.jugadores.isEmpty()) {
            System.out.println("\nTodos os xogadores en bancarrota! Xogo rematado.");
            System.exit(0);
        }
        // Axustar o turno se é necesario
        if (this.turno >= this.jugadores.size()) {
            this.turno = 0;
        }

        // Se só queda un xogador, declaramos o gañador e rematamos
        if (this.jugadores.size() == 1) {
            Jugador ganador = this.jugadores.get(0);
            System.out.println("\nO xogo rematou!");
            System.out.println("O gañador é " + ganador.getNombre() + " cunha fortuna de " + (int)ganador.getFortuna() + "€.");
            System.out.println("\nEstatísticas finais:");
            System.out.println(ganador.mostrarEstadisticas());
            System.exit(0);
        } else {
            System.out.println("Quedan " + this.jugadores.size() + " xogadores en xogo.");

            Jugador siguiente = this.jugadores.get(this.turno); // Obtenemos o novo xogador actual
            System.out.println("É o turno de: " + siguiente.getNombre() + "."); // Mostramos quen é o novo xogador
            System.out.println("Estado actual: " + siguiente); //toString creado en jugador
        }
    }


    private void estadisticasJugador(String nombreJugador) {
        Jugador jugador = null;
        for (Jugador j : jugadores) {
            if (j.getNombre().equalsIgnoreCase(nombreJugador)) {
                jugador = j;
                break;
            }
        }
        if (jugador != null) {
            System.out.println(jugador.mostrarEstadisticas());
        } else {
            System.out.println("Xogador non atopado: " + nombreJugador);
        }
    }

    private void estadisticasJuego() {
        System.out.println("{\n" +
                "casillaMasRentable: " + obtenerCasillaMasRentable() + ",\n" +
                "grupoMasRentable: " + obtenerGrupoMasRentable() + ",\n" +
                "casillaMasFrecuentada: " + obtenerCasillaMasFrecuentada() + ",\n" +
                "jugadorMasVueltas: " + obtenerJugadorMasVueltas() + ",\n" +
                "jugadorEnCabeza: " + obtenerJugadorEnCabeza() + "\n" +
                "}");
    }

    // Métodos auxiliares para estadísticas (implementación básica)
    private String obtenerCasillaMasRentable() {
       float maxRentabilidad = 0;
       String casillaMasRentable = "-";

       //Percorrer todas as casillas do taboleiro
        for (int lado = 0; lado < 4; lado++) {
            ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
            for (Casilla casilla : casillasLado) {
                if (casilla != null){
                    // A rentabilidade mídese polo total de alugueis cobrados
                    float rentabilidad = casilla.getTotalAlquileresCobrados();
                    if (rentabilidad > maxRentabilidad) {
                        maxRentabilidad = rentabilidad;
                        casillaMasRentable = casilla.getNombre();
                    }
                }
            }
        }
        return casillaMasRentable;
    }

    private String obtenerGrupoMasRentable() {
        //Map para almacenar a rentabilidade de cada grupo
        Map<String, Float> rentabilidadesGrupos = new HashMap<>();
        Map<String, String> nombresGrupos = new HashMap<>();

        // Percorrer todas as casillas do taboleiro
        for (int lado = 0; lado < 4; lado++) {
            ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
            for (Casilla casilla : casillasLado) {
                if (casilla != null && casilla.getGrupo() != null) {
                    String colorGrupo = casilla.getGrupo().getColorGrupo();
                    float alquileresCobrados = casilla.getTotalAlquileresCobrados();

                    // Acumulamos a rentabilidade do grupo
                    rentabilidadesGrupos.put(colorGrupo, rentabilidadesGrupos.getOrDefault(colorGrupo, 0f) + alquileresCobrados);
                    nombresGrupos.put(colorGrupo, colorGrupo); // Gardamos o nome do grupo
                }
            }
        }
        //Encontrar o grupo con maior rentabilidade
        String grupoMasRentable = "-";
        float maxRentabilidad = 0;
        for (Map.Entry<String, Float> entrada : rentabilidadesGrupos.entrySet()) {
            if (entrada.getValue() > maxRentabilidad) {
                maxRentabilidad = entrada.getValue();
                grupoMasRentable = nombresGrupos.get(entrada.getKey());
            }
        }
        return grupoMasRentable;
    }

    private String obtenerCasillaMasFrecuentada() {
        int maxVeces = 0;
        String casillaMasFrecuentada = "-";

        // Percorrer todas as casillas do taboleiro
        for (int lado = 0; lado < 4; lado++) {
            ArrayList<Casilla> casillasLado = this.tablero.getLado(lado);
            for (Casilla casilla : casillasLado) {
                if (casilla != null && casilla.getVecesCaida() > maxVeces) {
                    maxVeces = casilla.getVecesCaida();
                    casillaMasFrecuentada = casilla.getNombre();
                }
            }
        }
        return casillaMasFrecuentada;
    }

    private String obtenerJugadorMasVueltas() {
        int maxVueltas = 0;
        String jugadorMasVueltas = "-";

        for (Jugador j : jugadores) {
            if (j.getVueltas() > maxVueltas) {
                maxVueltas = j.getVueltas();
                jugadorMasVueltas = j.getNombre();
            }
        }
        return jugadorMasVueltas;
    }

    private String obtenerJugadorEnCabeza() {
        float maxFortuna = 0;
        String jugadorEnCabeza = "-";

        for (Jugador j : jugadores) {
            // Calcular fortuna total = diñeiro + valor propiedades + valor edificios
            float fortunaTotal = j.getFortuna();

            //sumar valor propiedades
            for (Casilla propiedad : j.getPropiedades()) {
                fortunaTotal += propiedad.getValor();
                Solares.DatosEdificios edificios = propiedad.getDatosedificios();
                if (edificios != null) {
                    fortunaTotal += Solares.calcularAlquiler(propiedad);
                }
            }
            if (fortunaTotal > maxFortuna) {
                maxFortuna = fortunaTotal;
                jugadorEnCabeza = j.getNombre();
            }
        }
        return jugadorEnCabeza;
    }

    public Tablero getTablero() {
        return this.tablero;
    }
}
