package partida;

import java.util.ArrayList;
import monopoly.casillas.*;
import monopoly.edificios.*;
import monopoly.Trato;

import monopoly.*;
import monopoly.casillas.Casilla;


public class Jugador {

    //Atributos:
    private String nombre; //Nombre del jugador
    private Avatar avatar; //Avatar que tiene en la partida.
    private float fortuna; //Dinero que posee.
    private float gastos; //Gastos realizados a lo largo del juego.
    private boolean enCarcel; //Será true si el jugador está en la carcel
    private int tiradasCarcel; //Cuando está en la carcel, contará las tiradas sin éxito que ha hecho allí para intentar salir (se usa para limitar el numero de intentos).
    private int vueltas; //Cuenta las vueltas dadas al tablero.
    private ArrayList<Casilla> propiedades; //Propiedades que posee el jugador.
    private ArrayList<Casilla> hipotecas; //nova
    private ArrayList<Edificio> edificios; //nova
    private boolean enBancarrota;    //novo: 0 si el jugador no está en bancarrota; 1 si está en bancarrota
    private int doblesConsecutivos; //contador de dobles consecutivos para cada xogador
    private Jugador ultimoCobraAlquiler; //ultimo xogador que lle cobrou un aluguer ao xogador actual
    private ArrayList<Trato> tratosPendientes = new ArrayList<>(); //tratos pendentes
    private ArrayList<Trato> tratosPropuestos = new ArrayList<>(); //tratos propostos

    //Para mostrar estatísticas
    private float dineroInvertido; //dinero invertido na compra de propiedades e edificaciones de cada xogador
    private float pagoTasasEImpuestos; //pago de tasas e impostos
    private float pagoDeAlquileres; //pago de alquileres
    private float cobroDeAlquileres; //cobro de alquileres
    private float pasarPorCasillaSalida; //diñeiro recibido ao pasar pola casilla de salida
    private float premiosInversionesOBote; //diñeiro recibido por inversiones, premios ou polo bote ao caer na casilla parking
    private int vecesEnCarcel; //veces que caeu na casila carcel


    //Constructor vacío. Se usará para crear la banca.
    public Jugador() {
        this.nombre = "Banca";
        this.fortuna = 0f; //A banca ten diñeiro ilimitado
        this.gastos = 0f;
        this.enCarcel  = false;
        this.tiradasCarcel = 0;
        this.vueltas = 0;
        this.propiedades = new ArrayList<>();
        this.hipotecas = new ArrayList<>();
        this.edificios = new ArrayList<Edificio>();
        this.enBancarrota = false;

        inicializarEstadisticas();
        //A banca non ten avatar nin pode estar en bancarrota

    }

    /*Constructor principal. Requiere parámetros:
     * Nombre del jugador, tipo del avatar que tendrá, casilla en la que empezará y ArrayList de
     * avatares creados (usado para dos propósitos: evitar que dos jugadores tengan el mismo nombre y
     * que dos avatares tengan mismo ID). Desde este constructor también se crea el avatar.
     */
    public Jugador(String nombre, String tipoAvatar, Casilla inicio, ArrayList<Avatar> avCreados) {
        //Comprobar que non exista un xogador co mesmo nome ou avatar repetido
        this.nombre = nombre;
        this.fortuna = Valor.FORTUNA_INICIAL; //saldo inicial do xogador
        this.gastos = 0f;
        this.enCarcel  = false;
        this.tiradasCarcel = 0;
        this.vueltas = 0;
        this.propiedades = new ArrayList<>();
        this.hipotecas = new ArrayList<>();
        this.edificios = new ArrayList<>();
        this.enBancarrota = false;       //Non é posible que un xogador empece a partida estando en bancarrota

        //creamos un avatar asociado
        this.avatar = new Avatar(tipoAvatar, this, inicio, avCreados);
        this.doblesConsecutivos = 0; //inicalizamos a 0
        this.ultimoCobraAlquiler = null; //ningun xogador lle cobrou aluguer aínda
        inicializarEstadisticas();
    }

    //Metodo para añadir una propiedad al jugador. Como parámetro, la casilla a añadir.
    public void anhadirPropiedad(Casilla casilla) {
        if (casilla != null && !propiedades.contains(casilla)) { //compóbase que un xogador non teña esa propiedade
            this.propiedades.add(casilla);

            // Verificar si é unha Propiedade
            if (casilla instanceof Propiedad) {
                ((Propiedad) casilla).setDuenho(this);
            } else {
                //Se non é unha Propiedade, non ten dono (por exemplo o Carcere)
                Juego.getConsola().imprimir(casilla.getNombre() + " non é unha propiedade, non ten dono.");
            }
        }
    }

    //Metodo para eliminar una propiedad del arraylist de propiedades de jugador.
    public void eliminarPropiedad(Casilla casilla) {
        if (casilla!= null){
            this.propiedades.remove(casilla); //non se comproba se esta nas propiedades do xogador porque faino remove directamente
        }
    }

    //Metodo para añadir fortuna a un jugador
    //Como parámetro se pide el valor a añadir. Si hay que restar fortuna, se pasaría un valor negativo.
    public void sumarFortuna(float valor) {
        this.fortuna += valor;
        if (valor < 0) {
            this.sumarGastos(Math.abs(valor)); // Só sumar gastos se é negativo (pago)
            //Math.abs é o valor absoluto
        }
        if (this.fortuna < 0 && !this.enBancarrota) {
            Juego.getConsola().imprimir(this.nombre + " entrou en números vermellos: " + (int) this.fortuna + "€");
        }
    }

    //Metodo para sumar gastos a un jugador.
    //Parámetro: valor a añadir a los gastos del jugador (será el precio de un solar, impuestos pagados...).
    public void sumarGastos(float valor) {
        this.gastos += valor;
    }

    /*Metodo para establecer al jugador en la cárcel.
     * Se requiere disponer de las casillas del tablero para ello (por eso se pasan como parámetro).*/
    public void encarcelar(ArrayList<ArrayList<Casilla>> pos, Tablero tablero) {
        this.enCarcel = true;
        this.tiradasCarcel = 0;
        this.vecesEnCarcel++; //incrementamos o contador de veces que caeu na carcel

        //buscar casilla carcel
        Casilla carcel = tablero.encontrar_casilla("Carcel");

        // Movemos o avatar ao cárcere
        if (carcel != null && this.avatar != null) {
            // Quitamos o avatar da súa casilla actual
            Casilla casillaActual = this.avatar.getLugar();
            if (casillaActual != null) {
                casillaActual.eliminarAvatar(this.avatar);
            }

            // Colocamos o avatar no cárcere
            this.avatar.setLugar(carcel);
            carcel.anhadirAvatar(this.avatar);
        }
    }

    //----------Metodos auxiliares

    private void inicializarEstadisticas() {
        this.dineroInvertido = 0f;
        this.pagoTasasEImpuestos = 0f;
        this.pagoDeAlquileres = 0f;
        this.cobroDeAlquileres = 0f;
        this.pasarPorCasillaSalida = 0f;
        this.premiosInversionesOBote = 0f;
        this.vecesEnCarcel = 0;
    }

    //Metodo para saber se un xogador ten suficiente diñeiro para pagar
    public boolean puedePagar(float valor) {
        //se o diñeiro que ten é maior ca o que debe pagar entón pode pagar
        return this.fortuna >= valor;
    }

    // Pagar a outro xogador automaticamente
    public boolean pagarJugador(Jugador receptor, float cantidad, Tablero tablero) {
        if (this.puedePagar(cantidad)) {
            this.sumarFortuna(-cantidad); //restamos o que ten que pagar
            receptor.sumarFortuna(cantidad); //sumamos ao que lle debe

            //this.pagoDeAlquileres += cantidad; //sumamos ao pago de alugueres
            //receptor.cobroDeAlquileres += cantidad; //sumamos ao cobro de alugueres
            return true;
        } else {
            this.sumarFortuna(-cantidad); //restamos o que ten que pagar
            Juego.getConsola().imprimir(this.nombre + " non pode pagar ");
            Juego.getConsola().imprimir("Opcións dispoñibles:");
            Juego.getConsola().imprimir("   - 'hipotecar <casilla>' para obter diñeiro");
            Juego.getConsola().imprimir("   - 'acabar turno' para declararse en bancarrota");
            return false;
        }
    }

    // Para o comando "salir cárcel"
    public void salirCarcel(Tablero tablero) {
        if (this.enCarcel && this.puedePagar(Valor.CARCEL_SALIDA)) { //se está no cárcere e pode pagar a saida
            this.sumarFortuna(-Valor.CARCEL_SALIDA); //réstaselle o que debe pagar
            this.pagoTasasEImpuestos += Valor.CARCEL_SALIDA; //sumamos ao pago de taxas e impostos
            this.enCarcel = false; //sae do cárcere
            this.tiradasCarcel = 0;
            Juego.getConsola().imprimir(this.nombre + " paga " + (int)Valor.CARCEL_SALIDA + "€ e sae do cárcere.");
        } else if (this.enCarcel && !this.puedePagar(Valor.CARCEL_SALIDA)) { //se non pode pagar a saida do cárcere
            Juego.getConsola().imprimir(this.nombre + " non ten diñeiro para sair do cárcere.");
        } else {
            Juego.getConsola().imprimir(this.nombre + " non está no cárcere.");
        }
    }

    // Metodo que se chama no turno para lanzar dados estando no cárcere
    // Retorna: 0 = sigue en cárcel, 1 = sale y puede moverse, -1 = bancarrota
    public int intentarSalirCarcel(Dado dado1, Dado dado2, Tablero tablero, boolean forzarTirada, int valorForzado1, int valorForzado2) {
        if (!enCarcel){
            return 1; // non está en cárcere, pode mover
        }

        tiradasCarcel++; // incremento turno en cárcere
        int v1, v2;
        // Tirada forzada
        if (forzarTirada) {
            v1 = valorForzado1;
            v2 = valorForzado2;
            // Realizamos tirada forzada
            dado1.lanzarForzado(v1);
            dado2.lanzarForzado(v2);
        } else {
            // Tirada normal
            v1 = dado1.hacerTirada();
            v2 = dado2.hacerTirada();
        }

        Juego.getConsola().imprimir(this.nombre + " saca " + v1 + " e " + v2 + " (turno " + this.tiradasCarcel + "/3)");

        if (v1 == v2) { // sacou dobles
            Juego.getConsola().imprimir(this.nombre + " saca dobles e sae do cárcere sen pagar.");
            this.enCarcel = false; //sae do carcere
            this.tiradasCarcel = 0; //se reinician
            return 1; // pode mover

        } else if (tiradasCarcel >= 3) { // 3 turnos sen sacar dobles, paga necesariamente
            if (puedePagar(Valor.CARCEL_SALIDA)) {
                salirCarcel(tablero);
                return 1; // pode mover e sae co valor dos dados
            } else {
                Juego.getConsola().imprimir(nombre + " non pode pagar para sair do cárcere.");
                this.declararBancarrota(tablero, null); //pasa as súas propiedades á banca
                return -1; // non pode mover, esta en bancarrota
            }
        }
        // Non sacou dobres e non leva 3 turnos
        return 0; // segue no cárcere
    }

    // Declara ao xogador en bancarrota
    public void declararBancarrota(Tablero tablero, Jugador pagarA) {
        if (this.enBancarrota){
            return; // Se xa está en bancarrota, non facemos nada
        }
        this.enBancarrota = true; // Marcamos ao xogador en bancarrota
        this.fortuna = 0;

        Jugador receptor = pagarA != null ? pagarA : tablero.getBanca(); // Se pagarA é null, pasaranse á banca

        //Transferimos as propiedades ao xogador ao que se lle debe diñeiro, mantendo as hipotecas
        ArrayList<Casilla> propiedadesHipotecadas = new ArrayList<>(this.hipotecas); // Creamos unha copia para evitar erro
        for (Casilla c : propiedadesHipotecadas) {
            if (c instanceof Propiedad) {
                ((Propiedad) c).setDuenho(receptor);  //transferimos a propiedade
            }
            if (receptor != tablero.getBanca()) {
                receptor.anhadirHipoteca(c); //o receptor mantén a hipoteca
            }
            this.eliminarHipoteca(c); //eliminamos a hipoteca do xogador en bancarrota
        }
        //transferir propiedades non hipotecadas
        ArrayList<Casilla> propiedadesNoHipotecadas = new ArrayList<>(this.propiedades); // Creamos unha copia para evitar erro
        for (Casilla c : propiedadesNoHipotecadas) {
            if (this.hipotecas.contains(c)) {
                continue; // Xa foi procesada como hipotecada
            }
            if (c instanceof Propiedad) {
                ((Propiedad) c).setDuenho(receptor);
            }
            if (receptor != tablero.getBanca()) {
                receptor.anhadirPropiedad(c); //transferimos a propiedade
            }
            this.eliminarPropiedad(c); //eliminamos a propiedade do xogador en bancarrota
        }

        this.propiedades.clear(); //clear elimina todos os elementos do arrayList
        this.hipotecas.clear(); // Liberamos hipotecas
        this.edificios.clear(); // Liberamos edificios (lista de obxetos)

        // Movemos avatar a null (ou deixámolo no tablero sen acción)
        if (this.avatar != null) {
            Casilla lugarActual = this.avatar.getLugar();
            if (lugarActual != null) {
                lugarActual.eliminarAvatar(this.avatar);
            }
            this.avatar = null; // O xogador xa non participa
        }

        if (pagarA != null) {
            Juego.getConsola().imprimir(this.nombre + " declárase en bancarrota e transfire as súas propiedades a " + pagarA.getNombre() + ".");
        } else {
            Juego.getConsola().imprimir(this.nombre + " declárase en bancarrota e transfire as súas propiedades á banca.");
        }
    }


    public void eliminarEdificio(String idEdificio) {
        for (int i = 0; i < edificios.size(); i++) {
            if (edificios.get(i).getId().equals(idEdificio)) {
                edificios.remove(i);
                break;
            }
        }
    } //eliminar un edificio da lista do xogador

    public void sumarInversion(float valor) {
        this.dineroInvertido += valor;
    }

    public void registrarPasoSalida(float valor) {
        this.pasarPorCasillaSalida += valor;
        this.incrementarVueltas();
    }

    public void registrarPremio(float valor) {
        this.premiosInversionesOBote += valor;
    }

    public void registrarTasa(float valor) {
        this.pagoTasasEImpuestos += valor;
    }

    public void incrementarVueltas() {
        this.vueltas++;
    }

    public void registrarPagoAlquiler(float valor) {
        this.pagoDeAlquileres += valor;
    }

    public void registrarCobroAlquiler(float valor) {
        this.cobroDeAlquileres += valor;
    }

    public void registrarVecesEnCarcel() {
        this.vecesEnCarcel++;
    }

    public void anhadirHipoteca(Casilla propiedad) {
        if (propiedad != null && !hipotecas.contains(propiedad)) {
            this.hipotecas.add(propiedad);
        }
    }

    public void anhadirEdificio(Edificio edificio) {
        if (edificio != null && !edificios.contains(edificio)){
            this.edificios.add(edificio);
        }
    }

    public void eliminarHipoteca(Casilla propiedad) {
        this.hipotecas.remove(propiedad);
    }

    public String infoJugador(){
        StringBuilder info = new StringBuilder();
        info.append("{\n");

        info.append("nome: ").append(this.nombre).append("\n");
        info.append("avatar: ").append(this.avatar != null ? this.avatar.getId() : "—").append("\n");
        info.append("fortuna: ").append((int)this.fortuna).append("\n");

        // Propiedades
        info.append("propiedades: [");
        int count = 0;
        for (Casilla p : this.propiedades){
            info.append(p.getNombre());
            if (++count < this.propiedades.size()){
                info.append(", ");
            }
        }
        info.append("]\n");

        // Hipotecas
        info.append("hipotecas: [");
        count = 0;
        for (Casilla h : this.hipotecas){
            info.append(h.getNombre());
            if (++count < this.hipotecas.size()){
                info.append(", ");
            }
        }
        info.append("]\n");

        // Edificios
        info.append("edificios: [");
        count = 0;
        for (monopoly.edificios.Edificio e : this.edificios) {
            info.append(e.getId());
            if (++count < this.edificios.size()) {
                info.append(", ");
            }
        }
        info.append("]\n");

        info.append("}");
        return info.toString();
    }

    public String mostrarEstadisticas() {
        StringBuilder info = new StringBuilder();
        info.append("{\n");
        info.append("dineroInvertido: ").append((int)this.dineroInvertido).append(",\n");
        info.append("pagoTasasEImpuestos: ").append((int)this.pagoTasasEImpuestos).append(",\n");
        info.append("pagoDeAlquileres: ").append((int)this.pagoDeAlquileres).append(",\n");
        info.append("cobroDeAlquileres: ").append((int)this.cobroDeAlquileres).append(",\n");
        info.append("pasarPorCasillaDeSalida: ").append((int)this.pasarPorCasillaSalida).append(",\n");
        info.append("premiosInversionesOBote: ").append((int)this.premiosInversionesOBote).append(",\n");
        info.append("vecesEnLaCarcel: ").append(this.vecesEnCarcel).append("\n");
        info.append("}");
        return info.toString();
    }


    // Incrementa o contador de dobles
    public void incrementarDobles() {
        this.doblesConsecutivos++;
    }

    // Resetea o contador de dobles
    public void resetearDobles() {
        this.doblesConsecutivos = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public Avatar getAvatar() {
        return this.avatar;
    }

    public float getFortuna() {
        return fortuna;
    }

    public boolean isEnCarcel() {
        return enCarcel;
    }

    public int getDoblesConsecutivos() {
        return doblesConsecutivos;
    }

    public void setEnCarcel(boolean enCarcel) {
        this.enCarcel = enCarcel;
    }

    public boolean isEnBancarrota() {
        return enBancarrota;
    }

    public ArrayList<Casilla> getPropiedades() {
        return propiedades;
    }

    public ArrayList<Edificio> getEdificios() {
        return edificios;
    }

    public int getVueltas() {
        return vueltas;
    }

    public Jugador getUltimoCobraAlquiler() {
        return ultimoCobraAlquiler;
    }

    public void setUltimoCobraAlquiler(Jugador ultimoCobraAlquiler) {
        this.ultimoCobraAlquiler = ultimoCobraAlquiler;
    }

    @Override
    public String toString() {
        return "{nombre: " + nombre + ", avatar: " + (avatar != null ? avatar.getId() : "—") +
                ", fortuna: " + (int)fortuna + ", propiedades: " + propiedades.size() +
                ", hipotecas: " + hipotecas.size() + ", edificios: " + edificios.size() + "}";
    }

    //metodos para xestionar tratos pendentes e propostos

    public void recibirTrato(Trato t){
        tratosPendientes.add(t);
    }

    public void proponerTrato(Trato t){
        tratosPropuestos.add(t);
    }
    
    public void eliminarTratoPendiente(Trato t) {
        tratosPendientes.remove(t);
    }

    public void eliminarTratoPropuesto(Trato t) {
        tratosPropuestos.remove(t);
    }

    public Trato buscarTratoPendientePorId(String id) {
        for (Trato t : tratosPendientes) {
            if (t.getId().equals(id)) {
                return t;
            }
        }
        return null;
    }

    public Trato buscarTratoPropuestoPorId(String id) {
        for (Trato t : tratosPropuestos) {
            if (t.getId().equals(id)) {
                return t;
            }
        }
        return null;
    }

    //getters de tratos

    public ArrayList<Trato> getTratosPendientes() { return tratosPendientes; }
    public ArrayList<Trato> getTratosPropuestos() { return tratosPropuestos; }
}

