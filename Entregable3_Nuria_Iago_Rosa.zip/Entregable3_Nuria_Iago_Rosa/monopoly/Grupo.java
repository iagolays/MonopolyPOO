package monopoly;

import monopoly.casillas.*;
import monopoly.exceptions.MonopolyException;
import partida.*;
import java.util.ArrayList;

public class Grupo {

    //Atributos
    private ArrayList<Propiedad> miembros; //Casillas membros do grupo
    private String colorGrupo;             //Cor identificativa do grupo
    private int numCasillas;               //Número total de casillas do grupo
    private float alquilerTotal;           //Estatística opcional

    public Grupo(String colorGrupo) {
        this.miembros = new ArrayList<>();
        this.colorGrupo = colorGrupo;
        this.numCasillas = 0;
        this.alquilerTotal = 0;
    }

    public Grupo() {
        this.miembros = new ArrayList<>();
        this.colorGrupo = "";
        this.numCasillas = 0;
        this.alquilerTotal = 0;
    }

    public Grupo(Solar cas1, Solar cas2, String colorGrupo) {
        this(colorGrupo);
        anhadirCasilla(cas1);
        anhadirCasilla(cas2);
    }

    public Grupo(Solar cas1, Solar cas2, Solar cas3, String colorGrupo) {
        this(colorGrupo);
        anhadirCasilla(cas1);
        anhadirCasilla(cas2);
        anhadirCasilla(cas3);
    }

    public void anhadirCasilla(Solar miembro) {
        if (miembro != null && !miembros.contains(miembro)) {
            miembros.add(miembro);
            miembro.setGrupo(this);     // Vincúlase pola outra banda
            numCasillas = miembros.size();
        }
    }

    public boolean esDuenhoGrupo(Jugador jugador) {
        if (jugador == null || miembros.isEmpty()) return false;

        for (Propiedad p : miembros) {
            if (p.getDuenho() == null || !p.getDuenho().equals(jugador)) {
                return false;
            }
        }
        return true;
    }

    public static String calcularColor(Casilla c) {
        int pos = c.getPosicion();
        final String RESET = "\u001B[0m";

        final String MARRON   = "\u001B[38;5;130m";
        final String AZUL_CL  = "\u001B[36m";
        final String ROSA     = "\u001B[35m";
        final String NARANJA  = "\u001B[33m";
        final String ROJO     = "\u001B[31m";
        final String AMARILLO = "\u001B[93m";
        final String VERDE    = "\u001B[32m";
        final String AZUL_OSC = "\u001B[34m";

        if (pos == 1 || pos == 3) return MARRON + c.getNombre() + RESET;
        if (pos == 6 || pos == 8 || pos == 9) return AZUL_CL + c.getNombre() + RESET;
        if (pos == 11 || pos == 13 || pos == 14) return ROSA + c.getNombre() + RESET;
        if (pos == 16 || pos == 18 || pos == 19) return NARANJA + c.getNombre() + RESET;
        if (pos == 21 || pos == 23 || pos == 24) return ROJO + c.getNombre() + RESET;
        if (pos == 26 || pos == 27 || pos == 29) return AMARILLO + c.getNombre() + RESET;
        if (pos == 31 || pos == 32 || pos == 34) return VERDE + c.getNombre() + RESET;
        if (pos == 37 || pos == 39) return AZUL_OSC + c.getNombre() + RESET;

        return c.getNombre();
    }

    public String obtenerInfoEdificios() throws MonopolyException {
        StringBuilder info = new StringBuilder();
        boolean primerElemento = true;
        boolean hayPropiedades = false;

        for (Propiedad propiedad : miembros) {
            if (propiedad instanceof Solar) {
                Solar solar = (Solar) propiedad;
                if (!primerElemento) {
                    info.append(",\n");
                }
                primerElemento = false;
                hayPropiedades = true;
                Jugador duenho = propiedad.getDuenho();

                info.append("{\n");
                info.append("propiedad: ").append(propiedad.getNombre()).append(",\n");

                if (duenho != null) {
                    // Hoteles
                    info.append("hoteles: ");
                    ArrayList<String> hotelesList = obtenerEdificiosTipo(solar, "hotel");
                    info.append(hotelesList.isEmpty() ? "-" : hotelesList.toString()).append(",\n");

                    // Casas
                    info.append("casas: ");
                    ArrayList<String> casasList = obtenerEdificiosTipo(solar, "casa");
                    info.append(casasList.isEmpty() ? "-" : casasList.toString()).append(",\n");

                    // Piscinas
                    info.append("piscinas: ");
                    ArrayList<String> piscinasList = obtenerEdificiosTipo(solar, "piscina");
                    info.append(piscinasList.isEmpty() ? "-" : piscinasList.toString()).append(",\n");

                    // Pistas de deporte
                    info.append("pistasDeDeporte: ");
                    ArrayList<String> pistasList = obtenerEdificiosTipo(solar, "pista");
                    info.append(pistasList.isEmpty() ? "-" : pistasList.toString()).append(",\n");
                } else {
                    info.append("hoteles: -,\n");
                    info.append("casas: -,\n");
                    info.append("piscinas: -,\n");
                    info.append("pistasDeDeporte: -,\n");
                }

                // Calcular alquiler del solar
                float alquiler = solar.calcularAlquiler();
                info.append("alquiler: ").append((int) alquiler).append("\n");
                info.append("}");
            }
        }

        if (!hayPropiedades) {
            return "Non hai solares neste grupo.";
        }

        info.append("\n").append(obtenerInfoConstruccionPosible());
        return info.toString();
    }

    private ArrayList<String> obtenerEdificiosTipo(Solar solar, String tipo) {
        ArrayList<String> resultado = new ArrayList<>();

        // metodo getIdsEdificios() de solar devuelve unha lista de IDs de edificios
        for (String idEdificio : solar.getIdsEdificios()) {
            if (idEdificio.startsWith(tipo + "-")) {
                resultado.add(idEdificio);
            }
        }

        return resultado;
    }

    public String obtenerInfoConstruccionPosible() {
        int totalCasas = 0;
        int totalHoteles = 0;
        int totalPiscinas = 0;
        int totalPistas = 0;

        int maxCasasPorSolar = 4;
        int maxHotelesPorSolar = 1;
        int maxPiscinasPorSolar = 1;
        int maxPistasPorSolar = 1;

        int posiblesCasas = 0;
        int posiblesHoteles = 0;
        int posiblesPiscinas = 0;
        int posiblesPistas = 0;

        for (Propiedad propiedad : miembros) {
            if (propiedad instanceof Solar) {
                Solar solar = (Solar) propiedad;
                Jugador duenho = propiedad.getDuenho();

                if (duenho != null && solar.getGrupo() != null && solar.getGrupo().esDuenhoGrupo(duenho)) {
                    totalCasas += solar.getNumCasas();
                    totalHoteles += solar.getNumHoteles();
                    totalPiscinas += solar.getNumPiscinas();
                    totalPistas += solar.getNumPistas();

                    // Calcular posibles construcciones
                    if (solar.getNumCasas() < maxCasasPorSolar && solar.getNumHoteles() == 0) {
                        posiblesCasas += (maxCasasPorSolar - solar.getNumCasas());
                    }

                    if (solar.getNumCasas() == maxCasasPorSolar && solar.getNumHoteles() < maxHotelesPorSolar) {
                        posiblesHoteles++;
                    }

                    if (solar.getNumHoteles() == maxHotelesPorSolar && solar.getNumPiscinas() < maxPiscinasPorSolar) {
                        posiblesPiscinas++;
                    }

                    if (solar.getNumHoteles() == maxHotelesPorSolar &&
                            solar.getNumPiscinas() == maxPiscinasPorSolar &&
                            solar.getNumPistas() < maxPistasPorSolar) {
                        posiblesPistas++;
                    }
                }
            }
        }

        // Construir mensaje
        StringBuilder mensaje = new StringBuilder();
        ArrayList<String> disponibles = new ArrayList<>();

        if (posiblesCasas > 0) {
            disponibles.add(posiblesCasas + " casa" + (posiblesCasas > 1 ? "s" : ""));
        }
        if (posiblesHoteles > 0) {
            disponibles.add(posiblesHoteles + " hotel" + (posiblesHoteles > 1 ? "s" : ""));
        }
        if (posiblesPiscinas > 0) {
            disponibles.add(posiblesPiscinas + " piscina" + (posiblesPiscinas > 1 ? "s" : ""));
        }
        if (posiblesPistas > 0) {
            disponibles.add(posiblesPistas + " pista" + (posiblesPistas > 1 ? "s" : "") + " de deporte");
        }

        if (disponibles.isEmpty()) {
            mensaje.append("Xa non se poden construír máis edificios neste grupo.");
        } else {
            mensaje.append("Aínda se poden edificar ");
            for (int i = 0; i < disponibles.size(); i++) {
                mensaje.append(disponibles.get(i));
                if (i < disponibles.size() - 2) {
                    mensaje.append(", ");
                } else if (i == disponibles.size() - 2) {
                    mensaje.append(" e ");
                }
            }
            mensaje.append(".");
        }

        return mensaje.toString();
    }

    private int contarEdificiosTipo(Solar solar, String tipo) {
        int contador = 0;
        for (String idEdificio : solar.getIdsEdificios()) {
            if (idEdificio.startsWith(tipo + "-")) {
                contador++;
            }
        }
        return contador;
    }

    public String obtenerColor() {
        switch (this.colorGrupo.toLowerCase()) {
            case "marrón":
            case "marron":
            case "brown":
                return "\u001B[38;5;130m";
            case "azul_claro":
            case "azul claro":
            case "light_blue":
                return "\u001B[36m";
            case "rosa":
            case "pink":
                return "\u001B[35m";
            case "naranja":
            case "orange":
                return "\u001B[33m";
            case "rojo":
            case "red":
                return "\u001B[31m";
            case "amarillo":
            case "yellow":
                return "\u001B[93m";
            case "verde":
            case "green":
                return "\u001B[32m";
            case "azul_oscuro":
            case "azul oscuro":
            case "dark blue":
                return "\u001B[34m";
            default:
                return "\u001B[97m";
        }
    }

    public String getColorGrupo() {
        return colorGrupo;
    }

    public ArrayList<Propiedad> getMiembros() {
        return miembros;
    }

    @Override
    public String toString() {
        return "Grupo{color='" + colorGrupo + "', casillas=" + numCasillas + "}";
    }

    public float sumarAlquilerGrupo(float cantidad) {
        this.alquilerTotal += cantidad;
        return alquilerTotal;
    }

    public boolean todosDeshipotecados(Jugador jugador) {
        if (!esDuenhoGrupo(jugador)) {
            return false;
        }

        for (Propiedad propiedad : miembros) {
            if (propiedad instanceof Solar) {
                Solar solar = (Solar) propiedad;
                if (solar.estaHipotecada()) {
                    return false;  // Encontró un solar hipotecado
                }
            }
        }
        return true;  // Todos los solares están deshipotecados
    }
}