package monopoly;

import partida.Jugador;
import monopoly.casillas.Propiedad;

public class Trato {

    private String id; //id do tipo trato2
    private Jugador propone; // xogador que propón o trato
    private Jugador receptor; // xogador que recibe a proposta
    private Propiedad propiedadOfrecida; //propiedade ofrecida no trato
    private Propiedad propiedadPedida; //propiedade pedida no trato
    private float dineroOfrecido; //diñeiro ofrecido no trato
    private float dineroPedido; //diñeiro pedido no trato

    // Constructor
    public Trato(String id, Jugador propone, Jugador receptor, Propiedad propiedadOfrecida, Propiedad propiedadPedida,
                 float dineroOfrecido, float dineroPedido) {
        this.id = id;
        this.propone = propone;
        this.receptor = receptor;
        this.propiedadOfrecida = propiedadOfrecida;
        this.propiedadPedida = propiedadPedida;
        this.dineroOfrecido = dineroOfrecido;
        this.dineroPedido = dineroPedido;
    }

    public String getId() { return id; }
    public Jugador getPropone() { return propone; }
    public Jugador getReceptor() { return receptor; }
    public Propiedad getPropiedadOfrecida() { return propiedadOfrecida; }
    public Propiedad getPropiedadPedida() { return propiedadPedida; }
    public float getDineroOfrecido() { return dineroOfrecido; }
    public float getDineroPedido() { return dineroPedido; }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("id: ").append(id).append(",\n");
        sb.append("jugadorPropone: ").append(propone.getNombre()).append(",\n");
        sb.append("trato: cambiar (");

        // Construir parte ofrecida
        StringBuilder ofrecido = new StringBuilder();
        if (propiedadOfrecida != null) {
            ofrecido.append(propiedadOfrecida.getNombre());
        }
        if (dineroOfrecido > 0) {
            if (!ofrecido.isEmpty()) {
                ofrecido.append(" y ");
            }
            ofrecido.append((int)dineroOfrecido).append("€");
        }

        // Construir parte pedida
        StringBuilder pedido = new StringBuilder();
        if (propiedadPedida != null) {
            pedido.append(propiedadPedida.getNombre());
        }
        if (dineroPedido > 0) {
            if (!pedido.isEmpty()) {
                pedido.append(" y ");
            }
            pedido.append((int)dineroPedido).append("€");
        }

        // Si ambas partes están vacías (no debería pasar)
        if (ofrecido.isEmpty()){
            ofrecido.append("0€");
        }
        if (pedido.isEmpty()){
            pedido.append("0€");
        }

        sb.append(ofrecido).append(" , ").append(pedido);
        sb.append(")\n");
        sb.append("}");
        return sb.toString();
    }
}