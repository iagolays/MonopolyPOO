package monopoly.cartas;

import partida.*;
import monopoly.*;
import monopoly.casillas.*;
import monopoly.exceptions.*;
import java.util.ArrayList;

public class CartaSuerte extends Carta {

    private TipoAccion tipoAccion;

    public CartaSuerte(String descripcion, int id, TipoAccion tipoAccion) {
        super(descripcion, id);
        this.tipoAccion = tipoAccion;
    }

    @Override
    public void accion(Jugador jugador, Tablero tablero) throws MonopolyException {
        switch(tipoAccion) {
            case AVANZAR_SOLAR19:
                avanzarASolar19(jugador, tablero);
                break;
            case IR_CARCEL:
                irCarcel(jugador, tablero);
                break;
            case LOTERIA:
                ganarLoteria(jugador);
                break;
            case PAGAR_TODOS:
                pagarATodos(jugador, tablero);
                break;
            case RETROCEDER3:
                retroceder3(jugador, tablero);
                break;
            case MULTA_MOVIL:
                multaMovil(jugador, tablero);
                break;
            case AVANZAR_TRANSPORTE:
                avanzarTransporte(jugador, tablero);
                break;
        }
    }

    private void avanzarASolar19(Jugador jugador, Tablero tablero) {
        jugador.getAvatar().moverAvatarHasta("Solar19", tablero.getPosiciones(), tablero, true);
        Casilla destino = tablero.encontrar_casilla("Solar19");

        if (destino instanceof Propiedad prop) { //Verifica se é unha propiedade
            try {
                if (prop.getDuenho() != null && !prop.getDuenho().equals(jugador)) { //se ten dono e non é o xogador cobra aluguer
                    float alquiler = prop.alquiler(0, true);
                    jugador.pagarJugador(prop.getDuenho(), alquiler, tablero);
                }
            } catch (MonopolyException e) { //Captura excepcións de pago de aluguer
                Juego.getConsola().imprimir(e.getMessage());
            }
        }
    }


    private void irCarcel(Jugador jugador, Tablero tablero) {
        Casilla carcel = tablero.encontrar_casilla("Carcel");
        if (carcel != null) {
            jugador.encarcelar(tablero.getPosiciones(), tablero);
        }
    }

    private void ganarLoteria(Jugador jugador) {
        jugador.sumarFortuna(1000000);
        jugador.registrarPremio(1000000);
    }

    private void pagarATodos(Jugador pagador, Tablero tablero) {
        ArrayList<Jugador> todosJugadores = tablero.getJugadores();
        int numJugadoresAPagar = 0;

        for (Jugador j : todosJugadores) { // Contar xogadores a pagar
            if (j != pagador && !j.isEnBancarrota()) {
                numJugadoresAPagar++;
            }
        }

        float total = numJugadoresAPagar * 250000f; // Calcular total a pagar para verificar que pode pagar a todos

        if (pagador.puedePagar(total)) {
            for (Jugador j : todosJugadores) {
                if (j != pagador && !j.isEnBancarrota()) {
                    pagador.pagarJugador(j, 250000f, tablero);
                }
            }
        } else { //se non pode pagar
            pagador.sumarFortuna(-total);
            // Notificar sobre deudas
            Juego.getConsola().imprimir("\n" + pagador.getNombre() + " non pode pagar o imposto de " + (int)total + "€.");
            Juego.getConsola().imprimir("Opcións dispoñibles:");
            Juego.getConsola().imprimir("   - 'hipotecar <casilla>' para obter diñeiro");
            Juego.getConsola().imprimir("   - 'acabar turno' para declararse en bancarrota");
            pagador.setUltimoCobraAlquiler(tablero.getBanca());
        }
    }

    private void retroceder3(Jugador jugador, Tablero tablero) {
        jugador.getAvatar().moverAvatar(tablero.getPosiciones(), -3, tablero, false);
    }

    private void multaMovil(Jugador jugador, Tablero tablero) {
        float multa = 150000f;
        if (jugador.puedePagar(multa)) {
            jugador.sumarFortuna(-multa);
            jugador.registrarTasa(multa);

            Parking parking = (Parking) tablero.encontrar_casilla("Parking");
            //Poderíase comprobar que é instancia de Parking, pero neste caso a casilla sempre corresponderá
            if (parking != null) {
                parking.sumarValor(multa);
            }
        } else {
            jugador.sumarFortuna(-multa);
            // Notificar sobre deudas
            Juego.getConsola().imprimir("\n" + jugador.getNombre() + " non pode pagar o imposto de " + (int)multa + "€.");
            Juego.getConsola().imprimir("Opcións dispoñibles:");
            Juego.getConsola().imprimir("   - 'hipotecar <casilla>' para obter diñeiro");
            Juego.getConsola().imprimir("   - 'acabar turno' para declararse en bancarrota");
            jugador.setUltimoCobraAlquiler(tablero.getBanca());
        }
    }

    private void avanzarTransporte(Jugador jugador, Tablero tablero) throws MonopolyException {
        ArrayList<Casilla> todasCasillas = tablero.CasillasLineales(); //Obter lista de todas as casillas do tablero
        Casilla actual = jugador.getAvatar().getLugar();

        int posActual = todasCasillas.indexOf(actual); //indexOf para saber a posición actual no array lineal das casillas
        Casilla destino = null;

        do {
            posActual = (posActual + 1) % todasCasillas.size(); //Avanzar á seguinte posición ata que se atope un transporte
            Casilla casillaActual = todasCasillas.get(posActual);
            if (casillaActual instanceof Transporte) { //verifica que se atopou un transporte
                destino = casillaActual;
                break;
            }
        } while (posActual != todasCasillas.indexOf(actual)); //evita bucle infinito se non hai transportes (non deberia ocorrer)

        if (destino != null && destino instanceof Transporte transporte) { //Mover o avatar á casilla de destino
            jugador.getAvatar().moverAvatarHasta(destino.getNombre(), tablero.getPosiciones(), tablero, false);

            try {
                if (transporte.getDuenho() != null && !transporte.getDuenho().equals(jugador)) {
                    float alquiler = transporte.alquiler(0, true) * 2; //O aluguer é o dobre
                    jugador.pagarJugador(transporte.getDuenho(), alquiler, tablero);
                }
            } catch (MonopolyException e) { //Captura excepcións de pago de aluguer
                Juego.getConsola().imprimir(e.getMessage());
            }
        }
    }

    public enum TipoAccion {
        AVANZAR_SOLAR19,
        IR_CARCEL,
        LOTERIA,
        PAGAR_TODOS,
        RETROCEDER3,
        MULTA_MOVIL,
        AVANZAR_TRANSPORTE
    }

    public TipoAccion getTipoAccion() {
        return tipoAccion;
    }
}