package monopoly.cartas;

import monopoly.exceptions.MonopolyException;
import partida.Jugador;
import monopoly.Tablero;

public abstract class Carta {

    //Os atributos son protected para que as subclases poidan acceder a eles directamente
    protected String descripcion; // Descrición da carta
    protected int id;             // Identificador único da carta

    //Constructor da carta, coa descrición e o id.
    public Carta(String descripcion, int id) {
        this.descripcion = descripcion;
        this.id = id;
    }

    //Metodo abstracto que executa a acción da carta.
    public abstract void accion(Jugador jugador, Tablero tablero) throws MonopolyException;

    public String getDescripcion() {
        return descripcion;
    }

    public int getId() {
        return id;
    }

    //Representación en forma de cadea da carta
    @Override
    public String toString() {
        return "Carta #" + id + ": " + descripcion;
    }
}