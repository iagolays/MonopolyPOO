package monopoly.cartas;

import partida.*;
import monopoly.*;
import monopoly.casillas.*;
import monopoly.casillas.Casilla;

//Clase filla de Carta, usase extends para herdar os atributos e obriga a implementar os métodos abstractos da clase Carta
public class CartaCajaComunidad extends Carta {

    private TipoAccion tipoAccion;

    public CartaCajaComunidad(String descripcion, int id, TipoAccion tipoAccion) {
        super(descripcion, id);
        this.tipoAccion = tipoAccion;
    }

    //Os métodos abstractos herdados deben implementarse obrigatoriamente, e é recomendable empregar @Override para garantir a sobrescritura correcta.
    @Override
    public void accion(Jugador jugador, Tablero tablero) {
        switch(tipoAccion) { //dependendo do tipo de acción, chama ao método correspondente
            case PAGAR_BALNEARIO:
                pagarBalneario(jugador, tablero);
                break;
            case IR_CARCEL_FRAUDE:
                irCarcelFraude(jugador, tablero);
                break;
            case IR_SALIDA:
                irSalida(jugador, tablero);
                break;
            case DEVOLUCION_FACENDA:
                devolucionFacenda(jugador);
                break;
            case RETROCEDER_SOLAR1:
                retrocederSolar1(jugador, tablero);
                break;
            case IR_SOLAR20:
                irSolar20(jugador, tablero);
                break;
        }
    }

    private void pagarBalneario(Jugador jugador, Tablero tablero) {
        float cantidad = 500000f;

        if (jugador.puedePagar(cantidad)) { //Verificamos se o xogador pode pagar a cantidade
            jugador.sumarFortuna(-cantidad);
            jugador.registrarTasa(cantidad);

            Parking parking = (Parking) tablero.encontrar_casilla("Parking"); //Buscamos a casilla Parking no tablero
            //Facemos un Downcasting para tratar a Casilla como un Parking (de clase pai a clase filla), cambiamos a referencia que apunta a un obxecto de tipo Casilla por unha de tipo Parking
            //Podemos facer isto porque sabemos que a casilla "Parking" é un Parking, se non o fose daría un erro en tempo de execución


            /*
            *Casilla c = tablero.encontrar_casilla("Parking");
            if (c instanceof Parking) {
                Parking parking = (Parking) c;
            }
            //Así poderiamonos asegurar que a casilla efectivamente é un Parking e podereimos empregar métodos propios do Parking*/

            if (parking != null) {
                parking.sumarValor(cantidad);
            }
        } else {
            jugador.sumarFortuna(-cantidad);
            // Notificar sobre deudas
            Juego.getConsola().imprimir("\n" + jugador.getNombre() + " non pode pagar o imposto de " + (int)cantidad + "€.");
            Juego.getConsola().imprimir("Opcións dispoñibles:");
            Juego.getConsola().imprimir("   - 'hipotecar <casilla>' para obter diñeiro");
            Juego.getConsola().imprimir("   - 'acabar turno' para declararse en bancarrota");
            jugador.setUltimoCobraAlquiler(tablero.getBanca()); //Configuramos o último cobrador como a banca para que o xogador poida hipotecar propiedades e pagar a súa débeda
        }
    }

    private void irCarcelFraude(Jugador jugador, Tablero tablero) {
        Casilla carcel = tablero.encontrar_casilla("Carcel"); //Non fai falta facer downcasting porque non imos empregar métodos propios da clase Cárcel
        if (carcel != null) {
            jugador.encarcelar(tablero.getPosiciones(), tablero);
        }
    }

    private void irSalida(Jugador jugador, Tablero tablero) {
        Casilla salida = tablero.encontrar_casilla("Salida");
        if (salida != null) {
            jugador.getAvatar().moverAvatarHasta("Salida", tablero.getPosiciones(), tablero, true);
        }
    }

    private void devolucionFacenda(Jugador jugador) {
        float cantidad = 500000f;
        jugador.sumarFortuna(cantidad);
        jugador.registrarPremio(cantidad);
    }

    private void retrocederSolar1(Jugador jugador, Tablero tablero) {
        jugador.getAvatar().moverAvatarHasta("Solar1", tablero.getPosiciones(), tablero, false);
    }

    private void irSolar20(Jugador jugador, Tablero tablero) {
        jugador.getAvatar().moverAvatarHasta("Solar20", tablero.getPosiciones(), tablero, true);
    }

    public enum TipoAccion { //enum para definir os tipos de acción dispoñibles, cada un asociado a un método
        PAGAR_BALNEARIO,
        IR_CARCEL_FRAUDE,
        IR_SALIDA,
        DEVOLUCION_FACENDA,
        RETROCEDER_SOLAR1,
        IR_SOLAR20
    }

    public TipoAccion getTipoAccion() {
        return tipoAccion;
    }
}