package monopoly.exceptions;

//excepción para cando un xogador tenta realizar unha acción sobre unha propiedade que non lle pertence

public class PropiedadeNonPertenceException extends TransaccionException{
    public PropiedadeNonPertenceException(String nomeXogador, String nomePropiedade) {
        super("A propiedade " + nomePropiedade + " non pertence a " + nomeXogador + ".");
    }

    //constructor indicando o dono da propiedade
    public PropiedadeNonPertenceException(String xogadoractual, String xogadorDono, String nomePropiedade) {
        super("A propiedade " + nomePropiedade + " non pertence a " + xogadoractual + ", pertence a " + xogadorDono + ".");
    }

    //constructor para erros nas operacións de tratos entre xogadores
    public PropiedadeNonPertenceException(String nomePropiedade, String xogadorIntento, boolean paraTrato) {
        super("O xogador " + xogadorIntento + " non pode realizar un trato con " + nomePropiedade + " porque non é o propietario.");
    }
}
