package monopoly.casillas;
import monopoly.*;
import monopoly.exceptions.MonopolyException;
import partida.*;
import monopoly.cartas.*;
import java.util.ArrayList;

public class CajaComunidad extends Accion {

    public CajaComunidad(String nombre, int posicion) {
        super(nombre, posicion);
    }

    @Override
    public void realizarAccion(Jugador jugador, Tablero tablero, ArrayList<Carta> mazoSuerte, ArrayList<Carta> mazoComunidad, int[] indices) throws MonopolyException {

        if (mazoComunidad != null && !mazoComunidad.isEmpty()) { //Verifica que o mazo non estea baleiro
            indices[1] = (indices[1] + 1) % mazoComunidad.size(); //Actualiza o índice da carta de comunidade
            Carta carta = mazoComunidad.get(indices[1]); //Obtén a carta correspondente
            Juego.getConsola().imprimir(jugador.getNombre() + ", saca unha carta de Caixa de Comunidade: " + carta.getDescripcion());
            carta.accion(jugador, tablero); //Executa a acción da carta
        }
    }

    @Override
    public String getTipo() {
        return "comunidad";
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("\ttipo: cajaComunidad,\n");
        sb.append("\tnome: \"").append(nombre).append("\",\n");
        sb.append("\tposicion: ").append(posicion).append("\n");
        sb.append("}");
        return sb.toString();
    }
}
