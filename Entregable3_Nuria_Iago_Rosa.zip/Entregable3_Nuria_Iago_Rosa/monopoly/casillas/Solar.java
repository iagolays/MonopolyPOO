package monopoly.casillas;

import monopoly.*;
import monopoly.cartas.Carta;
import monopoly.edificios.*;
import monopoly.exceptions.MonopolyException;
import monopoly.exceptions.*;
import partida.*;
import java.util.ArrayList;

public class Solar extends Propiedad {

    // Atributos específicos de Solar
    private boolean hipotecada;
    private float hipoteca;
    private Grupo grupo;
    private ArrayList<Edificio> edificios;
    private ArrayList<String> idsEdificios;

    // Contadores para verificación rápida
    private int numCasas;
    private int numHoteles;
    private int numPiscinas;
    private int numPistas;

    // Constructor que acepta grupo directamente
    public Solar(String nombre, int posicion, Jugador duenho, Grupo grupo) {
        super(nombre, posicion, duenho, Valor.obtenerPrecioSolar(nombre));
        this.edificios = new ArrayList<>();
        this.idsEdificios = new ArrayList<>();
        this.setGrupo(grupo);
        this.hipotecada = false;
        this.hipoteca = getValor() / 2;
        this.numCasas = 0;
        this.numHoteles = 0;
        this.numPiscinas = 0;
        this.numPistas = 0;
    }

    // Metodo para establecer o grupo
    public void setGrupo(Grupo grupo) {
        this.grupo = grupo;
        if (grupo != null && !grupo.getMiembros().contains(this)) {
            grupo.anhadirCasilla(this);
        }
    }

    // Metodo para hipotecar un solar
    public void hipotecar(Jugador jugador) throws MonopolyException {
        if (!perteneceAJugador(jugador)) {
            Juego.getConsola().imprimir(jugador.getNombre() + " non é o dono de " + getNombre() + " e non pode hipotecalo.");
            return;
        }
        if (hipotecada) {
            Juego.getConsola().imprimir(getNombre() + " xa está hipotecado.");
            return;
        }

        if (edificios != null && !edificios.isEmpty()) {
            Juego.getConsola().imprimir("Non se pode hipotecar " + getNombre() + " porque ten edificios. Debe vendelos antes de hipotecar.");
            return;
        }

        this.hipotecada = true;
        float valorHipoteca = this.hipoteca;

        jugador.anhadirHipoteca(this);
        jugador.sumarFortuna(valorHipoteca);
        jugador.sumarInversion(valorHipoteca);

        Juego.getConsola().imprimir(jugador.getNombre() + " recibe " + (int)valorHipoteca + "€ pola hipoteca de " + this.nombre + ". Non pode recibir alugueres, nin edificar no grupo " + (this.grupo != null ? this.grupo.getColorGrupo() : "") + ".");
    }

    // Metodo para deshipotecar o solar
    public void deshipotecar(Jugador jugador) throws MonopolyException {
        if (!perteneceAJugador(jugador)) {
            Juego.getConsola().imprimir(jugador.getNombre() + " non é o dono de " + getNombre() + " e non pode deshipotecalo.");
            return;
        }
        if (!hipotecada) {
            Juego.getConsola().imprimir(getNombre() + " non está hipotecado.");
            return;
        }

        float valorDeshipoteca = this.hipoteca;
        if (!jugador.puedePagar(valorDeshipoteca)) {
            Juego.getConsola().imprimir(jugador.getNombre() + " non pode deshipotecar " + this.nombre + ". Non ten diñeiro suficiente.");
            return;
        }

        this.hipotecada = false;
        jugador.sumarFortuna(-valorDeshipoteca);
        jugador.eliminarHipoteca(this);

        StringBuilder mensaje = new StringBuilder();
        mensaje.append(jugador.getNombre()).append(" paga ").append((int)valorDeshipoteca).append("€ por deshipotecar ").append(this.nombre).append(".");

        if (this.grupo != null && this.grupo.esDuenhoGrupo(jugador)) {
            if (this.grupo.todosDeshipotecados(jugador)) {
                mensaje.append(" Agora pode recibir alugueres e edificar no grupo ").append(this.grupo.getColorGrupo()).append(".");
            } else {
                mensaje.append(" Aínda non pode recibir alugueres nin edificar no grupo ").append(this.grupo.getColorGrupo()).append(" porque hai outros solares do grupo aínda hipotecados.");
            }
        } else {
            mensaje.append(" Agora pode recibir alugueres neste solar.");
        }

        Juego.getConsola().imprimir(mensaje.toString());
    }

    @Override
    public float valor() {
        return this.valor;
    }

    public boolean estaHipotecada() {
        return hipotecada;
    }

    // Metodo para engador edificio
    public void anhadirEdificio(Edificio edificio) {
        if (edificios == null) {
            edificios = new ArrayList<>();
        }
        if (idsEdificios == null) {
            idsEdificios = new ArrayList<>();
        }

        if (!edificios.contains(edificio)) {
            edificios.add(edificio);
            idsEdificios.add(edificio.getId());

            String tipo = edificio.obterTipoEdificio().toLowerCase();

            // Actualizar contadores
            switch (tipo) {
                case "casa":
                    numCasas++;
                    break;
                case "hotel":
                    numHoteles++;
                    break;
                case "piscina":
                    numPiscinas++;
                    break;
                case "pista":
                    numPistas++;
                    break;
            }
        }
    }

    public void eliminarEdificio(Edificio edificio) {
        if (edificios == null || edificio == null){
            return;
        }

        if (edificios.contains(edificio)) {
            edificios.remove(edificio);

            // También eliminar del array de IDs
            if (idsEdificios != null) {
                idsEdificios.remove(edificio.getId());
            }

            String tipo = edificio.obterTipoEdificio().toLowerCase();

            // Actualizar contadores
            switch (tipo) {
                case "casa":
                    if (numCasas > 0) {
                        numCasas--;
                    }
                    break;
                case "hotel":
                    if (numHoteles > 0) {
                        numHoteles--;
                    }
                    break;
                case "piscina":
                    if (numPiscinas > 0) {
                        numPiscinas--;
                    }
                    break;
                case "pista":
                    if (numPistas > 0){
                        numPistas--;
                    }
                    break;
            }
        }
    }

    public Edificio buscarEdificio(String id) {
        if (edificios == null) return null;

        for (Edificio e : edificios) {
            if (e.getId().equals(id)) {
                return e;
            }
        }
        return null;
    }

    public boolean tieneEdificios() {
        return edificios != null && !edificios.isEmpty();
    }

    public void anhadirIdEdificio(String id) {
        if (idsEdificios == null) {
            idsEdificios = new ArrayList<>();
        }
        if (!idsEdificios.contains(id)) {
            idsEdificios.add(id);
        }
    }

    public void eliminarIdEdificio(String id) {
        if (idsEdificios != null) {
            idsEdificios.remove(id);
        }
        Edificio e = buscarEdificio(id);
        if (e != null) {
            eliminarEdificio(e);
        }
    }

    // Metodo para eliminar todas las casas (ao construir hotel)
    private void eliminarTodasLasCasas() {
        if (edificios == null) return;

        // Crear lista temporal para evitar ConcurrentModificationException
        ArrayList<Edificio> casasAEliminar = new ArrayList<>();
        for (Edificio e : edificios) {
            if (e instanceof Casa) {
                casasAEliminar.add(e);
            }
        }

        // Eliminar todas as casas
        for (Edificio casa : casasAEliminar) {
            eliminarEdificio(casa);
            // También eliminar do xogador
            if (casa.getPropietario() != null) {
                casa.getPropietario().eliminarEdificio(casa.getId());
            }
        }

        // Resetear contador de casas
        numCasas = 0;
    }

    // Metodo para calcular o alquiler
    @Override
    public float alquiler(int tirada, boolean desdeCarta){
        // Si este solar está hipotecado, no se cobra
        if (hipotecada) return 0;

        // Verificar si é dono do grupo completo
        if (grupo != null && grupo.esDuenhoGrupo(duenho)) {
            //Se ten o grupo enteiro, verificar se algún solar do grupo está hipotecado
            for (Propiedad propiedad : grupo.getMiembros()) {
                if (propiedad instanceof Solar) {
                    Solar solar = (Solar) propiedad;
                    if (solar.estaHipotecada()) {
                        return 0;
                    }
                }
            }
        }

        float alquiler = Valor.obtenerAlquilerSolar(nombre);

        if (edificios != null) {
            for (Edificio e : edificios) {
                alquiler += e.obterAluguer();
            }
        }

        // Duplicar alquiler si tiene todo o grupo, sin edificios
        if (grupo != null && grupo.esDuenhoGrupo(duenho) &&
                (edificios == null || edificios.isEmpty())) {
            alquiler *= 2;
        }

        return alquiler;
    }

    // Metodo para calcular o alquiler sin tirada nin carta
    public float calcularAlquiler() {
        return alquiler(0, false);
    }

    // Metodo para construir un edificio no solar
    public boolean construirEdificio(String tipo, Jugador jugador) throws MonopolyException {
        if (!perteneceAJugador(jugador)) {
            throw new PropiedadeNonPertenceException(jugador.getNombre(), nombre);
        }

        if (hipotecada) {
            throw new PropiedadeHipotecadaException(nombre);
        }

        // Verificar que o xogador é dono do grupo completo
        if (grupo == null || !grupo.esDuenhoGrupo(jugador)) {
            throw new EstadoXogoException("Necesitas ter todo o grupo " + (grupo != null ? grupo.getColorGrupo() : "") + " para construír");
        }

        // Verificar que todos os solares do grupo non estén hipotecados
        if (grupo != null) {
            for (Propiedad propiedad : grupo.getMiembros()) {
                if (propiedad instanceof Solar) {
                    Solar solarDelGrupo = (Solar) propiedad;
                    if (solarDelGrupo.estaHipotecada()) {
                        throw new EstadoXogoException("Non se pode edificar no grupo " + grupo.getColorGrupo() + " porque " + solarDelGrupo.getNombre() + " está hipotecado.");
                    }
                }
            }
        }

        switch (tipo.toLowerCase()) {
            case "casa":
                if (numCasas >= 4) {
                    throw new EstadoXogoException("Xa hai 4 casas en " + nombre);
                }
                if (numHoteles > 0) {
                    throw new EstadoXogoException("Non se poden construír casas se hai hotel");
                }
                break;

            case "hotel":
                if (numCasas < 4) {
                    throw new EstadoXogoException("Necesitas 4 casas para construír un hotel");
                }
                if (numHoteles >= 1) {
                    throw new EstadoXogoException("Xa hai un hotel en " + nombre);
                }
                // Eliminar as 4 casas antes de construir hotel
                eliminarTodasLasCasas();
                break;

            case "piscina":
                if (numHoteles < 1) {
                    throw new EstadoXogoException("Necesitas un hotel para construír unha piscina");
                }
                if (numPiscinas >= 1) {
                    throw new EstadoXogoException("Xa hai unha piscina en " + nombre);
                }
                break;

            case "pista":
                if (numHoteles < 1) {
                    throw new EstadoXogoException("Necesitas un hotel para construír unha pista");
                }
                if (numPiscinas < 1) {
                    throw new EstadoXogoException("Necesitas unha piscina para construír unha pista");
                }
                if (numPistas >= 1) {
                    throw new EstadoXogoException("Xa hai unha pista en " + nombre);
                }
                break;

            default:
                throw new NonExisteEdificioException(tipo, nombre);
        }

        Edificio nuevoEdificio = null;
        switch (tipo.toLowerCase()) {
            case "casa":
                nuevoEdificio = new Casa(this, jugador);
                break;
            case "hotel":
                nuevoEdificio = new Hotel(this, jugador);
                break;
            case "piscina":
                nuevoEdificio = new Piscina(this, jugador);
                break;
            case "pista":
                nuevoEdificio = new PistaDeDeporte(this, jugador);
                break;
        }

        if (nuevoEdificio == null) {
            throw new EstadoXogoException("Erro ao crear o edificio " + tipo);
        }

        // Verificar que o xogador ten dinero suficiente
        float precio = nuevoEdificio.getPrecio();
        if (!jugador.puedePagar(precio)) {
            throw new DiñeiroInsuficienteException(jugador.getNombre(), precio, jugador.getFortuna());
        }

        // Realizar el pago y añadir el edificio
        jugador.sumarFortuna(-precio);
        jugador.sumarInversion(precio);
        anhadirEdificio(nuevoEdificio);
        jugador.anhadirEdificio(nuevoEdificio);

//        Juego.getConsola().imprimir("Constrúese un " + tipo + " en " + nombre + ".");
        return true;
    }

    // Metodo para evaluar a casilla solar
    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta, ArrayList<Carta> mazoSuerte, ArrayList<Carta> mazoComunidad, int[] indices) throws MonopolyException {
        vecesCaida++;

        if (duenho == null || duenho == banca) {
            Juego.getConsola().imprimir(nombre + " está en venda por " + (int)valor + "€");
            return true;
        }

        if (duenho.equals(actual)) {
            Juego.getConsola().imprimir(actual.getNombre() + " é o dono de " + nombre);
            return true;
        }

        // Verificar si se pode cobrar alquiler
        boolean sePuedeCobrar = !hipotecada;

        if (sePuedeCobrar && grupo != null && grupo.esDuenhoGrupo(duenho)) {
            // Si o dono ten todo o grupo, verificar que ningún solar esté hipotecado
            for (Propiedad propiedad : grupo.getMiembros()) {
                if (propiedad instanceof Solar) {
                    Solar solar = (Solar) propiedad;
                    if (solar.estaHipotecada()) {
                        sePuedeCobrar = false;
                        break;
                    }
                }
            }
        }

        if (sePuedeCobrar) {
            float alquilerAPagar = alquiler(tirada, desdeCarta);
            Juego.getConsola().imprimir(actual.getNombre() + " paga " + (int)alquilerAPagar + "€ a " + duenho.getNombre());

            boolean pagoExitoso = actual.pagarJugador(duenho, alquilerAPagar, tablero);
            if (pagoExitoso) {
                sumarAlquilerCobrado(alquilerAPagar);
                duenho.registrarCobroAlquiler(alquilerAPagar);
                actual.registrarPagoAlquiler(alquilerAPagar);
                return true;
            } else {
                actual.setUltimoCobraAlquiler(duenho);
                return false;
            }
        } else {
            Juego.getConsola().imprimir(nombre + " non cobra aluguer (está hipotecada ou hai solares hipotecados no grupo)");
            return true;
        }
    }

    @Override
    public String getTipo() {
        return "solar";
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("\ttipo: solar,\n");
        sb.append("\tgrupo: ").append(grupo != null ? grupo.getColorGrupo() : "-").append(",\n");
        sb.append("\tpropietario: ").append(duenho != null ? duenho.getNombre() : "Banca").append(",\n");
        sb.append("\tvalor: ").append((int)valor).append(",\n");
        sb.append("\talquiler: ").append((int)calcularAlquiler()).append(",\n");

        // Precios de edificios según el solar
        sb.append("\tvalor hotel: ").append((int)Valor.obtenerPrecioHotel(nombre.toLowerCase())).append(",\n");
        sb.append("\tvalor casa: ").append((int)Valor.obtenerPrecioCasa(nombre.toLowerCase())).append(",\n");
        sb.append("\tvalor piscina: ").append((int)Valor.obtenerPrecioPiscina(nombre.toLowerCase())).append(",\n");
        sb.append("\tvalor pista de deporte: ").append((int)Valor.obtenerPrecioPista(nombre.toLowerCase())).append(",\n");

        // Alquileres de edificios
        sb.append("\talquiler casa: ").append((int)Valor.obtenerAlquilerCasa(nombre.toLowerCase())).append(",\n");
        sb.append("\talquiler hotel: ").append((int)Valor.obtenerAlquilerHotel(nombre.toLowerCase())).append(",\n");
        sb.append("\talquiler piscina: ").append((int)Valor.obtenerAlquilerPiscina(nombre.toLowerCase())).append(",\n");
        sb.append("\talquiler pista de deporte: ").append((int)Valor.obtenerAlquilerPista(nombre.toLowerCase())).append(",\n");

        //Edificios construidos
        sb.append("\tedificios construidos: {\n");

        // Casas
        sb.append("\t\tcasas: [");
        ArrayList<String> casas = obtenerIdsEdificiosTipo("casa");
        if (casas.isEmpty()) {
            sb.append("-");
        } else {
            for (int i = 0; i < casas.size(); i++) {
                sb.append(casas.get(i));
                if (i < casas.size() - 1) sb.append(", ");
            }
        }
        sb.append("],\n");

        // Hoteles
        sb.append("\t\thoteles: [");
        ArrayList<String> hoteles = obtenerIdsEdificiosTipo("hotel");
        if (hoteles.isEmpty()) {
            sb.append("-");
        } else {
            for (int i = 0; i < hoteles.size(); i++) {
                sb.append(hoteles.get(i));
                if (i < hoteles.size() - 1) sb.append(", ");
            }
        }
        sb.append("],\n");

        // Piscinas
        sb.append("\t\tpiscinas: [");
        ArrayList<String> piscinas = obtenerIdsEdificiosTipo("piscina");
        if (piscinas.isEmpty()) {
            sb.append("-");
        } else {
            for (int i = 0; i < piscinas.size(); i++) {
                sb.append(piscinas.get(i));
                if (i < piscinas.size() - 1) sb.append(", ");
            }
        }
        sb.append("],\n");

        // Pistas de deporte
        sb.append("\t\tpistas de deporte: [");
        ArrayList<String> pistas = obtenerIdsEdificiosTipo("pista");
        if (pistas.isEmpty()) {
            sb.append("-");
        } else {
            for (int i = 0; i < pistas.size(); i++) {
                sb.append(pistas.get(i));
                if (i < pistas.size() - 1) sb.append(", ");
            }
        }
        sb.append("]\n");

        sb.append("\t}\n");
        sb.append("}");
        return sb.toString();
    }

    // Metodo auxiliar para obtener IDs de edificios por tipo
    private ArrayList<String> obtenerIdsEdificiosTipo(String tipo) {
        ArrayList<String> ids = new ArrayList<>();
        if (edificios == null) return ids;

        for (Edificio edificio : edificios) {
            if (edificio.obterTipoEdificio().equalsIgnoreCase(tipo)) {
                ids.add(edificio.getId());
            }
        }
        return ids;
    }

    // Getters
    public ArrayList<String> getIdsEdificios() {
        if (idsEdificios == null) {
            idsEdificios = new ArrayList<>();
        }
        return idsEdificios;
    }

    public int getNumCasas() {
        return numCasas;
    }

    public int getNumHoteles() {
        return numHoteles;
    }

    public int getNumPiscinas() {
        return numPiscinas;
    }

    public int getNumPistas() {
        return numPistas;
    }

    public ArrayList<Edificio> getEdificios() {
        if (edificios == null) {
            edificios = new ArrayList<>();
        }
        return edificios;
    }

    public Grupo getGrupo() {
        return grupo;
    }

    public float getHipoteca() {
        return hipoteca;
    }
}