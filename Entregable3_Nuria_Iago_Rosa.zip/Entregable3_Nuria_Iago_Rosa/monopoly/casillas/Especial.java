package monopoly.casillas;
import monopoly.*;
import partida.*;

//Clase concreta que representa unha casilla especial no taboleiro (Carcel, Saida, IsACarcel)
public abstract class Especial extends Casilla {

    //Constructor
    public Especial(String nombre, int posicion) {
        super(nombre, posicion);
    }

    @Override
    public String getTipo() {
        return "especial";
    }

    @Override
    public String infoCasilla() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("\ttipo: especial,\n");
        sb.append("\tnome: \"").append(nombre).append("\",\n");
        sb.append("\tposicion: ").append(posicion).append("\n");
        sb.append("}");
        return sb.toString();
    }
}
