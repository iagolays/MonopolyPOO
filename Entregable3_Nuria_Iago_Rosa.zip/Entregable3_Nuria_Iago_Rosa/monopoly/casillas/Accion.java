package monopoly.casillas;
import monopoly.*;
import monopoly.cartas.Carta;
import monopoly.exceptions.MonopolyException;
import partida.*;
import java.util.ArrayList;

public abstract class Accion extends Casilla {

    public Accion(String nombre, int posicion) {
        super(nombre, posicion);
    }

    // Acción xenérica a executar (nas subclases)
    public abstract void realizarAccion(Jugador jugador, Tablero tablero, ArrayList<Carta> mazoSuerte, ArrayList<Carta> mazoComunidad, int[] indices) throws MonopolyException;
    // indices[0]=suerte, indices[1]=comunidad

    @Override
    //engadese  boolean desdeCarta, ArrayList<Carta> mazoSuerte, ArrayList<Carta> mazoComunidad, int[] indices porque precisase para Suerte e CajaComunidad
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean desdeCarta, ArrayList<Carta> mazoSuerte, ArrayList<Carta> mazoComunidad, int[] indices) throws MonopolyException{
        vecesCaida++;
        realizarAccion(actual, tablero, mazoSuerte, mazoComunidad, indices);
        return true; //As accións non quebran ao xogador
    }
}
