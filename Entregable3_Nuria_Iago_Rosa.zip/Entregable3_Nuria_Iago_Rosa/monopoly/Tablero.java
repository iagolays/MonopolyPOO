package monopoly;

import monopoly.casillas.*;
import monopoly.cartas.*;
import partida.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Tablero {

    private ArrayList<ArrayList<Casilla>> posiciones;   // 4 lados do taboleiro
    private HashMap<String, Grupo> grupos;              // Mapa de grupos por nome
    private Jugador banca;                              // Referencia á banca
    private ArrayList<Jugador> jugadores;               // Lista de xogadores

    // Grupos xa creados ao iniciar Tablero
    private Grupo grupoMarron;
    private Grupo grupoAzulClaro;
    private Grupo grupoRosa;
    private Grupo grupoLaranxa;
    private Grupo grupoVermello;
    private Grupo grupoAmarelo;
    private Grupo grupoVerde;
    private Grupo grupoAzulEscuro;


    //Constructor
    public Tablero(Jugador banca) {

        this.banca = banca;                // Gardamos referencia á banca
        this.jugadores = new ArrayList<>(); // Lista baleira de xogadores
        this.posiciones = new ArrayList<>();
        this.grupos = new HashMap<>();

        // Creamos as listas para os 4 lados do taboleiro
        for (int i = 0; i < 4; i++) {
            posiciones.add(new ArrayList<>());
        }

        // ---- Inicializamos os grupos ANTES de crear solares ----
        grupoMarron     = new Grupo("Marrón");
        grupoAzulClaro  = new Grupo("Azul Claro");
        grupoRosa       = new Grupo("Rosa");
        grupoLaranxa    = new Grupo("Laranxa");
        grupoVermello   = new Grupo("Vermello");
        grupoAmarelo    = new Grupo("Amarelo");
        grupoVerde      = new Grupo("Verde");
        grupoAzulEscuro = new Grupo("Azul Escuro");

        // Gardamos os grupos no mapa
        grupos.put("Marrón", grupoMarron);
        grupos.put("Azul Claro", grupoAzulClaro);
        grupos.put("Rosa", grupoRosa);
        grupos.put("Laranxa", grupoLaranxa);
        grupos.put("Vermello", grupoVermello);
        grupos.put("Amarelo", grupoAmarelo);
        grupos.put("Verde", grupoVerde);
        grupos.put("Azul Escuro", grupoAzulEscuro);

        // Creamos as casillas xa asignando grupos
        this.generarCasillas();
    }


    private void generarCasillas() {
        insertarLadoSur();
        insertarLadoOeste();
        insertarLadoNorte();
        insertarLadoEste();
    }


    // ----- LADO SUR (pos 0–10) -----
    private void insertarLadoSur() {
        ArrayList<Casilla> sur = posiciones.get(0);

        sur.add(new Salida("Salida", 0));
        sur.add(new Solar("Solar1", 1, banca, grupoMarron));
        sur.add(new monopoly.casillas.CajaComunidad("Caja", 2));
        sur.add(new Solar("Solar2", 3, banca, grupoMarron));
        sur.add(new Impuesto("Imp1", 4, Valor.IMPUESTO_VALOR));
        sur.add(new Transporte("Trans1", 5, banca));
        sur.add(new Solar("Solar3", 6, banca, grupoAzulClaro));
        sur.add(new monopoly.casillas.Suerte("Suerte", 7));
        sur.add(new Solar("Solar4", 8, banca, grupoAzulClaro));
        sur.add(new Solar("Solar5", 9, banca, grupoAzulClaro));
        sur.add(new Carcel("Carcel", 10));
    }


    // ----- LADO OESTE (pos 11–19) -----
    private void insertarLadoOeste() {
        ArrayList<Casilla> oeste = posiciones.get(1);

        oeste.add(new Solar("Solar6", 11, banca, grupoRosa));
        oeste.add(new Servicio("Serv1", 12, banca));
        oeste.add(new Solar("Solar7", 13, banca, grupoRosa));
        oeste.add(new Solar("Solar8", 14, banca, grupoRosa));
        oeste.add(new Transporte("Trans2", 15, banca));
        oeste.add(new Solar("Solar9", 16, banca, grupoLaranxa));
        oeste.add(new monopoly.casillas.CajaComunidad("Caja", 17));
        oeste.add(new Solar("Solar10", 18, banca, grupoLaranxa));
        oeste.add(new Solar("Solar11", 19, banca, grupoLaranxa));
    }


    // ----- LADO NORTE (pos 20–30) -----
    private void insertarLadoNorte() {
        ArrayList<Casilla> norte = posiciones.get(2);

        norte.add(new Parking("Parking", 20));
        norte.add(new Solar("Solar12", 21, banca, grupoVermello));
        norte.add(new monopoly.casillas.Suerte("Suerte", 22));
        norte.add(new Solar("Solar13", 23, banca, grupoVermello));
        norte.add(new Solar("Solar14", 24, banca, grupoVermello));
        norte.add(new Transporte("Trans3", 25, banca));
        norte.add(new Solar("Solar15", 26, banca, grupoAmarelo));
        norte.add(new Solar("Solar16", 27, banca, grupoAmarelo));
        norte.add(new Servicio("Serv2", 28, banca));
        norte.add(new Solar("Solar17", 29, banca, grupoAmarelo));
        norte.add(new IrCarcel("IrCarcel", 30));
    }


    // ----- LADO LESTE (pos 31–39) -----
    private void insertarLadoEste() {
        ArrayList<Casilla> este = posiciones.get(3);

        este.add(new Solar("Solar18", 31, banca, grupoVerde));
        este.add(new Solar("Solar19", 32, banca, grupoVerde));
        este.add(new monopoly.casillas.CajaComunidad("Caja", 33));
        este.add(new Solar("Solar20", 34, banca, grupoVerde));
        este.add(new Transporte("Trans4", 35, banca));
        este.add(new monopoly.casillas.Suerte("Suerte", 36));
        este.add(new Solar("Solar21", 37, banca, grupoAzulEscuro));
        este.add(new Impuesto("Imp2", 38, Valor.IMPUESTO_VALOR));
        este.add(new Solar("Solar22", 39, banca, grupoAzulEscuro));
    }


    // Busca unha casilla polo seu nome
    public Casilla encontrar_casilla(String nombre) {
        for (ArrayList<Casilla> lado : posiciones) {
            for (Casilla casilla : lado) {
                if (casilla.getNombre().equalsIgnoreCase(nombre))
                    return casilla;
            }
        }
        return null;
    }


    // Devolve unha lista lineal con todas as casillas do taboleiro
    public ArrayList<Casilla> CasillasLineales() {
        ArrayList<Casilla> lista = new ArrayList<>();
        for (ArrayList<Casilla> lado : posiciones)
            lista.addAll(lado);
        return lista;
    }

    @Override
    public String toString() {
        // Obtén cada un dos lados do taboleiro
        ArrayList<Casilla> sur = posiciones.get(0);
        ArrayList<Casilla> oeste = posiciones.get(1);
        ArrayList<Casilla> norte = posiciones.get(2);
        ArrayList<Casilla> este = posiciones.get(3);

        StringBuilder sb = new StringBuilder();
        sb.append("\n                                 ======= TABLERO MONOPOLY =======\n\n");

        int ancho = 12;
        int alto = 4;
        int hueco = ancho * norte.size();

        // LADO NORTE (imprímese na parte superior)
        for (int fila = 0; fila < alto; fila++) {
            sb.append("".repeat(ancho));
            for (Casilla c : norte) {
                String texto = getContenidoCasilla(c, fila, ancho);
                sb.append(texto);
            }
            sb.append("\n");
        }

        // LADOS OESTE y ESTE (verticales)
        int maxFilas = Math.max(oeste.size(), este.size());
        for (int i = 0; i < maxFilas; i++) {
            Casilla izq = (i < oeste.size()) ? oeste.get(oeste.size() - 1 - i) : null;
            Casilla der = (i < este.size()) ? este.get(i) : null;

            for (int fila = 0; fila < alto; fila++) {
                if (izq != null) {
                    sb.append(getContenidoCasilla(izq, fila, ancho));
                } else {
                    sb.append(" ".repeat(ancho));
                }

                sb.append(" ".repeat(hueco - 12 - ancho));

                if (der != null) {
                    sb.append(getContenidoCasilla(der, fila, ancho));
                }
                sb.append("\n");
            }
        }

        // LADO SUR (izquierda a derecha)
        for (int fila = 0; fila < alto; fila++) {
            sb.append("".repeat(ancho));
            for (int i = sur.size() - 1; i >= 0; i--) {
                Casilla c = sur.get(i);
                String texto = getContenidoCasilla(c, fila, ancho);
                sb.append(texto);
            }
            sb.append("\n");
        }

        return sb.toString();
    }

    private String getContenidoCasilla(Casilla c, int fila, int ancho) {
        String nombre = c.getNombre();
        String tipo = c.getTipo();

        // Fila 0 → parte superior (borde)
        if (fila == 0) {
            return "┌" + "─".repeat(ancho - 2) + "┐";
        }

        // Fila 1 → nombre de la casilla (centrado y coloreado)
        if (fila == 1) {
            String nombreColor = Grupo.calcularColor(c);
            // Remove os códigos de cor para calcular o largo real do texto
            String limpio = nombreColor.replaceAll("\u001B\\[[;\\d]*m", "");

            int espacio = ancho - 2 - limpio.length();
            int izq = Math.max(0, espacio / 2);
            int der = Math.max(0, espacio - izq);

            return "│" + " ".repeat(izq) + nombreColor + " ".repeat(der) + "\u001B[0m│";
        }

        // Fila 2 → tipo de casilla
        if (fila == 2) {
            return String.format("│%-" + (ancho - 2) + "s│",
                    recortarCentro(tipo, ancho - 2));
        }

        // Fila 3 → borde inferior (avatares)
        if (fila == 3) {
            String avatares = c.getAvataresString();
            return String.format("│%-" + (ancho - 2) + "s│", recortarCentro(avatares, ancho - 2));
        }

        return "";
    }

    private String recortarCentro(String texto, int ancho) {
        if (texto.length() > ancho)
            return texto.substring(0, ancho);
        int espacio = ancho - texto.length();
        int izquierda = espacio / 2;
        int derecha = espacio - izquierda;
        return " ".repeat(izquierda) + texto + " ".repeat(derecha);
    }



    public Jugador getBanca() { return banca; }
    public ArrayList<ArrayList<Casilla>> getPosiciones() { return posiciones; }
    public HashMap<String, Grupo> getGrupos() { return grupos; }
    public ArrayList<Jugador> getJugadores() { return jugadores; }
}
