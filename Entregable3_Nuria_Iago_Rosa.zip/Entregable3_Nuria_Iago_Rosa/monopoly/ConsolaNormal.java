package monopoly;

import java.util.Scanner;
//implementacion normal da consola que usa system.out para escribir e scanner para ler

public class ConsolaNormal implements Consola {

    //Usamos un só Scanner para todo o programa.
    private Scanner sc;

    //Constructor que inicializa o Scanner unha única vez, para ler de System.in.
    public ConsolaNormal() {
        this.sc = new Scanner(System.in);
    }

    //Imprimir unha mensaxe usando System.out.println (reescritura do metodo da interfaz)
    @Override
    public void imprimir(String mensaxe) {
        System.out.println(mensaxe);
    }

    //Imprime a descripcion e le unha cadea do usuario (reescritura do metodo da interfaz)
    @Override
    public String ler(String descripcion) {
        System.out.print(descripcion);
        return sc.nextLine(); // Devolvemos a liña que escriba o usuario
    }
}
