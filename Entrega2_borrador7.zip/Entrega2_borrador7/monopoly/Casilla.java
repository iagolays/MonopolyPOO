package monopoly;

import partida.*;
import java.util.ArrayList;

public class Casilla {

    //Atributos:
    private String nombre; //Nombre de la casilla
    private String tipo; //Tipo de casilla (Solar, Especial, Transporte, Servicios, Comunidad, Suerte y Impuesto).
    private float valor; //Valor de esa casilla (en la mayoría será valor de compra, en la casilla parking se usará como el bote).
    private int posicion; //Posición que ocupa la casilla en el tablero (entero entre 1 y 40).
    private Jugador duenho; //Dueño de la casilla (por defecto sería la banca).
    private Grupo grupo; //Grupo al que pertenece la casilla (si es solar).
    private float impuesto; //Cantidad a pagar por caer en la casilla: el alquiler en solares/servicios/transportes o impuestos.
    private float hipoteca; //Valor otorgado por hipotecar una casilla
    private ArrayList<Avatar> avatares; //Avatares que están situados en la casilla.
    private boolean hipotecada;  //false se no nestá hipotecada ou non se pode,true si está hipotecada
    private Solares.DatosEdificios datosedificios; //Datos dos edificios construídos nesta casilla (se é solar)
    private CartasSuerte cartasSuerte; // Obxecto para xestionar as cartas

    //Estadísticas
    private int vecesCaida; //Número de veces que se ha caído en esta casilla
    private float totalAlquileresCobrados; //Total de alquileres cobrados en esta casilla

    //Constructores:
    public Casilla() {
        this.duenho = null; //Inicialmente non ten dono
        this.avatares = new ArrayList<>();
        this.hipotecada = false; //inicialmente non está hipotecada
        this.datosedificios = new Solares.DatosEdificios(); //inicializamos os datos de edificios
        this.vecesCaida = 0;
        this.totalAlquileresCobrados = 0;
        this.cartasSuerte = new CartasSuerte(); // Inicializar cartas

    }//Parámetros vacíos (definición de una nueva casilla)

    /*Constructor para casillas tipo Solar, Servicios o Transporte:
     * Parámetros: nombre casilla, tipo (debe ser solar, serv. o transporte), posición en el tablero, valor y dueño.
     */
    public Casilla(String nombre, String tipo, int posicion, float valor, Jugador duenho) {

        this.nombre = nombre;             //Definimos los parámetros que se nos pasan como argumentos de la función...
        this.tipo = tipo;
        this.posicion = posicion;
        this.valor = valor;
        this.duenho = duenho;
        this.hipotecada = false;
        this.avatares = new ArrayList<>();
        this.datosedificios = new Solares.DatosEdificios(); // Inicializar
        this.vecesCaida = 0;
        this.totalAlquileresCobrados = 0;
        this.cartasSuerte = new CartasSuerte(); // Inicializar cartas

        // Establecemos valores por defecto segundo o tipo
        if ("Solar".equalsIgnoreCase(tipo)) {
            this.impuesto = Solares.obtenerAlquiler(nombre); //como ObtenerAlquiler é static chámase coa clase, non hai que crear un obxecto
            this.hipoteca = valor / 2; // Valor da hipoteca é a metade do valor de compra
        } else if ("Transporte".equalsIgnoreCase(tipo)) {
            this.impuesto = Valor.TRANSPORTE_ALQUILER; // Aluguer base para transportes
            this.hipoteca = 0; //os transportes non teñen hipoteca nesta versión
        } else if ("Servicio".equalsIgnoreCase(tipo)) {
            this.impuesto = 0; // Calcúlase baseado nos dados
            this.hipoteca = 0; //os servizos non teñen hipoteca nesta versión
        }
    }

    /*Constructor utilizado para inicializar las casillas de tipo IMPUESTOS.
     * Parámetros: nombre, posición en el tablero, impuesto establecido y dueño.
     */
    public Casilla(String nombre, int posicion, float impuesto, Jugador duenho) {

        this.nombre = nombre;
        this.tipo = "Impuesto";
        this.posicion = posicion;
        this.impuesto = impuesto;
        this.duenho = duenho;

        this.valor = 0; //non teñen valor de compra
        this.avatares = new ArrayList<>();
        this.hipotecada = false;
        this.datosedificios = new Solares.DatosEdificios(); // Inicializar
        this.vecesCaida = 0;
        this.totalAlquileresCobrados = 0;
        this.cartasSuerte = new CartasSuerte(); // Inicializar cartas
    }

    /*Constructor utilizado para crear las otras casillas (Suerte, Caja de comunidad y Especiales):
     * Parámetros: nombre, tipo de la casilla (será uno de los que queda), posición en el tablero y dueño.
     */
    public Casilla(String nombre, String tipo, int posicion, Jugador duenho) {

        this.nombre = nombre;
        this.tipo = tipo;
        this.posicion = posicion;
        this.duenho = duenho;

        this.valor = 0; //non teñen valor de compra
        this.impuesto = 0; //non cobran aluguer
        this.avatares = new ArrayList<>();
        this.hipotecada = false;
        this.datosedificios = new Solares.DatosEdificios(); // Inicializar
        this.vecesCaida = 0;
        this.totalAlquileresCobrados = 0;
        this.cartasSuerte = new CartasSuerte(); // Inicializar cartas

        //Valor especial para o Parking que acumula o bote
        if ("Parking".equalsIgnoreCase(tipo)) {
            this.valor = 0; //inicialmente está a 0 o bote
        }

    }

    //Metodo utilizado para añadir un avatar al array de avatares en casilla.
    public void anhadirAvatar(Avatar av) {
        if (av != null && !this.avatares.contains(av)) { //Comprobamos que o avatar a engadir ao array de avatares non está (no queremos duplicados)
            this.avatares.add(av); //Se non está, engádese
            this.vecesCaida++; //Incrementamos o contador de veces que se cae nesta casilla
        } else {
            System.out.println("O avatar xa estaba nesta casilla");
        }
    }

    //Metodo utilizado para eliminar un avatar del array de avatares en casilla.
    public void eliminarAvatar(Avatar av) {
        if (av != null && this.avatares.contains(av)) { //Comprobamos que o avatar está no array
            this.avatares.remove(av);        //Se está en la lista de avatares, eliminámolo
        } else {
            System.out.println("Non se pode eliminar o avatar");
        }
    }

    /*Metodo para evaluar qué hacer en una casilla concreta. Parámetros:
     * - Jugador cuyo avatar está en esa casilla.
     * - La banca (para ciertas comprobaciones).
     * - El valor de la tirada: para determinar impuesto a pagar en casillas de servicios.
     * Valor devuelto: true en caso de ser solvente (es decir, de cumplir las deudas), y false
     * en caso de no cumplirlas.*/
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada, Tablero tablero, boolean cartas) {

        // Incrementar contador de veces caída
        this.vecesCaida++;

        //Segundo o tipo de casilla avalíase de maneira diferente
        switch (this.tipo.toLowerCase()) {
            case "solar":
                return evaluarSolar(actual, banca, tablero);
            case "transporte":
                return evaluarTransporte(actual, banca, tablero, cartas);
            case "servicio":
                return evaluarServicio(actual, banca, tirada, tablero);
            case "impuesto":
                return pagarImpuesto(actual, banca, tablero);
            case "suerte":
                return ejecutarCartaSuerte(actual, tablero, tablero.getJugadores());
            case "comunidad":
                return ejecutarCartaComunidad(actual, tablero);
            case "parking":
                return cobrarParking(actual);
            case "ircarcel":
                irACarcel(actual);
                return true;
            case "carcel":
                return true;
            case "salida":
                actual.sumarFortuna(Valor.SUMA_VUELTA);
                actual.registrarPasoSalida(Valor.SUMA_VUELTA);
                System.out.println(actual.getNombre() + " recibe " + (int)Valor.SUMA_VUELTA + "€ por pasar por Salida. Fortuna actual: " + (int)actual.getFortuna() + "€.");

                return true;
            default:
                System.out.println("Tipo de casilla non recoñecida: " + nombre);
                return true;
        }
    }

    /*Metodo usado para comprar una casilla determinada. Parámetros:
     * - Jugador que solicita la compra de la casilla.
     * - Banca del monopoly (es el dueño de las casillas no compradas aún).*/
    public void comprarCasilla(Jugador solicitante, Jugador banca){
        if (this.duenho == null || this.duenho == banca) { //se non ten dono ou o dono é a banca pódese comprar
            if (solicitante.puedePagar(valor)) {
                solicitante.sumarFortuna(-valor); // Restamos o valor da fortuna do xogador
                solicitante.sumarInversion(valor);
                this.duenho = solicitante; // Asignamos o dueño
                solicitante.anhadirPropiedad(this); // Engadimos a casilla ás propiedades do xogador

                System.out.println("O xogador " + solicitante.getNombre() + " compra a casilla " + this.nombre + " por " + (int)this.valor + "€. A súa fortuna actual é " + (int)solicitante.getFortuna() + "€.");
            } else {
                System.out.println(solicitante.getNombre() + " non ten diñeiro suficiente para comprar " + this.nombre + ".");
            }
        } else {
            System.out.println("A casilla " + this.nombre + " xa ten dono: " + this.duenho.getNombre());
        }
    }

    /*Metodo para añadir valor a una casilla. Utilidad:
     * - Sumar valor a la casilla de parking.
     * - Sumar valor a las casillas de solar al no comprarlas tras cuatro vueltas de todos los jugadores.
     * Este metodo toma como argumento la cantidad a añadir del valor de la casilla.*/
    public void sumarValor(float suma) {
        this.valor += suma;
    }

    // Metodo para registrar pago de alquiler (estadísticas)
    public void registrarAlquilerCobrado(float cantidad) {
        this.totalAlquileresCobrados += cantidad;
    }

    /* Metodo para mostrar información de una casilla en venta.
     * Valor devuelto: texto con esa información.
     */
    public String casEnVenta() {
        if ((duenho == null || "Banca".equalsIgnoreCase(duenho.getNombre())) && "solar".equalsIgnoreCase(tipo) ||
                "transporte".equalsIgnoreCase(tipo) || "servicio".equalsIgnoreCase(tipo)) {

            return "{\n" + "nome: " + this.nombre + ",\n" + "tipo: " + this.tipo +
                    (grupo != null ? ",\ngrupo: " + grupo.getColorGrupo() : "") +
                    ",\nvalor: " + (int)this.valor + "\n" +"}";
        }
        return "";
    }

    //----------Metodos auxiliares

    private boolean evaluar(Jugador actual, Jugador banca, Tablero tablero, float alquilerTransporte) {
        boolean resultado = actual.pagarJugador(duenho, alquilerTransporte, tablero);
        if (!resultado){
            return false; //o xogador non puido pagar o aluguer
        }
        else {
            registrarAlquilerCobrado(alquilerTransporte); // Actualizamos estatísticas
            if (duenho != null) {
                duenho.registrarCobroAlquiler(alquilerTransporte);
            }
            actual.registrarPagoAlquiler(alquilerTransporte);
        }
        return true;
    }

    private boolean evaluarSolar(Jugador actual, Jugador banca, Tablero tablero) {

        // 1) Se non ten dono ou pertence á banca
        if (duenho == null || duenho == banca) {
            float precioCompra = Solares.obtenerPrecio(nombre);
            System.out.println("O solar está dispoñible para comprar por " + (int)precioCompra + "€");
            return true;
        }

        // 2) Se o dono é o propio xogador
        if (duenho == actual) {
            System.out.println("É o dono desta propiedade");
            return true;
        }

        // 3) Comprobar si la casilla o el grupo están hipotecados
        boolean grupoHipotecado = this.grupo != null && this.grupo.getMiembros().stream().anyMatch(Casilla::isHipotecada);
        if (hipotecada || grupoHipotecado) {
            System.out.println("O solar ou algunha casilla do grupo está hipotecada, non se paga aluguer.");
            return true;
        }

        // 4) Calcular y cobrar alquiler
        float alquilerAPagar = Solares.calcularAlquiler(this);

        if (this.grupo != null && this.grupo.esDuenhoGrupo(duenho) && this.datosedificios != null && !this.datosedificios.isTieneEdificios()) {
            alquilerAPagar *= 2;
            System.out.println("O dono ten todo o grupo " + this.grupo.getColorGrupo() + ", o aluguer dóbrase.");
        }

        System.out.println(actual.getNombre() + " debe pagar " + (int)alquilerAPagar + "€ de aluguer a " + duenho.getNombre());
        return evaluar(actual, banca, tablero, alquilerAPagar);
    }

    /*
    // Avalía un solar, é privado polo que só pode ser chamado dende Casilla
    private boolean evaluarSolar(Jugador actual, Jugador banca, Tablero tablero) {

        // 1) Se non ten dono ou pertence á banca, o xogador pode mercar
        if (duenho == null || duenho == banca) {
            float precioCompra = Solares.obtenerPrecio(nombre);
            System.out.println("O solar está dispoñible para comprar por " + (int)precioCompra + "€");
            return true;
        }
        // Se o dono é o propio xogador
        else if (duenho == actual) {
            System.out.println("É o dono desta propiedade");
            return true;
        }

        // Verificar si alguna casilla del grupo está hipotecada
        boolean grupoHipotecado = false;
        if (this.grupo != null) {
            for (Casilla c : this.grupo.getMiembros()) {
                if (c.isHipotecada() == true) {
                    grupoHipotecado = true;
                    break;
                }
            }
        }

        // Si la casilla o el grupo están hipotecados, no se paga alquiler
        if (hipotecada || grupoHipotecado) {
            System.out.println("O solar ou algunha casilla do grupo está hipotecada, non se paga aluguer.");
            return true;
        }

        // 2) Se ten dono e non está hipotecado, págase aluguer
        else if (!hipotecada) {
            float alquilerAPagar = Solares.calcularAlquiler(this);

            //Verificamos se o dono ten o grupo para aplicar o incremento
            if (this.grupo != null && this.grupo.esDuenhoGrupo(duenho) && this.datosedificios != null && !this.datosedificios.isTieneEdificios()) {
                alquilerAPagar *= 2;
                System.out.println("O dono ten todo o grupo " + this.grupo.getColorGrupo() + ", o aluguer dóbrase.");
            }

            System.out.println(actual.getNombre() + " debe pagar " + (int)alquilerAPagar + "€ de aluguer a " + duenho.getNombre());
            boolean pagoExitoso = evaluar(actual, banca, tablero, alquilerAPagar);
            return pagoExitoso;
        }
        // 3) Se está hipotecado, non se paga aluguer
        else {
            System.out.println("O solar está hipotecado, non se paga aluguer.");
            return true;
        }
    }

    */

    // Avalía unha casilla de transporte
    private boolean evaluarTransporte(Jugador actual, Jugador banca, Tablero tablero, boolean cartas) {
        if (duenho == null || duenho == banca) {
            System.out.println("O transporte está dispoñible para comprar por " + (int)impuesto + "€");
            return true;
        } else if (duenho == actual) {
            System.out.println(actual.getNombre() + " é o dono deste transporte");
            return true;
        }
        else if (!hipotecada) {
            // En proximas entregas para transportes, o aluguer depende de cantos transportes ten o dono
            float alquilerTransporte = this.impuesto;
            if (cartas) {
                alquilerTransporte *= 2;
            }
            System.out.println(actual.getNombre() + " debe pagar " + (int)alquilerTransporte + "€ de aluguer a " + duenho.getNombre());
            boolean pagoExitoso = evaluar(actual, banca, tablero, alquilerTransporte);
            return pagoExitoso;
        }
        return true; //falta engadir se está hipotecada pero en próximas entregas
    }

    // Avalía unha casilla de servizo
    private boolean evaluarServicio(Jugador actual, Jugador banca, int tirada, Tablero tablero) {
        if (duenho == null || duenho == banca) {
            System.out.println("O servizo " + this.nombre + " está dispoñible para comprar por " + (int)this.valor + "€");
            return true;
        } else if (duenho == actual) {
            System.out.println("É o dono deste servizo");
            return true;
        }
        else if (!hipotecada) {
            //Nesta entrega o alquiler é catro veces os dados polo factor de servicio
            float pago = tirada * Valor.FACTOR_SERVICIO * 4;
            System.out.println(actual.getNombre() + " debe pagar " + (int)pago + "€ de aluguer a " + duenho.getNombre());
            boolean pagoExitoso = evaluar(actual, banca, tablero, pago);
            return pagoExitoso;
        }
        return true; //falta engadir se está hipotecada pero en próximas entregas
    }

    private boolean ejecutarCartaSuerte (Jugador actual, Tablero tablero, ArrayList<Jugador> jugadores) {
        cartasSuerte.sacarCartaSuerte(actual, tablero, jugadores);
        return !actual.isEnBancarrota(); //devolve true se non está en bancarrota
    }

    private boolean ejecutarCartaComunidad (Jugador actual, Tablero tablero) {
        cartasSuerte.sacarCartaComunidad(actual, tablero);
        return !actual.isEnBancarrota(); //devolve true se non está en bancarrota
    }

    // Avalía imposto
    private boolean pagarImpuesto(Jugador actual, Jugador banca, Tablero tablero) {
        if (actual.puedePagar(impuesto)) {
            actual.sumarFortuna(-impuesto);
            actual.sumarGastos(impuesto);
            actual.registrarTasa(impuesto);
            //Engádese ao parking
            Casilla parking = tablero.encontrar_casilla("Parking");
            if (parking != null){
                parking.sumarValor(impuesto);
                System.out.println("O imposto engádese ao bote do Parking. Bote actual: " + (int)parking.getValor() + "€");
            }
            return true;
        } else{
            //Non bancarrota automática
            System.out.println(actual.getNombre() + " non pode pagar o imposto de " + (int)impuesto + "€.");
            System.out.println("Opcións dispoñibles:");
            System.out.println("   - 'hipotecar <casilla>' para obter diñeiro");
            System.out.println("   - 'acabar turno' para declararse en bancarrota");
            return false;
        }
    }

    // Cobrar o bote do Parking
    public boolean cobrarParking(Jugador actual) {
        if (valor > 0) {
            System.out.println(actual.getNombre() + " recibe o bote do Parking: " + (int)valor + "€");
            actual.sumarFortuna(valor);
            actual.registrarPremio(valor);
            valor = 0; // Reiniciamos o bote
        } else {
            System.out.println("O Parking está baleiro");
        }
        return true;
    }

    //Metodo para xestionar hipotecas
    public boolean hipotecar (Jugador jugador){
        //Verificar que o xogador é dono
        if (this.duenho == null || !this.duenho.equals(jugador)){
            System.out.println(jugador.getNombre() + " non pode hipotecar " + this.nombre + " porque non é o seu dono.");
            return false;
        }
        //Verificar que non está hipotecada
        if (this.hipotecada){
            System.out.println(this.nombre + " xa está hipotecada.");
            return false;
        }
        //Comprobar se é un solar, e que non teña edificios
        if (!"solar".equalsIgnoreCase(this.tipo)){
            System.out.println(jugador.getNombre() + " non pode hipotecar " + this.nombre + ". Non é unha propiedade hipotecable.");
            return false;
        }
        if (this.datosedificios != null && this.datosedificios.isTieneEdificios()) {
            System.out.println(jugador.getNombre() + " non pode hipotecar " + this.nombre + ". Ten edificios que deben venderse primeiro.");
            return false;
        }

        //Hipotecar, dase o diñeiro ao xogador
        this.hipotecada = true;
        float valorHipoteca = this.hipoteca;
        // actualizar listas del jugador
        jugador.anhadirHipoteca(this);
        jugador.sumarFortuna(valorHipoteca);
        jugador.sumarInversion(valorHipoteca);

        System.out.println(jugador.getNombre() + " recibe " + (int)valorHipoteca + "€ pola hipoteca de " + this.nombre +
                ". Non pode recibir alugueres, nin edificar no grupo " + (this.grupo != null ? this.grupo.getColorGrupo() : "") + ".");
        return true;
    }

    //Metodo para deshipotecar unha casilla
    public boolean deshipotecar(Jugador jugador){
        //Comprobar que o xogador é dono
        if (this.duenho == null || !this.duenho.equals(jugador)){
            System.out.println(jugador.getNombre() + " non pode deshipotecar " + this.nombre + " porque non é o seu dono.");
            return false;
        }

        if (!"solar".equalsIgnoreCase(this.tipo)){
            System.out.println(jugador.getNombre() + " non pode deshipotecar " + this.nombre + ". Non é unha propiedade hipotecable.");
            return false;
        }

        //Verificar que está hipotecada
        if (!this.hipotecada){
            System.out.println(this.nombre + " non está hipotecada.");
            return false;
        }

        //Deshipotecar, restase o diñeiro ao xogador, compróbase que ten diñeiro suficiente
        float valorDeshipoteca = this.hipoteca;
        if (!jugador.puedePagar(valorDeshipoteca)){
            System.out.println(jugador.getNombre() + " non pode deshipotecar " + this.nombre + ". Non ten diñeiro suficiente.");
            return false;
        }
        this.hipotecada = false;
        jugador.sumarFortuna(-valorDeshipoteca);
        jugador.sumarGastos(valorDeshipoteca);
        jugador.eliminarHipoteca(this);
        System.out.println(jugador.getNombre() + " paga " + (int)valorDeshipoteca + "€ por deshipotecar " + this.nombre +
                "." + (this.grupo != null && this.grupo.esDuenhoGrupo(jugador)? " Agora pode recibir alugueres e edificar no grupo " + this.grupo.getColorGrupo() : " Agora pode recibir alugueres") + ".");
        return true;
    }

    // Metodo para obter información detallada da casilla
    public String infoCasilla() {
        StringBuilder info = new StringBuilder();
        info.append("{\n");

        switch (this.tipo.toLowerCase()) {
            case "solar":
                info.append("tipo: solar,\n");
                info.append("grupo: ").append(grupo != null ? grupo.getColorGrupo() : "-").append(",\n");
                info.append("propietario: ").append(duenho != null ? duenho.getNombre() : "Banca").append(",\n");
                info.append("valor: ").append((int)valor).append(",\n");
                info.append("alquiler: ").append((int)Solares.calcularAlquiler(this)).append(",\n");
                info.append("valor hotel: ").append((int)Solares.obtenerPrecioHotel(nombre)).append(",\n");
                info.append("valor casa: ").append((int)Solares.obtenerPrecioCasa(nombre)).append(",\n");
                info.append("valor piscina: ").append((int)Solares.obtenerPrecioPiscina(nombre)).append(",\n");
                info.append("valor pista de deporte: ").append((int)Solares.obtenerPrecioPista(nombre)).append(",\n");
                info.append("alquiler casa: ").append((int)Solares.obtenerDatos(nombre).getAlquilerCasa()).append(",\n");
                info.append("alquiler hotel: ").append((int)Solares.obtenerDatos(nombre).getAlquilerHotel()).append(",\n");
                info.append("alquiler piscina: ").append((int)Solares.obtenerDatos(nombre).getAlquilerPiscina()).append(",\n");
                info.append("alquiler pista de deporte: ").append((int)Solares.obtenerDatos(nombre).getAlquilerPista()).append("\n");
                break;

            case "impuesto":
                info.append("tipo: impuesto,\n");
                info.append("a pagar: ").append((int)impuesto).append("\n");
                break;

            case "parking":
                info.append("tipo: parking,\n");
                info.append("bote: ").append((int)valor).append(",\n");
                info.append("jugadores: [").append(getAvataresString()).append("]\n");
                break;

            case "carcel":
                info.append("tipo: carcel,\n");
                info.append("salir: ").append((int)Valor.CARCEL_SALIDA).append(",\n");
                info.append("jugadores: [").append(getAvataresString()).append("]\n");
                break;

            default:
                info.append("tipo: ").append(tipo).append(",\n");
                info.append("propietario: ").append(duenho != null ? duenho.getNombre() : "Banca").append(",\n");
                if (valor > 0) {
                    info.append("valor: ").append((int)valor).append(",\n");
                }
                if (impuesto > 0) {
                    info.append("alquiler: ").append((int)impuesto).append(",\n");
                }
                info.append("jugadores: [").append(getAvataresString()).append("]\n");
        }

        info.append("}");
        return info.toString();
    }


    public void irACarcel(Jugador actual) {
        actual.setEnCarcel(true);
        actual.registrarVecesEnCarcel();
    }

    public String getAvataresString(){
        if (avatares == null || avatares.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for(Avatar av : avatares){
            sb.append(av.getId()); // Mostrar o ID do avatar
            if (av.getJugador().isEnCarcel()) {
                sb.append("");
            }
            sb.append(" ");
        }
        return sb.toString().trim();
    }

    public String getNombre() {
        return nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public float getValor() {
        return valor;
    }

    public int getPosicion() {
        return posicion;
    }

    public Jugador getDuenho() {
        return duenho;
    }

    public float getImpuesto() {
        return impuesto;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public void setDuenho(Jugador duenho) {
        this.duenho = duenho;
    }

    public void setGrupo(Grupo grupo) {
        this.grupo = grupo;
    }

    public Grupo getGrupo() {
        return grupo;
    }

    public int getVecesCaida() {
        return vecesCaida;
    }

    public float getTotalAlquileresCobrados() {
        return totalAlquileresCobrados;
    }

    public Solares.DatosEdificios getDatosedificios() {
        return datosedificios;
    }

    public boolean isHipotecada() {
        return hipotecada;
    }
}