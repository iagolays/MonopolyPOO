package monopoly;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;


import partida.*;

/*
 * Clase para xestionar todos os datos dos solares do xogo Monopoly
 */
public class Solares {

    /*Clase interna para gardar todos os datos dun solar
    É static porque non precisa acceder a ningún atributo nin metodo de Solares, só serve como modelo de datos
    (un conxunto de valores numéricos).
     */
    public static class DatosSolar {
        private float precio; // Prezo de compra do solar
        private float alquiler; // Aluguer base do solar
        private float valorCasa; // Valor para construír unha casa
        private float valorHotel; // Valor para construír un hotel
        private float valorPiscina; // Valor para construír unha piscina
        private float valorPista; // Valor para construír unha pista de deporte
        private float alquilerCasa; // Aluguer cando ten casa
        private float alquilerHotel; // Aluguer cando ten hotel
        private float alquilerPiscina; // Aluguer cando ten piscina
        private float alquilerPista; // Aluguer cando ten pista de deporte

        // Constructor para inicializar todos os valores dun solar
        public DatosSolar(float precio, float alquiler, float valorCasa, float valorHotel, float valorPiscina, float valorPista,
                          float alquilerCasa, float alquilerHotel, float alquilerPiscina, float alquilerPista) {

            this.precio = precio;
            this.alquiler = alquiler;
            this.valorCasa = valorCasa;
            this.valorHotel = valorHotel;
            this.valorPiscina = valorPiscina;
            this.valorPista = valorPista;
            this.alquilerCasa = alquilerCasa;
            this.alquilerHotel = alquilerHotel;
            this.alquilerPiscina = alquilerPiscina;
            this.alquilerPista = alquilerPista;
        }

        public float getPrecio() {
            return precio;
        }

        public float getAlquiler() {
            return alquiler;
        }

        public float getValorCasa() {
            return valorCasa;
        }

        public float getValorHotel() {
            return valorHotel;
        }

        public float getValorPiscina() {
            return valorPiscina;
        }

        public float getValorPista() {
            return valorPista;
        }

        public float getAlquilerCasa() {
            return alquilerCasa;
        }

        public float getAlquilerHotel() {
            return alquilerHotel;
        }

        public float getAlquilerPiscina() {
            return alquilerPiscina;
        }

        public float getAlquilerPista() {
            return alquilerPista;
        }

        @Override
        public String toString() {
            return "{ precio: " + (int) precio +
                    ", alquiler: " + (int) alquiler +
                    ", valorCasa: " + (int) valorCasa +
                    ", valorHotel: " + (int) valorHotel +
                    ", valorPiscina: " + (int) valorPiscina +
                    ", valorPista: " + (int) valorPista +
                    " }";
        }
    }

    public static class DatosEdificios {
        private int numCasas;
        private int numHoteles;
        private int numPiscinas;
        private int numPistas;
        private boolean tieneEdificios;

        // Constructor
        public DatosEdificios() {
            this.numCasas = 0;
            this.numHoteles = 0;
            this.numPiscinas = 0;
            this.numPistas = 0;
            this.tieneEdificios = false;
        }

        public int getNumCasas() {
            return numCasas;
        }

        public int getNumHoteles() {
            return numHoteles;
        }

        public int getNumPiscinas() {
            return numPiscinas;
        }

        public int getNumPistas() {
            return numPistas;
        }

        public boolean isTieneEdificios() {
            return tieneEdificios;
        }

        // Metodos para actualizar el estado de tieneEdificios
        public void actualizarEstadoEdificios() {
            this.tieneEdificios = (numCasas > 0 || numHoteles > 0 || numPiscinas > 0 || numPistas > 0);
        }

        public void setNumCasas(int numCasas) {
            this.numCasas = numCasas;
        }

        public void setNumHoteles(int numHoteles) {
            this.numHoteles = numHoteles;
        }

        public void setNumPiscinas(int numPiscinas) {
            this.numPiscinas = numPiscinas;
        }

        public void setNumPistas(int numPistas) {
            this.numPistas = numPistas;
        }
    }

    // Mapa onde gardamos todos os datos dos solares, é static porque pertence á clase e final porque non se pode cambiar a referencia do mapa (aínda que si se poden engadir elementos dentro).
    //HashMap é unha estrutura de datos que garda pares “string (clave) → DatosSolar (valor)”.
    public static final Map<String, DatosSolar> DATOS = new HashMap<>();

    //lista global para IDs unicos de edificios
    private static final ArrayList<String> idsEdificios = new ArrayList<>();

    static { // Bloque estático - execútase unha única vez, cando se carga a clase (antes de crear ningún obxecto).
        // Solar 1          O metodo put() engade un elemento novo ao mapa.
        DATOS.put("solar1", new DatosSolar(Valor.SOLAR1_PRECIO, Valor.SOLAR1_ALQUILER, Valor.SOLAR1_PRECIO_CASA, Valor.SOLAR1_PRECIO_HOTEL,
                Valor.SOLAR1_PRECIO_PISCINA, Valor.SOLAR1_PRECIO_PISTA, Valor.SOLAR1_ALQUILER_CASA, Valor.SOLAR1_ALQUILER_HOTEL,
                Valor.SOLAR1_ALQUILER_PISCINA, Valor.SOLAR1_ALQUILER_PISTA));

        // Solar 2
        DATOS.put("solar2", new DatosSolar(Valor.SOLAR2_PRECIO, Valor.SOLAR2_ALQUILER, Valor.SOLAR2_PRECIO_CASA, Valor.SOLAR2_PRECIO_HOTEL,
                Valor.SOLAR2_PRECIO_PISCINA, Valor.SOLAR2_PRECIO_PISTA, Valor.SOLAR2_ALQUILER_CASA, Valor.SOLAR2_ALQUILER_HOTEL,
                Valor.SOLAR2_ALQUILER_PISCINA, Valor.SOLAR2_ALQUILER_PISTA));

        // Solar 3
        DATOS.put("solar3", new DatosSolar(Valor.SOLAR3_PRECIO, Valor.SOLAR3_ALQUILER, Valor.SOLAR3_PRECIO_CASA, Valor.SOLAR3_PRECIO_HOTEL,
                Valor.SOLAR3_PRECIO_PISCINA, Valor.SOLAR3_PRECIO_PISTA, Valor.SOLAR3_ALQUILER_CASA, Valor.SOLAR3_ALQUILER_HOTEL,
                Valor.SOLAR3_ALQUILER_PISCINA, Valor.SOLAR3_ALQUILER_PISTA));

        // Solar 4
        DATOS.put("solar4", new DatosSolar(Valor.SOLAR4_PRECIO, Valor.SOLAR4_ALQUILER, Valor.SOLAR4_PRECIO_CASA, Valor.SOLAR4_PRECIO_HOTEL,
                Valor.SOLAR4_PRECIO_PISCINA, Valor.SOLAR4_PRECIO_PISTA, Valor.SOLAR4_ALQUILER_CASA, Valor.SOLAR4_ALQUILER_HOTEL,
                Valor.SOLAR4_ALQUILER_PISCINA, Valor.SOLAR4_ALQUILER_PISTA));

        // Solar 5
        DATOS.put("solar5", new DatosSolar(Valor.SOLAR5_PRECIO, Valor.SOLAR5_ALQUILER, Valor.SOLAR5_PRECIO_CASA, Valor.SOLAR5_PRECIO_HOTEL,
                Valor.SOLAR5_PRECIO_PISCINA, Valor.SOLAR5_PRECIO_PISTA, Valor.SOLAR5_ALQUILER_CASA, Valor.SOLAR5_ALQUILER_HOTEL,
                Valor.SOLAR5_ALQUILER_PISCINA, Valor.SOLAR5_ALQUILER_PISTA));

        // Solar 6
        DATOS.put("solar6", new DatosSolar(Valor.SOLAR6_PRECIO, Valor.SOLAR6_ALQUILER, Valor.SOLAR6_PRECIO_CASA, Valor.SOLAR6_PRECIO_HOTEL,
                Valor.SOLAR6_PRECIO_PISCINA, Valor.SOLAR6_PRECIO_PISTA, Valor.SOLAR6_ALQUILER_CASA, Valor.SOLAR6_ALQUILER_HOTEL,
                Valor.SOLAR6_ALQUILER_PISCINA, Valor.SOLAR6_ALQUILER_PISTA));

        // Solar 7
        DATOS.put("solar7", new DatosSolar(Valor.SOLAR7_PRECIO, Valor.SOLAR7_ALQUILER, Valor.SOLAR7_PRECIO_CASA, Valor.SOLAR7_PRECIO_HOTEL,
                Valor.SOLAR7_PRECIO_PISCINA, Valor.SOLAR7_PRECIO_PISTA, Valor.SOLAR7_ALQUILER_CASA, Valor.SOLAR7_ALQUILER_HOTEL,
                Valor.SOLAR7_ALQUILER_PISCINA, Valor.SOLAR7_ALQUILER_PISTA));

        // Solar 8
        DATOS.put("solar8", new DatosSolar(Valor.SOLAR8_PRECIO, Valor.SOLAR8_ALQUILER, Valor.SOLAR8_PRECIO_CASA, Valor.SOLAR8_PRECIO_HOTEL,
                Valor.SOLAR8_PRECIO_PISCINA, Valor.SOLAR8_PRECIO_PISTA, Valor.SOLAR8_ALQUILER_CASA, Valor.SOLAR8_ALQUILER_HOTEL,
                Valor.SOLAR8_ALQUILER_PISCINA, Valor.SOLAR8_ALQUILER_PISTA));

        // Solar 9
        DATOS.put("solar9", new DatosSolar(Valor.SOLAR9_PRECIO, Valor.SOLAR9_ALQUILER, Valor.SOLAR9_PRECIO_CASA, Valor.SOLAR9_PRECIO_HOTEL,
                Valor.SOLAR9_PRECIO_PISCINA, Valor.SOLAR9_PRECIO_PISTA, Valor.SOLAR9_ALQUILER_CASA, Valor.SOLAR9_ALQUILER_HOTEL,
                Valor.SOLAR9_ALQUILER_PISCINA, Valor.SOLAR9_ALQUILER_PISTA));

        // Solar 10
        DATOS.put("solar10", new DatosSolar(Valor.SOLAR10_PRECIO, Valor.SOLAR10_ALQUILER, Valor.SOLAR10_PRECIO_CASA, Valor.SOLAR10_PRECIO_HOTEL,
                Valor.SOLAR10_PRECIO_PISCINA, Valor.SOLAR10_PRECIO_PISTA, Valor.SOLAR10_ALQUILER_CASA, Valor.SOLAR10_ALQUILER_HOTEL,
                Valor.SOLAR10_ALQUILER_PISCINA, Valor.SOLAR10_ALQUILER_PISTA));

        // Solar 11
        DATOS.put("solar11", new DatosSolar(Valor.SOLAR11_PRECIO, Valor.SOLAR11_ALQUILER, Valor.SOLAR11_PRECIO_CASA, Valor.SOLAR11_PRECIO_HOTEL,
                Valor.SOLAR11_PRECIO_PISCINA, Valor.SOLAR11_PRECIO_PISTA, Valor.SOLAR11_ALQUILER_CASA, Valor.SOLAR11_ALQUILER_HOTEL,
                Valor.SOLAR11_ALQUILER_PISCINA, Valor.SOLAR11_ALQUILER_PISTA));

        // Solar 12
        DATOS.put("solar12", new DatosSolar(Valor.SOLAR12_PRECIO, Valor.SOLAR12_ALQUILER, Valor.SOLAR12_PRECIO_CASA, Valor.SOLAR12_PRECIO_HOTEL,
                Valor.SOLAR12_PRECIO_PISCINA, Valor.SOLAR12_PRECIO_PISTA, Valor.SOLAR12_ALQUILER_CASA, Valor.SOLAR12_ALQUILER_HOTEL,
                Valor.SOLAR12_ALQUILER_PISCINA, Valor.SOLAR12_ALQUILER_PISTA));

        // Solar 13
        DATOS.put("solar13", new DatosSolar(Valor.SOLAR13_PRECIO, Valor.SOLAR13_ALQUILER, Valor.SOLAR13_PRECIO_CASA, Valor.SOLAR13_PRECIO_HOTEL,
                Valor.SOLAR13_PRECIO_PISCINA, Valor.SOLAR13_PRECIO_PISTA, Valor.SOLAR13_ALQUILER_CASA, Valor.SOLAR13_ALQUILER_HOTEL,
                Valor.SOLAR13_ALQUILER_PISCINA, Valor.SOLAR13_ALQUILER_PISTA));

        // Solar 14
        DATOS.put("solar14", new DatosSolar(Valor.SOLAR14_PRECIO, Valor.SOLAR14_ALQUILER, Valor.SOLAR14_PRECIO_CASA, Valor.SOLAR14_PRECIO_HOTEL,
                Valor.SOLAR14_PRECIO_PISCINA, Valor.SOLAR14_PRECIO_PISTA, Valor.SOLAR14_ALQUILER_CASA, Valor.SOLAR14_ALQUILER_HOTEL,
                Valor.SOLAR14_ALQUILER_PISCINA, Valor.SOLAR14_ALQUILER_PISTA));

        // Solar 15
        DATOS.put("solar15", new DatosSolar(Valor.SOLAR15_PRECIO, Valor.SOLAR15_ALQUILER, Valor.SOLAR15_PRECIO_CASA, Valor.SOLAR15_PRECIO_HOTEL,
                Valor.SOLAR15_PRECIO_PISCINA, Valor.SOLAR15_PRECIO_PISTA, Valor.SOLAR15_ALQUILER_CASA, Valor.SOLAR15_ALQUILER_HOTEL,
                Valor.SOLAR15_ALQUILER_PISCINA, Valor.SOLAR15_ALQUILER_PISTA));

        // Solar 16
        DATOS.put("solar16", new DatosSolar(Valor.SOLAR16_PRECIO, Valor.SOLAR16_ALQUILER, Valor.SOLAR16_PRECIO_CASA, Valor.SOLAR16_PRECIO_HOTEL,
                Valor.SOLAR16_PRECIO_PISCINA, Valor.SOLAR16_PRECIO_PISTA, Valor.SOLAR16_ALQUILER_CASA, Valor.SOLAR16_ALQUILER_HOTEL,
                Valor.SOLAR16_ALQUILER_PISCINA, Valor.SOLAR16_ALQUILER_PISTA));

        // Solar 17
        DATOS.put("solar17", new DatosSolar(Valor.SOLAR17_PRECIO, Valor.SOLAR17_ALQUILER, Valor.SOLAR17_PRECIO_CASA, Valor.SOLAR17_PRECIO_HOTEL,
                Valor.SOLAR17_PRECIO_PISCINA, Valor.SOLAR17_PRECIO_PISTA, Valor.SOLAR17_ALQUILER_CASA, Valor.SOLAR17_ALQUILER_HOTEL,
                Valor.SOLAR17_ALQUILER_PISCINA, Valor.SOLAR17_ALQUILER_PISTA));

        // Solar 18
        DATOS.put("solar18", new DatosSolar(Valor.SOLAR18_PRECIO, Valor.SOLAR18_ALQUILER, Valor.SOLAR18_PRECIO_CASA, Valor.SOLAR18_PRECIO_HOTEL,
                Valor.SOLAR18_PRECIO_PISCINA, Valor.SOLAR18_PRECIO_PISTA, Valor.SOLAR18_ALQUILER_CASA, Valor.SOLAR18_ALQUILER_HOTEL,
                Valor.SOLAR18_ALQUILER_PISCINA, Valor.SOLAR18_ALQUILER_PISTA));

        // Solar 19
        DATOS.put("solar19", new DatosSolar(Valor.SOLAR19_PRECIO, Valor.SOLAR19_ALQUILER, Valor.SOLAR19_PRECIO_CASA, Valor.SOLAR19_PRECIO_HOTEL,
                Valor.SOLAR19_PRECIO_PISCINA, Valor.SOLAR19_PRECIO_PISTA, Valor.SOLAR19_ALQUILER_CASA, Valor.SOLAR19_ALQUILER_HOTEL,
                Valor.SOLAR19_ALQUILER_PISCINA, Valor.SOLAR19_ALQUILER_PISTA));

        // Solar 20
        DATOS.put("solar20", new DatosSolar(Valor.SOLAR20_PRECIO, Valor.SOLAR20_ALQUILER, Valor.SOLAR20_PRECIO_CASA, Valor.SOLAR20_PRECIO_HOTEL,
                Valor.SOLAR20_PRECIO_PISCINA, Valor.SOLAR20_PRECIO_PISTA, Valor.SOLAR20_ALQUILER_CASA, Valor.SOLAR20_ALQUILER_HOTEL,
                Valor.SOLAR20_ALQUILER_PISCINA, Valor.SOLAR20_ALQUILER_PISTA));

        // Solar 21
        DATOS.put("solar21", new DatosSolar(Valor.SOLAR21_PRECIO, Valor.SOLAR21_ALQUILER, Valor.SOLAR21_PRECIO_CASA, Valor.SOLAR21_PRECIO_HOTEL,
                Valor.SOLAR21_PRECIO_PISCINA, Valor.SOLAR21_PRECIO_PISTA, Valor.SOLAR21_ALQUILER_CASA, Valor.SOLAR21_ALQUILER_HOTEL,
                Valor.SOLAR21_ALQUILER_PISCINA, Valor.SOLAR21_ALQUILER_PISTA));

        // Solar 22
        DATOS.put("solar22", new DatosSolar(Valor.SOLAR22_PRECIO, Valor.SOLAR22_ALQUILER, Valor.SOLAR22_PRECIO_CASA, Valor.SOLAR22_PRECIO_HOTEL,
                Valor.SOLAR22_PRECIO_PISCINA, Valor.SOLAR22_PRECIO_PISTA, Valor.SOLAR22_ALQUILER_CASA, Valor.SOLAR22_ALQUILER_HOTEL,
                Valor.SOLAR22_ALQUILER_PISCINA, Valor.SOLAR22_ALQUILER_PISTA));
    }

    //metodos publicos para poder acceder aos datos

    // Metodo simple para obter datos dun solar
    public static DatosSolar obtenerDatos(String nombreSolar) {
        return DATOS.get(nombreSolar.toLowerCase());
    }

    // Metodo para obter o prezo
    public static float obtenerPrecio(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.precio : 0; // Se non existe, devolvemos 0
    }

    // Metodo para obter o aluguer
    public static float obtenerAlquiler(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.alquiler : 0;
    }

    // Metodo para obter o prezo da casa, para proximas entregas
    public static float obtenerPrecioCasa(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.getValorCasa() : 0;
    }

    // Metodo para obter precio hotel, para proximas entregas
    public static float obtenerPrecioHotel(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.getValorHotel() : 0;
    }

    // Metodo para obter precio piscina, para proximas entregas
    public static float obtenerPrecioPiscina(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.getValorPiscina() : 0;
    }

    // Metodo para obter precio pista, para proximas entregas
    public static float obtenerPrecioPista(String nombreSolar) {
        DatosSolar datos = obtenerDatos(nombreSolar);
        return datos != null ? datos.getValorPista() : 0;
    }

    //Calcula o aluguer total dunha casilla segundo os edificios que teña
    public static float calcularAlquiler(Casilla casilla) {
        DatosSolar datos = obtenerDatos(casilla.getNombre());
        if (datos == null){
            return 0;
        }
        DatosEdificios edificios = casilla.getDatosedificios();
        float alquilerTotal = datos.getAlquiler();

        if (edificios != null) {
            alquilerTotal += edificios.getNumCasas() * datos.getAlquilerCasa();
            alquilerTotal += edificios.getNumHoteles() * datos.getAlquilerHotel();
            alquilerTotal += edificios.getNumPiscinas() * datos.getAlquilerPiscina();
            alquilerTotal += edificios.getNumPistas() * datos.getAlquilerPista();
        }
        return alquilerTotal;
    }

    //Metodo para verificar que se poden construír casas
    public static boolean PuedeConstruir(Casilla casilla, Jugador jugador, String tipo) {

        // Comprobar si la casilla o alguna del grupo está hipotecada
        if (casilla.isHipotecada()) {
            System.out.println("Non se pode construír en " + casilla.getNombre() + " porque está hipotecada.");
            return false;
        }
        Grupo grupo = casilla.getGrupo();
        if (grupo != null) {
            for (Casilla c : grupo.getMiembros()) {
                if (c.isHipotecada()) {
                    System.out.println("Non se pode construír en " + casilla.getNombre() + " porque algunha casilla do grupo está hipotecada.");
                    return false;
                }
            }
        }

        if (casilla.getDuenho() == null || !casilla.getDuenho().equals(jugador)) {
            System.out.println("Non se pode construír en " + casilla.getNombre() + " porque " + jugador.getNombre() + " non é o propietario da casilla.");
            return false;
        }
        if (jugador.getAvatar().getLugar() != casilla) {
            System.out.println("Non se pode construír en " + casilla.getNombre() + " porque " + jugador.getNombre() + " non está nesa casilla.");
            return false;
        }
        if (casilla.getGrupo() == null || !casilla.getGrupo().esDuenhoGrupo(jugador)) {
            System.out.println("Non se pode construír en " + casilla.getNombre() + " porque " + jugador.getNombre() + " non posúe todo o grupo.");
            return false;
        }

        DatosEdificios edificios = casilla.getDatosedificios();
        if (edificios == null) {
            return false;
        }

        switch (tipo.toLowerCase()){
            case "casa":
                if (edificios.getNumCasas() + 1> 4) {
                    System.out.println("Non se poden construír máis de 4 casas en " + casilla.getNombre() + ".");
                    return false;
                }
                if (edificios.getNumHoteles() >= 1) {
                    System.out.println("Non se poden construír casas en " + casilla.getNombre() + " porque xa hai un hotel construído.");
                    return false;
                }
                break;
            case "hotel":
                if (edificios.getNumCasas() < 4) {
                    System.out.println("Non se pode construír un hotel en " + casilla.getNombre() + " porque non hai 4 casas construídas.");
                    return false;
                } if (edificios.getNumHoteles() >= 1) {
                    System.out.println("Non se poden construír máis de 1 hotel en " + casilla.getNombre() + ".");
                    return false;
                }
                break;
            case "piscina":
                //So se pode construir unha piscina se hai un hotel
                if (edificios.getNumHoteles() < 1) {
                    System.out.println("Non se pode construír unha piscina en " + casilla.getNombre() + " porque non hai ningún hotel construído.");
                    return false;
                }
                if (edificios.getNumPiscinas() >= 1) {
                    System.out.println("Non se poden construír máis de 1 piscina en " + casilla.getNombre() + ".");
                    return false;
                }
                break;
            case "pista":
                //So se pode construir unha pista se hai un hotel e unha piscina
                if (edificios.getNumHoteles() < 1) {
                    System.out.println("Non se pode construír unha pista de deporte en " + casilla.getNombre() + " porque non hai ningún hotel construído.");
                    return false;
                }
                if (edificios.getNumPiscinas() < 1) {
                    System.out.println("Non se pode construír unha pista de deporte en " + casilla.getNombre() + " porque non hai ningunha piscina construída.");
                    return false;
                }
                if (edificios.getNumPistas() >= 1) {
                    System.out.println("Non se poden construír máis de unha pista de deporte en " + casilla.getNombre() + ".");
                    return false;
                }
                break;
            default:
                System.out.println("Tipo de edificio descoñecido: " + tipo);
                return false;
        }
        return true;
    }

    //Metodo para verificar que se poden construír casas
    public static boolean PuedeConstruirSilencio(Casilla casilla, Jugador jugador, int cantidad, String tipo) {

        if (casilla.getDuenho() == null || !casilla.getDuenho().equals(jugador) || casilla.getGrupo() == null || !casilla.getGrupo().esDuenhoGrupo(jugador)) {
            return false;
        }

        if (jugador.getAvatar() != null && jugador.getAvatar().getLugar() != casilla) {
            return false;
        }

        // Comprobar si la casilla o alguna del grupo está hipotecada
        if (casilla.isHipotecada()) {
            return false;
        }
        Grupo grupo = casilla.getGrupo();
        if (grupo != null) {
            for (Casilla c : grupo.getMiembros()) {
                if (c.isHipotecada()) {
                    return false; // No se puede construir si alguna casilla del grupo está hipotecada
                }
            }
        }

        DatosEdificios edificios = casilla.getDatosedificios();
        if (edificios == null) {
            return false;
        }

        switch (tipo.toLowerCase()){
            case "casa":
                if (edificios.getNumCasas() + cantidad > 4 || edificios.getNumHoteles() >= 1) {
                    return false;
                }
                break;
            case "hotel":
                if (edificios.getNumCasas() < 4 || edificios.getNumHoteles() >= 1) {
                    return false;
                }
                break;
            case "piscina":
                //So se pode construir unha piscina se hai un hotel
                if (edificios.getNumHoteles() < 1 || edificios.getNumPiscinas() >= 1) {
                    return false;
                }
                break;
            case "pista":
                //So se pode construir unha pista se hai un hotel e unha piscina
                if (edificios.getNumHoteles() < 1 || edificios.getNumPiscinas() < 1 || edificios.getNumPistas() >= 1) {
                    return false;
                }
                break;
            default:
                System.out.println("Tipo de edificio descoñecido: " + tipo);
                return false;
        }
        return true;
    }

    // Metodo para construir edificios nun solar
    public static boolean construirEdificio(Casilla casilla, Jugador jugador, String tipo) {
        if (!PuedeConstruir(casilla, jugador, tipo)){
            return false;
        }
        DatosSolar datos = obtenerDatos(casilla.getNombre());
        DatosEdificios edificios = casilla.getDatosedificios();
        float costeTotal = 0;

        switch (tipo.toLowerCase()){
            case "casa":
                costeTotal = datos.getValorCasa();
                if (!jugador.puedePagar(costeTotal)) {
                    System.out.println("A fortuna de " + jugador.getNombre() + " non é suficiente para construír unha casa en " + casilla.getNombre() + ".");
                    return false;
                }
                //Xerar IDs para as nova casa
                String idCasa = generarIdEdificio("casa", jugador.getEdificios());
                jugador.anhadirEdificio(idCasa);
                edificios.setNumCasas(edificios.getNumCasas() + 1);
                break;
            case "hotel":
                costeTotal = datos.getValorHotel();
                if (!jugador.puedePagar(costeTotal)){
                    System.out.println("A fortuna de " + jugador.getNombre() + " non é suficiente para construír un hotel en " + casilla.getNombre() + ".");
                    return false;
                }
                String idHotel = generarIdEdificio("hotel", jugador.getEdificios());
                jugador.anhadirEdificio(idHotel);

                //eliminar as casas
                int casasEliminadas = 0;
                ArrayList<String> edificiosAEliminar = new ArrayList<>();
                for (String id : jugador.getEdificios()) {
                    if (id.startsWith("casa-") && casasEliminadas < 4) {
                        edificiosAEliminar.add(id);
                        casasEliminadas++;
                    }
                }
                for (String id : edificiosAEliminar) {
                    jugador.eliminarEdificio(id); //eliminamos as primeiras 4 casas da lista
                }

                edificios.setNumCasas(0); //eliminamos as casas
                edificios.setNumHoteles(edificios.getNumHoteles() + 1);
                break;
            case "piscina":
                costeTotal = datos.getValorPiscina();
                if (!jugador.puedePagar(costeTotal)) {
                    System.out.println("A fortuna de " + jugador.getNombre() + " non é suficiente para construír unha piscina en " + casilla.getNombre() + ".");
                    return false;
                }
                String idPiscina = generarIdEdificio("piscina", jugador.getEdificios());
                jugador.anhadirEdificio(idPiscina);
                edificios.setNumPiscinas(edificios.getNumPiscinas() + 1);
                break;
            case "pista":
                costeTotal = datos.getValorPista();
                if (!jugador.puedePagar(costeTotal)) {
                    System.out.println("A fortuna de " + jugador.getNombre() + " non é suficiente para construír unha pista de deporte en " + casilla.getNombre() + ".");
                    return false;
                }
                String idPista = generarIdEdificio("pista", jugador.getEdificios());
                jugador.anhadirEdificio(idPista);
                edificios.setNumPistas(edificios.getNumPistas() + 1);
                break;
            default:
                System.out.println("Tipo de edificio descoñecido: " + tipo + ".");
                return false;
        }
        jugador.sumarFortuna(-costeTotal);
        jugador.sumarGastos(costeTotal);
        jugador.sumarInversion(costeTotal);
        edificios.actualizarEstadoEdificios();

        System.out.println("Constrúese un " + tipo + " en " + casilla.getNombre() + ". A fortuna de " + jugador.getNombre() + " é " + (int) jugador.getFortuna() + "€.");
        return true;
    }

    //Metodo para vender edificios nun solar polo seu valor de compra
    public static boolean venderEdificio(Casilla casilla, Jugador jugador, String tipo, int cantidad) {

        //Comprobar que o xogador é o dono da casilla
        if (!casilla.getDuenho().equals(jugador)) {
            System.out.println("Non se pode vender " + casilla.getNombre() + " porque " + jugador.getNombre() + " non é o propietario da casilla.");
            return false;
        }
        DatosSolar datos = obtenerDatos(casilla.getNombre());
        DatosEdificios edificios = casilla.getDatosedificios();
        float ingresoTotal = 0;
        int cantidadVendida = 0;

        switch (tipo.toLowerCase()) {
            case "casa":
                if (edificios.getNumCasas() < cantidad) {
                    System.out.println("Non se poden vender " + cantidad + " casas en " + casilla.getNombre() + " porque só hai " + edificios.getNumCasas() + " casas construídas.");
                    return false;
                }
                ingresoTotal = datos.getValorCasa() * cantidad;
                edificios.setNumCasas(edificios.getNumCasas() - cantidad);
                cantidadVendida = cantidad;

                // Eliminar IDs de casas (eliminar as primeiras 'cantidad' casas da lista)
                int casasEliminadas = 0;
                ArrayList<String> edificiosAEliminar = new ArrayList<>();
                for (String id : jugador.getEdificios()) {
                    if (id.startsWith("casa-") && casasEliminadas < cantidad) {
                        edificiosAEliminar.add(id);
                        casasEliminadas++;
                    }
                }
                for (String id : edificiosAEliminar) {
                    jugador.eliminarEdificio(id);
                }
                break;
            case "hotel":
                if (edificios.getNumHoteles() < 1) {
                    System.out.println("Non se pode vender un hotel en " + casilla.getNombre() + " porque non hai ningún hotel construído.");
                    return false;
                }
                ingresoTotal = datos.getValorHotel();
                edificios.setNumHoteles(edificios.getNumHoteles() - 1);
                cantidadVendida = 1;

                // Eliminar ID do hotel
                for (String id : jugador.getEdificios()) {
                    if (id.startsWith("hotel-")) {
                        jugador.eliminarEdificio(id);
                        break;
                    }
                }
                break;
            case "piscina":
                if (edificios.getNumPiscinas() < 1) {
                    System.out.println("Non se pode vender unha piscina en " + casilla.getNombre() + " porque non hai ningunha piscina construída.");
                    return false;
                }
                ingresoTotal = datos.getValorPiscina();
                edificios.setNumPiscinas(edificios.getNumPiscinas() - 1);
                cantidadVendida = 1;

                // Eliminar ID da piscina
                for (String id : jugador.getEdificios()) {
                    if (id.startsWith("piscina-")) {
                        jugador.eliminarEdificio(id);
                        break;
                    }
                }
                break;
            case "pista":
                if (edificios.getNumPistas() < 1) {
                    System.out.println("Non se pode vender unha pista de deporte en " + casilla.getNombre() + " porque non hai ningunha pista construída.");
                    return false;
                }
                ingresoTotal = datos.getValorPista();
                edificios.setNumPistas(edificios.getNumPistas() - 1);
                cantidadVendida = 1;

                // Eliminar ID de la pista
                for (String id : jugador.getEdificios()) {
                    if (id.startsWith("pista-")) {
                        jugador.eliminarEdificio(id);
                        break;
                    }
                }
                break;
            default:
                System.out.println("Tipo de edificio descoñecido: " + tipo + ".");
                return false;
        }
        jugador.sumarFortuna(ingresoTotal);
        edificios.actualizarEstadoEdificios();
        String mensaje = jugador.getNombre() + " vendéronse " + cantidadVendida + " " + tipo;
        if (cantidadVendida > 1) {
            mensaje += "s";
        }
        mensaje += " en " + casilla.getNombre() + ", recibindo " + (int) ingresoTotal + "€.";

        if ("casa".equalsIgnoreCase(tipo) && edificios.getNumCasas() > 0) {
            mensaje += " Na propiedade queda " + edificios.getNumCasas() + " casa(s).";
        }

        System.out.println(mensaje);
        return true;
    }

    public static String generarIdEdificio(String tipo, ArrayList<String> idsExistentes) {
        Random rand = new Random();
        String nuevoId;
        boolean idValido;

        do {
            // Xenerar número entre 1-1000
            int numero = rand.nextInt(1000) + 1;
            nuevoId = tipo.toLowerCase() + "-" + numero;

            // Comprobar que o ID non estea en uso
            idValido = !idsExistentes.contains(nuevoId) && !idsEdificios.contains(nuevoId);
            if (idValido) {
                idsEdificios.add(nuevoId); // Engadir o novo ID á lista global
            }
        } while (!idValido);

        return nuevoId;
    }

    //Metodo para obter a información dun edificio
    public static String generarInfoEdificio (String id, Jugador propietario, Casilla casilla, float coste) {
        return "{\n" +
                "id: " + id + ",\n" +
                "propietario: " + propietario.getNombre() + ",\n" +
                "casilla: " + casilla.getNombre() + ",\n" +
                "grupo: " + (casilla.getGrupo() != null ? casilla.getGrupo().getColorGrupo() : "-") + ",\n" +
                "coste: " + (int)coste + "\n" +
                "}";
    }
}